import { LightningElement, api, wire } from 'lwc';

//CEAS-82941 Changes
import { EnclosingTabId, getTabInfo, openSubtab, setTabIcon, refreshTab, setTabLabel} from 'lightning/platformWorkspaceApi';

//Import Apex Controller methods
import fetchGCComplaintSummary from '@salesforce/apexContinuation/GCAppealsController_ACE.fetchGCComplaintSummary';

import ViewBenefits_ViewAll_ACE from '@salesforce/label/c.ViewBenefits_ViewAll_ACE';
import BaseLWC from 'c/baseLWCFunctions_CF';

export default class LwcAppealsSummarySubtabs_ACE extends LightningElement {
    //CEAS-82941 Changes
    @wire(EnclosingTabId) enclosingTabId;

    label = {
        ViewBenefits_ViewAll_ACE        
    };

    @api boolShowSpinnerGC = false;
    @api boolNoRecordsGC = false;
    @api boolAPIError = false;
    @api strSubscriberId = '';
    @api tabId; //CEAS-77880
    //CEAS-84459 AutoDoc Appeals
    @api recordId;
    objCatchError;
  

    //Table Data
    @api lstGCAppealsData = [];
    @api objGCAppealsSettings = {};

    connectedCallback() {

        this.boolShowSpinnerGC = true;

        //Table Settings
        this.objGCAppealsSettings = {
            pageSize: 5,
            restrictedPageSize: 5,
            boolViewMore: false,
            columnsData: [
                { label: 'Appeal Type', fieldName: 'strAppealType', sortable: true, type: '' },
                { label: 'Appeal Creation Date', fieldName: 'strAppealCreationDate', sortable: true, boolInitSort: true, type: '' },
                { label: 'Compliance Due Date', fieldName: 'strComplianceDueDate', sortable: true, type: '' },
                { label: 'Appeal Status', fieldName: 'strAppealStatus', sortable: true, type: '' },
                { label: 'Complaint Class', fieldName: 'strComplaintClass', sortable: true, boolAsc: false, type: '' },
                { label: 'Appeal ID', fieldName: 'strAppealID', sortable: true, type: '' }
            ],
            boolShowFilter: false,
            boolSecondaryTable: false,
            boolPagination: false,
            boolShowSearch: false,
            boolShowSearchLabel: false,
            searchPlaceholder : 'Search Text',
            boolShowCheckbox : false,
            boolShowHeader : false,
            boolPaginationwithSize : false
        }

        this.fetchData();
    }

    @api
    fetchData() {

        if (!this.strSubscriberId) {
            return;
        }

        let jasonreqbody = '{"strSubscriberid": "'+ (this.strSubscriberId * 1).toString() + '"}';

        this.boolShowSpinnerGC = true;
        this.boolAPIError = false;
        this.lstGCAppealsData = [];

        fetchGCComplaintSummary({
            strDataJSON: jasonreqbody
        }).then(objResult => {
                
                var lstAppealsGC = [];

                const lstData=JSON.parse(objResult);
                for(let i=0;i<lstData.length;i++) {
                    const obj={...lstData[i]};
                    lstAppealsGC.push(obj);
                } 

                if (!lstAppealsGC.length)
                {
                    this.boolNoRecordsGC = true;
                } else {

                    //Format Data
                    lstAppealsGC = this.formatData(lstAppealsGC);

                    //Sort Array
                    lstAppealsGC.sort((a, b) => {
                        if (a.strAppealCreationDate !== '' && b.strAppealCreationDate !== ''){
                            const dateTime1 = Date.parse(a.strAppealCreationDate);
                            const dateTime2 = Date.parse(b.strAppealCreationDate);
                            
                            if (dateTime1 > dateTime2) {
                                return -1;
                            } else if (dateTime1 < dateTime2) {
                                return 1;
                            }
                            else {
                                return 0;
                            }
                        }
                        else if (a.strAppealCreationDate !== '') {
                            return -1;
                        } else if (b.strAppealCreationDate !== '') {
                            return 1;
                        } else {
                            return 0;
                        }
                      });

                    //Only first 5 records
                    lstAppealsGC = lstAppealsGC.slice(0, 5)

                    this.lstGCAppealsData = lstAppealsGC;
                    this.boolNoRecordsGC = false;
                }

                this.boolShowSpinnerGC = false;
                    
        }).catch(error => {
            this.boolShowSpinnerGC = false;
            this.boolAPIError = true;
        });
    }

    convertDateFormat(strDateTime) {
        var finalDate = '';
        if(strDateTime) {
            const dateTimeArray = strDateTime.split("T");
            var strDate = dateTimeArray[0].toString();
            var strDateSplit =strDate.split("-");
            finalDate = strDateSplit[1]+"/"+strDateSplit[2]+"/"+strDateSplit[0];
        }

        return finalDate;
    }

    formatData(objData) {
        for (let i = 0; i < objData.length; i++){
                const strAppealID = `<a data-strAppealID=${objData[i]['strAppealID']} href='javascript:void(0);'>${objData[i]['strAppealID']}</a>`;
                objData[i].strAppealID = {
                        value: objData[i]['strAppealID'],
                        subtabRecordID: objData[i]['Id'],
                        wrapper: strAppealID,
                        url: 'Test'
                };
                objData[i].strAppealCreationDate = this.convertDateFormat(objData[i].strAppealCreationDate);
                objData[i].strComplianceDueDate = this.convertDateFormat(objData[i].strComplianceDueDate);
        }

        return objData;
    }

    /**
         * Actions for Table Elements
         *
         * @param objEvent Event Object
         */
    handleRowAction(objEvent){
        const rowData = JSON.parse(objEvent.detail);
        this.openAppealDetails(rowData.activeColumnData.value.value);
    }

    openAppealDetails = (strAppealId) => {
        const strEncodedAppealId = btoa('?appealId=' + strAppealId + '&accountId=' + this.recordId);
        const strFlexiPageName = 'ViewGCAppealDetails_FlexiPage_ACE';
        const strIconName = 'standard:work_plan';
        let objPageReference;
        objPageReference = {
            "type": "standard__navItemPage",
            "attributes": {
                "apiName": strFlexiPageName,
                "uid": strAppealId
            },
            "state": {
                "c__BaseURLParam": strEncodedAppealId
            }
        };

        //CEAS-82941 Changes
        if (!this.enclosingTabId) {
            return;
        }
        getTabInfo(this.enclosingTabId).then((tabInformation) => {
            const tabInfo = tabInformation;
            const primaryTabId = tabInfo.isSubtab ? tabInfo.parentTabId : tabInfo.tabId;
            openSubtab(primaryTabId, { pageReference: objPageReference, focus: true}).then((response) => {
                localStorage.strBypassCustomRefreshLogic = "true";
                const focusedSubTabId = response;
                setTabIcon(focusedSubTabId,strIconName,strFlexiPageName);
                refreshTab(focusedSubTabId);
                setTabLabel(focusedSubTabId, strAppealId);
            }).catch(function(error) {
                this.handleErrors(error);
            }); 
            
        }).catch((error) => {
            this.handleErrors(error);
        });
    }

    handleErrors(error) {
      this.objCatchError = error;
    }

    viewAll(){        
        // Navigate to the TMG Pended Claims history view.
        const strUrl=location.origin+'/lightning/n/GC_Appeals_History_FlexiPage_ACE';
        //CEAS-84459 AutoDoc Appeals
        const strEncodedParams = BaseLWC.helperBaseEncodeUrl('?acccountId=' +  this.recordId);
        if (!this.enclosingTabId) {
            return;
        }
        getTabInfo(this.enclosingTabId).then((tabInformation) => {
            const tabInfo = tabInformation;
            const primaryTabId = tabInfo.isSubtab ? tabInfo.parentTabId : tabInfo.tabId;
            //CEAS-84459 AutoDoc Appeals
            openSubtab(primaryTabId, { url: strUrl + strEncodedParams, focus: true, icon : 'standard:work_plan',label : "GUIDING CARE APPEAL HISTORY"});
            
        }).catch((error) => {
            this.handleErrors(error);
        });
    }
    

    
}