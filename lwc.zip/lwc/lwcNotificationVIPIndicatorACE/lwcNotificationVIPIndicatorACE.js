import { LightningElement,track,api,wire } from 'lwc';
import integrationErrMes from '@salesforce/label/c.IntegrationFailMessage_ACE';
import vendorManagmnt from '@salesforce/label/c.NotificationPreferences_VendorManagementTitle_ACE';
import accoladLabel from '@salesforce/label/c.NotificationPreferences_AccoladeLabel_ACE';
import accoladeOptOut from '@salesforce/label/c.NotificationPreferences_AccoladeOptOut_ACE';
import accoladeOptIn from '@salesforce/label/c.NotificationPreferences_AccoladeOptIn_ACE';
import Government_Medicare_Sup_Label_ACE from '@salesforce/label/c.Government_Medicare_Sup_Label_ACE';
import HideComponentsByLOB from '@salesforce/label/c.HideComponentsByLOB_ACE';
import CustomerAdvocateSpecialist_Profile_ACE from '@salesforce/label/c.CustomerAdvocateSpecialist_Profile_ACE';
import Supervisor_Profile_ACE from '@salesforce/label/c.Supervisor_Profile_ACE';
import BusinessAdministrator_Profile_ACE from '@salesforce/label/c.BusinessAdministrator_Profile_ACE';
import System_Administrator_profile_ACE from '@salesforce/label/c.System_Administrator_profile_ACE';
import strChatUserProfileName from '@salesforce/label/c.ChatUser_Profile_ACE';
import strClinicianProfileName from '@salesforce/label/c.Clinician_Profile_ACE';
import strInventoryManagerProfileName from '@salesforce/label/c.InventoryManager_Profile_ACE';
import strStandardProfileName from '@salesforce/label/c.Standard_Profile_ACE';



import fetchAccountPolicies from "@salesforce/apex/NotificationPrefLWCController_ACE.fetchAccountPoliciesLWC";
import saveVIPIndicator from "@salesforce/apex/NotificationPrefLWCController_ACE.saveVipIndicatorLWC";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import ProfileName from '@salesforce/schema/User.Profile.Name';
import USER_ID from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi';
import BaseLWC from "c/baseLWCFunctions_CF";
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';

//Import Messaging Channel.
import {
    publish,
    MessageContext
} from 'lightning/messageService';
import bridgeHelper from '@salesforce/messageChannel/LWCAuraVFBridgeHelper__c';




export default class LwcNotificationVIPIndicatorACE extends LightningElement {

    Label = {
        integrationErrMes,
        vendorManagmnt,
        accoladLabel,
        accoladeOptOut,
        accoladeOptIn,
        Government_Medicare_Sup_Label_ACE,
        HideComponentsByLOB,
        CustomerAdvocateSpecialist_Profile_ACE,
        Supervisor_Profile_ACE,
        BusinessAdministrator_Profile_ACE,
        System_Administrator_profile_ACE,
        strChatUserProfileName,
        strClinicianProfileName,
        strInventoryManagerProfileName,
        strStandardProfileName
    };

    @api profileName ;
    @api objplandetails ;
    

    strLOB;
    objFamilyDetails;
    
    
    plandetail ;

    @wire(getRecord, { recordId: USER_ID, fields: [ProfileName] })
    wireUserData({ error, data }) {
        if (data) {
            this.profileName = data.fields.Profile.value.fields.Name.value;
        } else if (error) {

        }
    }

    
    //Wire functions
    @wire(MessageContext)
    messageContext;

    @wire(EnclosingTabId) enclosingTabId;



    // Show Toast
    @track strToastType = 'success';
	@track strToastMessage;
	@track messageIsHtml = false;
	@track showVIPToastBar = false;
    @track showVMToastBar = false;
	@api autoCloseTime = 5000;
	@track strToastIcon = '';
    @track compName;



    // VIP
    strErrorMessage ="";
    boolError= false;
    @track showVIPCard = false;
    @track strRelation;
    @track boolVIPChecked= false;
    @track boolVIPToggleDisabled = false;
    @track boolVIPSaveDisabled = false;
    @track showVIPSpinner = true;
    boolVIPRefresh = false;
    @track boolInitVIPToggle ;


    //
    strSubMemberId='';
    keyForAccountPoliciesData ='';
    @track showVMCard = false;
    @track strRelation;
    @track boolVMChecked= false;
    @track boolVMToggleDisabled = true;
    @track boolVMSaveDisabled = true;
    @track showVMSpinner = true;
    boolVMRefresh = false;
    boolVMError = false;
    @track boolInitVMToggle ;

    
    //Tab fields
    objTabData;
    strBaseCurrentTabId;
    strBaseCurrentTabUrl;
    boolBaseIsItSubTab;
    strBaseCurrentParentTabId;

    @track isVIPRefresh = false;


    async handleVIPSave(){
        
        this.showVIPSpinner = true;
        
        let listOffamily = this.plandetail.lstFamilyDetails;
        
        let listOffamilydata = this.objFamilyDetails;
        var mapOfMids = {};
        var mapOfMidsVIp = {};
        let keyForMAp = '';
        let boolvipIndicator = '';
        let strMarketSegment = this.plandetail.objSelectedPlanDetails.objViewEmployerGroupWrapper.strMarketSegment;
        let boolIsAccountAPIAvailable = this.plandetail.objSelectedPlanDetails.objViewEmployerGroupWrapper.boolIsAccountAPIAvailable;
        let listOfMids = [];
        let strGroup = this.plandetail.objSelectedPlanDetails.strGroupNumber;
        let strCorp = this.plandetail.objSelectedPlanDetails.strCorporationCode;
        let strSub = this.plandetail.objSelectedPlanDetails.strSubscriberId;
        let keyForAccountPolicies =strSub+ strGroup + strCorp  ;
        for (let i = 0; i < listOffamily.length; i++) {
            listOfMids.push(listOffamily[i].strMemberId);
        }

        for (let i = 0; i < listOffamilydata.length; i++) {
            keyForMAp = listOffamilydata[i].strMemberId;
            boolvipIndicator = listOffamilydata[i].boolVIPIndicator;
            mapOfMidsVIp[keyForMAp] = boolvipIndicator;
        }

        return new Promise(async (resolve, reject) =>{ 
            try {
                let result = await saveVIPIndicator({ listOfMids: JSON.stringify(listOfMids), strMarketSegment : strMarketSegment, keyForAccountPolicies:keyForAccountPolicies, boolIsAccountAPIAvailable:boolIsAccountAPIAvailable,
                    boolVipChecked: this.boolVIPChecked, boolVendorChecked: false});
                this.showToastLocal('success','Changes successfully updated','utility:success',9000,'VIP');
                this.boolInitVIPToggle = this.boolVIPChecked;
            } catch(e){
                //Do Nothing
            }
            this.showVIPSpinner = false;   
            this.boolVIPSaveDisabled = false;         
            let key = 'vipIndicator_' + strSub   + strGroup + strCorp ;
            
            const localStorageData = {
                "key": key,
                "newValue": String(this.boolVIPChecked),
                "oldValue": null
            };
            this.postMessageHelper(localStorageData, false, true, 'postMessageData');
        });        
        
    }

    /**
     * Used to post message to local storage using messaging channel.
     */
    postMessageHelper(objDataToBeSent, boolLocalStorage, boolPostMessage, strDestinationId) {
        try {
            const objParameterData = {
                strDestinationId: strDestinationId,
                objMessage: objDataToBeSent
            };
            const objPayload = {
                bridgeMessageData: objParameterData
            };
            if(this.messageContext !== undefined && this.messageContext !== null){
                publish(this.messageContext, bridgeHelper, objPayload);
            }
        } catch (exception) {
            //No handling Needed.
        }

    }



    get getIconName() {
		if (this.strToastIcon) {
			return this.strToastIcon;
		}
		return 'utility:' + this.strToastType;
	}
    get outerClass() {
		return 'slds-notify slds-notify_toast slds-theme_' + this.strToastType;
	}
    get innerClass() {
		return 'slds-icon_container slds-icon-utility-' + this.strToastType + ' slds-m-right_small slds-no-flex slds-align-top' +' toastIconSuccess';
	}

    showToastLocal(strToastType, strToastMessage, strToastIcon, time, compName) {
		this.strToastType = strToastType;
		this.strToastMessage = strToastMessage;
		this.strToastIcon = strToastIcon;
		this.autoCloseTime = time;
        if(compName == 'VIP'){
            this.showVIPToastBar = true;
        }else {
            this.showVMToastBar = true;
        }
		setTimeout(() => {
			this.closeToastMessage(compName);
		}, this.autoCloseTime);
	}
	closeToastMessage(compName) {
        if(compName == 'VIP'){
            this.showVIPToastBar = false;
        }else {
            this.showVMToastBar = false;
        }
		
	}
    closeToastMessageVIP() {        
        this.showVIPToastBar = false;        
		
	}
    closeToastMessageVM() {        
        this.showVMToastBar = false;        
		
	}

    handleVMToggle(event){
        if(event.target.checked){ 
            this.boolVMChecked = true;
        } else {
            this.boolVMChecked = false;
        }

    }

    handleVIPToogleChange(event){
        if(event.target.checked){ 
            this.boolVIPChecked = true;
        } else {
            this.boolVIPChecked = false;
        }

       
        
    }

    

    handleVIPRefresh(){
        this.showVIPSpinner = true;
        setTimeout(() => { // Refresh function is showing existing value but spins for 1 ms
			this.onPlanLoadDetails('', this.objplandetails);
            this.showVIPSpinner = false;
		}, 2000);       
        
    }

    onPlanLoadDetails(strMarketSegmentdat, objplandetails) {

        if(strMarketSegmentdat && strMarketSegmentdat != undefined && strMarketSegmentdat !== ''){
            if ( strMarketSegmentdat.boolIsLargeGroup) {
                this.boolVIPChecked = strMarketSegmentdat.boolVipIndicatorForLarge;
                this.boolVIPToggleDisabled = false;
                //this.boolVIPSaveDisabled = true;
            } else {
                this.boolVIPChecked = strMarketSegmentdat.boolVipIndicatorForSmall;
                this.boolVIPToggleDisabled = true;
                this.boolVIPSaveDisabled = true;    
            }
        }

    }


    isHideVIPCard(){
        this.strLOB = this.strLOB.toLowerCase();
        let strRelation  = this.strRelation;  

        if (strRelation && strRelation !== 'SUB') {
            return true;
        } else if ( this.strLOB === 'retail'|| this.strLOB === this.Label.Government_Medicare_Sup_Label_ACE.toLowerCase()) {
            return true;
        } else if (this.Label.HideComponentsByLOB.toLowerCase().includes(this.strLOB)) {
            return true;
        } else if (this.strLOB !== 'retail' && this.isSpecialistOrHigherProfile()) {
            return false;
        } else {
            return false;
        }
    }

    isSpecialistOrHigherProfile() {

        if( this.profileName == this.Label.CustomerAdvocateSpecialist_Profile_ACE || 
            this.profileName == this.Label.Supervisor_Profile_ACE || 
            this.profileName == this.Label.BusinessAdministrator_Profile_ACE || 
            this.profileName == this.Label.System_Administrator_profile_ACE) {
                return true;
        } else {
            return false;
        }
                    
    }

    connectedCallback(){
        this.loadCards(this.objplandetails);
        this.fetchTabData();       
    }

    @api loadCards( objPlanData ){
        if(this.objplandetails && this.objplandetails !== 'undefined' && this.objplandetails !== null && this.objplandetails !== ''){
            this.plandetail = JSON.parse(JSON.stringify(this.objplandetails));
            if(this.plandetail.lstFamilyDetails){
                this.objFamilyDetails = JSON.parse(JSON.stringify(this.plandetail.lstFamilyDetails));
            }
            this.strRelation = this.plandetail.objSelectedPlanDetails.strRelationshipTypeCode;
            this.strLOB =  this.plandetail.objSelectedPlanDetails.strAceLineOfBusiness;
            if (this.isHideVIPCard()) { 
                this.showVIPCard = false;
            } else {
                
                if (this.strLOB.toUpperCase() !== 'RETAIL' && (this.profileName == this.Label.CustomerAdvocateSpecialist_Profile_ACE || this.profileName == this.Label.Supervisor_Profile_ACE || this.profileName == this.Label.BusinessAdministrator_Profile_ACE || this.profileName == this.Label.System_Administrator_profile_ACE)) { 

                    this.showVIPCard = true;
                    
                    let strMarketSegmentdat = this.plandetail.strMarketSegmentData;
                    if (strMarketSegmentdat !== undefined && strMarketSegmentdat !== null && strMarketSegmentdat !== '') {
                        this.onPlanLoadDetails(strMarketSegmentdat, this.objplandetails);
                    }
                    
                    this.boolInitVIPToggle = this.boolVIPChecked;
                    if (this.objFamilyDetails == null || this.objFamilyDetails == undefined) {
                        this.showVIPSpinner = true;
                    } else{
                        this.showVIPSpinner = false;
                    }
                    
                }
                        
            }

            // Vendor management Card
            let strGroup = this.plandetail.objSelectedPlanDetails.strGroupNumber;
            let strCorp = this.plandetail.objSelectedPlanDetails.strCorporationCode;
            let strSub = this.plandetail.objSelectedPlanDetails.strSubscriberId;
            this.keyForAccountPoliciesData =strSub+ strGroup + strCorp;
            let listOffamily = this.plandetail.lstFamilyDetails;
            for (let i = 0; i < listOffamily.length; i++) {
                if (listOffamily[i].strRelation === 'Subscriber') {
                        this.strSubMemberId = listOffamily[i].strMemberId;
                }
            }
            this.getAccountPolicyDataforVendorMangement(this.keyForAccountPoliciesData,this.strSubMemberId);
            this.boolInitVMToggle = this.boolVMChecked;
            if (this.plandetail.objSelectedPlanDetails.strRelationshipTypeCode === 'SUB'
                    && ((this.plandetail.objSelectedPlanDetails.strAccountNumber == '028110' && (this.profileName == this.Label.CustomerAdvocateSpecialist_Profile_ACE || this.profileName == this.Label.Supervisor_Profile_ACE || this.profileName == this.Label.BusinessAdministrator_Profile_ACE || this.profileName == this.Label.System_Administrator_profile_ACE)) ||
                    (this.plandetail.objSelectedPlanDetails.strAccountNumber =='166275' && (this.profileName == this.Label.CustomerAdvocateSpecialist_Profile_ACE || this.profileName == "Developer" || this.profileName == this.Label.Supervisor_Profile_ACE || this.profileName == this.Label.BusinessAdministrator_Profile_ACE || this.profileName == this.Label.System_Administrator_profile_ACE || this.profileName == this.Label.strChatUserProfileName || this.profileName == this.Label.strClinicianProfileName || this.profileName == this.Label.strInventoryManagerProfileName || this.profileName == this.Label.strStandardProfileName))
                        )) {
                        
                        this.showVMCard = true;  
                        this.showVMSpinner = false;

                        if(this.plandetail.objSelectedPlanDetails.strEnrollmentStatus === "Inactive") {                            
                            this.boolVMToggleDisabled = true;
                            this.boolVMSaveDisabled = true;
                        } else if (this.plandetail.objSelectedPlanDetails.strEnrollmentStatus === "Active"){
                            this.boolVMToggleDisabled = false;
                            this.boolVMSaveDisabled = false;
                        }

                    } else {
                        this.showVMCard = false;  
                        this.showVMSpinner = false;

                    }                                   


        } else {
            this.boolError = true;
            this.boolVMError = true;
        }
    }


    async getAccountPolicyDataforVendorMangement(keyForAccountPoliciesData,strSubMemberId) {

        if(keyForAccountPoliciesData != ''&& keyForAccountPoliciesData != undefined) {
           
            return new Promise(async (resolve, reject) =>{            
                
                try{
                    let result = await fetchAccountPolicies({ keyForAccountPolicies: keyForAccountPoliciesData,strSubMemberId : strSubMemberId});
                
                    var objResult = JSON.parse(result.replace(/(&quot\;)/g,"\""));
                    let boolOptedOut = false;
                    if(objResult.length > 0){
                        boolOptedOut = objResult[0].Accolade_ACE__c;
                    }
                    if(boolOptedOut) {     
                        this.boolVMChecked = true;                  
                    } else {
                        this.boolVMChecked = false;
                    }
                    this.boolInitVMToggle = this.boolVMChecked;
                    
                    this.showVMSpinner = false;
                }catch( error){
                    // DO nothing
                }                   
                this.showVMSpinner = false;                    
                
            });
            
        }
    }

    handleVMRefresh(){
        this.showVMSpinner = true;
        this.getAccountPolicyDataforVendorMangement(this.keyForAccountPoliciesData,this.strSubMemberId);
        
    }

    async handleVMSave(){

        this.showVMSpinner = true;        
        let listOffamily = this.plandetail.lstFamilyDetails;
        var mapOfMids = {};
        var mapOfMidsVIp = {};
        let keyForMAp = '';
        let boolvipIndicator = '';
        let listOfMids = [];
        let strGroup = this.plandetail.objSelectedPlanDetails.strGroupNumber;
        let strCorp = this.plandetail.objSelectedPlanDetails.strCorporationCode;
        let strSub = this.plandetail.objSelectedPlanDetails.strSubscriberId;
        let keyForAccountPolicies =strSub+ strGroup + strCorp  ;
        for (let i = 0; i < listOffamily.length; i++) {
            listOfMids.push(listOffamily[i].strMemberId);
        }
        
        return new Promise(async (resolve, reject) =>{
            try{
                let result = await saveVIPIndicator({ listOfMids: JSON.stringify(listOfMids), strMarketSegment : null, keyForAccountPolicies:keyForAccountPolicies, boolIsAccountAPIAvailable:false,
                            boolVipChecked: false, boolVendorChecked: this.boolVMChecked});
                
                this.boolInitVMToggle = this.boolVMChecked;
                const objParameter = {
                    'boolAccoladeOptout':  this.boolVMChecked,
                    'strGlobalMid': this.plandetail.objSelectedPlanDetails.strMemberId
                };
                if(BaseLWC.stringIsNotBlank(this.strBaseCurrentTabId)) {
                    BaseLWC.helperBasePostTabIdMessageCustomEvents('TriggerHIPPAAccoladeBadge', null, objParameter, 'HIPPAAAccoladeIndicator_ACE', this.strBaseCurrentTabId).catch(() => {
                        /*Do nothing*/
                    });
                }

                this.showToastLocal('success','Changes successfully updated','utility:success',9000,'VM');
            }catch( error){

            }
               
            this.showVMSpinner = false;                

        });

    }


    
    /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     * 
     */
    fetchTabData = () => {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
                this.processTabData(objTabData);
            })
            .catch((error) => {
            });
        }
    };

    processTabData = (objTabData) => {
        try {
            this.objTabData = objTabData;
            this.strBaseCurrentTabId = this.objTabData.tabId;
            this.strBaseCurrentTabUrl = this.objTabData.url;
            this.boolBaseIsItSubTab = this.objTabData.isSubtab;
            if (this.boolBaseIsItSubTab === true) {
                this.strBaseCurrentParentTabId = this.objTabData.parentTabId;
            } else {
                this.strBaseCurrentParentTabId = this.objTabData.tabId;
            }            
        } catch (error) {
            //
        }
    };

    
}