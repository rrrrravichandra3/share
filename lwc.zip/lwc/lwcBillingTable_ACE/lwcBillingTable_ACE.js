import { LightningElement,api,track, wire } from 'lwc';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
import getBillingDetails from '@salesforce/apexContinuation/ViewBillingInformationController_ACE.fetchBillingDetails';
import ViewPlanSummary_CardHeader_Refresh_ACE from "@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE";
import Message_warning_ACE from "@salesforce/label/c.MessageLightningComponent_Warning_ACE";
import SafeMode_ToastMessage_ACE from "@salesforce/label/c.SafeMode_ToastMessage_ACE";
import IntegrationFailMessage_ACE from "@salesforce/label/c.FacetsNotesAPIErrorMessage_ACE";
import ViewBillingHeader_ACE from "@salesforce/label/c.ViewBillingHeader_ACE";
import Message_error_ACE from "@salesforce/label/c.Message_error_ACE";
import HCSCClaimsStaticResource_ACE from "@salesforce/resourceUrl/HCSCClaimsStaticResource_ACE";
import safeModeUserData from "@salesforce/apex/SafeModeController_ACE.fetchUserDetails";
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
export default class LwcBillingTableACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    imageSource =
        HCSCClaimsStaticResource_ACE + "/Images/Rendering_Provider_Information.svg";
    infoImageURL = HCSCClaimsStaticResource_ACE + "/Images/info.png";
    label = {
        ViewPlanSummary_CardHeader_Refresh_ACE,
        Message_warning_ACE,
        SafeMode_ToastMessage_ACE,
        IntegrationFailMessage_ACE,
        Message_error_ACE,
        ViewBillingHeader_ACE,
        EnableVPSTabSpecificEvents_ACE
    };
    boolVPSTabSpecificEvents
    strBaseCurrentParentTabId
    boolShowTable = false;
    @api lstTableData = [];
    objTabData = {};
    boolError=false;
    objAPIResponse={};
    response_BillingInfo ={};
    billingInformation={};
    selectBillingValue = 'Billing Summary';
    boolShowSpinner = true;
    boolShowSafeMode = false;
    boolAPIError = false;
    boolPaymentMethod = false;
    boolPaymentHistory = false;
    boolBillingSummary = false;
    boolBankingInformation = false;
    @api creditoverpayment;
    facetsGroupId ='';
    subscriberId ='';
    boolPlanSummaryData = false;
    PlanSummaryData={};
    strProductInfo = 'Product Information';
     //Table Data
    @api lstPaymentMethodData = [];
    @api lstBankingInformationData = [];
    @api lstBillingSummaryData = [];
    @api lstPaymentHistoryData = [];
    @track lstBillingInfoData = [];
    //Header Info Variables
    @api strProcessingStatus = 'N/A';
    @api strNetAmountDue = 'N/A';
    @api strSuspendBilling = 'N/A';
    @api strCredit_overpayment = 'N/A';
    // Constant Declarations
    constPicklistOptions = {
        bankingInformation : 'Banking Information',
        billingSummary : 'Billing Summary',
        paymentHistory : 'Payment History',
        paymentMethod : 'Payment Method',
        billingInformation : 'Billing Information'
    }
    get billingTypeOptions() {
        return [
            { label: 'Banking Information', value: 'Banking Information' },
            { label: 'Billing Summary', value: 'Billing Summary' },
            { label: 'Payment History', value: 'Payment History' },
            { label: 'Payment Method', value: 'Payment Method' },
        ];
    }
    //Table Settings
    objPaymentMethodSetting = {
        pageSize: 25,
        showPagination : true,
        pageMenu : [25,50,75,100],
        boolViewMore: false,
        columnsData: [
            { label: 'EFFECTIVE DATE', fieldName: 'effectiveDate', sortable: false, type: 'date' },
            { label: 'TERMINATION DATE', fieldName: 'terminationDate', sortable: false, type: 'date' },
            { label: 'PAYMENT METHOD', fieldName: 'paymentMethod', sortable: false, type: 'text' },
            { label: 'BILLING CYCLE', fieldName: 'billingCycle', sortable: false, type: 'text' }
        ],
        boolSecondaryTable: false,
        boolShowFilter: true,
        boolPagination: true,
        boolShowSearch:true,
        searchPlaceholder : 'Search Text',
        boolHasSearchandFilterCustomMargins: true,
        objSearchandFilterCustomMargins:{
            top: "0.75rem",
            bottom: "0",
            right: "0",
            left: "13rem"
        },
        filterData : [
            {strType : '', intCol : -1, strFilterName : 'Select a value'},
            {strType : 'date', intCol : 1, strFilterName : 'EFFECTIVE DATE'},
            {strType : 'date', intCol : 2, strFilterName : 'TERMINATION DATE'},
            {strType : 'text', intCol : 3, strFilterName : 'PAYMENT METHOD'},
            {strType : 'text', intCol : 4, strFilterName : 'BILLING CYCLE'}
        ],
        boolShowCheckbox : false,
        boolShowHeader : false,
        boolShowSearchLabel: false,
        restrictedPageSize : false,
        boolPaginationwithSize:true
    };
    objBankingInformationSetting = {
        pageSize: 25,
        showPagination : true,
        pageMenu : [25,50,75,100],
        boolViewMore: false,
        columnsData: [
            { label: 'EFFECTIVE DATE', fieldName: 'effectiveDate', sortable: false, type: 'date' },
            { label: 'TERMINATION DATE', fieldName: 'terminationDate', sortable: false, type: 'date' },
            { label: 'BANK ROUTING NUMBER', fieldName: 'bankRoutingNumber', sortable: false, type: 'text' },
            { label: 'BANK NAME', fieldName: 'bankName', sortable: false, type: 'text' },
            { label: 'ACCOUNT NAME', fieldName: 'accountName', sortable: false, type: 'text' },
            { label: 'ACCOUNT NUMBER', fieldName: 'accountNumber', sortable: false, type: 'text' },
            { label: 'ACCOUNT TYPE', fieldName: 'accountType', sortable: false, type: 'text' },
            { label: 'AUTHORIZATION ON FILE', fieldName: 'authorizationOnFile', sortable: false, type: 'text' },
        ],
        boolSecondaryTable: false,
        boolShowFilter: true,
        boolPagination: true,
        boolShowSearch:true,
        searchPlaceholder : 'Search Text',
        boolHasSearchandFilterCustomMargins: true,
        objSearchandFilterCustomMargins:{
           top: "0.75rem",
            bottom: "0",
            right: "0",
            left: "13rem"
        },
        filterData : [
            {strType : '', intCol : -1, strFilterName : 'Select a value'},
            {strType : 'date', intCol : 1, strFilterName : 'EFFECTIVE DATE'},
            {strType : 'date', intCol : 2, strFilterName : 'TERMINATION DATE'},
            {strType : 'text', intCol : 3, strFilterName : 'BANK ROUTING NUMBER'},
            {strType : 'text', intCol : 4, strFilterName : 'ACCOUNT NAME'},
            {strType : 'text', intCol : 5, strFilterName : 'ACCOUNT NUMBER'},
            {strType : 'text', intCol : 6, strFilterName : 'ACCOUNT TYPE'},
            {strType : 'text', intCol : 7, strFilterName : 'AUTHORIZATION ON FILE'}
        ],
        boolShowCheckbox : false,
        boolShowHeader : false,
        boolShowSearchLabel: false,
        restrictedPageSize : false,
        boolPaginationwithSize:true
    };
    objBillingSummarySetting = {
        pageSize: 25,
        showPagination : true,
        pageMenu : [25,50,75,100],
        boolViewMore: false,
        columnsData: [
            { label: 'DUE DATE', fieldName: 'dueDate', sortable: false, type: 'date' },
            { label: 'END DATE', fieldName: 'endDate', sortable: false, type: 'date' },
            { label: 'CREATED DATE', fieldName: 'createDate', sortable: false, type: 'date' },
            { label: 'BILLED AMOUNT', fieldName: 'billedAmount', sortable: false, type: 'text' },
            { label: 'AMOUNT RECEIVED', fieldName: 'amountReceived', sortable: false, type: 'text' },
            { label: 'PAYMENT STATUS', fieldName: 'paymentStatus', sortable: false, type: 'text' },
            { label: 'DELINQUENCY DATE', fieldName: 'deliquencyDate', sortable: false, type: 'date' },
            { label: 'INVOICE NUMBER', fieldName: 'invoiceNumber', sortable: false, type: 'text' },
            { label: 'BILLING CONTRIVED KEY', fieldName: 'billingContrivedKey', sortable: false, type: 'text' ,boolHidden:true},
            { label: 'INVOICE ID', fieldName: 'invoiceId', sortable: false, type: 'text' ,boolHidden:true},
        ],
        boolShowFilter: true,
        boolPagination: true,
        boolShowSearch:true,
        searchPlaceholder : 'Search Text',
        boolHasSearchandFilterCustomMargins: true,
        objSearchandFilterCustomMargins:{
           top: "0.75rem",
            bottom: "0",
            right: "0",
            left: "13rem"
        },
        filterData : [
            {strType : '', intCol : -1, strFilterName : 'Select a value'},
            {strType : 'date', intCol : 1, strFilterName : 'DUE DATE'},
            {strType : 'date', intCol : 2, strFilterName : 'END DATE'},
            {strType : 'date', intCol : 3, strFilterName : 'CREATED DATE'},
            {strType : 'text', intCol : 4, strFilterName : 'BILLED AMOUNT'},
            {strType : 'text', intCol : 5, strFilterName : 'AMOUNT RECEIVED'},
            {strType : 'text', intCol : 6, strFilterName : 'PAYMENT STATUS'},
            {strType : 'date', intCol : 7, strFilterName : 'DELINQUENCY DATE'},
            {strType : 'text', intCol : 8, strFilterName : 'INVOICE NUMBER'}
        ],
        boolShowCheckbox : false,
        boolShowHeader : false,
        boolShowSearchLabel: false,
        boolSecondaryTable: true,
        restrictedPageSize : false,
        boolPaginationwithSize:true
    };
    objSecondaryTableSettings = {
        pageSize: 25,
        boolViewMore: false,
        columnsData: [
            { label: 'PRODUCT ID', fieldName: 'productId', sortable: false, type: 'text' },
            { label: 'CATEGORY', fieldName: 'category', sortable: false, type: 'text' },
            { label: 'BILLING CHARGE', fieldName: 'billingCharge', sortable: false, type: 'text' },
            { label: 'BILLING AMOUNT', fieldName: 'billedAmount', sortable: false, type: 'text' }
        ],
        boolSecondaryTable: false,
        boolShowFilter: false,
        boolPagination: false,
        boolShowSearch:false,
        boolShowCheckbox : false,
        boolShowHeader : false
    };
    objPaymentHistorySetting = {
        pageSize: 25,
        showPagination : true,
        pageMenu : [25,50,75,100],
        boolViewMore: false,
        columnsData: [
            { label: 'RECEIVED DATE', fieldName: 'receivedDate', sortable: false, type: 'date' },
            { label: 'AMOUNT RECEIVED', fieldName: 'amountReceived', sortable: false, type: 'text' },
            { label: 'CHECK NUMBER', fieldName: 'checkNumber', sortable: false, type: 'text' },
            { label: 'TYPE', fieldName: 'type', sortable: false, type: 'text' },
            { label: 'RECEIPT ID', fieldName: 'receiptId', sortable: false, type: 'text' },
            { label: 'PAYMENT ENTERED DATE', fieldName: 'paymentEnteredDate', sortable: false, type: 'date' },
        ],
        boolSecondaryTable: false,
        boolShowFilter: true,
        boolPagination: true,
        boolShowSearch:true,
        searchPlaceholder : 'Search Text',
        boolHasSearchandFilterCustomMargins: true,
        objSearchandFilterCustomMargins:{
           top: "0.75rem",
            bottom: "0",
            right: "0",
            left: "13rem"
        },
        filterData : [
            {strType : '', intCol : -1, strFilterName : 'Select a value'},
            {strType : 'date', intCol : 1, strFilterName : 'RECEIVED DATE'},
            {strType : 'text', intCol : 2, strFilterName : 'AMOUNT RECEIVED'},
            {strType : 'text', intCol : 3, strFilterName : 'CHECK NUMBER'},
            {strType : 'text', intCol : 4, strFilterName : 'TYPE'},
            {strType : 'text', intCol : 5, strFilterName : 'RECEIPT ID'},
            {strType : 'date', intCol : 6, strFilterName : 'PAYMENT ENTERED DATE'}
        ],
        boolShowCheckbox : false,
        boolShowHeader : false,
        boolShowSearchLabel: false,
        restrictedPageSize : false,
        boolPaginationwithSize:true
    };
    hideOtherBillingTables(strSelectedOption) {
        this.boolPaymentMethod = false;
        this.boolPaymentHistory = false;
        this.boolBillingSummary = false;
        this.boolBankingInformation = false;
        this.fetchBillingTableData(strSelectedOption);
        if(strSelectedOption === this.constPicklistOptions.bankingInformation) {
            this.boolBankingInformation = true;
        }else if(strSelectedOption === this.constPicklistOptions.paymentMethod) {
            this.boolPaymentMethod = true;
        }else if(strSelectedOption === this.constPicklistOptions.paymentHistory) {
            this.boolPaymentHistory = true; 
        }else if(strSelectedOption === this.constPicklistOptions.billingSummary) { 
            this.boolBillingSummary = true;
        } else {
            //Do nothing
        }
        this.selectBillingValue = strSelectedOption;
    }
    //On change method for Billing Type
    handleBillingTypeChange(event) {
        this.selectBillingType =  event.detail.value;
        this.lstTableData =[];
        this.hideOtherBillingTables(this.selectBillingType);        
    }
    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.fetchTabData();
        } catch (error) {
            //Handle Error
        }
    }
    fetchTabData() {
        if (!this.enclosingTabId) {
            return;
        }
        getTabInfo(this.enclosingTabId).then(objTabData => {
            this.objTabData = objTabData;
            //Always add executeInitialFunctionality function which can be reused for refresh.
            if (this.objTabData.isSubtab === true) {
                this.strBaseCurrentParentTabId = this.objTabData.parentTabId;
            } else {
                this.strBaseCurrentParentTabId = this.objTabData.tabId;
            }
            if (BaseLWC.stringIsNotBlank(this.label.EnableVPSTabSpecificEvents_ACE) && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                this.boolVPSTabSpecificEvents = true;
            }
            this.planSummaryListener();
            this.fetchSafeModeUserData();
            this.executeInitialFunctionality();
        }).catch(() => {
            this.handleErrors();
        });
    }
    planSummaryListener() {
        if (this.boolVPSTabSpecificEvents) {
            window.addEventListener(
                "PlanSummaryEvent_" + this.strBaseCurrentParentTabId,
                this.capturePlanSummaryListener
            );
        } else {
            window.addEventListener(
                "PlanSummaryEvent",
                this.capturePlanSummaryListener
            );
        }
    }
    capturePlanSummaryListener = (planSummaryDataEvent) => {
        if (BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail) ) {
            if (this.boolVPSTabSpecificEvents) {
                window.removeEventListener("PlanSummaryEvent_" + this.strBaseCurrentParentTabId,this.capturePlanSummaryListener);
            } else {
                window.removeEventListener("PlanSummaryEvent",this.capturePlanSummaryListener);
            }
            this.PlanSummaryData = JSON.parse(planSummaryDataEvent.detail);
            if(this.PlanSummaryData.strIdDestination === 'PlanCardDetails_ACE') {
                this.boolPlanSummaryData = true;
                this.facetsGroupId = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strFacetsGroupId;
                this.subscriberId = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strSubscriberId;
                this.fetchBillingTableData(this.constPicklistOptions.billingInformation); 
                this.fetchBillingTableData(this.constPicklistOptions.billingSummary);
            }
        }
    };

    executeInitialFunctionality() {
        if (this.objTabData.isSubtab === true) {
            //Always segregate the Main tab and Sub tab functions.
            this.executeSubTabFunctionality();
        } else if (this.objTabData.isSubtab === false) {
            //Always segregate the Main tab and Sub tab functions.
            this.executeMainTabFunctionality();
        } else {
            //Do nothing
        }
    }
    handleErrors(error) {
        this.boolError = error;
    }
    executeMainTabFunctionality() {
        this.boolPrimaryTab = true;
    }
    executeSubTabFunctionality() {
            this.boolPrimaryTab = false;

        }

    fetchBillingTableData(strBillingType) {
        if(this.subscriberId.startsWith('0')) {
            this.subscriberId = this.subscriberId.slice(3);
        }
        getBillingDetails({
            strBillingType: strBillingType,
            strSubId : this.subscriberId,
            strGroupNumber : this.facetsGroupId,
            strinvoiceId : '',
            billingDueDate : '',
            strbillingContrivedKey : ''
        }).then(objResult => {
                this.boolAPIError = false;
                this.boolShowSpinner = false;
                this.objAPIResponse = JSON.parse(objResult.replaceAll("\n",""));
                if(strBillingType === this.constPicklistOptions.billingSummary) {
                    this.lstBillingSummaryData = this.setBillingSummaryData(this.objAPIResponse.billingSummary);
                    this.boolBillingSummary = true;
                } else if (strBillingType === this.constPicklistOptions.bankingInformation) {
                    this.lstBankingInformationData = this.setBankingSummaryData(this.objAPIResponse.bankingInformation);
                }else if (strBillingType === this.constPicklistOptions.paymentMethod) {
                    this.lstPaymentMethodData = this.setPaymentMethodData(this.objAPIResponse.paymentMethod);
                } else if(strBillingType === this.constPicklistOptions.paymentHistory ) {
                    this.lstPaymentHistoryData = this.setPaymentHistoryData(this.objAPIResponse.paymentHistory);
                } else if(strBillingType === this.constPicklistOptions.billingInformation ) {
                    this.setBillingInfoData(this.objAPIResponse.billingInformation);
                } else {
                    //DO Nothing
                }
        }).catch(error => {
            this.boolAPIError = true;
            this.boolShowSpinner = false;
            this.handleErrors(error);
        });
    }
    setBillingInfoData(objAPIResponse) {
        if(objAPIResponse !== null && objAPIResponse!== undefined) {
            this.strProcessingStatus = objAPIResponse[0].processingStatus;
            if(BaseLWC.isNotUndefinedOrNull(objAPIResponse[0].netAmountDue) && !objAPIResponse[0].netAmountDue.includes('.')) {
                this.strNetAmountDue ='$'+ objAPIResponse[0].netAmountDue+'.00';
            }
            this.strSuspendBilling = objAPIResponse[0].suspendBilling;
            if(BaseLWC.isNotUndefinedOrNull(objAPIResponse[0]['credit/overpayment']) && !objAPIResponse[0]['credit/overpayment'].includes('.')) {
                this.strCredit_overpayment ='$'+ objAPIResponse[0]['credit/overpayment']+'.00';
            }
        }
    }
    fetchProductInformation(strinvoiceId,billingDueDate,strbillingContrivedKey) {
        if(this.subscriberId.startsWith('0')) {
            this.subscriberId = this.subscriberId.slice(3);
        }
        getBillingDetails({
            strBillingType: this.strProductInfo,
            strSubId : this.subscriberId,
            strGroupNumber : this.facetsGroupId,
            strinvoiceId : strinvoiceId,
            billingDueDate : billingDueDate,
            strbillingContrivedKey : strbillingContrivedKey
        }).then(objResult => {
                this.boolAPIError = false;
                this.boolShowSpinner = false;
                const objProductInfo = JSON.parse(objResult.replaceAll("\n",""));
                this.setDataforSecondaryTable(objProductInfo.productInformation,strinvoiceId,strbillingContrivedKey);          
        }).catch(error => {
            this.handleErrors(error);
        });
    }
    refreshCard = () => {
        try {
            this.executeInitialFunctionality();
            this.boolShowSpinner = true;
            this.executeInitialFunctionality();
            this.hideOtherBillingTables(this.selectBillingValue);
            this.fetchBillingTableData(this.constPicklistOptions.billingInformation); 
            this.boolShowSpinner = false;
        } catch (error) {
            this.handleErrors(error);
        }
    };
    fetchSafeModeUserData = () => {
        safeModeUserData({}).then((objResult) => {
            if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                this.boolShowSafeMode =
                    objResult.objSafeModeUser.Safe_Mode_Enabled_ACE__c;
                if (this.boolShowSafeMode === true) {
                    this.boolShowSpinner = false;
                } else {
                    //DO Nothing
                }
            } else {
                //Do nothing
            }
        })
            .catch(() => {
                this.boolShowSpinner = false;
            });
    }
    handleRowAction(strRowInstance) {
        let strinvoiceId;
        let billingDueDate ;
        let strbillingContrivedKey; 
        try {
            if (strRowInstance !== null && strRowInstance !== undefined) {
                const eventDetail = JSON.parse(strRowInstance.detail);
                const objRowInstance = JSON.parse(eventDetail.renderedRowData);
                if(objRowInstance !== null && objRowInstance !== undefined) {
                    objRowInstance.forEach(objItr => {
                        if(objItr.key === "invoiceNumber") {
                            strinvoiceId = objItr.value;
                        } else if(objItr.key === "dueDate") {
                            billingDueDate =objItr.value;
                        } else if(objItr.key === "billingContrivedKey") {
                            strbillingContrivedKey = objItr.value;
                        } else {
                            //do nothing
                        }
                    });
                    if(eventDetail !== null && eventDetail !== undefined && eventDetail.isExpanded === true) {
                        this.fetchProductInformation(strinvoiceId,billingDueDate,strbillingContrivedKey);
                    }
                }
            }
        } catch (error) {
            this.handleErrors();
        }
    }
    setDataforSecondaryTable (objAPIResponse,strinvoiceId,strbillingContrivedKey) {
        const strAA = '{"productInformation":[{"productId":"abc","category":"abc","billingCharge":"Monthly","billedAmount":"0"},{"productId":"ILH0C006","category":"PC02","billingCharge":"Monthly","billedAmount":"0"},{"productId":"ILH0C006","category":"PD02","billingCharge":"Monthly","billedAmount":"0"}]}';
        const lstBillingTableData = this.lstBillingSummaryData;
        const objUpdatedData = objAPIResponse;
        if(lstBillingTableData !== null && lstBillingTableData !== undefined && objUpdatedData !== null && objUpdatedData !== undefined) {
            try{
                lstBillingTableData.forEach(objItr => {
                    if(objItr['invoiceNumber'] === strinvoiceId && objItr['billingContrivedKey' ] === strbillingContrivedKey) {
                        //Temp Code
                        if(objAPIResponse !== null && objAPIResponse !== undefined) {   
                            objItr['objSecondaryTableData'] = objAPIResponse;
                            //Adding data directly in lwcCustomizedDatatable 
                            const localrenderingTableData = this.template.querySelector('c-lwc-customized-datatable[class=billingSummaryDataTable]').renderingTableData;
                            const localsortedData = this.template.querySelector('c-lwc-customized-datatable[class=billingSummaryDataTable]').sortedData;
                            const locallstFilteredData = this.template.querySelector('c-lwc-customized-datatable[class=billingSummaryDataTable]').lstFilteredData;
                            const cloneLocalRenderingData = {...localrenderingTableData};
                            const lstLocalRendringData = [];
                            for(const objItrNew in cloneLocalRenderingData) {
                                let cloneObjItr = {...cloneLocalRenderingData[objItrNew]};
                                const cloneMap = {};
                                const tempObjMap = cloneObjItr.list.reduce(function(_map, obj) {
                                    cloneMap[obj.key] = obj.value;
                                    return cloneMap;
                                });
                                if (tempObjMap["billingContrivedKey"] === strbillingContrivedKey && tempObjMap["invoiceNumber"] === strinvoiceId){ 
                                    cloneObjItr = {...cloneObjItr};
                                    cloneObjItr.other = {...cloneObjItr.other};
                                    cloneObjItr.other.objSecondaryTableData = {...cloneObjItr.other.objSecondaryTableData};
                                    cloneObjItr.other.objSecondaryTableData = Array.from(objUpdatedData);
                                    cloneObjItr.other.boolNestedSpinner = false;
                                } else {
                                    //do nothing
                                }
                                lstLocalRendringData.push(cloneObjItr);
                        }
                            localsortedData.forEach(objItr=>{
                                const tempObjMap = objItr.get('rowData').reduce(function(map, obj) {
                                    map[obj.key] = obj.value;
                                    return map;
                                });
                                if (tempObjMap["billingContrivedKey"] === strbillingContrivedKey && tempObjMap["invoiceNumber"] === strinvoiceId){ 
                                    objItr.set('objSecondaryTableData',Array.from(objUpdatedData));
                                    objItr.set('boolNestedSpinner',false);
                                } else {
                                    //do nothing
                                }
                            });
                            locallstFilteredData.forEach(objItr=>{
                                const tempObjMap = objItr.get('rowData').reduce(function(map, obj) {
                                    map[obj.key] = obj.value;
                                    return map;
                                });
                                if (tempObjMap["billingContrivedKey"] === strbillingContrivedKey && tempObjMap["invoiceNumber"] === strinvoiceId){ 
                                    objItr.set('objSecondaryTableData',Array.from(objUpdatedData));
                                    objItr.set('boolNestedSpinner',false);
                                } else {
                                    //do nothing
                            }
                            }); 
                            // Setting Data
                            this.template.querySelector('c-lwc-customized-datatable[class=billingSummaryDataTable]').renderingTableData = lstLocalRendringData;
                            this.template.querySelector('c-lwc-customized-datatable[class=billingSummaryDataTable]').sortedData = localsortedData;
                            this.template.querySelector('c-lwc-customized-datatable[class=billingSummaryDataTable]').lstFilteredData = locallstFilteredData;
                            this.template.querySelector('c-lwc-customized-datatable[class=billingSummaryDataTable]').refreshNestedTableData();
                        } else {
                            objItr['objSecondaryTableData'] = JSON.parse(strAA).productInformation;
                        }
                    }
                });
                this.lstBillingSummaryData = lstBillingTableData;
        } catch(objException) {
            this.handleErrors(objException)
        }
        }
    }
    setBillingSummaryData(lstResponsefromAPI) {
        //setting Sample data
        const tableObject = lstResponsefromAPI.map((itrRow) => {
            itrRow['boolNestedTable'] = true;
            itrRow['boolHidden'] = false;
            itrRow['boolSecTable'] = false;
            itrRow['dueDate'] = this.formatDate(itrRow['dueDate']);
            itrRow['endDate'] = this.formatDate(itrRow['endDate']);
            itrRow['createDate'] = this.formatDate(itrRow['createDate']);
            itrRow['deliquencyDate'] = this.formatDate(itrRow['deliquencyDate']);
            if(BaseLWC.isNotUndefinedOrNull( itrRow['billedAmount']) && !itrRow['billedAmount'].includes('.')) {
                itrRow['billedAmount'] = '$'+itrRow['billedAmount']+'.00';
            }
            if(BaseLWC.isNotUndefinedOrNull( itrRow['amountReceived']) && !itrRow['amountReceived'].includes('.')) {
                itrRow['amountReceived'] = '$'+itrRow['amountReceived']+'.00';
            }
            itrRow['objSecTableStatus'] = {
                boolExpanded: false,
                boolDisabled: false,
                
            }
            itrRow['objSecondaryTableSetting'] = this.objSecondaryTableSettings;
            itrRow['objSecondaryTableData'] = [];
            return itrRow;
        });
        return tableObject;
    }
    setPaymentHistoryData(lstResponsefromAPI) {
        const tableObject = lstResponsefromAPI.map((itrRow) => {
            itrRow['receivedDate'] = this.formatDate(itrRow['receivedDate']);
            itrRow['paymentEnteredDate'] = this.formatDate(itrRow['paymentEnteredDate']);
            if(BaseLWC.isNotUndefinedOrNull( itrRow['amountReceived']) && !itrRow['amountReceived'].includes('.')) {
                itrRow['amountReceived'] = '$'+itrRow['amountReceived']+'.00';
            }
            return itrRow;
        });
        return tableObject;
    }
    setPaymentMethodData(lstResponsefromAPI) {
        const tableObject = lstResponsefromAPI.map((itrRow) => {
            itrRow['effectiveDate'] = this.formatDate(itrRow['effectiveDate']);
            itrRow['terminationDate'] = this.formatDate(itrRow['terminationDate']);
            return itrRow;
        });
        return tableObject;
    }
    setBankingSummaryData(lstResponsefromAPI) {
        const tableObject = lstResponsefromAPI.map((itrRow) => {
            if(itrRow['accountNumber'] !== null && itrRow['accountNumber'] !== undefined && itrRow['accountNumber']!== '') {
                itrRow['accountNumber'] = itrRow['accountNumber'].slice(-4);
            }
            itrRow['effectiveDate'] = this.formatDate(itrRow['effectiveDate']);
            itrRow['terminationDate'] = this.formatDate(itrRow['terminationDate']);
            return itrRow;
        });
        return tableObject;
    }
    formatDate(strUnformatedDate) {
        if(strUnformatedDate !== null && strUnformatedDate !== undefined && strUnformatedDate!== '') {
            const objDateTime = new Date(strUnformatedDate);
            let intMonth = objDateTime.getMonth() + 1;
            let intDay = objDateTime.getDate();
            const intYear = objDateTime.getFullYear();
            if (intMonth < 10) {
                intMonth = "0" + intMonth;
            }
            if (intDay < 10) {
                intDay = "0" + intDay;
            }
            return intMonth + "/" + intDay + "/" + intYear;
        }
        return null;
    }
}