import { LightningElement, api } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF'; 
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import InteractionHistoryPage_NoRecordFound_ACE from '@salesforce/label/c.InteractionHistoryPage_NoRecordFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';

import fetchData from '@salesforce/apex/MagellanCallHistoryController_ACE.fetchData';

export default class LwcMagellanCallHistoryTabComponent extends LightningElement {
    label = {
        
        SafeMode_ToastMessage_ACE,
        InteractionHistoryPage_NoRecordFound_ACE,
        IntegrationFailMessage_ACE 
   }

    @api tabData;
    @api globalData;
    @api boolSafeMode; 


    boolDisplayData = false;
    boolSpinner = false;
    boolShowNoRecorsFound = true;
    boolAPIError = false; 
    intLimitCount = 100;  
    lstTableData = [];

    columns = [
        { label:'Member ID', fieldName: 'EnrolleeID_ACE__c', sortable: true, type: '' } ,
        { label:'Date/Time Received', fieldName: 'DateTimeReceived_ACE__c', sortable: true, type: 'date' },
        { label:'Category', fieldName: 'Category_ACE__c', sortable: true, type: '' } 
    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: true,
        boolShowSearch: true,
        boolShowSearchLabel: true,
        filterData: [
            { strType: 'Select a value', intCol: -1, strFilterName: 'Select a value' },
            { strType: 'text', intCol: 1, strFilterName: 'Member ID' },
            { strType: 'dateRangeMF', intCol: 2, strFilterName: 'Date/Time Received' },
            { strType: 'text', intCol: 3, strFilterName: 'Category' } 
        ] 
    };

    connectedCallback() {
        this.fetchLobDetail(); 
    }
    
    fetchLobDetail() {
        this.boolDisplayData = false;
        this.boolShowNoRecorsFound = true;
        this.boolAPIError = false;
        this.boolSpinner = true;
        let strMedicaidId;
        let strSubscriberId;
        let strfirstName;
        let strlastname; 

        //CEAS-82436 - Null Checks for Temp Members
        if (this.globalData) {
            strSubscriberId = this.globalData.strSubscriberId;
            if (this.globalData.planData) {
                strMedicaidId = this.globalData.planData.strMedicaidId;
                strfirstName = this.globalData.planData.strfirstName;
                strlastname = this.globalData.planData.strlastname; 
            }
        }
        
        fetchData({
            strMedicaidId: strMedicaidId,
            strSubscriberId: strSubscriberId,
            strfirstName: strfirstName,
            strlastname: strlastname
        }).then((result)=>{
            if (result) { 
                this.lstCRD = [...result];
                if (BaseLWC.isNotUndefinedOrNull(this.lstCRD) && this.lstCRD.length > 0) { 
                    for (let i = 0; i < this.lstCRD.length; i++) {
                        const obj = { ...this.lstCRD[i] };
                        
                        if (obj['EnrolleeID_ACE__c']) {
                            obj.EnrolleeID_ACE__c = obj['EnrolleeID_ACE__c'];
                        } else {
                            obj.EnrolleeID_ACE__c = '';
                        }
                        
                        if (new Date(obj.DateTimeReceived_ACE__c).toString() !== 'Invalid Date') {
                            let DateTimeReceived = '';
                            if (BaseLWC.dtDateTimeISOtoLocal(obj.DateTimeReceived_ACE__c) !== 'Invalid Date') {
                                DateTimeReceived = BaseLWC.dtDateTimeISOtoLocal(obj.DateTimeReceived_ACE__c)
                            }

                            obj['DateTimeReceived_ACE__c'] = {
                                value: obj.DateTimeReceived_ACE__c,
                                wrapper: `<span>${DateTimeReceived}</span>`
                            } 
                        }
                        if (obj['Category_ACE__c']) {
                            obj.Category_ACE__c = obj['Category_ACE__c'];
                        } else {
                            obj.Category_ACE__c ='';
                        }
                        if (obj['Description_ACE__c']) {
                            obj.Description_ACE__c = obj['Description_ACE__c'];
                        } else {
                            obj.Description_ACE__c = '';
                        }
                        if (obj['Outcome_ACE__c']) {
                            obj.Outcome_ACE__c = obj['Outcome_ACE__c'];
                        } else {
                            obj.Outcome_ACE__c= '';
                        }
                        obj['boolSecTable'] = true;
                        obj['strSecTable'] = 
                        `<div>
                           Description: ${obj.Description_ACE__c}</br>
                           Outcome: ${obj.Outcome_ACE__c}</br> 
                        </div>`;
                        
                        
                         

                        this.lstTableData.push(obj);
                    } 
                    this.boolSpinner = false; 
                    
                    if (this.lstTableData.length) {
                        this.boolDisplayData = true;
                        this.boolShowNoRecorsFound = false;
                    }
                } else {
                    this.boolShowNoRecorsFound = true;
                    this.boolSpinner = false; 
                    this.boolDisplayData = true;
                }
                
            }
          }
        ).catch(()=>{
            this.boolSpinner = false;
            this.boolDisplayData = true;
            this.boolShowNoRecorsFound = true;
        });
    }

    

    refreshData = () => {
        this.lstTableData = [];
        this.fetchLobDetail();
    }
}