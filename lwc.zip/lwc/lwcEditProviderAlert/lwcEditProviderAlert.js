import { LightningElement, api, track } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
import CreateAlerts_InvalidDate_ACE from '@salesforce/label/c.CreateAlerts_InvalidDate_ACE';
import CreateAlerts_RequiredChk_ACE from '@salesforce/label/c.CreateAlerts_RequiredChk_ACE';
import CreateAlerts_ValidEndDateChk_ACE from '@salesforce/label/c.CreateAlerts_ValidEndDateChk_ACE';
import CreateAlerts_StartDateChk_ACE from '@salesforce/label/c.CreateAlerts_StartDateChk_ACE';
import CreateAlerts_EndDateChk_ACE from '@salesforce/label/c.CreateAlerts_EndDateChk_ACE';


export default class LwcEditProviderAlert extends LightningElement {

    @api strTitle = "Test";
    @track startDate="";
    @track boolShowStartDateFormatError = false;
    @track boolShowEndDateFormatError = false;
    @track boolShowEndDateError = false;
    @track boolShowEndDateRequiredError = false;
    @track boolShowStartDateRequiredError = false;
    @track boolShowPreviousEndDate = false;
    @track boolShowPreviousStartDate = false;
    @track endDate = "";
   label = {
        CreateAlerts_InvalidDate_ACE,
        CreateAlerts_RequiredChk_ACE,
        CreateAlerts_ValidEndDateChk_ACE,
        CreateAlerts_StartDateChk_ACE,
        CreateAlerts_EndDateChk_ACE
   }

    updateDates = (objEvent) => {
        if(objEvent.target?.dataset?.id && objEvent.target.dataset.id === 'startDate' && objEvent.detail) {
            this.startDate = objEvent.detail;
        } else if(objEvent.target?.dataset?.id && objEvent.target.dataset.id === 'endDate' && objEvent.detail) {
            this.endDate = objEvent.detail;    
        } else {
            // do nothing
        }   
   }
    fireUpdatePNTAPRecordsEvent = () => {
        const boolValidated = this.validateDates();
        if(boolValidated) {
            const submiteditmodalclickEvent = new CustomEvent("submiteditmodalclick",{
                detail:{
                    startDate : this.startDate,
                    endDate : this.endDate }
                }
            );
            this.dispatchEvent(submiteditmodalclickEvent);
        }
    }

    validateDates = () => {
        
        let boolHasError = false;
        const pattern = /(0\d{1}|1[0-2])\/([0-2]\d{1}|3[0-1])\/[0-9]{4}/;
        const matchStartDatePattern = this.startDate.match(pattern);
        const matchEndDatePattern = this.endDate.match(pattern);
        
        let errStartDate = false;
        let errEndDate = false;
        if(this.startDate === "") {
            this.boolShowStartDateRequiredError = true;
            this.boolShowStartDateFormatError = false;
            this.boolShowPreviousStartDate = false;
            errStartDate = true;
        } else if (!matchStartDatePattern) {
            this.boolShowStartDateFormatError = true;
            this.boolShowStartDateRequiredError = false;
            this.boolShowPreviousStartDate = false;
            errStartDate = true;
        } else {
            this.boolShowStartDateFormatError = false;
            this.boolShowPreviousStartDate = false;
            this.boolShowStartDateRequiredError = false;
            errStartDate = false;
        }
        if(this.endDate === "") {
            this.boolShowEndDateRequiredError = true;
            this.boolShowEndDateFormatError = false;
            this.boolShowPreviousEndDate = false;
            errEndDate = true;
        } else if (!matchEndDatePattern) {
            this.boolShowEndDateFormatError = true;
            this.boolShowEndDateRequiredError = false;
            this.boolShowPreviousEndDate = false;
            errEndDate = true;
        } else {
            this.boolShowEndDateFormatError = false;
            this.boolShowPreviousEndDate = false;
            this.boolShowEndDateRequiredError = false;
            errEndDate = false;
        }

        if(!errStartDate && !errEndDate) {
            const startDate = new Date(this.startDate); 
            const endDate = new Date(this.endDate); 
            if(endDate <= startDate) {
                this.boolShowEndDateError = true;
                boolHasError = true;
            } else {
                this.boolShowEndDateError = false;
            }
        } else {
            return false;
        }

        if(!boolHasError) {
            return true;
        } else {
            return false;
        }
    }

    closeModal = () => {
        const objParams={};
        BaseLWC.fireNativeCustomEvent('canceleditmodalclick',objParams,this);
    }

    fetchDate(dateTime) {
        if(dateTime) {
            return new Date(dateTime);
        } else {
            return new Date(new Date().setHours(0,0,0,0));
        }
    }

}