import { LightningElement, wire, track, api } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import { openSubtab, setTabIcon, setTabLabel } from 'lightning/platformWorkspaceApi';

import fetchTMGCallSummary from '@salesforce/apexContinuation/TMGCallDetailsController_ACE.fetchTMGCallSummaryLwc'

//labels for TMG Call History
import TMGCallHistory_TableHeader_CallId_ACE from '@salesforce/label/c.TMGCallHistory_TableHeader_CallId_ACE';
import TMGCallHistory_TableHeader_CreatedDate_ACE from '@salesforce/label/c.TMGCallHistory_TableHeader_CreatedDate_ACE';
import TMGCallHistory_TableHeader_CallerName_ACE from '@salesforce/label/c.TMGCallHistory_TableHeader_CallerName_ACE';
import TMGCallHistory_TableHeader_CallerType_ACE from '@salesforce/label/c.TMGCallHistory_TableHeader_CallerType_ACE';
import TMGCallHistory_TableHeader_CallInMethod_ACE from '@salesforce/label/c.TMGCallHistory_TableHeader_CallInMethod_ACE';
import TMGCallHistory_TableHeader_Subject_ACE from '@salesforce/label/c.ViewCaseSummary_Subject_ACE';
import TMGCallHistory_TableHeader_Category_ACE from '@salesforce/label/c.TMGCallHistory_TableHeader_Category_ACE';
import TMGCallHistory_TableHeader_LastUpdatedDate_ACE from '@salesforce/label/c.TMGCallHistory_TableHeader_LastUpdatedDate_ACE';
import TMGCallHistory_TableHeader_Status_ACE from '@salesforce/label/c.IDCardStatus_ACE';
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import InteractionHistoryPage_NoRecordFound_ACE from '@salesforce/label/c.InteractionHistoryPage_NoRecordFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';

export default class LwcTmgCallHistoryTabComponent extends LightningElement {

    label = {
        TMGCallHistory_TableHeader_CallId_ACE,
        TMGCallHistory_TableHeader_CreatedDate_ACE,
        TMGCallHistory_TableHeader_CallerName_ACE,
        TMGCallHistory_TableHeader_CallerType_ACE,
        TMGCallHistory_TableHeader_CallInMethod_ACE,
        TMGCallHistory_TableHeader_Subject_ACE,
        TMGCallHistory_TableHeader_Category_ACE,
        TMGCallHistory_TableHeader_LastUpdatedDate_ACE,
        TMGCallHistory_TableHeader_Status_ACE,
        SafeMode_ToastMessage_ACE,
        InteractionHistoryPage_NoRecordFound_ACE,
        IntegrationFailMessage_ACE
    }

    @api tabData;
    @api globalData;
    @api boolSafeMode;

    boolDisplayData = false;
    boolSpinner = false;
    boolShowNoRecorsFound = false;
    boolAPIError = false;

    lstTableData = [];
    columns = [
        { label: this.label.TMGCallHistory_TableHeader_CallId_ACE, fieldName: 'callIdLink', sortable: true, type: '' },
        { label: this.label.TMGCallHistory_TableHeader_CreatedDate_ACE, fieldName: 'createdDate', sortable: true, type: 'date', boolInitSort: true, boolAsc: false },
        { label: this.label.TMGCallHistory_TableHeader_CallerName_ACE, fieldName: 'name', sortable: true, type: '' },
        { label: this.label.TMGCallHistory_TableHeader_CallerType_ACE, fieldName: 'callerType', sortable: true, type: '' },
        { label: this.label.TMGCallHistory_TableHeader_CallInMethod_ACE, fieldName: 'callInMethod', sortable: true, type: '' },
        { label: this.label.TMGCallHistory_TableHeader_Subject_ACE, fieldName: 'subject', sortable: true, type: '' },
        { label: this.label.TMGCallHistory_TableHeader_Category_ACE, fieldName: 'category', sortable: true, type: '' },
        { label: this.label.TMGCallHistory_TableHeader_LastUpdatedDate_ACE, fieldName: 'lastUpdatedDate', sortable: true, type: 'date' },
        { label: this.label.TMGCallHistory_TableHeader_Status_ACE, fieldName: 'status', sortable: true, type: '' },
        { label: '', fieldName: 'strTextTooltipContent', sortable: false, boolHidden: false, type: '', boolIsTooltip: true, boolIsInfoIconTooltip: true }
    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: true,
        boolShowSearch: true,
        boolShowSearchLabel: true,
        filterData: [
            { strType: 'Select a value', intCol: -1, strFilterName: 'Select a value' },
            { strType: 'text', intCol: 1, strFilterName: 'Call ID' },
            { strType: 'dateRangeMF', intCol: 2, strFilterName: 'Created Date' },
            { strType: 'text', intCol: 3, strFilterName: 'Caller Name' },
            { strType: 'picklist', intCol: 4, strFilterName: 'Caller Type' },
            { strType: 'picklist', intCol: 5, strFilterName: 'Call In Method' },
            { strType: 'text', intCol: 6, strFilterName: 'Subject' },
            { strType: 'picklist', intCol: 7, strFilterName: 'Category' },
            { strType: 'dateRangeMF', intCol: 8, strFilterName: 'Last Updated Date' },
            { strType: 'picklist', intCol: 9, strFilterName: 'Status' }
        ],
    };

    connectedCallback() {
        this.fetchData();

    }

    fetchData = () => {
        this.boolDisplayData = false;
        this.boolShowNoRecorsFound = false;
        this.boolAPIError = false;
        this.boolSpinner = true;
        //CEAS-74787
        this.lstTableData=[];
        if (!this.globalData) {
            return;
        }
        const strFacetsGroupId = this.globalData.strFacetsGroupId;
        const strSubscriberId = this.globalData.strSubscriberId;
        if (strFacetsGroupId !== null && strFacetsGroupId !== undefined &&
            strSubscriberId !== null && strSubscriberId !== undefined) {
            fetchTMGCallSummary({ strFacetsGroupIdParam: strFacetsGroupId, strFacetSubscriberIdParam: strSubscriberId.substring(3) })
                .then(result => {

                    const lstData = JSON.parse(result).callSummary;
                    for (let i = 0; i < lstData.length; i++) {
                        const obj = { ...lstData[i] };
                        if (obj.callID === '') {
                            return;
                        }
                        if(this.globalData.strLOB.toUpperCase() === 'GOVERNMENT-MEDICAID' && (this.globalData.strCorpCode === 'TX1' || this.globalData.strCorpCode === 'IL1' )) {
                            obj.callIdSeq = obj.callID;
                        } else {
                            obj.callIdSeq = obj.callID + obj.sequenceNumber;       
                        }
                        
                        if (new Date(obj.createdDate).toString() !== 'Invalid Date') {
                            let createdDateTime = '';
                            if (BaseLWC.dtDateTimeISOtoLocal(obj.createdDate) !== 'Invalid Date') {
                                createdDateTime = BaseLWC.dtDateTimeISOtoLocal(obj.createdDate)
                            }

                            obj['createdDate'] = {
                                value: obj.createdDate,
                                wrapper: `<span>${createdDateTime}</span>`
                            }
                        }
                        if (new Date(obj.lastUpdatedDate).toString() !== 'Invalid Date') {
                            let lastUpdatedDateTime = '';
                            if (BaseLWC.dtDateTimeISOtoLocal(obj.lastUpdatedDate) !== 'Invalid Date') {
                                lastUpdatedDateTime = BaseLWC.dtDateTimeISOtoLocal(obj.lastUpdatedDate)
                            }

                            obj['lastUpdatedDate'] = {
                                value: obj.lastUpdatedDate,
                                wrapper: `<span>${lastUpdatedDateTime}</span>`
                            }
                        }

                        obj['callIdLink'] = {
                            value: obj['callIdSeq'],
                            strCallId: obj['callID'],
                            strCallIdSeq: obj['callIdSeq'],
                            wrapper: `<a>${obj.callIdSeq}</a>`
                        };
                        let strName = '';
                        if (obj.callerFirstName) {
                            strName = obj.callerFirstName + ' ';
                        }
                        if (obj.callerLastName) {
                            strName += obj.callerLastName;
                        }
                        obj.name = strName;
                        obj['boolSecTable'] = true;
                        obj['strSecTable'] = `<p>Summary: ${obj.summary}</p>`;
                        obj['strTextTooltipContent'] = {
                            value: '',
                            wrapper: true,
                            strCellValue: `<div>
                           Created User: ${obj.createdUser}</br>
                           Last Updated User: ${obj.lastUpdatedUser}</br>
                           Complaint: ${obj.complaint}
                        </div>`,
                            strTextTooltipContent: `<div>
                            Created User: ${obj.createdUser}</br>
                            Last Updated User: ${obj.lastUpdatedUser}</br>
                            Complaint: ${obj.complaint}
                        </div>`
                        }

                        this.lstTableData.push(obj);
                    }

                    this.boolSpinner = false;
                    this.boolDisplayData = true;
                    if (!this.lstTableData.length) {
                        this.boolShowNoRecorsFound = true;
                    }
                })
                .catch(() => {
                    this.boolSpinner = false;
                    this.boolAPIError = true;
                });
        } else {
            this.boolSpinner = false;
            this.boolDisplayData = true;
            this.boolShowNoRecorsFound = true;
        }
    }

    handleRowAction(event) {
        const rowData = JSON.parse(event.detail);
        if (rowData.activeColumnName === this.label.TMGCallHistory_TableHeader_CallId_ACE) {
            this.openTMGCallDetails(rowData.activeColumnData.value.strCallId, rowData.activeColumnData.value.strCallIdSeq)
        }
    }

    //CEAS-78019 - FIXED ALL TMG RECORDS OPENING IN SAME SUBTAB
    openTMGCallDetails = (strCallId) => {

        const strEncodedParams = btoa('?timeInMillis=' + Date.now() + '&callId=' + strCallId)
        //CEAS-78019  
        const objPageReference = {
            "type": "standard__navItemPage",
            "attributes": {
                "apiName": 'viewTMGCallIdDetailsFlexipage_ACE',
                "uid": strCallId
            },
            "state": {
                "c__BaseURLParam": strEncodedParams
            }
        };

        openSubtab(this.tabData.tabId,{pageReference:objPageReference,focus:true})
            .then(objresponse => {
                setTabLabel(objresponse, strCallId)
                    .then(() => {
                        setTabIcon(objresponse, "standard:call", strCallId)
                            .then(() => {
                                //Do nothing
                            }).catch(() => {
                                //Do nothing
                            })
                    }).catch(() => {
                        //Do nothing
                    })

            }).catch(() => {
            })
    }

    refreshData = () => {
        this.fetchData();
    }
}
