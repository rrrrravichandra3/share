/****************************************************************************************************************
 * Author: U448223
 * Created on 2/20/2024
 **************************************************************************************************************** 
 *      Version             Date                Author                  Comments
 *      1                   2/20/2024           U448223                 Inital Version (CEAS-78630)
 *      
 ****************************************************************************************************************/
import { LightningElement,api,track,wire } from 'lwc';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
import Message_error_ACE from "@salesforce/label/c.Message_error_ACE";
//CEAS-82979 Platform Workspace API
import { EnclosingTabId, getTabInfo} from 'lightning/platformWorkspaceApi';

import ViewPlanSummary_CardHeader_Refresh_ACE from "@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE";
import Message_warning_ACE from "@salesforce/label/c.MessageLightningComponent_Warning_ACE";
import SafeMode_ToastMessage_ACE from "@salesforce/label/c.SafeMode_ToastMessage_ACE";
import IntegrationFailMessage_ACE from "@salesforce/label/c.FacetsNotesAPIErrorMessage_ACE";
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';

export default class LwcEligibilityEvents_ACE extends LightningElement {
    label = {
        ViewPlanSummary_CardHeader_Refresh_ACE,
        Message_warning_ACE,
        SafeMode_ToastMessage_ACE,
        IntegrationFailMessage_ACE,
        Message_error_ACE,
        EnableVPSTabSpecificEvents_ACE
    };
    @wire(EnclosingTabId) enclosingTabId;
    objTabData = {};
    boolError=false;
    boolShowSpinner = true;
    boolShowSafeMode = false;
    facetsGroupId ='';
    subscriberId ='';
    boolPlanSummaryData = false;
    boolPrimaryTab = false;
    boolFetchData=false;
    PlanSummaryData={};
    strBaseCurrentParentTabId;
    boolVPSTabSpecificEvents;


    //Table Data
    @api lstEligibilityEvents = [];


    //Table Settings
    @track objEligibilitySetting = {
        pageSize: 5,
        showPagination : true,
        boolViewMore: false,
        columnsData: [
            { label: 'EVENT NAME', fieldName: 'eventname', sortable: false, type: 'text' },
            { label: 'EFFECTIVE DATE', fieldName: 'effectivedate', sortable: false, type: 'date' },
            { label: 'RECEIVED DATE', fieldName: 'receiveddate', sortable: false, type: 'date', boolInitSort: true, boolAsc: false },
            { label: 'REASON', fieldName: 'reason', sortable: false, type: 'text' },
            { label: 'PLAN ID', fieldName: 'planid', sortable: false, type: 'text' },
            { label: 'PLAN NAME', fieldName: 'planname', sortable: false, type: 'text' }
        ],
        boolSecondaryTable: false,
        boolShowFilter: true,
        boolPagination: true,
        boolShowSearch:true,
        searchPlaceholder : 'Search Text',
        boolHasSearchandFilterCustomMargins: true,
        objSearchandFilterCustomMargins:{
            top: "0.75rem",
            bottom: "0",
            right: "0",
        },
        filterData : [
            {strType : '', intCol : -1, strFilterName : 'Select a value'},
            {strType : 'text', intCol : 1, strFilterName : 'EVENT NAME'},
            {strType : 'date', intCol : 2, strFilterName : 'EFFECTIVE DATE'},
            {strType : 'date', intCol : 3, strFilterName : 'RECEIVED DATE'},
            {strType : 'text', intCol : 4, strFilterName : 'REASON'},
            {strType : 'text', intCol : 5, strFilterName : 'PLAN ID'},
            {strType : 'text', intCol : 6, strFilterName : 'PLAN NAME'}
        ],
        boolShowCheckbox : false,
        boolShowHeader : false,
        boolShowSearchLabel: false,
        restrictedPageSize : false,
        boolPaginationwithSize:true,
        pageMenu : [5]
    };


    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.fetchTabData();
        } catch (error) {
            //Handle Error
        }
    }


    fetchTabData() {
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
                this.objTabData = objTabData;
                // this.planSummaryListener();
                this.executeInitialFunctionality();
                if (this.objTabData.isSubtab === true) {
                    this.strBaseCurrentParentTabId = this.objTabData.parentTabId;
                } else {
                    this.strBaseCurrentParentTabId = this.objTabData.tabId;
                }
                if (BaseLWC.stringIsNotBlank(this.label.EnableVPSTabSpecificEvents_ACE) && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                    this.boolVPSTabSpecificEvents = true;
                }
                this.planSummaryListener();
            }).catch(e => {
                this.handleErrors(e);
            });
        }
    }
    
    planSummaryListener() {
        if(this.boolVPSTabSpecificEvents)  {
            window.addEventListener('PlanSummaryEvent_' + this.strBaseCurrentParentTabId, this.capturePlanSummaryListener, false);
        } else {
            window.addEventListener('PlanSummaryEvent', this.capturePlanSummaryListener);
        }
    
       if (!this.planSummaryListened) {
            if (this.label.EnableVPSTabSpecificEvents_ACE && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === "true") {
                BaseLWC.helperBasePostTabIdMessageCustomEvents('TriggerPlanSummaryData_' + this.strBaseCurrentParentTabId, null, null, 'PlanCardDetails_ACE', this.strBaseCurrentParentTabId).catch(() => {});
            } else {
                BaseLWC.helperBasePostTabIdMessageCustomEvents('TriggerPlanSummaryData', null, null, 'PlanCardDetails_ACE', this.strBaseCurrentParentTabId).catch(() => {});
            }
        }
    }

    capturePlanSummaryListener = (planSummaryDataEvent) => {
        try{
            if (BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail) ) {
            
                this.planSummaryListened = true;
                this.PlanSummaryData = JSON.parse(planSummaryDataEvent.detail);
                 
                if(this.PlanSummaryData.strIdDestination === 'PlanCardDetails_ACE') {
                    this.boolPlanSummaryData = true;
                    this.boolFetchData=false;
                    this.lstEligibilityEvents = this.fetchEligibilityData(); 
                    this.boolFetchData=true;
                }
                if (this.boolVPSTabSpecificEvents) {
                    window.removeEventListener("PlanSummaryEvent_" + this.parenttabId,this.capturePlanSummaryListener, false);
                } else {
                    window.removeEventListener("PlanSummaryEvent",this.capturePlanSummaryListener);
                }
            }
        } catch (e) {
            this.handleErrors(e);
        }
    }

    executeInitialFunctionality() {
        if (this.objTabData.isSubtab === true) {
            //Always segregate the Main tab and Sub tab functions.
            this.executeSubTabFunctionality();
        } else if (this.objTabData.isSubtab === false) {
            //Always segregate the Main tab and Sub tab functions.
            this.executeMainTabFunctionality();
        } else {
            //Do nothing
        }
    }

    executeSubTabFunctionality() {
        this.boolPrimaryTab = false;
    }

    executeMainTabFunctionality() {
        this.boolPrimaryTab = true;

    }

    fetchEligibilityData() {
        this.boolShowSpinner = false;
        let lstmemberevent = [];
        let tableObject;
        let planId;
        let planName;

        if(this.PlanSummaryData.objParameters.objMessage !== null &&  this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails !== null ) {
            lstmemberevent = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.lstMemberEvents;
            planId = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strMedicaidPlanId;
            planName = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.objFacetPolicy.planDescription;
        }
        if(lstmemberevent !== null &&  lstmemberevent !== undefined && lstmemberevent.length > 0){
             tableObject = lstmemberevent.map((itrRow) => {
                itrRow['eventname'] = itrRow['eligibilityEventDescription'];
                itrRow['effectivedate'] = this.formatDate(itrRow['eligibilityEventDate']);
                itrRow['receiveddate'] = this.formatDate(itrRow['eligibilityEventSourceUpdate']);
                itrRow['reason'] = itrRow['eligibilityExplanation'];
                itrRow['planid'] = planId;
                itrRow['planname'] = planName;
                return itrRow;
            });
        }
        return tableObject;
    }


    handleErrors(error) {
        this.boolError = error;
    }

    formatDate(strUnformatedDate) {
        var finalDate = '';
        if(strUnformatedDate) {
            var strDateSplit =strUnformatedDate.split("-");
            finalDate = strDateSplit[1]+"/"+strDateSplit[2]+"/"+strDateSplit[0];
            return finalDate;
        }

        return null;
    }

    refreshCard = () => {
        try {
            this.executeInitialFunctionality();
            this.boolShowSpinner = true;
            this.executeInitialFunctionality();
            this.boolFetchData=false;
            this.planSummaryListened = false;
            this.planSummaryListener();
            this.boolShowSpinner = false;
        } catch (error) {
            
            this.handleErrors(error);
        }
    };
}