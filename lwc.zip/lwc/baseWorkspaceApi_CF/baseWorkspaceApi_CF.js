/**
 * JS helper for Workspace API.
 * <p /><p />
 * @author Prateek Jain.
 */

/**
 * Used to Invoke Workspace API.
 * @param methodName: API Method Name.
 * @pram methodArgs: API arguments(optional).
 * @return Promise.
*/
export const invokeWorkspaceAPI = (methodName, methodArgs) => {
    return new Promise((resolve, reject) => {
        const apiEvent = new CustomEvent("internalapievent", {
            bubbles: true,
            composed: true,
            cancelable: false,
            detail: {
                category: "workspaceAPI",
                methodName: methodName,
                methodArgs: methodArgs,
                callback: (err, response) => {
                    if (err) {
                        return reject(err);
                    } else {
                        return resolve(response);
                    }
                }
            }
        });
        window.dispatchEvent(apiEvent);
    });
}

/**
 * Used to fetch Focused Tab info.
 * @return Promise.
*/
export const getTabData = () => {
    return new Promise((resolve, reject) => {

        isConsoleTab().then(isConsole => {
            if (isConsole) {
                invokeWorkspaceAPI('getFocusedTabInfo').then(objTabData => {
                    resolve(objTabData);
                }).catch(error => {
                    reject(error);
                });
            } else {
                reject('Error');
            }
        }).catch(error => {
            reject(error);
        });

    });
}

/**
 * Used to check Console Tab.
 * @return Promise.
*/
export const isConsoleTab = () => {
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('isConsoleNavigation').then(isConsole => {
            resolve(isConsole);
        }).catch(error => {
            reject(error);
        });

    });
}

/**
 * Used to open Sub Tab with RecordId.
 * @param strParentTabId : Parent Tab Id.
 * @param strRecordId : Record Id.
 * @param boolFocus : Focus Tab.
 * @return Promise.
*/
export const openSubTabWithRecordId = (strParentTabId, strRecordId, boolFocus) => {
    let strParentId = strParentTabId;
    if (strParentTabId.indexOf('_') > -1) {
        strParentId = strParentTabId.split('_')[0];
    }
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('openSubtab', {
            parentTabId: strParentId,
            recordId: strRecordId,
            focus: boolFocus
        }).then(tabId => {
            resolve(tabId);
        }).catch(error => {
            reject(error);
        });
    });
}

export const openSubTabWithPageRef = (strParentTabId, objPageReference, boolFocus) => {
    let strParentId = strParentTabId;
    if (strParentTabId.indexOf('_') > -1) {
        strParentId = strParentTabId.split('_')[0];
    }
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('openSubtab', {
            parentTabId: strParentId,
            pageReference: objPageReference,
            focus: boolFocus
        }).then(tabId => {
            resolve(tabId);
        }).catch(error => {
            reject(error);
        });
    });
}
/**
 * Used to open Sub Tab with Url.
 * @param strParentTabId : Parent Tab Id.
 * @param strUrl : Url.
 * @param boolFocus : Focus Tab.
 * @return Promise.
*/
export const openSubTabWithUrl = (strParentTabId, strUrl, boolFocus) => {
    let strParentId = strParentTabId;
    if (strParentTabId.indexOf('_') > -1) {
        strParentId = strParentTabId.split('_')[0];
    }
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('openSubtab', {
            parentTabId: strParentId,
            url: strUrl,
            focus: boolFocus
        }).then(tabId => {
            resolve(tabId);
        }).catch(error => {
            reject(error);
        });
    });
}

/**
 * Used to get full Tab info.
 * @param strTabId : Tab Id.
 * @return Promise.
*/
export const getTabInfo = (strTabId) => {
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('getTabInfo', {
            tabId: strTabId
        }).then(objTabData => {
            resolve(objTabData);
        }).catch(error => {
            reject(error);
        });
    });
}

/**
 * Used to get full Tab info.
 * @param strTabId : Tab Id.
 * @return Promise.
*/
export const getEnclosingTabId = () => {
    return new Promise(async (resolve, reject) => {
        const objEnclosingTabFunction = await eval("$A.get('e.force:getEnclosingTabId')");
            if(objEnclosingTabFunction) {
                objEnclosingTabFunction.setParams({
                    callback: (strEnclosingTabId) => {
                        resolve(strEnclosingTabId);
                    }
                }).fire();
            } else {
                reject('Failed to execute Enclosing Tab');
            }
    });
}

export const getEnclosingTabInfo = () => {
    return new Promise(async (resolve, reject) => {
        getEnclosingTabId().then(objEnclosingTabId=>{
            if(objEnclosingTabId) {
                getTabInfo(objEnclosingTabId).then(objTabData => {
                    resolve(objTabData);
                }).catch(error=>{
                    reject(error);
                });
            } else {
                reject('Failed to execute Enclosing Tab2');
            }
        }).catch(error=>{
            reject(error);
        });
    });
}

/**
 * Used to Close Tab.
 * @param strTabId : Tab Id.
 * @return Promise.
 */
export const closeTab = (strTabId) => {
    return new Promise((reject) => {
        invokeWorkspaceAPI('closeTab', {
            tabId: strTabId
        }).catch(error => {
            reject(error);
        });
    });
}

/**
 * Used to open Tab with Url.
 * @param strUrl : Url.
 * @param boolFocus : Focus Tab.
 * @return Promise.
*/
export const openTabWithUrl = (strUrl, boolFocus) => {
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('openTab', {
            url: strUrl,
            focus: boolFocus
        }).then(tabId => {
            resolve(tabId);
        }).catch(error => {
            reject(error);
        });
    });
}

/**
 * Used to open Tab with Url.
 * @param strUrl : Url.
 * @param boolFocus : Focus Tab.
 * @return Promise.
*/
export const openTabWithRecordId = (strRecordId, boolFocus) => {
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('openTab', {
            recordId: strRecordId,
            focus: boolFocus
        }).then(tabId => {
            resolve(tabId);
        }).catch(error => {
            reject(error);
        });
    });
}

/**
 * Used to set Tab Url.
 * @param strTabId: Tab Id.
 * @param strLabel: Tab Label.
 * @return Promise with Tab Info.
 */
 export const setTabLabel = (strTabId, strLabel) => {
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('setTabLabel', {
            tabId: strTabId,
            label: strLabel
        }).then(objTabInfo => {
            resolve(objTabInfo);
        }).catch(error => {
            reject(error);
        });
    });
}

/**
 * Used to focus Tab 
 * @param strTabId : TabID which needs to be focused
 * @return Promise.
*/
export const focusTab = (strTabId) => {
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('focusTab', {
            tabId: strTabId
        }).then(objTabData => {
            resolve(objTabData);
        }).catch(error => {
            reject(error);
        });
    });
}

/**
 * Used to Refresh Tab 
 * @param strTabId : TabID which needs to be focused
 * @return Promise.
*/
export const refreshTab = (strTabId) => {
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('refreshTab', {
            tabId: strTabId
        }).then(objTabData => {
            resolve(objTabData);
        }).catch(error => {
            reject(error);
        });
    });
}

/**
 * Used to Refresh Tab 
 * @param strTabId : TabID which needs to be focused
 * @return Promise.
*/
export const setTabIcon = (strTabId,strIcon,strIconAlt) => {
    return new Promise((resolve, reject) => {
        invokeWorkspaceAPI('setTabIcon', {
            tabId: strTabId,
            icon: strIcon,
            iconAlt: strIconAlt
        }).then(objTabData => {
            resolve(objTabData);
        }).catch(error => {
            reject(error);
        });
    });
}