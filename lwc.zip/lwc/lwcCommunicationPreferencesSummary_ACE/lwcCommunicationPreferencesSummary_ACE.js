import { LightningElement, api, wire, track } from 'lwc';
import Domain_Visualforce_ACE from '@salesforce/label/c.Domain_Visualforce_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import CommunicationPreferencesLabel_ACE from '@salesforce/label/c.CommunicationPreferencesLabel_ACE';
import ViewPlanSummary_CardHeader_Refresh_ACE from '@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE';
import MessageLightningComponent_Warning_ACE from '@salesforce/label/c.MessageLightningComponent_Warning_ACE';
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import MessageLightningComponent_Error_ACE from '@salesforce/label/c.MessageLightningComponent_Error_ACE';
import Clinician_Profile_ACE from '@salesforce/label/c.Clinician_Profile_ACE';
import System_Administrator_profile_ACE from '@salesforce/label/c.System_Administrator_profile_ACE';
import CommunicationPreferencesSummary_PreferredPhoneNumber_ACE from '@salesforce/label/c.CommunicationPreferencesSummary_PreferredPhoneNumber_ACE';
import PermissiontoVoicemailLabel_ACE from '@salesforce/label/c.PermissiontoVoicemailLabel_ACE';
import CommunicationPreferencesSummary_PermissionToLeaveVoiceMail_ACE from '@salesforce/label/c.CommunicationPreferencesSummary_PermissionToLeaveVoiceMail_ACE';
import CommunicationPreferencesSummary_PreferredSpokenLanguage_ACE from '@salesforce/label/c.CommunicationPreferencesSummary_PreferredSpokenLanguage_ACE';
import CommunicationPreferencesSummary_PreferredWrittenLanguage_ACE from '@salesforce/label/c.CommunicationPreferencesSummary_PreferredWrittenLanguage_ACE';
import CommunicationPreferencesSummary_PreferredMailingAddress_ACE from '@salesforce/label/c.CommunicationPreferencesSummary_PreferredMailingAddress_ACE';
import CommunicationPreferencesSummary_PreferredPhoneNumberNoVoice_ACE from '@salesforce/label/c.CommunicationPreferencesSummary_PreferredPhoneNumberNoVoice_ACE';
import CommunicationPreferencesSummary_PreferredEmailAddress_ACE from '@salesforce/label/c.CommunicationPreferencesSummary_PreferredEmailAddress_ACE';
import CommunicationPreferencesSummary_PreferredTextPhoneNumber_ACE from '@salesforce/label/c.CommunicationPreferencesSummary_PreferredTextPhoneNumber_ACE';
import ViewBenefits_ViewAll_ACE from '@salesforce/label/c.ViewBenefits_ViewAll_ACE';
import General_False_ACE from '@salesforce/label/c.General_False_ACE';
import MemberAgeMessageLabel_ACE from '@salesforce/label/c.MemberAgeMessageLabel_ACE';
import CommMemberAgeMessageLabel_ACE from '@salesforce/label/c.CommMemberAgeMessageLabel_ACE';
import CaseWithoutMemberErrorMessage_ACE from '@salesforce/label/c.CaseWithoutMemberErrorMessage_ACE';
import LineOfBusinessDefault_ACE from '@salesforce/label/c.LineOfBusinessDefault_ACE';
import Retail_LineOfBusinessLabel_ACE from '@salesforce/label/c.Retail_LineOfBusinessLabel_ACE';
import BaseLightningComponent_Error_ACE from '@salesforce/label/c.BaseLightningComponent_Error_ACE';
import { getRecord } from 'lightning/uiRecordApi';
import MID_Surrogate_ACE_FIELD from '@salesforce/schema/Account.MID_Surrogate_ACE__c';
//Import Shared JS files.

//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import { EnclosingTabId, getTabInfo, openSubtab } from 'lightning/platformWorkspaceApi';
import ViewCaseSummary_ViewLessLink_ACE from '@salesforce/label/c.ViewCaseSummary_ViewLessLink_ACE';
import profileDetails from '@salesforce/apex/CommunicationPreferSummaryController_ACE.profileDetails';
import getCommunicationPreferencesMethod from '@salesforce/apexContinuation/CommunicationPreferSummaryController_ACE.getCommunicationPreferencesMethod';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import HideFEPCommunication from '@salesforce/label/c.HideFEPCommunication';
export default class LwcCommunicationPreferencesSummaryACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    label = {
        Domain_Visualforce_ACE,
        IntegrationFailMessage_ACE,
        CommunicationPreferencesLabel_ACE,
        ViewPlanSummary_CardHeader_Refresh_ACE,
        MessageLightningComponent_Warning_ACE,
        SafeMode_ToastMessage_ACE,
        MessageLightningComponent_Error_ACE,
        Clinician_Profile_ACE,
        System_Administrator_profile_ACE,
        CommunicationPreferencesSummary_PreferredPhoneNumber_ACE,
        PermissiontoVoicemailLabel_ACE,
        CommunicationPreferencesSummary_PermissionToLeaveVoiceMail_ACE,
        CommunicationPreferencesSummary_PreferredSpokenLanguage_ACE,
        CommunicationPreferencesSummary_PreferredWrittenLanguage_ACE,
        CommunicationPreferencesSummary_PreferredMailingAddress_ACE,
        CommunicationPreferencesSummary_PreferredPhoneNumberNoVoice_ACE,
        CommunicationPreferencesSummary_PreferredEmailAddress_ACE,
        CommunicationPreferencesSummary_PreferredTextPhoneNumber_ACE,
        ViewBenefits_ViewAll_ACE,
        General_False_ACE,
        MemberAgeMessageLabel_ACE,
        CommMemberAgeMessageLabel_ACE,
        CaseWithoutMemberErrorMessage_ACE,
        ViewCaseSummary_ViewLessLink_ACE,
        LineOfBusinessDefault_ACE,
        Retail_LineOfBusinessLabel_ACE,
        BaseLightningComponent_Error_ACE,
        EnableVPSTabSpecificEvents_ACE,
        HideFEPCommunication
    };
    @api recordId;

    boolDisable = true;

    boolError = false;

    boolMain = false;

    boolShowRefreshIcon = true;

    boolListenMidFromSummary = false;

    boolIntegrationError = false;

    boolSafeModeOfUser = false;

    boolIsLineOfBusinessFEP = false;

    boolIsLineOfBusinessRETAIL = false;

    boolDataAvailable = false;

    boolDentalPlanSelected = false;

    boolSendDataToSMSCmp = false;

    boolSecureDataAvailable = false;

    boolSendDataToSecureCmp = false;

    boolIsLineOfBusinessGovMedicaidNM1 = false;

    boolSendDataToCorrespondenceCmp = true;

    boolProvider = false;

    planSummaryInteractionListener = null;

    strProfileName;

    objCatchError;

    strNewPage = '/lightning/n/Communications';

    strVfHost = this.label.Domain_Visualforce_ACE;

    strMID;

    strDataDivId;

    strTabId;

    strMemberIdToSent;

    strRecordId;

    strGroupNumber;

    strCorpCode;

    strAceLineOfBusiness;

    @track objCommunicationResponseWrapper = null;

    objPlanSummaryListener = null;

    objSafeModeUtilitySummaryListener = null;

    objSafeModeUtilitySummaryGenericListener = null;

    receiverListener = null;

    objPlanSummaryChangeCustomEventListener = null;

    objSubTabCommunicationListener = null;

    strBaseHelperTabInfo;

    strErrorMessage = this.label.IntegrationFailMessage_ACE;

    strDateOfBirth;

    objSelectedPlanDetails = null;

    receiverSMSTextMessageListener = null;

    receiverSecureTextMessageListener = null;

    strRecordError;

    objRecord;

    objAccountRecord;

    strMidSurrogate;

    objTabData;

    idTopDivTemplate = false;

    idCommunicationTemplate = true;

    idCommunicationSafeModeTemplate = false;

    boolSpinner = false;

    boolSubTabListenerActive = false;

    strBaseCurrentTabId;

    strBaseCurrentTabUrl;

    boolBaseIsItSubTab;

    strBaseCurrentParentTabId;
    //CEAS-71659

    boolFireEventFromPlanSummary = false;

    @track birthDateValidation = true;

    boolIsCalloutInitiated = false;

    boolVPSTabSpecificEvents = false;

    @wire(getRecord, { recordId: '$recordId', fields: [MID_Surrogate_ACE_FIELD] })
    wiredRecord({ error, data }) {
        if (error) {
            this.strRecordError = 'Unknown error';
            if (Array.isArray(error.body)) {
                this.strRecordError = error.body.map((e) => e.message).join(', ');
            } else if (typeof error.body.message === 'string') {
                this.strRecordError = error.body.message;
            } else {
                //do nothing
            }
        } else if (data) {
            // Process record data
            this.strMidSurrogate = data.fields.MID_Surrogate_ACE__c.value;
        } else {
            //do nothing
        }
    }

    connectedCallback() {
        this.fetchTabData();
    }

    /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     * All components should have this code.
     */
    fetchTabData = () => {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId)
            .then((objTabData) => {
                this.processTabData(objTabData);
            })
            .catch((error) => {
                //do nothing
            });
        }
    };

    processTabData = (objTabData) => {
        try {
            this.objTabData = objTabData;
            this.strBaseCurrentTabId = this.objTabData.tabId;
            this.strBaseCurrentTabUrl = this.objTabData.url;
            this.boolBaseIsItSubTab = this.objTabData.isSubtab;
            //CEAS-73247 - Get Profile Name from URL.
            const strProfileParam = BaseLWC.helperBaseGetUrlParameters('pfn', this.strBaseCurrentTabUrl);
            if(strProfileParam) {
                this.strProfileName = strProfileParam;
            }
            if (this.boolBaseIsItSubTab === true) {
                this.strBaseCurrentParentTabId = this.objTabData.parentTabId;
            } else {
                this.strBaseCurrentParentTabId = this.objTabData.tabId;
            }
            if (BaseLWC.stringIsNotBlank(this.label.EnableVPSTabSpecificEvents_ACE) && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                this.boolVPSTabSpecificEvents = true;
            }
            this.executeInitialFunctionality();
            this.listenerforHidingViewAll();
        } catch (error) {
            this.handleErrors(error);
        }
    };

    handleErrors = (error) => {
        this.objCatchError = error;
    };
    /*
    Initial Method 
    */

    executeInitialFunctionality() {

        try {
        this.safeModeUtilityComponentListenerForCommCard();
        this.safeModeUtilityGenericComponentListenerForCommCard();
        if (BaseLWC.stringIsNotBlank(this.recordId) && this.recordId.startsWith('500') && !this.boolBaseIsItSubTab) {
            this.idTopDivTemplate = true;
            this.boolShowRefreshIcon = false;
            this.strErrorMessage = this.label.CaseWithoutMemberErrorMessage_ACE;
            this.boolError = true;
            this.boolIsLineOfBusinessGovMedicaidNM1 = false;
        } else if(BaseLWC.stringIsNotBlank(this.recordId) && (this.recordId.startsWith('500') || this.recordId.startsWith('001'))) {
            if (BaseLWC.helperBaseGetUrlParameters('boolPA', this.strBaseCurrentTabUrl) === 'true') {
                this.communicationCardListenerFromVPSCard();
                this.fetchCommunicationPreferences();
                this.setPlanSummaryChangeCustomEventListener();
                this.firePostMessageFromPrimaryTabToSMSTextCmp();
                this.firePostMessageFromPrimaryTabToSecureTextCmp();
                this.firePostMessageFromPrimaryTabToViewCorrespondenceCmp();
            } else if(this.strBaseCurrentTabUrl && BaseLWC.stringIsNotBlank(this.recordId) &&
                     this.recordId.startsWith('500') && 
                     this.strBaseCurrentTabUrl.match(/\?./)?.input?.includes('Account') && !this.strBaseCurrentTabUrl.match(/\?./)?.input?.includes('BaseURLParam')) {
                this.activateSubTabListener();
            } else {
                this.idCommunicationTemplate = false;
                this.idCommunicationSafeModeTemplate = false;
            }
        } else {
                this.communicationCardListenerFromVPSCard();
                this.fetchCommunicationPreferences();
                this.setPlanSummaryChangeCustomEventListener();
                this.firePostMessageFromPrimaryTabToSMSTextCmp();
                this.firePostMessageFromPrimaryTabToSecureTextCmp();
                this.firePostMessageFromPrimaryTabToViewCorrespondenceCmp();
            }
        } catch (error) {
            this.handleErrors(error);
        }
    }

    viewAllPreferences = () => {
        this.subTabHelper();
    };

    /**
     * Method to call the server side controller to get profile name of logged in user and listern the data from event fired by server side controller.
     *
     
     */
    fetchCommunicationPreferences = () => {
        try {
            if (BaseLWC.helperBaseGetUrlParameters('boolProspectMember', this.strBaseCurrentTabUrl) === 'true' && this.idCommunicationTemplate) {
                this.idCommunicationTemplate = false;
            }
            //Set strCaseId attribute for ClickToDial functionality
            this.strRecordId = '';
            if (BaseLWC.stringIsNotBlank(this.recordId)) {
                this.strRecordId = this.recordId;
            }

            if (this.boolBaseIsItSubTab) {
                this.boolSpinner = true;
                if(this.boolSubTabListenerActive === false) {
                    this.activateSubTabListener();
                }
                if(BaseLWC.stringIsNotBlank(this.strBaseCurrentTabId)) {
                    BaseLWC.helperBasePostTabIdMessageCustomEvents('TriggerCommPreferenceData_' + this.strBaseCurrentParentTabId, null, '', 'CommunicationCardDetailsSummary_ACE', this.strBaseCurrentTabId);
                }
                } else {
                const strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.strBaseCurrentTabUrl);
                const objUrl = new URL(strDecodedURL);
                const strUrlMemberId = objUrl.searchParams.get('mid');
                if (strUrlMemberId) {
                    this.strDataDivId = 'dataDivIdCommunicationPreference' + strUrlMemberId;
                    this.strMID = strUrlMemberId;
                    this.strDataDivId = 'strDataDivIdCommunicationPreference' + strUrlMemberId;
                }
                this.boolSpinner = true;
                this.parentTabCallout();
                if(!this.strProfileName) {
                    this.fetchProfileDetails();
                }
            }
        } catch (objException) {
            //Do Nothing.
        }
    };

    //Get Profile Name
    fetchProfileDetails() {
        profileDetails({})
        .then((objProfileDetailsResult) => {
            try {
                const strProfileName = objProfileDetailsResult;
                this.strProfileName = strProfileName;
            } catch (exception) {
                //No handling Needed.
            }
        })
        .catch(() => {
            //do nothing
        });
    }

    subTabHelper = () => {
        try {
            let strNewPage;
            if (BaseLWC.isUndefinedOrNullOrBlank(this.strMID)) {
                strNewPage = this.strNewPage;
            } else {
                strNewPage = this.strNewPage + '/?mid=' + this.strMID + '&corpCode=' + this.strCorpCode + '&groupNumber=' + this.strGroupNumber;
            }
            strNewPage = BaseLWC.helperBaseEncodeUrl(strNewPage);
            if (BaseLWC.stringIsNotBlank(this.strBaseCurrentParentTabId)) {
                openSubtab(this.strBaseCurrentParentTabId, {url: strNewPage, focus: true});
            }
        } catch (objException) {
            //Do Nothing.
        }
    };

    /**
     * Subtab Listener
     * @returns 
     */
    activateSubTabListener() {
        
        if (BaseLWC.isUndefinedOrNullOrBlank(this.objSubTabCommunicationListener)) {
            const objSubTabCommunicationListener = (objEventData) => {
                try {
                    if (BaseLWC.isUndefinedOrNullOrBlank(this.objCommunicationResponseWrapper)) {
                        const strBaseResponse = BaseLWC.helperBaseGetDataForCustomEvents(objEventData, '', 'CommunicationCardDetailsSummary_ACE');
                        if (strBaseResponse === undefined) {
                            return;
                        } else {
                            if (strBaseResponse === this.label.BaseLightningComponent_Error_ACE) {
                                this.boolError = true;
                                //no functions exists in aura
                                this.postErrorStatusHelper();
                                this.boolSpinner = false;
                            } else if (
                                JSON.parse(strBaseResponse).objParameters.objMessage.boolIntegrationError === true &&
                                JSON.parse(strBaseResponse).objParameters.strParentTabId === this.strBaseCurrentParentTabId
                            ) {
                                this.boolError = true;
                                this.boolSpinner = false;
                                this.idTopDivTemplate = true;
                                this.boolShowRefreshIcon = false;
                                window.removeEventListener('CommunicationPreferenceEvent_' + this.strBaseCurrentParentTabId, objSubTabCommunicationListener);
                                this.boolSubTabListenerActive = false;
                            } else {
                                if (
                                    JSON.parse(strBaseResponse).strIdDestination === 'CommunicationCardDetailsSummary_ACE' &&
                                    JSON.parse(strBaseResponse).objParameters.strParentTabId === this.strBaseCurrentParentTabId
                                ) {
                                    this.boolSpinner = false;
                                    this.boolError = false;
                                    this.idTopDivTemplate = true;
                                    this.objCommunicationResponseWrapper = JSON.parse(strBaseResponse).objParameters.objMessage.objCommunicationDetails;
                                    this.setBirthDateValidation();
                                    this.strProfileName = JSON.parse(strBaseResponse).objParameters.objMessage.strProfileName;
                                    this.boolIsLineOfBusinessFEP = JSON.parse(strBaseResponse).objParameters.objMessage.boolIsLineOfBusinessFEP;
                                    this.boolProvider = JSON.parse(strBaseResponse).objParameters.objMessage.boolProvider;
                                    this.boolIsLineOfBusinessRETAIL = JSON.parse(strBaseResponse).objParameters.objMessage.boolIsLineOfBusinessRETAIL;
                                    this.boolShowRefreshIcon = false;
                                    if (BaseLWC.isNotUndefinedOrNull(JSON.parse(strBaseResponse).objParameters.objMessage.boolIsLineOfBusinessGovMedicaidNM1)) {
                                        this.boolIsLineOfBusinessGovMedicaidNM1 = JSON.parse(strBaseResponse).objParameters.objMessage.boolIsLineOfBusinessGovMedicaidNM1;
                                    }
                                    this.setSafeModeMessage(JSON.parse(strBaseResponse).objParameters.objMessage.boolSafeModeEnabled);

                                    // turning off the Event Listener once the valid message is received, processed.
                                    window.removeEventListener('CommunicationPreferenceEvent_' + this.strBaseCurrentParentTabId, objSubTabCommunicationListener);
                                    this.boolSubTabListenerActive = false;
                                }
                            }
                        }
                    }
                } catch (exception) {
                    /*Do nothing */
                }
            };
            this.objSubTabCommunicationListener = objSubTabCommunicationListener;
            if(this.boolSubTabListenerActive === false) {
            window.addEventListener('CommunicationPreferenceEvent_' + this.strBaseCurrentParentTabId, objSubTabCommunicationListener, false);
            this.boolSubTabListenerActive = true;
            }
        }
    }
    /**
     * Communication Callout
     * @returns 
     */
    parentTabCallout() {
        try {
            let strUrlMemberId;
            let strMemberIdToSent;
            let strGetMidFromAccountRecord;
            const strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.strBaseCurrentTabUrl);
            const objUrl = new URL(strDecodedURL);
            strUrlMemberId = objUrl.searchParams.get('mid');
            //CEAS-71659
            if(objUrl.searchParams.get('groupNumber')) {
                this.strGroupNumber = objUrl.searchParams.get('groupNumber');
            }
            if(objUrl.searchParams.get('corpCode')) {
                this.strCorpCode = objUrl.searchParams.get('corpCode');
            }

            //If mid from URL is not defined or null call getUrlParameters helper method.
            if (strUrlMemberId === undefined || strUrlMemberId === null) {
                strUrlMemberId = BaseLWC.helperBaseGetUrlParameters('mid', this.strBaseCurrentTabUrl);
            }

            //If Mid is available then the detail to vf Page to fetch the Communication Preferences details.
            if (strUrlMemberId) {
                strMemberIdToSent = strUrlMemberId;
                this.strDataDivId = 'dataDivIdCommunicationPreference' + strUrlMemberId;
                this.strMID = strUrlMemberId;
                this.strDataDivId = 'strDataDivIdCommunicationPreference' + strUrlMemberId;
            } else {
                //Fetch mid from SFDC record ID.
                strGetMidFromAccountRecord = this.strMidSurrogate;
                if (strGetMidFromAccountRecord) {
                    strMemberIdToSent = strGetMidFromAccountRecord;
                    this.strDataDivId = 'dataDivIdCommunicationPreference' + strMemberIdToSent;
                    this.strMID = strUrlMemberId;
                    this.strDataDivId = 'strDataDivIdCommunicationPreference' + strMemberIdToSent;
                } else {
                    this.boolListenMidFromSummary = true;
                    this.idTopDivTemplate = true;
                    this.boolError = true;
                    this.boolSpinner = false;
                    return;
                }
            }
            this.strMemberIdToSent = strMemberIdToSent;
            this.onSubmitRequestHelper();
        } catch (exception) {
            /*Do nothing */
        }
    }

    communicationCardListenerFromVPSCard = () => {
        try {
            if (this.boolBaseIsItSubTab) {
                return;
            }
            if (BaseLWC.isUndefinedOrNullOrBlank(this.objPlanSummaryListener)) {
                const objPlanSummaryListener = (objPlanEvent) => {
                    if (objPlanEvent !== null && objPlanEvent !== undefined && objPlanEvent.detail !== null && typeof objPlanEvent.detail === 'string') {
                       
                        //69682
                        if (this.objPlanSummaryListener === undefined) {
                            if (this.boolVPSTabSpecificEvents) {
                                window.removeEventListener('PlanSummaryEvent_' + this.strBaseCurrentParentTabId, objPlanSummaryListener, false);
                            } else {
                                window.removeEventListener('PlanSummaryEvent', objPlanSummaryListener, false);
                            }
                        }
                        let strParsedData;
                        try {
                            strParsedData = JSON.parse(objPlanEvent.detail);
                            if (strParsedData === undefined || strParsedData === null) {
                                return;
                            }
                            //Fetch data from View plan summary component.
                            if (
                                strParsedData.strIdDestination &&
                                strParsedData.strIdDestination === 'PlanCardDetails_ACE' &&
                                strParsedData.objParameters &&
                                strParsedData.objParameters.strParentTabId &&
                                strParsedData.objParameters.strParentTabId === this.strBaseCurrentTabId   
                            ) {
                                this.objSelectedPlanDetails = strParsedData.objParameters.objMessage.objSelectedPlanDetails;
                                if (BaseLWC.isNotUndefinedOrNull(this.objSelectedPlanDetails)) {
                                    //69682
                                    if (this.boolVPSTabSpecificEvents) {
                                        window.removeEventListener('PlanSummaryEvent_' + this.strBaseCurrentParentTabId, objPlanSummaryListener, false);
                                    } else {
                                        window.removeEventListener('PlanSummaryEvent', objPlanSummaryListener, false);
                                    }
                                }
                                this.processPlanData(strParsedData.objParameters.objMessage.objSelectedPlanDetails, strParsedData.objParameters.objMessage.lstFamilyDetails);
                            }
                        } catch (objException) {
                            // Do nothing
                        }
                    }
                };
                this.objPlanSummaryListener = objPlanSummaryListener;
                //69682
                if (this.boolVPSTabSpecificEvents) {
                    window.addEventListener('PlanSummaryEvent_' + this.strBaseCurrentParentTabId, objPlanSummaryListener, false);
                } else {
                    window.addEventListener('PlanSummaryEvent', objPlanSummaryListener, false);
                }
            }
        } catch (objException) {
            //Do Nothing.
        }
    };
    processPlanData = (planData, familyData) => {
        const strMIDFromVPSCard = planData.strMemberId;
        this.objSelectedPlanDetails = planData;
        this.strMemberIdToSent = strMIDFromVPSCard;
        this.strMID = strMIDFromVPSCard;
        this.strDataDivId = 'dataDivIdCommunicationPreference' + strMIDFromVPSCard;
        this.strMID = strMIDFromVPSCard;
        this.strDataDivId = 'strDataDivIdCommunicationPreference' + strMIDFromVPSCard;
        this.strGroupNumber = planData.strGroupNumber;
        this.strCorpCode = planData.strCorporationCode;
        this.boolIsLineOfBusinessFEP = planData.boolIsLineOfBusinessFEP;
        this.strAceLineOfBusiness = planData.strAceLineOfBusiness;
        //CEAS-52321--added to get the DOB
        //CEAS-56338 - Fetch correct DOB
        //CEAS-58640 - Comapre MID instead of firstname and lastname.
        const strMemberId = planData.strMemberId;
        for (let i = 0; i < familyData.length; i++) {
            if (familyData[i].strMemberId === strMemberId) {
                this.strDateOfBirth = familyData[i].strDateOfBirth;
            }
        }
        if (BaseLWC.isNotUndefinedOrNull(this.objSelectedPlanDetails)) {
            this.setBoolDentalPlanSelected(this.objSelectedPlanDetails);
        }
        if (this.strAceLineOfBusiness && this.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICAID' && this.strCorpCode && this.strCorpCode.toUpperCase() === 'NM1') {
            this.boolIsLineOfBusinessGovMedicaidNM1 = true;
        }
        if (this.strAceLineOfBusiness && this.strAceLineOfBusiness.toUpperCase() === 'RETAIL') {
            this.boolIsLineOfBusinessRETAIL = true;
        }
        if (this.boolSafeModeOfUser !== true) {
            this.idCommunicationTemplate = true;
            if (
                planData &&
                planData.strMemberId 
            ) {
                
                if(this.boolIsCalloutInitiated) {
                    if(this.boolDataAvailable && !this.boolError) {
                        this.fireCommunicationDatefromPlanSummaryResponse();
                        this.boolFireEventFromPlanSummary = true;
                        this.boolSpinner = false;
                    } else {
						this.boolFireEventFromPlanSummary = true;
					}
                } else {
                    this.boolSpinner = true;
                    this.boolFireEventFromPlanSummary = true;
                    this.onSubmitRequestHelper();
                }
            }
        } else {
            this.boolSpinner = false;
        }
    }
    setPlanSummaryChangeCustomEventListener = () => {
        if (BaseLWC.isUndefinedOrNullOrBlank(this.objPlanSummaryChangeCustomEventListener)) {
            if (this.boolBaseIsItSubTab) {
                return;
            }
            const objPlanSummaryChangeCustomEventListener = (objEventData) => {
                try {
                    if (objEventData.detail !== undefined && objEventData.detail !== null &&
                        typeof objEventData.detail === 'string') {
                        const objParsedEventDetail = JSON.parse(objEventData.detail);
                        if (BaseLWC.isNotUndefinedOrNull(objParsedEventDetail.strIdDestination) && objParsedEventDetail.objParameters.strParentTabId === this.strBaseCurrentTabId &&
                            objParsedEventDetail.strIdDestination === "PlanChangedDetails_PlanSummary_ACE" && objParsedEventDetail.objParameters.objMessage) {
                            if (BaseLWC.isNotUndefinedOrNull(objParsedEventDetail.objParameters.objMessage)) {
                                this.setBoolDentalPlanSelected(objParsedEventDetail.objParameters.objMessage);
                            }
                            this.boolDataAvailable = false;
                            this.boolIsCalloutInitiated = false;
                            this.boolError = false;
                            this.boolFireEventFromPlanSummary = false;
                            this.processPlanData(objParsedEventDetail.objParameters.objMessage, objParsedEventDetail.objParameters.objMessage.lstFamilyWrapper);
                        }
                    } else {
                        // Do nothing
                    }
                } catch (exception) {
                    //do nothing
                }
            };
            this.objPlanSummaryChangeCustomEventListener = objPlanSummaryChangeCustomEventListener;
            if (this.boolVPSTabSpecificEvents) {
                window.addEventListener('PlanChangedCustomEvent_' + this.strBaseCurrentParentTabId, objPlanSummaryChangeCustomEventListener, false);
            } else {
                window.addEventListener('PlanChangedCustomEvent', objPlanSummaryChangeCustomEventListener, false);
            }
        }
    };

    setSafeModeMessage = (boolSafeModeEnabled) => {
        if (boolSafeModeEnabled === true) {
            this.idCommunicationSafeModeTemplate = true;
            this.idCommunicationTemplate = false;
            this.boolSpinner = false;
        } else if (boolSafeModeEnabled === false) {
            this.idCommunicationTemplate = true;
            this.idCommunicationSafeModeTemplate = false;
            this.idCommunicationTemplate = true;
        } else {
            //Do Nothing
        }
    };

    listenerforHidingViewAll = () => {
        const strPlanSummaryInteractionEvent = 'PlanSummaryInteractionEvent' + '_' + this.strBaseCurrentTabId;
        const strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.strBaseCurrentTabUrl);
        const objUrl = new URL(strDecodedURL);
        const strProviderSearch = objUrl.searchParams.get('ProviderSearch');
        const strPlanSummaryInteractionDestinationId = 'PlanSummaryInteractionEvent_' + this.strBaseCurrentTabId;
        if (BaseLWC.isNotUndefinedOrNull(strProviderSearch) && (strProviderSearch === 'true' || strProviderSearch === true)) {
            this.boolProvider = true;
        } else {
            this.boolProvider = false;
        }
        if (BaseLWC.isUndefinedOrNullOrBlank(this.planSummaryInteractionListener)) {
            const planSummaryInteractionListener = (objListenerEvent) => {
                if (BaseLWC.isUndefinedOrNullOrBlank(this.planSummaryInteractionListener)) {
                    window.removeEventListener(strPlanSummaryInteractionEvent, planSummaryInteractionListener, false);
                }
                let objLocalStorageData;
                if (BaseLWC.isNotUndefinedOrNull(objListenerEvent) && typeof objListenerEvent.detail === 'string') {
                    try {
                        objLocalStorageData = JSON.parse(objListenerEvent.detail);
                    } catch (objException) {
                        // Do nothing
                    }
                    if (objLocalStorageData.strIdDestination !== strPlanSummaryInteractionDestinationId) {
                        return;
                    }
                    if (
                        BaseLWC.isNotUndefinedOrNull(objLocalStorageData) &&
                        BaseLWC.isNotUndefinedOrNull(objLocalStorageData.objParameters) &&
                        BaseLWC.isNotUndefinedOrNull(objLocalStorageData.objParameters.objMessage)
                    ) {
                        const boolIsProvider = objLocalStorageData.objParameters.objMessage.boolIsProvider;
                        if ((BaseLWC.isNotUndefinedOrNull(boolIsProvider) && (boolIsProvider === 'true' || boolIsProvider === true)) || this.boolProvider) {
                            this.boolProvider = true;
                        } else if (BaseLWC.isNotUndefinedOrNull(boolIsProvider) && (boolIsProvider === 'false' || boolIsProvider === false)) {
                            this.boolProvider = false;
                        } else {
                            /* Do Nothing*/
                        }
                    }
                }
            };
            this.planSummaryInteractionListener = planSummaryInteractionListener;
            window.addEventListener(strPlanSummaryInteractionEvent, planSummaryInteractionListener, false);
        }
    };

    setBoolDentalPlanSelected = (objPlanDetails) => {
        try {
            const STRING_POLICY_TYPE_CODE_D = 'Dent';
            const lstHideDentalForLOB = [this.label.LineOfBusinessDefault_ACE, this.label.Retail_LineOfBusinessLabel_ACE];
            if (objPlanDetails.strPlanTypeCode === STRING_POLICY_TYPE_CODE_D && lstHideDentalForLOB.indexOf(objPlanDetails.strAceLineOfBusiness) > -1) {
                this.boolDentalPlanSelected = true;
            } else {
                this.boolDentalPlanSelected = false;
            }
        } catch (exception) {
            //Do nothing
        }
    };
    sendMessageToSecureMessageCmpHelper = () => {
        try {
            let strEmail = null;
            if (BaseLWC.isNotUndefinedOrNull(this.objCommunicationResponseWrapper)) {
                strEmail = this.objCommunicationResponseWrapper.strEmail;
            }

            if (this.boolDataAvailable) {
                this.boolSendDataToSecureCmp = false;
            } else {
                this.boolSendDataToSecureCmp = true;
            }

            if (BaseLWC.isNotUndefinedOrNull(this.objTabData)) {
                const strParameterToBeSent = {
                    strEmail: strEmail,
                    boolDataAvailable: this.boolDataAvailable,
                    boolIntegrationError: this.boolIntegrationError
                };
                BaseLWC.helperBasePostTabIdMessageCustomEvents(
                    'GetDataFromCommPrefEventSecure' + this.strBaseCurrentParentTabId,
                    null,
                    strParameterToBeSent,
                    'SecureTextMessage_ACE',
                    this.strBaseCurrentTabId
                );
            }
        } catch (objException) {
            //Do Nothing
        }
    };
    firePostMessageFromPrimaryTabToSecureTextCmp = () => {
        if (!this.boolBaseIsItSubTab) {
            const strEventName = 'TriggerGetDataFromCommPrefSecure' + this.strBaseCurrentParentTabId;
            window.addEventListener(
                strEventName,
                () => {
                    this.sendMessageToSecureMessageCmpHelper();
                },
                false
            );
        }
    };

    //Rahul Starts Here
    /**
     * Method to post message recursive setTimeout of 1 second.
     *
     * Rahul
     */
    firePostMessageFromPrimaryTabToSubTab = () => {
        if (BaseLWC.isUndefinedOrNullOrBlank(this.receiverListener)) {
            const objCommPreferenceData = () => {
                try {
                    if (this.receiverListener === null) {
                        window.removeEventListener('TriggerCommPreferenceData_' + this.strBaseCurrentParentTabId, objCommPreferenceData, false);
                    }

                    if (!this.boolBaseIsItSubTab) {
                        const objErrorData = {};
                        objErrorData.strComponentName = 'lwcCommunicationPreferencesSummary_ACE';
                        objErrorData.strMessage = 'SetIntervals';
                        objErrorData.strFunctionName = 'firePostMessageFromPrimaryTabToSubTab';
                        objErrorData.strStackTrace = 'MaxIntervalReached;\nClearedInterval;\n';
                        objErrorData.strError = 'Profile Name Loading Issue: ' + this.strProfileName;
                        if (BaseLWC.isNotUndefinedOrNull(this.strProfileName)) {
                            const strParameterToBeSent = {
                                objCommunicationDetails: this.objCommunicationResponseWrapper,
                                strProfileName: this.strProfileName,
                                boolIntegrationError: this.boolIntegrationError,
                                boolSafeModeEnabled: this.boolSafeModeOfUser,
                                boolIsLineOfBusinessFEP: this.boolIsLineOfBusinessFEP,
                                boolProvider: this.boolProvider,
                                boolIsLineOfBusinessRETAIL: this.boolIsLineOfBusinessRETAIL,
                                boolIsLineOfBusinessGovMedicaidNM1: this.boolIsLineOfBusinessGovMedicaidNM1,
                                strAceLineOfBusiness: this.strAceLineOfBusiness
                            };
                            setTimeout(function () { 
                                //NT: CEAS-76682 Timeout added to ensure listener ready 
                                //on initial load from DynamicCaseCreation Aura Component
                                BaseLWC.helperBasePostTabIdMessageCustomEvents(
                                    'CommunicationPreferenceEvent_' + this.strBaseCurrentParentTabId,
                                    null,
                                    strParameterToBeSent,
                                    'CommunicationCardDetailsSummary_ACE',
                                    this.strBaseCurrentTabId
                                )
                            }.bind(this), 3000);
                        }
                    }
                } catch (objException) {
                    //Do Nothing.
                }
            };
            this.receiverListener = objCommPreferenceData;
            window.addEventListener('TriggerCommPreferenceData_' + this.strBaseCurrentParentTabId, objCommPreferenceData, false);
        }
    };

    /**
     * Method to post the message to continuation method onload and Refresh the component.
     *
     *
     */
    onSubmitRequestHelper() {
        try {
            this.boolSpinner = true;

            //CEAS-52321-->pass birthDate to show CommPref Card Details fro MCP
            try {
                if (BaseLWC.isNotUndefinedOrNull(this.strMemberIdToSent) && BaseLWC.isNotUndefinedOrNull(this.strGroupNumber) && BaseLWC.isNotUndefinedOrNull(this.strCorpCode) && !this.boolIsCalloutInitiated) {
                    this.boolIsCalloutInitiated = true;
                    getCommunicationPreferencesMethod({
                        strMemberId: this.strMemberIdToSent,
                        strGroupNumber: this.strGroupNumber,
                        strCorpCode: this.strCorpCode
                    })
                        .then((result) => {
                            try {
                                this.boolSpinner = true;
                                if (result) {
                                    const objResult = JSON.parse(result);
                                    if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                                        this.idTopDivTemplate = true;
                                    } else {
                                        this.boolError = true;
                                        this.boolSpinner = false;
                                    }
                                    const staCode = objResult.strStatusCode;
                                    if (objResult && staCode === '200') {
                                        if (objResult.strMemberId) {
                                            this.boolSpinner = false;

                                            this.boolError = false;
                                            this.objCommunicationResponseWrapper = objResult;
                                            this.boolDataAvailable = true;

                                            if (this.boolSendDataToSMSCmp) {
                                                this.sendMessageToSMSTextCmpHelper();
                                            }
                                            if (this.boolSendDataToSecureCmp) {
                                                this.sendMessageToSecureMessageCmpHelper();
                                            }
                                            if (this.boolSendDataToCorrespondenceCmp) {
                                                this.sendMessageToViewCorrespondenceCmpHelper();
                                            }
                                            if(this.boolFireEventFromPlanSummary) {
                                                this.fireCommunicationDatefromPlanSummaryResponse();
                                            }
                                        }
                                    } else if (objResult && staCode === 403) {
                                        const strRedirectUrl = objResult.strResponseBody;
                                        window.open(strRedirectUrl.replace(/&amp;/g, '&'), '_top');
                                    } else {
                                        this.boolSpinner = false;
                                        this.boolError = true;
                                        this.boolIntegrationError = true;

                                        this.fireCommunicationDataOnSuccess();

                                        
                                        BaseLWC.helperBasePostTabIdMessageCustomEvents(
                                            'CommunicationPreferredNamePreferenceEvent_' + this.strBaseCurrentParentTabId,
                                            null,
                                            '',
                                            'CommunicationPreferenceError_' + this.strMID + this.strBaseCurrentTabId,
                                            this.strBaseCurrentTabId
                                        );

                                        this.boolDataAvailable = true;
                                        if (this.boolSendDataToSMSCmp) {
                                            this.sendMessageToSMSTextCmpHelper();
                                        }
                                    }
                                }
                            } catch (objException) {
                                this.boolError = true;
                                this.boolSpinner = false;
                            }
                        })
                        .catch(() => {
                            //Do Nothing;
                            this.boolError = true;
                            this.boolSpinner = false;
                        });
                }
            } catch (objException) {
                //do nothing
            }
        } catch (objException) {
            //Do Nothing.
        }
    }
    /*
    # fire commuication on success
    #Rahul
    */
    fireCommunicationDatefromPlanSummaryResponse() {
        //CEAS-52321--shifting the DOB calculation logic here.
        const strDateOfBirth = this.strDateOfBirth;
        if (BaseLWC.isNotUndefinedOrNull(strDateOfBirth)) {
            const today = new Date().toISOString().slice(0, 10);
            const strYearOfBirth = strDateOfBirth.split('-', 3)[0];
            const strMonthOfBirth = strDateOfBirth.split('-', 3)[1];
            const strDayOfBirth = strDateOfBirth.split('-', 3)[2];
            const datDateOfBirth = new Date(strYearOfBirth, strMonthOfBirth, strDayOfBirth).toISOString().slice(0, 10);
            const monthsBtwnDates = (datDateOfBirth, today) => {
                const startDate = new Date(datDateOfBirth);
                const endDate = new Date(today);
                return Math.max((endDate.getFullYear() - startDate.getFullYear()) * 12 + endDate.getMonth() - startDate.getMonth(), 0);
            };
            this.objCommunicationResponseWrapper.strBirthDate = Math.round(monthsBtwnDates(datDateOfBirth, today) / 12);
            this.setBirthDateValidation();
        }

        //Posting Data  to load the Communication Preferences Card while opening SubTab instead of making an apex callout.
        this.firePostMessageFromPrimaryTabToSubTab();
        
        this.fireCommunicationDataOnSuccess();
       

        if (BaseLWC.isNotUndefinedOrNull(this.strMID)) {
            const objMessage = {
                objParameters: {
                    strMessage: this.objCommunicationResponseWrapper.objPreferredNameWrapper.name,
                    objAddress: JSON.stringify(this.objCommunicationResponseWrapper.objAddress),
                    strEmail: this.objCommunicationResponseWrapper.strEmail,
                    strLanguage: this.objCommunicationResponseWrapper.strWrittenLanguage,
                    nativeLanguagePreference: this.objCommunicationResponseWrapper.nativeLanguagePreference
                }
            };
            BaseLWC.helperBasePostTabIdMessageCustomEvents(
                'CommunicationPreferredNamePreferenceEvent_' + this.strBaseCurrentParentTabId,
                null,
                objMessage,
                'CommunicationPreference_' + this.strMID + this.strBaseCurrentTabId,
                this.strBaseCurrentTabId
            );
        }
    }
    fireCommunicationDataOnSuccess() {
        if (BaseLWC.isNotUndefinedOrNull(this.strProfileName)) {
            const strParameterToBeSent = {
                objCommunicationDetails: this.objCommunicationResponseWrapper,
                strProfileName: this.strProfileName,
                boolIntegrationError: this.boolIntegrationError,
                boolSafeModeEnabled: this.boolSafeModeOfUser,
                boolIsLineOfBusinessGovMedicaidNM1: this.boolIsLineOfBusinessGovMedicaidNM1
            };
            BaseLWC.helperBasePostTabIdMessageCustomEvents('CommunicationPreferenceEvent_' + this.strBaseCurrentParentTabId, null, strParameterToBeSent, 'CommunicationCardDetailsSummary_ACE', this.strBaseCurrentTabId)
                .then(function () {
                    //Do Nothing.
                })
                .catch(function () {
                    //Do Nothing
                });
        }
    }
    /**
     * Method to listen to Safe Mode Listener
     *
     */
    safeModeUtilityComponentListenerForCommCard() {
        try {
            const strTabId = this.objTabData.tabId;
            const strSafeModeModalEventName = 'SafeModeModalEventOnTab_ACE_' + strTabId;
            const strSafeModeModalEventDestinationId = 'SafeModeModalEventIdOnTab_ACE_' + strTabId;
            if (BaseLWC.isUndefinedOrNullOrBlank(this.objSafeModeUtilitySummaryListener)) {
                const objSafeModeSummaryListener = (objEventData) => {
                    if (objEventData !== null && objEventData.detail !== null && typeof objEventData.detail === 'string') {
                        if (this.objSafeModeUtilitySummaryListener === undefined) {
                            window.removeEventListener(strSafeModeModalEventName, objSafeModeSummaryListener, false);
                        }
                        const strParsedData = JSON.parse(objEventData.detail);
                        if (strParsedData.strIdDestination && strParsedData.strIdDestination === strSafeModeModalEventDestinationId) {
                            this.boolSafeModeOfUser = strParsedData.boolSafeModeEnabled;
                            this.setSafeModeMessage(strParsedData.boolSafeModeEnabled);
                        }
                    }
                };
                this.objSafeModeUtilitySummaryListener = objSafeModeSummaryListener;
                window.addEventListener(strSafeModeModalEventName, objSafeModeSummaryListener, false);
            }
        } catch (objException) {
            //Do Nothing.
        }
    }

    /**
     * Method to listen to Safe Mode Listener
     *
     */
    safeModeUtilityGenericComponentListenerForCommCard() {
        try {
            const strSafeModeModalGenericEventName = 'SafeModeModalHCDEvent_ACE';
            const strSafeModeModalEventGenericDestinationId = 'SafeModeModalHCDEventId_ACE';
            if (BaseLWC.isUndefinedOrNullOrBlank(this.objSafeModeUtilitySummaryGenericListener)) {
                const objSafeModeSummaryGenericListener = (objEventData) => {
                    if (objEventData !== null && objEventData.detail !== null && typeof objEventData.detail === 'string') {
                        if (this.objSafeModeUtilitySummaryGenericListener === undefined) {
                            window.removeEventListener(strSafeModeModalGenericEventName, objSafeModeSummaryGenericListener, false);
                        }
                        const strParsedData = JSON.parse(objEventData.detail);
                        if (strParsedData.strIdDestination && strParsedData.strIdDestination === strSafeModeModalEventGenericDestinationId) {
                            this.boolSafeModeOfUser = strParsedData.objMessage;
                            this.setSafeModeMessage(strParsedData.objMessage);
                        }
                    }
                };
                this.objSafeModeUtilitySummaryGenericListener = objSafeModeSummaryGenericListener;
                window.addEventListener(strSafeModeModalGenericEventName, objSafeModeSummaryGenericListener, false);
            }
        } catch (objException) {
            //Do Nothing.
        }
    }
    firePostMessageFromPrimaryTabToSMSTextCmp = () => {
        if (!this.boolBaseIsItSubTab) {
            const strEventName = 'TriggerGetDataFromCommPref_' + this.strBaseCurrentTabId;

            window.addEventListener(
                strEventName,
                () => {
                    this.sendMessageToSMSTextCmpHelper();
                },
                false
            );
        }
    };

    sendMessageToSMSTextCmpHelper() {
        try {
            let strPreferredTextPhoneNumber = null;
            if (this.objCommunicationResponseWrapper) {
                strPreferredTextPhoneNumber = this.objCommunicationResponseWrapper.strPreferredPhoneNumberText;
            }

            if (this.boolDataAvailable) {
                this.boolSendDataToSMSCmp = false;
            } else {
                this.boolSendDataToSMSCmp = false;
            }

            if (BaseLWC.stringIsNotBlank(this.strBaseCurrentTabId)) {
                if (this.boolBaseIsItSubTab === false) {
                    if (this.objSelectedPlanDetails !== null && this.objSelectedPlanDetails !== undefined) {
                        const strParameterToBeSent = {
                            objSelectedPlanSummaryData: this.objSelectedPlanDetails,
                            strPreferredTextPhoneNumber: strPreferredTextPhoneNumber,
                            boolDataAvailable: this.boolDataAvailable,
                            boolIntegrationError: this.boolIntegrationError
                        };
                        BaseLWC.helperBasePostTabIdMessageCustomEvents(
                            'GetDataFromCommPrefEvent_' + this.strBaseCurrentParentTabId,
                            null,
                            strParameterToBeSent,
                            'SMSTextMessage_ACE',
                            this.strBaseCurrentTabId
                        );
                    }
                }
            }
        } catch (objException) {
            //Do Nothing
        }
    }

    firePostMessageFromPrimaryTabToViewCorrespondenceCmp = () => {
        if (!this.boolBaseIsItSubTab) {
            const strEventName = 'TriggerGetDataFromCommPrefForViewCorrespondence_' + this.strBaseCurrentParentTabId;

            window.addEventListener(
                strEventName,
                () => {
                    this.sendMessageToViewCorrespondenceCmpHelper();
                },
                false
            );
        }
    };

    //Rahul
    sendMessageToViewCorrespondenceCmpHelper = () => {
        try {
            let strEmail = null;
            if (this.objCommunicationResponseWrapper) {
                strEmail = this.objCommunicationResponseWrapper.strEmail;
            }

            if (this.boolDataAvailable) {
                this.boolSendDataToCorrespondenceCmp = false;
            } else {
                this.boolSendDataToCorrespondenceCmp = true;
            }

            if (BaseLWC.stringIsNotBlank(this.strBaseCurrentTabId)) {
                const strParameterToBeSent = {
                    strEmail: strEmail,
                    boolDataAvailable: this.boolDataAvailable,
                    boolIntegrationError: this.boolIntegrationError
                };
                BaseLWC.helperBasePostTabIdMessageCustomEvents(
                    'GetDataFromCommPrefForViewCorrespondenceEvent_' + this.strBaseCurrentParentTabId,
                    null,
                    strParameterToBeSent,
                    'CommDataToViewCorrespondence_ACE',
                    this.strBaseCurrentTabId
                );
            }
        } catch (objException) {
            //Do Nothing
        }
    };
    getCommunicationPreferences = () => {
        this.boolIsCalloutInitiated = false;
        this.parentTabCallout();
    };
    setBirthDateValidation = () => {
        if (this.objCommunicationResponseWrapper.strBirthDate >= 18 || this.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICAID') {
            this.birthDateValidation = true;
        } else {
            this.birthDateValidation = false;
        }
    }
    get profileValidation() {
        if ((this.strProfileName === this.label.Clinician_Profile_ACE || this.strProfileName === this.label.System_Administrator_profile_ACE) && !this.boolIsLineOfBusinessFEP) {
            return true;
        } else {
            return false;
        }
    }
    get boolshowcardFEP() {
        if(this.label.HideFEPCommunication === 'true' && this.boolIsLineOfBusinessFEP) {
            return false;
        } else {
            return true;
        }
    }

    disconnectedCallback() {
        const strPlanSummaryInteractionEvent = 'PlanSummaryInteractionEvent' + '_' + this.strBaseCurrentTabId;
        const strSafeModeModalEventName = 'SafeModeModalEventOnTab_ACE_' + this.strBaseCurrentTabId;
        const strSafeModeModalGenericEventName = 'SafeModeModalHCDEvent_ACE'; 
        //69682
        if (this.boolVPSTabSpecificEvents) {
            window.removeEventListener('PlanSummaryEvent_' + this.strBaseCurrentParentTabId, this.objPlanSummaryListener, false);
            window.removeEventListener('PlanChangedCustomEvent_' + this.strBaseCurrentParentTabId, this.objPlanSummaryChangeCustomEventListener, false);
        } else {
            window.removeEventListener('PlanSummaryEvent', this.objPlanSummaryListener, false);
            window.removeEventListener('PlanChangedCustomEvent', this.objPlanSummaryChangeCustomEventListener, false);
        }
        window.removeEventListener(strPlanSummaryInteractionEvent, this.planSummaryInteractionListener, false);
        window.removeEventListener('TriggerCommPreferenceData_' + this.strBaseCurrentParentTabId, this.receiverListener, false); 
        window.removeEventListener(strSafeModeModalEventName, this.objSafeModeUtilitySummaryListener, false);
        window.removeEventListener(strSafeModeModalGenericEventName, this.objSafeModeUtilitySummaryGenericListener, false);
        if (this.boolBaseIsItSubTab) {
            window.removeEventListener('CommunicationPreferenceEvent_' + this.strBaseCurrentParentTabId, this.objSubTabCommunicationListener, false); 
            this.boolSubTabListenerActive = false;
        }
    }
}
