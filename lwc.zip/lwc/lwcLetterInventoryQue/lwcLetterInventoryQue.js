import { LightningElement,track,wire,api } from 'lwc';
import fetchLetterInventoryData from '@salesforce/apex/CaseRelatedTableController_ACE.fetchLetterInventory';
import BaseLWC from 'c/baseLWCFunctions_CF';

export default class LwcLetterInventoryQue extends LightningElement {
    letterInventoryData;

    letterInventoryCodes = [];
    letterOutputData ={
        original_claim_id : '',
        check_no : '',
        precert_phone : '',
        procedure_code: '',
        reason_text: '',
        claim_id : '',
        coverage_start_date: '',
        coverage_end_date: '',        
		reason_codes_section: []
    }
    boolSpinner = false;
    strMbrEffDate = 'MBR EFF DATE';
    strMbrCancelDate = 'MBR CANCEL DATE';
    strDateFormat = 'MM/DD/YYYY';
    strPrecertificationPhNum = 'PRECERTIFICATION PHONE NUMBER';
    strPhoneNumFormat = '(xxx) xxx-xxxx';
    strAdditionalInfo = '<Enter information not listed above.>';
    @track modalClass = 'slds-modal_hidden';
    @track isModalShow=false;
    @api lettername;
    @track letterNameCaps;
    @track disablePreviewButton = true;
    @track inputLetterData = {};
    @wire(fetchLetterInventoryData, { name: '$lettername' })
    wiredLetterInventoryData({ error, data }) {
        if (data) {
            this.boolShowSpinner = true;
            this.letterInventoryData = data.map(item => ({
                ...item,
                checked: false,
                inputValues: this.extractInputValues(item.value),
                isTextArea: item.value === this.strAdditionalInfo
            }));
            this.letterInventoryCodes =[];
            this.clearJsonData();
            data.forEach(item => {
                let letId = item.letterId;
                let inputVal= this.extractInputValues(item.value);
                if(inputVal.length > 1 ){
                    for(let i=0; i< inputVal.length ; i++){
                        letId = letId + '_'+ inputVal[i].label.replace(/ /g,'');
                        let letterCodeMap ={
                            letterId: letId,
                            letterLabel: item.name,
                            boolLabelCocat : true,
                            letterCode: item.code
                        }
                        letId=item.letterId;
                        this.letterInventoryCodes.push(letterCodeMap);
                    }
                } else {
                    let letterCodeMap ={
                        letterId: letId,
                        letterLabel: item.name,
                        boolLabelCocat : false,
                        letterCode: item.code
                    }
                    this.letterInventoryCodes.push(letterCodeMap);
                }
            });



            this.boolShowSpinner = false;
            this.letterNameCaps = this.lettername.toUpperCase();
        } else if (error) {
            this.boolShowSpinner = false;
        }
    }

    clearJsonData(){
        
        this.letterOutputData ={
            original_claim_id : '',
            check_no : '',
            precert_phone : '',
            procedure_code: '',
            reason_text: '',
            claim_id : '',
            coverage_start_date: '',
            coverage_end_date: '',        
            reason_codes_section: []
        }
    }



    extractInputValues(value) {
        let inputValues = value.match(/<[^>]*>/g);
        
        inputValues = inputValues ? inputValues.map(val => val.replace(/<|>/g, '')) : [];
        if (inputValues) {
            return inputValues.map((match) => ({
                label: match.replace(/<|>/g, ''),
                placeholder: match === this.strMbrEffDate || match === this.strMbrCancelDate ? this.strDateFormat : match === this.strPrecertificationPhNum ? this.strPhoneNumFormat : '',
            }));
        }
        
        return [];
    }
    
    handleCheckboxChange(event) {
        const checkbox = event.target;
        const checked = event.target.checked;
        const dataId = checkbox.getAttribute('data-id');
        const spanElement = this.template.querySelector(`span[data-id="${dataId}"]`);
        const letterId = spanElement.innerText;
        this.letterInventoryData = this.letterInventoryData.map(item => {
            if (item.letterId === dataId) {
                item.checked = event.target.checked;
            }
            return item;
        });
        
        let boolIsDisabled ;
        let boolDisablePrevBtnCounter = false;
        for(let item=0 ;item < this.letterInventoryData.length; item++){
            if(this.letterInventoryData[item].checked) {
                if(this.letterInventoryData[item].checked && this.letterInventoryData[item].inputValues.length == 0 && !BaseLWC.isUndefinedOrNullOrBlank(this.inputLetterData[this.letterInventoryData[item].letterId])) {
                    boolIsDisabled = this.letterInventoryData[item].checked;
                    
                } else if(this.letterInventoryData[item].checked && this.letterInventoryData[item].inputValues.length == 1 && BaseLWC.isUndefinedOrNullOrBlank(this.inputLetterData[this.letterInventoryData[item].letterId])) {
                    boolIsDisabled = false;
                    boolDisablePrevBtnCounter =true;
                } else if(this.letterInventoryData[item].checked && this.letterInventoryData[item].inputValues.length > 1) {
                    for(let key=0; key< this.letterInventoryData[item].inputValues.length ; key++ ){
                        let strId = this.letterInventoryData[item].inputValues[key].label ? this.letterInventoryData[item].letterId+'_'+this.letterInventoryData[item].inputValues[key].label.replace(/ /g,'') : '';
                        if(strId && !this.inputLetterData[strId]) {
                            boolIsDisabled = false;
                            this.disablePreviewButton = !boolIsDisabled;
                            boolDisablePrevBtnCounter =true
                            }
                    }
                }
                
                else if(this.letterInventoryData[item].checked && this.letterInventoryData[item].inputValues.length <= 0) {
                    this.inputLetterData = { ...this.inputLetterData, [this.letterInventoryData[item].letterId]:true};
                    
                    for(let itemChecked=0;itemChecked< this.letterInventoryData.length; itemChecked++ ) {
                        if(this.letterInventoryData[itemChecked].checked && this.letterInventoryData[itemChecked].inputValues.length <= 1 && !BaseLWC.isUndefinedOrNullOrBlank(this.inputLetterData[this.letterInventoryData[itemChecked].letterId])) {
                            boolIsDisabled = this.letterInventoryData[itemChecked].checked;
                        } else if(this.letterInventoryData[itemChecked].checked && this.letterInventoryData[itemChecked].inputValues.length > 1) {
                            for(let key=0; key< this.letterInventoryData[itemChecked].inputValues.length ; key++ ){
                                let strId = this.letterInventoryData[itemChecked].inputValues[key].label ? this.letterInventoryData[itemChecked].letterId+'_'+this.letterInventoryData[itemChecked].inputValues[key].label.replace(/ /g,'') : '';
                                if(strId && !this.inputLetterData[strId]) {
                                    boolIsDisabled = false;
                                    this.disablePreviewButton = !boolIsDisabled;
                                    boolDisablePrevBtnCounter =true
                                    }
                            }
                        } 
                        if(boolIsDisabled == false) {
                            this.disablePreviewButton = !boolIsDisabled;
                            break;
                        }
                    }
                    if(boolIsDisabled == false) {
                        this.disablePreviewButton = !boolIsDisabled;
                        break;
                    }
                } 
            } else {
            if(!checked && !this.letterInventoryData[item].checked) {
                    delete this.inputLetterData[this.letterInventoryData[item].letterId];
                        
                        for(let itemChecked = 0;itemChecked < this.letterInventoryData.length ; itemChecked++) {
                            if(this.letterInventoryData[itemChecked].checked && this.letterInventoryData[itemChecked].inputValues.length == 1 && this.inputLetterData[this.letterInventoryData[itemChecked].letterId]) {
                                boolIsDisabled = true;
                            } else if( this.letterInventoryData[itemChecked].checked && this.letterInventoryData[itemChecked].inputValues.length > 1) {
                                for(let key=0; key< this.letterInventoryData[itemChecked].inputValues.length ; key++ ){
                                    let strId = this.letterInventoryData[itemChecked].inputValues[key].label ? this.letterInventoryData[itemChecked].letterId+'_'+this.letterInventoryData[itemChecked].inputValues[key].label.replace(/ /g,'') : '';
                                    if( strId && !this.inputLetterData[strId]) {
                                            boolIsDisabled = false;
                                            break;
                                        } else{
                                          boolIsDisabled = true;
                                        }
                                        if(boolIsDisabled !== undefined && !boolIsDisabled){
                                            this.disablePreviewButton = !boolIsDisabled;
                                            break;
                                          }
                                    
                                  }
                                  if(boolIsDisabled !== undefined && !boolIsDisabled){
                                    this.disablePreviewButton = !boolIsDisabled;
                                    break;
                                  }
                            } 
                        }
                        
                }
            }
            
        }
        this.disablePreviewButton = boolDisablePrevBtnCounter || !boolIsDisabled;
    }
    
    handleInputChange(event) {
        let strInput = event.target.value;
        let letterId = event.target.dataset.id;
        let letterName =  event.target.name;
        
        let boolIsDisabled;
        for(let i = 0; i < this.letterInventoryData.length; i++) {
            if(this.letterInventoryData[i].inputValues.length > 0) {
                if(this.letterInventoryData[i].letterId === letterId && strInput) {
                    if(this.letterInventoryData[i].inputValues.length > 1) {
                        this.inputLetterData = { ...this.inputLetterData, [letterId+'_'+letterName.replace(/ /g,'')]: `${strInput}` }; 
                    } else {
                        this.inputLetterData = { ...this.inputLetterData, [letterId]: `${letterName}, ${strInput}` };
                    }
                    
                } 
            } 
        }

        for(let i = 0; i < this.letterInventoryData.length; i++) {
            if(this.letterInventoryData[i].checked && !strInput && this.letterInventoryData[i].letterId === letterId) {
                if(this.letterInventoryData[i].inputValues.length > 1) {
                    for(let key=0; key< this.letterInventoryData[i].inputValues.length ; key++ ){
                        let strId = this.letterInventoryData[i].inputValues[key].label ? this.letterInventoryData[i].letterId+'_'+this.letterInventoryData[i].inputValues[key].label.replace(/ /g,'') : '';
                    
                        if(strId && this.inputLetterData[strId] && letterName === this.letterInventoryData[i].inputValues[key].label) {
                            
                           delete this.inputLetterData[strId]; 
                        }
                    }
                } else {
                    delete this.inputLetterData[this.letterInventoryData[i].letterId];
                }
                boolIsDisabled = true;
            }
            if(boolIsDisabled){
                return this.disablePreviewButton = true;
                //break;
            }
        }

        for(let i = 0; i < this.letterInventoryData.length; i++) {
            
            if(this.letterInventoryData[i].inputValues.length > 0) {
                if(this.letterInventoryData[i].checked && this.letterInventoryData[i].inputValues.length == 1 && this.inputLetterData[this.letterInventoryData[i].letterId]) {
                    boolIsDisabled = false;
                } else if( this.letterInventoryData[i].checked && this.letterInventoryData[i].inputValues.length > 1) {
                    for(let key=0; key< this.letterInventoryData[i].inputValues.length ; key++ ){
                        let strId = this.letterInventoryData[i].inputValues[key].label ? this.letterInventoryData[i].letterId+'_'+this.letterInventoryData[i].inputValues[key].label.replace(/ /g,'') : '';
                        if( strId && !this.inputLetterData[strId]) {
                                boolIsDisabled = true;
                                break;
                            } else{
                              boolIsDisabled = false;
                            }
                            if(boolIsDisabled){
                                break;
                              }
                      }
                      if(boolIsDisabled){
                        break;
                      }
                } else if(this.letterInventoryData[i].checked && this.letterInventoryData[i].inputValues.length <= 1 && !this.inputLetterData[this.letterInventoryData[i].letterId] && strInput) {
                    for(let item=0 ; item < this.letterInventoryData.length; item++){
                        if(this.letterInventoryData[item].checked && this.letterInventoryData[item].inputValues && !this.inputLetterData[this.letterInventoryData[item].letterId]){
                            boolIsDisabled = true;
                            break;
                        } else {
                            boolIsDisabled = false;
                        }
                    }
                    if(boolIsDisabled){
                        break;
                    }
                } else if(this.letterInventoryData[i].checked && this.letterInventoryData[i].letterId === letterId && !this.inputLetterData[this.letterInventoryData[i].letterId] && strInput) {
                    boolIsDisabled = true;
                    break;
                }
                
            }
        }
        this.disablePreviewButton = boolIsDisabled; 
    }

    openModal() {
        this.modalClass = 'slds-modal_show';
        this.isModalShow = true;
    }

    cancelAction() {
        this.closeModal();
    }

    closeModal() {
        const closeModal = new CustomEvent('cancelorclosemodal', {
            detail: { boolopenmodal: false }
        });
        // Fire the custom event
        this.dispatchEvent(closeModal);
    }
    handleHighlight() {
        for(let x=0;x<this.letterInventoryData.length;x++) {
            let spanElement = this.template.querySelector(`span[data-id="${this.letterInventoryData[x].letterId}"]`);
             let spanText = spanElement.innerText;
             let textToHighlight = this.searchTerm;
             const spanTextCons = spanElement.innerText;
             let highlightedText ='';
             if (this.searchTerm.length >= 3 && spanText) {
                let strInput = spanText.split(' ');
                for(let i=0;i<strInput.length;i++) {
                    const index = strInput[i].toLowerCase().indexOf(textToHighlight.toLowerCase()); 
                    if (index !== -1 && strInput[i]) {
                         highlightedText +=
                        strInput[i].substring(0, index).replace(/\</g,"&lt;").replace(/\>/g,"&gt;") +
                            '<span style="background-color: yellow;">' +
                            strInput[i].substring(index, textToHighlight.length+index).replace(/\</g,"&lt;").replace(/\>/g,"&gt;") +
                            '</span>' +
                            strInput[i].substring(index + textToHighlight.length).replace(/\</g,"&lt;").replace(/\>/g,"&gt;")+' ';

                            
                    } else {
                        highlightedText +=strInput[i].replace(/\</g,"&lt;").replace(/\>/g,"&gt;")+' ';
                    }
                }
                if(highlightedText) {
                    spanElement.innerHTML = highlightedText.trim();
                }
                
             } else {
                if(!BaseLWC.isUndefinedOrNullOrBlank(spanTextCons)) {
                    spanElement.innerHTML = spanTextCons.replace(/\</g,"&lt;").replace(/\>/g,"&gt;");
                }
             }
                 
        }     
    }

    handleSearchChange(event) {
        this.searchTerm = event.target.value;
        this.handleHighlight();
        
    }
    previewAction(event){

        let lettersToAdd =[];
        this.clearJsonData();
        for(let i=0 ; i < this.letterInventoryCodes.length; i++) { 
            
            if(this.inputLetterData[this.letterInventoryCodes[i].letterId]){
                let val = this.inputLetterData[this.letterInventoryCodes[i].letterId];
                if(typeof val =='boolean' && val){
                    let tempJson ={
                        reason_code : this.letterInventoryCodes[i].letterCode
                    }
                    this.letterOutputData.reason_codes_section.push(tempJson);
                } else if (typeof val =='string') {
                    
                    let tempList = val.split(/,(.*)/s); //NT: CEAS-83679 - Updated split to account for special characters ',' 
                    
                    if(this.letterInventoryCodes[i].boolLabelCocat){
                        if(this.letterInventoryCodes[i].letterId.toLocaleLowerCase().includes('checknumber') ){                            
                            this.letterOutputData.check_no = val; 
                        }
                        if(this.letterInventoryCodes[i].letterId.toLocaleLowerCase().includes('claimnumber') ){                            
                            this.letterOutputData.original_claim_id = val;
                        } 
                        lettersToAdd.push(this.letterInventoryCodes[i].letterCode); 
                        
                    } else {
                        if(tempList[0].trim().toLocaleUpperCase() == 'PRECERTIFICATION PHONE NUMBER') {
                            this.letterOutputData.precert_phone = tempList[1].trim();   
                        } else if(tempList[0].trim().toLocaleUpperCase() == 'PROCEDURE CODE') {
                            this.letterOutputData.procedure_code = tempList[1].trim();
                        } else if(tempList[0].trim().toLocaleUpperCase() == 'OTHER INFORMATION') {
                            this.letterOutputData.reason_text = tempList[1].trim();
                        } else if(tempList[0].trim().toLocaleUpperCase() == 'MBR EFF DATE') {
                            this.letterOutputData.coverage_start_date = tempList[1].trim();
                        } else if(tempList[0].trim().toLocaleUpperCase() =='MBR CANCEL DATE') {
                            this.letterOutputData.coverage_end_date = tempList[1].trim();
                        }
                        let tempJson ={
                            reason_code : this.letterInventoryCodes[i].letterCode
                        }
                        if(this.lettername === "Claim Maintain After Review" && tempList[0].trim().toLocaleUpperCase() === 'OTHER INFORMATION') {
                            // Do not add code
                        } else {                                                        
                            this.letterOutputData.reason_codes_section.push(tempJson);
                        }
                    }             

                }
            }
        }
        let lettersToAddSet = new Set(lettersToAdd);
        lettersToAdd = [...lettersToAddSet];
        for(let i=0;i < lettersToAdd.length ;i++){
            let tempJson ={
                reason_code : lettersToAdd[i]
            }
            this.letterOutputData.reason_codes_section.push(tempJson);
        }

        const previewModal = new CustomEvent('previewbutton', {
            detail: {
                 booPreviewLetter: true ,  letterOutputData: this.letterOutputData ,selectedTemplate : this.lettername   
            }
        });
        // Fire the custom event
        this.dispatchEvent(previewModal);
    }

    previousAction(event) {
        const previousModal = new CustomEvent('previousbutton', {
            detail: {}
        });
        // Fire the custom event
        this.dispatchEvent(previousModal);
    }
}