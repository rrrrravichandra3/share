import { LightningElement, api,wire } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import {getPicklistValues} from 'lightning/uiObjectInfoApi';
import IDCardRequiredError_ACE from '@salesforce/label/c.IDCardRequiredError_ACE';
import IDCardCaseOrigin_ACE from '@salesforce/label/c.IDCardCaseOrigin_ACE';
import CaseOrigin_Field from '@salesforce/schema/Case.Origin';
import DefaultRecordTypeID_ACE from '@salesforce/label/c.DefaultRecordTypeID_ACE';

import CaseGuidingNotesModalError_Message from '@salesforce/label/c.CaseGuidingNotesModalError_Message';

export default class LwcGuidingCaseAddNotesModal extends LightningElement {
    @api hideCancelButton = false;
    @api showRefreshButon = false;
    @api boolIsAerialProgram = false;
    @api recordTypeId;
    @api inputLabel;
    @api maxLenght;    
    @api callingFrom;
    @api strLob;  
    @api isFromActivity; 
    @api isMedicaideLob;
    @api isGMSFEPRetailLob;
    caseOriginDefaultValues='';
    isSubmitResultSuccess = false;
    lstCaseOrigin = [];
    label = {
        IDCardRequiredError_ACE,
        IDCardCaseOrigin_ACE
    };
    showAction = false;
    selectedAction ='Care Coordination General Referral';
    strErrorValue;
    @api
    get handleError() {
        return true;
    }
    set handleError(value) {
        this.boolSpinner = false;
        this.boolError = true;
        this.submitDisabled = false;
        this.strErrorValue = value;
    }
    boolError = false;
    boolSpinner = false;
    label = {
        CaseGuidingNotesModalError_Message
    };
    strGuidingCareNotes;
    strErrorMessage = this.label.CaseGuidingNotesModalError_Message;
    submitDisabled = false;
    get disableSubmit() {
        if(this.showAction && BaseLWC.stringIsNotBlank(this.strGuidingCareNotes) && BaseLWC.stringIsNotBlank(this.selectedAction) && BaseLWC.stringIsNotBlank(this.caseOriginDefaultValues)){
            return false;
        }else if(!this.showAction && BaseLWC.stringIsNotBlank(this.strGuidingCareNotes)){
            return false;
        }else{
            return true;
        }
        
    }
    actionOptions = [
        { label: 'Care Coordination General Referral', value: 'Care Coordination General Referral' },
        { label: 'Connected to Assigned Care Coordinator\'s Voicemail', value: 'Connected to Assigned Care Coordinator\'s Voicemail' },
        { label: 'Declined- Already Engaged with Care Coordinator', value: 'Declined- Already Engaged with Care Coordinator' },
        { label: 'General Care Coordination Questions', value: 'General Care Coordination Questions' },
        { label: 'Not interested in Care Coordination', value: 'Not interested in Care Coordination' },
        { label: 'Warm Transferred to Care Coordination', value: 'Warm Transferred to Care Coordination' }       
       
    ];
   

    /*To Fetch Case Origin PickList Value*/
    @wire(getPicklistValues, { recordTypeId: DefaultRecordTypeID_ACE, fieldApiName: CaseOrigin_Field})
    originPicklistValues({error, data}) {
        if (data && data.values) {
            this.isError = false;
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocaloriginvalues = [];
            lstLocaloriginvalues.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocaloriginvalues.push(objType)
            }
            this.caseOriginDefaultValues = 'TELEPHONE';
            this.lstCaseOrigin = lstLocaloriginvalues;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }

    /* Method To Handle On Change of Origin*/
    handleChangeOrigin(objEvent) {
        this.caseOriginDefaultValues = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
    }

    toggleCombobox(objEvent) {
        const objCmbx = objEvent.target.closest('.slds-combobox');
        if (objCmbx.querySelector('.highlight') && objCmbx.querySelector('.highlight').classList) {
            objCmbx.querySelector('.highlight').classList.remove('highlight');
        }
        const objDimensions = objCmbx.getBoundingClientRect();
        const objDropdown = objCmbx.querySelector('.slds-dropdown');
        objDropdown.style.top = objDimensions.top + 34 + 'px';
        objDropdown.style.width = objDimensions.width + 'px';
        objDropdown.style.left = objDimensions.left -
            objCmbx.closest('.slds-modal__container').getBoundingClientRect().left + 'px';
        if (objCmbx && objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]') && objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]').classList) {
            objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]').classList.add('highlight');
        }
        objCmbx.classList.toggle('slds-is-open');
    }

    connectedCallback(){
        if(this.isMedicaideLob && this.isFromActivity){
           this.showAction = true; 
        }
    }
    handleCancel = () => {
        BaseLWC.fireNativeCustomEvent('cancel', '', this);
    };
    handleSubmit = () => {
        // CEAS-56937 code start
        const data = this.strGuidingCareNotes;
        // CEAS-56937 code end
        this.boolError = false;
        this.submitDisabled = true;
        this.boolSpinner = true;
        const objAerialDetails = {
            guidingCareNotes : this.strGuidingCareNotes,
            actionTaken : this.selectedAction,
            inputLabel : this.inputLabel,
            caseOrigin : this.caseOriginDefaultValues
        }
        BaseLWC.fireNativeCustomEvent('submit', objAerialDetails, this);
        // CEAS-56937 code start
        const auraEvent = new CustomEvent('guidingcaresubmit', {
            detail: { 
                guidingCareNotes : this.strGuidingCareNotes,
                actionTaken : this.selectedAction,
                inputLabel : this.inputLabel,
                caseOrigin : this.caseOriginDefaultValues
            }
        });
        this.dispatchEvent(auraEvent);
        // CEAS-56937 code end
    };
    handleTextArea = (event) => {
        const { value } = event.target;
        this.strGuidingCareNotes = value;
    };
    handleRefresh = () => {
        this.strGuidingCareNotes = '';
        this.boolSpinner = false;
        this.boolError = false;
        this.submitDisabled = false;
    };
    @api
    showError(errMessage) {
        this.boolSpinner = false;
        this.boolError = true;
        this.submitDisabled = true;
        this.strErrorMessage = errMessage;
    }
    handleChangeAction(event){
        this.selectedAction = event.target.value;
    }
}