import { LightningElement,api,track,wire } from 'lwc';
import getCaseDetails from '@salesforce/apex/PreviewLetterController_ACE.getCaseDetails';
import BaseLWC from 'c/baseLWCFunctions_CF';
export default class LwcCreateLetterContainerModalLWC extends LightningElement {
    @track clsInitalModal = 'slds-hide';
    @track clsClaimTemplateModal = 'slds-hide';
    @track clsNonClaimTemplateModal = 'slds-hide';
    @track clsPreviewLetter = 'slds-hide';
    @track selectedletterTemplate = 'OUT OF COUNTRY PROOF OF INSURANCE';
    @api recordid;
    @api planSummaryDetails;
    @track modalCssClass;
    @track modaldivCssClass;
    @track previewLetterCode;

    selectedClaimNumber = '';
    totalBillAmount ='';
    strPaperMailWrapper;
    boolPreviewLetter = false;
    caseRecord;
    selectedRecipientGlobal;
    memberFullName='';
    providerFullName='';
    jsonData = {
        documentType: 'ace',
        documentVersion: 'DRAFT', // By default
        source: 'ACE',
        enrichment: ['MPIH'],
        documentData:{
            hcm_output : {
                correspondence : []
            }
        },
        correspondenceIds:[]

    };
    
    @wire(getCaseDetails, {strCaseId: "$recordid"})
    caseRecordDetail({ data, error }) {
       
        if (data) {
            this.caseRecord = data;           
        } else if (error) {
            this.caseRecord = {};
        }
    }

    getDateInYYYYMMDDFormat(dateToBeFormat) {
		if(dateToBeFormat) {
            let strDate = dateToBeFormat.toString();
            strDate = strDate.replace(/-/g,'/');
			let objDateTime = new Date(strDate);
			let intMonth = objDateTime.getMonth() + 1;
			let intDay = objDateTime.getDate();
			let intYear = objDateTime.getFullYear();
			if (intMonth < 10) {
				intMonth = "0" + intMonth;
			}
			if (intDay < 10) {
				intDay = "0" + intDay;
			}
			return intYear + '' + intMonth + '' +  intDay;
		}
		return '';
	}


    connectedCallback() {
        this.clsInitalModal = 'slds-show';
        this.modalCssClass = 'slds-modal slds-fade-in-open';
        this.modaldivCssClass = 'slds-modal__container slds-is-relative';
    }

    handleCreateLetterCloseModel (event) {
        let closeModal = new CustomEvent('closeorcancelmodal', {
            detail: { boolopencreateletter: false }
        });
        // Fire the custom event
        this.dispatchEvent(closeModal);
        
    }

    handlePrevious (event) {
       
        if(this.clsClaimTemplateModal === 'slds-show' || this.clsNonClaimTemplateModal === 'slds-show') {
            this.clsNonClaimTemplateModal= 'slds-hide';
            this.clsClaimTemplateModal = 'slds-hide';
            this.clsInitalModal = 'slds-show';
            this.modaldivCssClass = 'slds-modal__container slds-is-relative';
            this.modalCssClass = 'slds-modal slds-fade-in-open';
        }
    }

    handlePreview(event){
        try{
            let domainData;
            let detail = JSON.parse(JSON.stringify(event.detail));
            if(detail) {            
                domainData=  this.fillSourceDomainData(detail.letterOutputData);
            } else {
                domainData=  this.fillSourceDomainData('');
            }
            let letterCode = this.getLetterCode(this.selectedletterTemplate);
            this.jsonData.documentData.hcm_output.correspondence =[];
            if(this.selectedRecipientGlobal === 'providermember') {  
                        
                let providerData = this.buildJsonData('P', letterCode);
                providerData['source_domain'] =domainData;
                providerData.membership_section.member_section["lang_preference" ] ="ENG";
                this.jsonData.documentData.hcm_output.correspondence.push(providerData);
                let memberData = this.buildJsonData('M', letterCode);
                memberData['source_domain'] =domainData;
                this.jsonData.documentData.hcm_output.correspondence.push(memberData);
            } else if(this.selectedRecipientGlobal === 'provideronly') {
                let providerData = this.buildJsonData('P', letterCode);
                providerData['source_domain'] =domainData;
                providerData.membership_section.member_section["lang_preference" ] ="ENG";
                this.jsonData.documentData.hcm_output.correspondence.push(providerData);
            } else if(this.selectedRecipientGlobal === 'memberonly') {
                let memberData = this.buildJsonData('M', letterCode);
                memberData['source_domain'] =domainData;
                this.jsonData.documentData.hcm_output.correspondence.push(memberData);
            }
            if(this.caseRecord){
                this.memberFullName = this.caseRecord.Member_Name_ACE__c ?? '';
                this.providerFullName = this.caseRecord.ProviderInfoName_ACE__c ?? '';
            } 

            this.clsNonClaimTemplateModal= 'slds-hide';
            this.clsClaimTemplateModal = 'slds-hide';
            this.clsInitalModal = 'slds-hide';
            this.boolPreviewLetter = true;
            this.modaldivCssClass = 'slds-modal__container sectionWidth';
        }catch(error){
            //Do Nothing
        }
    }

    checkBVA(){  
        if(this.caseRecord && this.caseRecord.AddonServices_ACE__c) {
            let lstCoverageCodes = this.caseRecord.AddonServices_ACE__c.split(',');
            for(let i=0; i < lstCoverageCodes.length; i++){
                if( lstCoverageCodes[i].toLowerCase() === 'bva'){
                    return 'bva';
                } else if ( lstCoverageCodes[i].toLowerCase() === 'has') {
                    return 'has';
                }
            }
        }  
        return null;
    }

    getPlanId() {
        if(this.caseRecord) {
            let policyId = this.caseRecord.Policy_ID_ACE__c;
            if( this.caseRecord.LineOfBusiness_ACE__c && this.caseRecord.LineOfBusiness_ACE__c.toUpperCase() ==='RETAIL' &&  policyId && policyId.split('^').length > 3) {
                return policyId.split('^')[2];
            }
        }
        return '';
    }

    checkPlanEffectiveDate(){
        if(this.caseRecord) {
            let effectiveDate =  this.caseRecord.Plan_Effective_Date_ACE__c;
            if(effectiveDate) {
                effectiveDate = new Date(effectiveDate);
                let today = new Date();
                let months =0;
                var ynew = Number(today.getFullYear());
                var mnew = Number(today.getMonth());

                var yold = Number(effectiveDate.getFullYear());
                var mold = Number(effectiveDate.getMonth());

                if(ynew > yold){
                    months = months + ( ynew - yold )*12;
                }
                if(mnew > mold){
                    months = months + ( mnew - mold);
                } else {
                    months = months - ( mold - mnew);
                }

                if(months > 18 ){
                    return 'Y';
                } else  {
                    return 'N';
                }
            }
        }
        return '';
    }

    fillSourceDomainData(letterOutputData){
        try {
            let letterData = letterOutputData;
            let strGroupNumber = '';
            let strEnrollmentStatus = '';
            let patientID ='';
            let caseNum ='';
            let dateOfServiceTo ='';
            let planEffectiveDate ='';
            let productType ='';
            let planTerminationDate ='';

            if(this.planSummaryDetails && this.planSummaryDetails.objSelectedPlanDetails) { 
                strEnrollmentStatus = this.planSummaryDetails.objSelectedPlanDetails.strEnrollmentStatus;
            }
            if(this.caseRecord){
                strGroupNumber = this.caseRecord.GroupName_ACE__c  ?? '';
                patientID = this.caseRecord.PatientIdNumber_ACE__c  ?? '';
                caseNum = this.caseRecord.CaseNumber  ?? '';
                dateOfServiceTo = this.caseRecord.DateofServiceTo_ACE__c  ?? '';
                planEffectiveDate = this.caseRecord.Plan_Effective_Date_ACE__c  ?? '';
                productType = this.caseRecord.Product_Type_ACE__c  ?? '';
                planTerminationDate = this.caseRecord.Plan_Termination_Date_ACE__c  ?? '';
                
            }

            let source_domain = {
                group_name : strGroupNumber,
                patient_id : patientID,  
                contact_phone : null,
                reference_id : caseNum,
                has_bva : this.checkBVA(), 
                service_date : this.getDateInYYYYMMDDFormat(dateOfServiceTo),
                case_no : caseNum,
                claim_id : this.selectedClaimNumber, 
                original_claim_id : '',
                reason_text : '',
                number_of_participants : '',
                coverage_18_mos_ind : this.checkPlanEffectiveDate(),
                select : '',
                waiting_affiliation_start_Date : null,
                member_status : strEnrollmentStatus,
                coverage_start_date : '',
                coverage_end_date : '',
                health_plan_no : this.getPlanId(),
                cobra : '',
                policy_type : productType,
                deductible_copay_amt : '',
                payment_level : '',
                oop_max : '',
                max_benefit_amt : '',
                max_visit_amt : '',
                lifetime_limit_ind : '',
                max_lifetime_limit_amt : '',
                inn_deductible_amt : '',
                inn_benefit_level : '',
                em_room_copay_amt : '',
                hca_balance : '',
                no_of_hours : '',
                procedure_code : '',
                check_no : '',
                precert_phone : ''
            }

            if(this.selectedletterTemplate === "Claim Maintain After Review" || this.selectedletterTemplate === "PTC Maintain Denial"){
                source_domain.original_claim_id = letterData.original_claim_id;
                source_domain.check_no = letterData.check_no;
                source_domain.precert_phone = letterData.precert_phone;
                source_domain.procedure_code = letterData.procedure_code;
                source_domain.reason_text = letterData.reason_text;
                source_domain.coverage_start_date = this.getDateInYYYYMMDDFormat(letterData.coverage_start_date);
                source_domain.coverage_end_date = this.getDateInYYYYMMDDFormat(letterData.coverage_end_date);
                source_domain['reason_codes_section'] = letterData.reason_codes_section;

                if(this.selectedletterTemplate === "PTC Maintain Denial"){
                    source_domain['orig_billed_amt'] = this.totalBillAmount;
                }
            
            } else if (this.selectedletterTemplate.toUpperCase() === 'OUT OF COUNTRY PROOF OF INSURANCE'){
                source_domain.deductible_copay_amt = letterData.deductible_copay_amt;
                source_domain.payment_level = letterData.payment_level;
                source_domain.oop_max = letterData.oop_max;
                source_domain.max_benefit_amt = letterData.max_benefit_amt;
                source_domain.max_visit_amt = letterData.max_visit_amt;
                source_domain.lifetime_limit_ind = letterData.lifetime_limit_ind;
                source_domain.max_lifetime_limit_amt = letterData.max_lifetime_limit_amt;            
                source_domain.coverage_start_date = this.getDateInYYYYMMDDFormat(planEffectiveDate);
                source_domain['reason_codes_section'] = letterData.reason_codes_section;
            } else if (this.selectedletterTemplate.toUpperCase() === 'OUT OF COUNTRY SUMMARY OF BENEFITS'){
                source_domain.inn_deductible_amt = letterData.inn_deductible_amt;
                source_domain.inn_benefit_level = letterData.inn_benefit_level;
                source_domain.em_room_copay_amt = letterData.em_room_copay_amt;
                source_domain.max_lifetime_limit_amt = letterData.max_lifetime_limit_amt;
                source_domain.hca_balance = letterData.hca_balance;
                source_domain.no_of_hours = letterData.no_of_hours;              
                source_domain.coverage_start_date = this.getDateInYYYYMMDDFormat(planEffectiveDate);
            } else if (this.selectedletterTemplate.toUpperCase() === 'CERTIFICATE OF CREDIBLE COVERAGE (COCC)'){
                source_domain.select = letterData.select;
                source_domain.cobra = letterData.cobra;
                source_domain.coverage_start_date = this.getDateInYYYYMMDDFormat(planEffectiveDate);
                source_domain.coverage_end_date = this.getDateInYYYYMMDDFormat(planTerminationDate);
                source_domain['number_of_participants'] =1;
            }

            return source_domain;
        } catch(error) {
            // Do Nothing
        }

    }


    handleEditLetter(event){
        if(event && event.detail) { 
            this.boolPreviewLetter = false;            
            if(this.selectedletterTemplate === "Claim Maintain After Review" || this.selectedletterTemplate === "PTC Maintain Denial") {
                this.clsInitalModal = 'slds-hide';
                this.modaldivCssClass = 'slds-modal__container sectionWidth';
                this.clsNonClaimTemplateModal = 'slds-show';
                this.clsClaimTemplateModal = 'slds-hide';
            } else if(this.selectedletterTemplate === "Cannot Reach"){
                
                this.clsNonClaimTemplateModal= 'slds-hide';
                this.clsClaimTemplateModal = 'slds-hide';
                this.clsInitalModal = 'slds-show';
                this.modaldivCssClass = 'slds-modal__container slds-is-relative';

            } else {
                this.clsInitalModal = 'slds-hide';
                this.clsNonClaimTemplateModal= 'slds-hide';
                this.clsClaimTemplateModal = 'slds-show';
                this.modaldivCssClass = 'slds-modal__container templateSelectionStyle ';
            }
        }
    }

    handleCreateLetterSubmit (event) {

    }

    handleNextButton (event) {
        if(event && event.detail) {
            let selectedRecipient = event.detail.selectedRecipient;
            this.selectedRecipientGlobal = event.detail.selectedRecipient;
            this.selectedClaimNumber = event.detail.selectedClaimNumber;
            this.selectedletterTemplate = event.detail.selectedTemplate;
            this.totalBillAmount = event.detail.totalBilledAmount;
            if(this.selectedletterTemplate === "Claim Maintain After Review" || this.selectedletterTemplate === "PTC Maintain Denial") {
                this.clsInitalModal = 'slds-hide';
                this.modaldivCssClass = 'slds-modal__container sectionWidth';
                this.clsNonClaimTemplateModal = 'slds-show';
                this.clsClaimTemplateModal = 'slds-hide';
            } else if(this.selectedletterTemplate === "Cannot Reach"){


                
                this.jsonData.documentData.hcm_output.correspondence =[];
                let domainData=  this.fillSourceDomainData('');

                let letterCode = this.getLetterCode(this.selectedletterTemplate);
                if(selectedRecipient === 'providermember') {              
                    let providerData = this.buildJsonData('P', letterCode);
                    providerData['source_domain'] =domainData;
                    providerData.membership_section.member_section["lang_preference" ] ="ENG";
                    this.jsonData.documentData.hcm_output.correspondence.push(providerData);
                    let memberData = this.buildJsonData('M', letterCode);
                    memberData['source_domain'] =domainData;
                    this.jsonData.documentData.hcm_output.correspondence.push(memberData);
                } else if(selectedRecipient === 'provideronly') {
                    let providerData = this.buildJsonData('P', letterCode);
                    providerData['source_domain'] =domainData;
                    providerData.membership_section.member_section["lang_preference" ] ="ENG";
                    this.jsonData.documentData.hcm_output.correspondence.push(providerData);
                } else if(selectedRecipient === 'memberonly') {
                    let memberData = this.buildJsonData('M', letterCode);
                    memberData['source_domain'] =domainData;
                    this.jsonData.documentData.hcm_output.correspondence.push(memberData);
                }

                if(this.caseRecord){
                    this.memberFullName = this.caseRecord.Member_Name_ACE__c ?? '';
                    this.providerFullName = this.caseRecord.ProviderInfoName_ACE__c ?? '';
                } 

                this.boolPreviewLetter = true;
                this.clsNonClaimTemplateModal= 'slds-hide';
                this.clsClaimTemplateModal = 'slds-hide';
                this.clsInitalModal = 'slds-hide';
                this.modaldivCssClass = 'slds-modal__container sectionWidth';

            } else {
                this.clsInitalModal = 'slds-hide';
                this.clsNonClaimTemplateModal= 'slds-hide';
                this.clsClaimTemplateModal = 'slds-show';
                this.modaldivCssClass = 'slds-modal__container templateSelectionStyle ';
            }
        }
    }

    buildJsonData(memberType, letterCode) {
        let caseDetails = this.caseRecord;
        let planDetails = {};
        let memberFullName = '';
        let memberDOB='';
        let subId ='';
        let memberFirstName ='';
        let memberLastName ='';
        let groupId ='';
        let sectionNum = '';
        let corpCode = '';
        let stateCD ='';
        let providerFullName ='';
        let providerStreet ='';
        let providerState ='';
        let providerCity='';
        let providerZipCode ='';
        let busSegment ='';
        let mid='';
        let fundingType='';
        let planSumDOB ='';

        if(this.planSummaryDetails && this.planSummaryDetails.objSelectedPlanDetails) {
            fundingType = this.planSummaryDetails.objSelectedPlanDetails.strFundingTypeCode;
            planSumDOB =  this.planSummaryDetails.objSelectedPlanDetails.strdateOfBirth;
        }

        if(this.caseRecord){
            if(this.caseRecord.Account.RecordType.DeveloperName === 'BlueCard_Member_ACE'){
                memberDOB= this.caseRecord.Account.BirthDate_ACE__c ?? '';
            } else {
                memberDOB=planSumDOB;
            }
           
            memberFullName= this.caseRecord.Member_Name_ACE__c ?? '';
            subId = this.caseRecord.SubscriberID_ACE__c ?? '';
            memberFirstName  = this.caseRecord.Account.FirstName ?? '';
            memberLastName = this.caseRecord.Account.LastName ?? '';
            groupId = this.caseRecord.GroupNumber_ACE__c ?? '';
            sectionNum = this.caseRecord.SectionNumber_ACE__c ?? '';
            corpCode = this.caseRecord.CorporationCode_ACE__c ?? '';
            if(corpCode){
                stateCD = corpCode.replace('1','');
            }
            providerFullName = this.caseRecord.ProviderInfoName_ACE__c ?? '';
            providerStreet = this.caseRecord.ProviderStreet_ACE__c ?? '';
            providerCity = this.caseRecord.ProviderCity_ACE__c ?? '';
            providerState = this.caseRecord.ProviderState_ACE__c ?? '';
            providerZipCode = this.caseRecord.ProviderZipCode_ACE__c ?? '';

            mid = this.caseRecord.Account.MID_Surrogate_ACE__c ?? '';

            if(this.caseRecord.LineOfBusiness_ACE__c && this.caseRecord.LineOfBusiness_ACE__c.toUpperCase().startsWith('GOV')){
                busSegment='GOVT';
                fundingType='PREM';
            } else if (this.caseRecord.LineOfBusiness_ACE__c && this.caseRecord.LineOfBusiness_ACE__c.toUpperCase() === 'RETAIL'){
                busSegment='RETAIL';
            } else if (this.caseRecord.LineOfBusiness_ACE__c 
                && this.caseRecord.LineOfBusiness_ACE__c.toUpperCase() === 'GMS'
                && this.caseRecord.Account.RecordType.DeveloperName === 'PersonAccount'){
                busSegment='GROUP';
            } else if (this.caseRecord.LineOfBusiness_ACE__c 
                && this.caseRecord.LineOfBusiness_ACE__c.toUpperCase() === 'GMS'
                && this.caseRecord.Account.RecordType.DeveloperName === 'BlueCard_Member_ACE'){
                busSegment='GROUP';
                fundingType='PREM';
            }

        }

		let providerData = {
			correspondence_id: '',
			hcm_section: {
				process_date: this.getDateInYYYYMMDDFormat(BaseLWC.dateFormatterHelper(new Date().toString())),
				letter_code: letterCode,
				proof_ind: 'Y',
				storage_metadata: null
			},
			mcc_section: {
				appeals_code: null,
				tracking_db_key: null
			},
            membership_section : { 
				member_section: {
					member_id: mid, 
					member_dob: this.getDateInYYYYMMDDFormat(memberDOB),
					full_name: memberFullName,
					first_name: memberFirstName,  
					last_name: memberLastName
				},
				subscriber_section : {
					subscriber_id: subId,
					full_name: memberFullName,
					first_name: memberFirstName,
					last_name: memberLastName,
					group_id: groupId,
					section_id: sectionNum,
					corp_cd:  corpCode,
					state_cd: stateCD,
					bus_segment: busSegment,
					funding_type:fundingType,
					policy_type: 'E'
				}
			}
		};
        if(memberType === 'P') {
            providerData['recipient_section'] = {
				isOriginal: 'Y',
				recipient_type: memberType,
				full_name: providerFullName,
                first_name: providerFullName,
                last_name: "",
				address: {
					isForeign: 'N',
					street_addr1: providerStreet,
					street_addr2: null,
					city: providerCity,
					state: providerState, 
					zip_code: providerZipCode,
					country_name: 'US'
				}
			};
            providerData['provider_section'] =  {
				attending_section : {
					full_name: providerFullName
				}
			};
        } else if(memberType === 'M') {
            providerData['recipient_section'] = {
				isOriginal: 'Y',
				recipient_type: memberType,
				full_name: memberFullName,
				first_name: memberFirstName,
				last_name: memberLastName,
                isForeign: 'N'
			};
            providerData.membership_section.member_section['isForeign'] ='N';
            providerData['provider_section'] =  {
				
			};
        }
        return providerData;
    }

    getLetterCode(letterTemplate) {
        let templateName = '';
        if(letterTemplate === 'Cannot Reach') {
            templateName = 'Cannot_Reach';
        } else if(letterTemplate === 'Claim Maintain After Review') {
            templateName = 'CLM_Maintain';
        } else if(letterTemplate === 'CERTIFICATE OF CREDIBLE COVERAGE (COCC)') {
            templateName = 'COCC';
        } else if(letterTemplate === 'OUT OF COUNTRY PROOF OF INSURANCE') {
            templateName = 'OOC_Proof';
        } else if(letterTemplate === 'OUT OF COUNTRY SUMMARY OF BENEFITS') {
            templateName = 'OOC_Summary';
        } else if(letterTemplate === 'PTC Maintain Denial') {
            templateName = 'PTC_Denial';
        }
        this.previewLetterCode = templateName;
        return templateName;
    }
}