import { LightningElement, api, track } from "lwc";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


//Base LWC functions.
import BaseLWC from "c/baseLWCFunctions_CF";
import WorkspaceApi from 'c/baseWorkspaceApi_CF';

export default class lwcCOBMiscInfoTable_ACE extends LightningElement {

    @api boolShowSpinner;
    @api boolAPIError;
    @api boolNoRecords;
    @api objInitTableSettings
    @api lstCOBMiscDataRaw
    @api lstCOBMiscData

    boolShowSpinner = true;

    lstCOBMiscData = [];

    columns = [
        { label: 'LVL', fieldName: 'level', sortable: true, type: '', boolInitSort: true, boolAsc: true},
        { label: 'MEMBER NAME', fieldName: 'memberName', sortable: true, type: ''},
        { label: 'DOB', fieldName: 'dateOfBirth', sortable: true, type: '' },
        { label: 'EFFECTIVE DATE', fieldName: 'effectiveDate', sortable: true, type: 'date' },
        { label: 'TERM DATE', fieldName: 'terminationDate', sortable: true, type: 'date' },
        { label: 'PROCESSED DATE', fieldName: 'processedDate', sortable: true, type: 'date' },
        { label: 'PLAN CODE', fieldName: 'planCode', sortable: true, type: '' },
        { label: 'EXPLANATION', fieldName: 'explanation', sortable: true, type: '' },
    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: false,
        boolShowSearch: true,
        boolShowSearchLabel: true,
        filterData: [
            { strType: 'Select a value', intCol: -1, strFilterName: 'Select a value' },
            { strType: 'picklist', intCol: 1, strFilterName: 'LVL' },
            { strType: 'text', intCol: 2, strFilterName: 'MEMBER NAME' },
            { strType: 'date', intCol: 3, strFilterName: 'DOB' },
            { strType: 'date', intCol: 4, strFilterName: 'EFFECTIVE DATE' },
            { strType: 'date', intCol: 5, strFilterName: 'TERM DATE' },
            { strType: 'date', intCol: 6, strFilterName: 'PROCESSED DATE' },
            { strType: 'text', intCol: 7, strFilterName: 'PLAN CODE' },
            { strType: 'text', intCol: 8, strFilterName: 'EXPLANATION' }
        ]
    };

    //Initial method
    connectedCallback() {
        if (this.boolAPIError != true) {
            try {
                this.boolShowSpinner = true;
                this.formatData();
                this.boolAPIError = false;
                
            } catch (error) {
                this.boolAPIError = true;
            }
        } 
        this.boolShowSpinner = false;
    }

    //Formats and sets up date for table
    formatData() {
        this.lstCOBMiscData = JSON.parse(this.lstCOBMiscDataRaw)
        
        if (this.lstCOBMiscData.length != 0) {
            this.lstCOBMiscData.forEach(x => {
                if (x.dateOfBirth && x.dateOfBirth != '-') {
                    x.dateOfBirth = this.formatDate(x.dateOfBirth);
                }
                if (x.effectiveDate && x.effectiveDate != '-') {
                    x.effectiveDate = this.formatDate(x.effectiveDate);
                }
                if (x.dateTermDate && x.dateTermDate != '-') {
                    x.dateTermDate = this.formatDate(x.dateTermDate);
                }
                if (x.dateProcessDate && x.dateProcessDate != '-') {
                    x.dateProcessDate = this.formatDate(x.dateProcessDate);
                }
            })
            this.boolNoRecords = false;
        } else {
            this.boolNoRecords = true;
        }
    }

    //Format Dates
    formatDate(dateInput) {
        let objDateTime = new Date(dateInput);
        let intMonth = objDateTime.getUTCMonth() + 1;
        let intDay = objDateTime.getUTCDate();
        let intYear = objDateTime.getUTCFullYear();
        if (intMonth < 10) {
            intMonth = "0" + intMonth;
        }
        if (intDay < 10) {
            intDay = "0" + intDay;
        }
        return intMonth + "/" + intDay + "/" + intYear;
    }
}