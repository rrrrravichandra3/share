/**
 * Created by U390163 on 2/17/2021.
 */

import { LightningElement, track, api } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';

import MessageLightningComponent_Error_ACE from '@salesforce/label/c.MessageLightningComponent_Error_ACE';
import MessageLightningComponent_Success_ACE from '@salesforce/label/c.Message_success_ACE';
import MessageLightningComponent_Warning_ACE from '@salesforce/label/c.MessageLightningComponent_Warning_ACE';
import Message_error_ACE from '@salesforce/label/c.Message_error_ACE';
import Message_success_ACE from '@salesforce/label/c.Message_success_ACE';
import Message_warning_ACE from '@salesforce/label/c.MessageLightningComponent_Warning_ACE';
import Message_Close_ACE from '@salesforce/label/c.Message_Close_ACE';

export default class MessageLwcComponent extends LightningElement {

    label = {
        MessageLightningComponent_Success_ACE,
        MessageLightningComponent_Warning_ACE,
        MessageLightningComponent_Error_ACE,
        Message_error_ACE,
        Message_success_ACE,
        Message_warning_ACE,
        Message_Close_ACE
    };

    @api boolError = false;
    @api boolWarning = false;
    @api boolSuccess = false;
    @api strMessage = '';
    @api boolIsCloseBtn = false;
    @api boolIsMessageOpen = false;
    @api boolHasHelptext = false;
    @api helpIconVariant = 'bare';
    @api helpContent = '';
    @api noWarningIconWidth = false;

    @track boolNoRecords = false;

    connectedCallback() {
        if(this.strMessage === "No Records Found") {
            this.boolNoRecords = true;
        } else {
            this.boolNoRecords = false;
        }
    }

    closeToast(event) {
        const objParameter = {
            value : event.currentTarget.name
        };
        const closeEvent = new CustomEvent('closetemplate', {
            detail: objParameter
        });
        this.dispatchEvent(closeEvent);
    }
}
