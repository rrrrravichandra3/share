import { LightningElement,api, track, wire} from 'lwc';
import FlexiPageHeader_ACE from "@salesforce/resourceUrl/FlexiPageHeader_ACE";
import HCSCStaticResource_ACE from "@salesforce/resourceUrl/HCSCStaticResource_ACE";
import { loadStyle } from 'lightning/platformResourceLoader';

//Import Shared JS files.
//Base LWC functions.
import BaseLWC from "c/baseLWCFunctions_CF";
//import platformWorkspaceApi
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
import getProviderDetails from "@salesforce/apex/ManageAGSAlertsController_ACE.getProviderDetails";

export default class LwcProviderAlertDetail extends LightningElement {
    //wire
    @wire(EnclosingTabId) enclosingTabId;

    @api recordId;
    objTabData = {}
    objCardError = {}
    boolAPIError = false
    providerData = []
    alertRecordId = "";
    columns = [
        { label: 'PROVIDER NAME', fieldName: 'ProviderName_ACE__c',sortable: false,type: 'text' },
        { label: 'PROVIDER NUMBER', fieldName: 'ProviderNumber_ACE__c',sortable: false,type: 'text' },
        { label: 'PROVIDER ADDRESS', fieldName: 'ProviderAddress_ACE__c', sortable: false,type: 'text'},
        { label: 'START DATE', fieldName: 'StartDate_ACE__c',sortable: false, type: 'date'},
        { label: 'END DATE', fieldName: 'EndDate_ACE__c',sortable: false, type: 'date'},
        { label: 'STATUS', fieldName: 'IsActive_ACE__c',sortable: false, type: 'text', boolWrapper: true },
    ];

    objInitTableSettings = {
        pageSize: 10,
        boolViewMore: false,
        columnsData: this.columns,
        boolSecondaryTable: false,
        boolShowFilter: false,
        boolPagination: true,
        boolShowSearch:false,
        filterData : [],
        boolShowCheckbox : false,
        boolShowHeader : false
    };
    renderedCallback() {
        Promise.all([
            loadStyle(this, FlexiPageHeader_ACE  + '/CSS/HideFlexiPageHeader_ACE.css'),
            loadStyle(this, HCSCStaticResource_ACE  + '/CSS/GenericCSS/commonStyleGuide.css')
        ])
    }

    connectedCallback() {
        try {
                        this.fetchTabData();
        } catch (error) {
            this.handleErrors(error);
        }
    }

    /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     * All components should have this code.
     */
     fetchTabData = () => {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
            this.objTabData = objTabData;
            const strURL = this.objTabData.url;
            const durl = new URL(strURL);
            //@CEAS55088
            const paramsVal = durl.searchParams.getAll('c__BaseURLParam');  
            const alertId = paramsVal[0].split('=')[1];
            //const alertId = BaseLWC.helperBaseGetUrlParameters("strAlertId", strURL);
            //const alertId = paramsVal[1];
           
            this.alertRecordId = alertId;
            if(this.alertRecordId) {
                this.fetchProviderDetails();
            }
            
        }).catch((error) => {
            this.handleErrors(error);
        });
    }
}
    handleErrors = (error) => {
        //show Account API Error
        this.objCardError = error;
        this.boolAPIError = true;
        
    }

    fetchProviderDetails() {
        getProviderDetails({
            strAlertRecordId: this.alertRecordId
        }).then((objResult) => {
            objResult.forEach(data => {
                if(data.IsActive_ACE__c) {
                    data.IsActive_ACE__c = {wrapper :'<span class="label slds-badge slds-badge_lightest" style="border-color: #005fb2;background: white;color: #005fb2;border-radius: 15rem;padding: .25rem .5rem;border-radius: 15rem;text-transform: uppercase;font-weight: normal;letter-spacing: .0625em;vertical-align: middle;white-space: nowrap;">ACTIVE</span>'}
                } else {
                    data.IsActive_ACE__c = {wrapper :'<span class="label slds-badge slds-badge_lightest" style="border-color: #bcced9;background: #bcced9;color: white;border-radius: 15rem;padding: .25rem .5rem;border-radius: 15rem;text-transform: uppercase;font-weight: normal;letter-spacing: .0625em;vertical-align: middle;white-space: nowrap;">INACTIVE</span>'}
                }
            })
            this.providerData = objResult;
        });
    }


}