import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

import fetchSecureAlerts from '@salesforce/apex/MemberSearchHelper_ACE.fetchSecureGroupAGSAlerts';
//reusing existing "No Records found" label
import ViewCaseSummary_NoCasesError_ACE from '@salesforce/label/c.ViewCaseSummary_NoCasesError_ACE';

export default class LwcSecureGroupAlertsModal extends NavigationMixin(LightningElement) {

    label = {
        ViewCaseSummary_NoCasesError_ACE
    };

    //values passed from member search lightning component.
    @api accountNumber;
    @api groupNumber;
    @api sectionNumber;
    @api applicableTo;

    boolAlertsAvailable = false;
    boolNoRecords = false;
    boolShowSpinner = true;
    finalDate = '';

    lstOfAlerts = [];
    objCardError = {};

    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            //fetch alert data
            this.fetchDataFromServer();
        } catch (error) {
            this.handleErrors(error);
        }
    }

    /**
     * CEAS-60877
     * fetch data from Alerts and display in the modal
     */
    fetchDataFromServer() {
        //Checking whether userdid member search from MEMBER / MEMBER + PROVIDER radio button.
        let providerSearch = false;
        if (this.applicableTo.includes('Provider')) {
            providerSearch = true;
        }
        fetchSecureAlerts({
            accountNumber: this.accountNumber,
            groupNumber: this.groupNumber,
            sectionNumber: this.sectionNumber,
            applicableTo: providerSearch
        }).then(result => {
            if (result.length > 0) {
                result.forEach((element) => {
                    //creating an object to hold values every iteration.
                    const callBackDataHandler = { title: '', createdDate: '', description: '' };
                    if (element.title) {
                        try {
                            callBackDataHandler.title = (element.title).toUpperCase();
                        } catch (error) {
                            this.handleErrors(error);
                        }
                    }
                    if (element.createdDate) {
                        this.getCreatedDate(element.createdDate);
                        callBackDataHandler.createdDate = this.finalDate;
                    }
                    if (element.description) {
                        callBackDataHandler.description = element.description;
                    }
                    this.lstOfAlerts.unshift(callBackDataHandler);
                });
                this.boolAlertsAvailable = true;
            } else {
                this.boolAlertsAvailable = false;
                this.boolNoRecords = true;
            }
            this.boolShowSpinner = false;
        }).catch((error) => {
            this.handleErrors(error);
        });
    }

    /**
     * CEAS-60877
     * @param {created datetime of the alert record} dateTimeValue
     * changing the date format to suite the UI requirement (MM/DD/YYYY)
     * adding 0 and slicing so that we can show trailing '0' for single digit months and dates.
     */
    getCreatedDate(dateTimeValue) {
        const timestamp = Date.parse(dateTimeValue);
        const date = new Date(timestamp);
        this.finalDate = ('0' + (date.getMonth() + 1)).slice(-2) + "/" + ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear();
    }

    /**
     * To handle Errors.
     * Helps to show case errors.
     * All components should have this code.
     * removedap
     */
    handleErrors = (error) => {
        this.objCardError = error;
        this.boolShowSpinner = false;
    };

}