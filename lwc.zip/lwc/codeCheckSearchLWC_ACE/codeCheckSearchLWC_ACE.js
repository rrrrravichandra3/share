import {
	LightningElement,
	track, wire
} from 'lwc';
import CodeCheck_CodeTypeInstruction_ACE from '@salesforce/label/c.CodeCheck_CodeTypeInstruction_ACE';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import CodeCheck_APIAvailableError_ACE from '@salesforce/label/c.CodeCheck_APIAvailableError_ACE';
import getCodeCheck from '@salesforce/apexContinuation/CodeCheckController_ACE.getCodeCheck';
export default class codeCheckSearchLWC_ACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
	boolShowSpinner = false;
	boolErrorWarning = false;
	selectedState = '';
	selectedCodeTypes = [];
	@track dateOfService;
	objTabData;
	strBaseCurrentParentTabId;
	boolVPSTabSpecificEvents;
	boolPlanSummaryData = false;
	PlanSummaryData;
	strCMID;
	strGroupNumber;
	strCorpCode;
	strPolicyId;
	strEffectiveDate;
	strTerminationDate;
	boolHCPCS = false;
	boolICDDiagnosis = false;
	boolICDProcedure = false;
	boolNDC = false;
	boolCalloutDone = false;
	boolAPIError = false;
	@track selectedItem = '';
    strCPTHCPCS;
    strICDDiagnosis;
    strICDProcedure;
    strNDC;
    boolHideAutoDoc = true;
    @track premCodeData;
    @track premCodeslst;
    @track codeTypeGens = {};
    @track lstFormattedResult;
	labels = {
		CodeCheck_CodeTypeInstruction_ACE,
		EnableVPSTabSpecificEvents_ACE,
		CodeCheck_APIAvailableError_ACE
	};
	subscriberId;
	stateOptions = [{
			label: '',
			value: ''
		},
		{
			label: 'Illinois',
			value: 'IL1'
		},
		{
			label: 'Oklahoma',
			value: 'OK1'
		},
		{
			label: 'New Mexico',
			value: 'NM1'
		},
		{
			label: 'Montana',
			value: 'MT1'
		},
		{
			label: 'Texas',
			value: 'TX1'
		},
	];
	codeTypeOptions = [{
			label: 'CPT ; HCPCS',
			value: 'C'
		},
		{
			label: 'ICD 10 Diagnosis Code',
			value: '1'
		},
		{
			label: 'ICD 10 Procedure Codes',
			value: 'Z'
		},
		{
			label: 'NDC',
			value: 'R'
		},
	];
	lstStateValues = [{
			label: 'Illinois',
			value: 'IL1'
		},
		{
			label: 'Oklahoma',
			value: 'OK1'
		},
		{
			label: 'New Mexico',
			value: 'NM1'
		},
		{
			label: 'Montana',
			value: 'MT1'
		},
		{
			label: 'Texas',
			value: 'TX1'
		},
	];
	@track lstTableData = [];
	columns = [{
			label: "Flag",
			fieldName: 'flag',
			sortable: true,
			type: 'text',
			boolInitSort: true,
			boolAsc: true,
			boolIsTooltip: true,
			boolIsInfoIconTooltip: true
		},
		{
			label: "Group Id",
			fieldName: 'bitCodeGroup',
			sortable: true,
			boolAsc: true,
			type: ''
		},
		{
			label: "Group Name",
			fieldName: 'name',
			sortable: false,
			type: ''
		},
		{
			label: "Effective Date",
			fieldName: 'effectiveDate',
			sortable: false,
			type: 'date'
		},
		{
			label: "End Date",
			fieldName: 'endDate',
			sortable: false,
			type: 'date'
		},
		{
			label: '',
			fieldName: 'bitPrem',
			sortable: false,
			type: '',
			boolHidden: true
		},
		{
			label: '',
			fieldName: 'isIconDisabled',
			sortable: false,
			type: '',
			boolHidden: true
		}
	];
    toggleSection(objEvent) {
        if(objEvent.target) {
            const index = objEvent.target.getAttribute('data-id');
            const intIndex = Number(index);
            const boolIsSectionOpen = this.lstFormattedResult[intIndex].isSectionOpen;
            if(boolIsSectionOpen) {
                this.lstFormattedResult[intIndex]['accordianClass'] = 'slds-col slds-m-left_medium slds-size--11-of-12 slds-accordian__section slds-p-left_x-large slds-p-bottom_small slds-p-top_large';
                this.lstFormattedResult[intIndex]['isSectionOpen'] = false;
                this.lstFormattedResult[intIndex]['iconName'] = 'utility:chevronright';
            } else {
                this.lstFormattedResult[intIndex]['accordianClass'] = 'slds-col slds-m-left_medium slds-size--11-of-12 slds-accordian__section slds-p-left_x-large slds-p-bottom_small slds-p-top_large slds-is-open';
                this.lstFormattedResult[intIndex]['isSectionOpen'] = true;
                this.lstFormattedResult[intIndex]['iconName'] = 'utility:chevrondown';
            }
            
        }
    }
	@track
	objInitTableSettings = {
		pageSize: 25,
		restrictedPageSize: 25,
		boolShowSearch: false,
		boolPagination: true,
		columnsData: this.columns,
		boolShowIcon: false,
		iconNameToShow: 'utility:note',
		boolHeaderNoCapital: true,
	};
    @track lstCodesForAPI;
	strState;
	connectedCallback() {
		this.fetchTabData();
		let dtToday = new Date();
		this.dateOfService = ((dtToday.getMonth() > 8) ? (dtToday.getMonth() + 1) : ('0' + (dtToday.getMonth() + 1))) + '/' + ((dtToday.getDate() > 9) ? dtToday.getDate() : ('0' + dtToday.getDate())) + '/' + dtToday.getFullYear();
	}
	checkIfApIisDown(objEvent) {}
	handleStateSelection(objEvent) {
		this.selectedState = objEvent.detail.value;
		let stateElement = document.getElementsByName('lightning-combobox[data-id="STATE"]');
	}
	handleReset(objEvent) {
        this.resetSearchValues();
    }
	handleSearch(objEvent) {
        this.registerInput();
        if(this.validateInputs()) {
            this.createRequestBody();
            this.performAPICall();
            this.resetSearchValues();
        }
    }
    performAPICall() {
        try {
            this.boolShowSpinner = true;
            const currentDate = new Date().toISOString().split('T')[0]
            getCodeCheck({
                strServiceDate: currentDate,
                strCorporateEntityCode: this.strState,
                strPremierCodes: JSON.stringify(this.lstCodesForAPI)
            }).then((response) => {
                this.boolShowSpinner = false;
                if (response) {
                    this.premCodeData = JSON.parse(response);
                    if (typeof this.premCodeData && this.premCodeData?.codes?.length) {
                        this.premCodeslst = [];
                        this.premCodeData.codes.forEach(el => {
                            this.premCodeslst.push(
                                {
                                    code: el.code,
                                    codeType: el.codeType,
                                    codeTypeHeader: this.getNextCodeTypeGenerator(el.codeType),
                                    codeTypeAutoDoc: this.getNextCodeTypeGenerator(el.codeType),
                                    codeGroups: el.codeGroups,
                                    descriptions: el.descriptions
                                })
                        });
                        this.boolCalloutDone = true;
                        this.formatData();
                        this.boolAPIError = false;
                    }
                } else {
                    this.boolAPIError = true;
                }
            }).catch((error) => {
                this.boolShowSpinner = false;
                this.handleErrors(error);
            });
        } catch (error) {
            this.boolAPIError = true;
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }
    formatData() {
        let localDataList = this.premCodeslst;
        let lstFormattedData = [];
        localDataList.forEach((objElement) => {
            let localDataMap = {};
            localDataMap['accordianClass'] = 'slds-col slds-m-left_medium slds-size--11-of-12 slds-accordian__section slds-p-left_x-large slds-p-bottom_small slds-p-top_large slds-is-open';
            localDataMap['code'] = objElement.code;
            localDataMap['descriptions'] = objElement.descriptions;
            localDataMap['boolShowDescription'] = this.checkDescription(objElement.descriptions);
            localDataMap['codeTypeHeader'] = objElement.codeTypeHeader;
            localDataMap['lstTableData'] = this.createTableData(objElement.codeGroups);
            localDataMap['isSectionOpen'] = true;
            localDataMap['iconName'] = 'utility:chevrondown';
            if(!localDataMap['lstTableData'].length) {
                localDataMap['accordianClass'] = 'slds-col slds-m-left_medium slds-size--11-of-12 slds-accordian__section slds-p-left_x-large slds-p-bottom_small slds-p-top_large';
                localDataMap['boolShowNoRecordsFound']= true;
                localDataMap['isSectionOpen'] = false;
                localDataMap['iconName'] = 'utility:chevronright';
            }
            lstFormattedData.push(localDataMap);
        });
        this.lstFormattedResult = lstFormattedData;
    }
    checkDescription(objDescription) {
        let boolLongCheck = false;
        let boolSmallCheck = false;
        if(objDescription?.longDesc) {
            boolLongCheck = true;
        }
        if(objDescription?.shortDesc) {
            boolSmallCheck = true;
        }
        if(boolLongCheck && boolSmallCheck) {
            return true;
        }
        return false;
    }
    //Removing the Primary DX text from code, so that we can find the code in premMap in premCodeClick().
    removePrimaryDXText(data) {
        if (data && typeof data === 'string') {
            return data.replace('- Primary DX', '').replace(/\s/g, '');
        }
    }
    //logic for getting values from generator function.
    getNextCodeTypeGenerator(codeType) {
        try {
            if (!this.codeTypeGens[codeType]) {
                this.codeTypeGens[codeType] = this.createCodeTypesGens(codeType);
            }
            return this.codeTypeGens[codeType].next().value;
        } catch (error) {
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }
    //Create the data table to display the prem code data.
    createTableData(data) {
        try {
            let lstTableData = [];
            if (data && typeof data === 'object' && data.length) {
                this.objInitTableSettings.boolShowIcon = !this.boolHideAutoDoc; 
                for (let i = 0; i < data.length; i++) {
                    const obj = data[i];
                    obj['flag'] = {};
                    obj['flag'].value = obj.strColor;
                    obj['flag'].strCellValue = obj.strHoverText;
                    obj['flag'].strTooltipNubbinAlignment = 'left-top';
                    if (obj.strColor === '1') {
                        obj['flag'].wrapper = `<span class="slds-m-horizontal_small circular-shape slds-badge bg-red">&nbsp;</span>` //slds-theme_error
                        obj['flag'].strTextTooltipContent = obj.strHoverText;
                    } else if (obj.strColor === '2') {
                        obj['flag'].wrapper = `<span class= "slds-m-horizontal_small circular-shape slds-badge bg-orange">&nbsp;</span>`
                        obj['flag'].strTextTooltipContent = obj.strHoverText;
                    } else if (obj.strColor === '3') {
                        obj['flag'].wrapper = `<span class= "slds-m-horizontal_medium">&nbsp;</span>`
                    }
                    obj['bitPrem'] = this.currentSelectedCode + '-' + obj['bitCodeGroup'];
                    if (localStorage.getItem('codecheckLS' + '-' + this.strInteractionLogId + this.strCMID + this.currentSelectedCode + obj['bitCodeGroup'])) {
                        obj['isIconDisabled'] = true;
                    }
                    lstTableData.push(obj);
                }
            }
            return lstTableData;
        } catch (error) {
            this.boolNoRecords = true;
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }
    validateInputs() {
        let boolIsDataValid = true;
        if(!this.dateOfService){
            this.template.querySelector('.clsDateOfService').reportValidity();
            boolIsDataValid = false;
        }
        if(this.boolHCPCS && !this.strCPTHCPCS) {
            this.template.querySelector('.clsHCPCS').reportValidity();
            boolIsDataValid = false;
        }
        if(this.boolICDDiagnosis && !this.strICDDiagnosis) {
            this.template.querySelector('.clsICDDiagnosis').reportValidity();
            boolIsDataValid = false;
        }
        if(this.boolICDProcedure && !this.strICDProcedure) {
            this.template.querySelector('.clsICDProcedure').reportValidity();
            boolIsDataValid = false;
        }
        if(this.boolNDC) {
            if(this.template.querySelector('.clsNDC').checkValidity()){
                boolIsDataValid = false;
            }
            this.template.querySelector('.clsNDC').reportValidity();
        }
        return boolIsDataValid;
    }
    resetSearchValues() {
        this.strCPTHCPCS = '';
        this.strICDDiagnosis = '';
        this.strICDProcedure = '';
        this.strNDC = '';
        this.boolHCPCS = false;
        this.boolICDDiagnosis = false;
        this.boolICDProcedure = false;
        this.boolNDC = false;
        if(this.template.querySelector('.clsMultiSelect')) {
            this.template.querySelector('.clsMultiSelect').resetValue();
        }
    }
    createRequestBody() {
        let lstPremierCodes = [];
        const lstCPTAndHCPCSCodes = this.strCPTHCPCS?.split(' ');
        if (lstCPTAndHCPCSCodes && lstCPTAndHCPCSCodes.length > 0) {
            lstCPTAndHCPCSCodes.forEach(function(strCode) {
                let objCode = {
                    code: strCode.toUpperCase(),
                    codeType: 'C'
                }
                lstPremierCodes.push(objCode);
            });
        }
        const lstICD10DiagnosisCodes = this.strICDDiagnosis?.split(' ');
        if (lstICD10DiagnosisCodes && lstICD10DiagnosisCodes.length > 0) {
            lstICD10DiagnosisCodes.forEach(function(strCode) {
                var objCode = {
                    code: strCode.toUpperCase(),
                    codeType: '1'
                }
                lstPremierCodes.push(objCode);
            });
        }
        const lstICD10ProcedureCodes = this.strICDProcedure?.split(' ');
        if (lstICD10ProcedureCodes && lstICD10ProcedureCodes.length > 0) {
            lstICD10ProcedureCodes.forEach(function(strCode) {
                var objCode = {
                    code: strCode.toUpperCase(),
                    codeType: 'Z'
                }
                lstPremierCodes.push(objCode);
            });
        }
        const lstNDCCodes = this.strNDC?.split(' ');
        if (lstNDCCodes && lstNDCCodes.length > 0) {
            lstNDCCodes.forEach(function(strCode) {
                var objCode = {
                    code: strCode.toUpperCase(),
                    codeType: 'R'
                }
                lstPremierCodes.push(objCode);
            });
        }
        this.lstCodesForAPI = lstPremierCodes;
    }
	handleCodeTypeOptions(objEvent) {
		const strValues = objEvent.detail;
		if (this.selectedCodeTypes) {
			const lstValues = JSON.parse(strValues);
			if (lstValues && lstValues.length) {
				lstValues.forEach((objElement) => {
					if (objElement.label === 'CPT ; HCPCS') {
						this.boolHCPCS = objElement.selected;
					} else if (objElement.label === 'ICD 10 Diagnosis Code') {
						this.boolICDDiagnosis = objElement.selected;
					} else if (objElement.label === 'ICD 10 Procedure Codes') {
						this.boolICDProcedure = objElement.selected;
					} else if (objElement.label === 'NDC') {
						this.boolNDC = objElement.selected;
					}
				});
			}
		}
	}
	fetchTabData() {
        if (!this.enclosingTabId) {
            return;
        }
		getTabInfo(this.enclosingTabId).then(objTabData => {
			this.objTabData = objTabData;
			if (BaseLWC.stringIsNotBlank(this.labels.EnableVPSTabSpecificEvents_ACE) && this.labels.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
				this.boolVPSTabSpecificEvents = true;
			}
			if (this.objTabData.isSubtab === true) {
				this.strBaseCurrentParentTabId = this.objTabData.parentTabId;
			} else {
				this.strBaseCurrentParentTabId = this.objTabData.tabId;
			}
			//Always add executeInitialFunctionality function which can be reused for refresh.
			this.planSummaryListener();
		}).catch(() => {
			this.handleErrors();
		});
	}
	handleErrors() {
		//DO nothing
	}
	planSummaryListener() {
		if (this.boolVPSTabSpecificEvents) {
			window.addEventListener(
				"PlanSummaryEvent_" + this.strBaseCurrentParentTabId,
				this.capturePlanSummaryListener
			);
		} else {
			window.addEventListener(
				"PlanSummaryEvent",
				this.capturePlanSummaryListener
			);
		}
	}
	capturePlanSummaryListener = (planSummaryDataEvent) => {
		if (BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail)) {
			if (this.boolVPSTabSpecificEvents) {
				window.removeEventListener("PlanSummaryEvent_" + this.strBaseCurrentParentTabId, this.capturePlanSummaryListener);
			} else {
				window.removeEventListener("PlanSummaryEvent", this.capturePlanSummaryListener);
			}
			this.PlanSummaryData = JSON.parse(planSummaryDataEvent.detail);
			if (this.PlanSummaryData.strIdDestination === 'PlanCardDetails_ACE') {
				this.boolPlanSummaryData = true;
				let objPlanData;
				if (this.PlanSummaryData && this.PlanSummaryData.objParameters && this.PlanSummaryData.objParameters.objMessage && this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails) {
					objPlanData = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails;
					this.subscriberId = objPlanData.strSubscriberId;
					this.strCMID = objPlanData.strClientMemberId;
					this.strGroupNumber = objPlanData.strGroupNumber;
					this.strCorpCode = objPlanData.strCorpCode + '1';
					this.strState = this.strCorpCode;
					this.strPolicyId = objPlanData.strPolicyId;
					this.strEffectiveDate = objPlanData.strEffectiveDate;
					this.strTerminationDate = objPlanData.strTerminationDate;
				}
			}
		}
	}
	onChangeDateofService(objEvent) {
        this.dateOfService = this.template.querySelector('.clsDateOfService').value;
    }
    registerInput() {
        if(this.template.querySelector('.clsNDC')) {
            this.strNDC = this.template.querySelector('.clsNDC').value;
        } 
        if(this.template.querySelector('.clsICDProcedure')) {
            this.strICDProcedure = this.template.querySelector('.clsICDProcedure').value;
        }
        if(this.template.querySelector('.clsICDDiagnosis')) {
            this.strICDDiagnosis = this.template.querySelector('.clsICDDiagnosis').value;
        }
        if(this.template.querySelector('.clsHCPCS')) {
            this.strCPTHCPCS = this.template.querySelector('.clsHCPCS').value;
        }
    }
    createCodeTypesGens(codeType) {
        try {
            const codeTypeHeader = {
                'R': "R - NDC",
                '1': "1 - ICD 10 Diagnosis",
                '9': "9 - ICD 9 Diagnosis",
                'Z': "Z - ICD 10 Procedure",
                'H': "H - ICD 9 Procedure",
                'C': "C - CPT HCPCS",
                'G': "G - BIT_PCG"
            }
            const codeTypeForAutoDoc = {
                'R': "NDC",
                '1': "ICD 10 Diagnosis",
                '9': "ICD 9 Diagnosis",
                'Z': "ICD 10 Procedure",
                'H': "ICD 9 Procedure",
                'C': "CPT & HCPCS"
            }
            return (function* () {
                while (true) {
                    yield codeTypeHeader[codeType];
                    yield codeTypeForAutoDoc[codeType];
                }
            })();
        } catch (error) {
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }
}