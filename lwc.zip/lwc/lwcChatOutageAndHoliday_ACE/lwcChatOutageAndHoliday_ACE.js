import { LightningElement, track, wire } from 'lwc';

import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
import latestChatConfigMessage from '@salesforce/label/c.ChatConfig_Outage_Message_ACE';

export default class LwcChatOutageAndHolidayACE extends LightningElement {

      @wire(EnclosingTabId) enclosingTabId;
      
      boolError = false;
      @track isAlertVisible;

      label = {
        latestChatConfigMessage
      }
      /**
     * Connected Call back function.
     */
      connectedCallback() {
        this.isAlertVisible = true;
      }
     /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     * All components should have this code.
     */
      fetchTabData() {
            if (this.enclosingTabId) {
                  getTabInfo(this.enclosingTabId).then(objTabData => {
                        this.objTabData = objTabData;
                  }).catch(error => {
                        this.handleErrors(error);
                  });
            }
      }

      /**
      * To handle Close.
      * Removes the alert off the screen.
      */
      closeNotification() {
        this.isAlertVisible= false;
      }

      /**
      * To handle Errors.
      * Helps to show case errors.
      * All components should have this code.
      */
      handleErrors() {
            this.boolError = true;
      }
}