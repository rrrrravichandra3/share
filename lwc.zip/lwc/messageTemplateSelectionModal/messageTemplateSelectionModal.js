import { LightningElement, track, api } from "lwc";
//Import Shared JS files.
//Base LWC functions.
import BaseLWC from "c/baseLWCFunctions_CF";
import getSMSMessageTemplates from "@salesforce/apexContinuation/SMSTextMessageController_ACE.fetchSMSTemplates";
import getSecureMessageTemplates from "@salesforce/apexContinuation/SecureMessageController_ACE.fetchSecureMessageTemplates";
import SMSTextMessage_Communication_Api_Error_Message from "@salesforce/label/c.IntegrationFailMessage_ACE";
import SMS_Text_Message_Insert_Template_Header from "@salesforce/label/c.SMS_Text_Message_Insert_Template_Header";
import Secure_Message_Insert_Template_Header from "@salesforce/label/c.Secure_Message_Insert_Template_Header";

export default class MessageTemplateSelectionModal extends LightningElement {
  @api isSecure;
  columns = [
    {
      label: "Name",
      fieldName: "Link",
      sortable: true,
      type: "text"
    },
    {
      label: "Message Body Preview",
      fieldName: "MessageBodyPreview",
      sortable: true,
      type: "text"
    }
  ];
  extraColumns = [
    {
      label: "Subject",
      fieldName: "Subject",
      sortable: false,
      type: "text",
      boolHidden: true
    },
    {
      label: "Message Body",
      fieldName: "MessageBody",
      sortable: false,
      type: "text",
      boolHidden: true
    }
  ];
  pageSize = 100;
  objInitTableSettings = {
    pageSize: this.pageSize,
    boolViewMore: false,
    columnsData: this.columns,
    boolSecondaryTable: false,
    boolShowSearch: false,
    boolPagination: false
  };
  @track filteredTemplateData = [];
  @track templateData = [];
  boolTemplateLoading;
  boolTemplateAPIError;
  templateAPIErrorMessage;
  templateAPIData;
  label = {
    SMSTextMessage_Communication_Api_Error_Message,
    Secure_Message_Insert_Template_Header,
    SMS_Text_Message_Insert_Template_Header
  };
  header;
  connectedCallback() {
    if (this.isSecure) {
      this.columns.push(this.extraColumns[0]);
      this.columns.push(this.extraColumns[1]);
      this.header = this.label.Secure_Message_Insert_Template_Header;
      this.getSecureMessageTemplates();
    } else {
      this.header = this.label.SMS_Text_Message_Insert_Template_Header;
      this.getSMSMessageTemplates();
    }
  }
  convertToPlain(html) {
    const tempDivELement = document.createElement("div");
    tempDivELement.innerHTML = html;
    return tempDivELement.textContent || tempDivELement.innerText || "";
  }
  getSMSMessageTemplates() {
    this.boolTemplateLoading = true;
    getSMSMessageTemplates()
      .then((objResult) => {
        if (BaseLWC.isNotUndefinedOrNull(objResult)) {
          const resultData = JSON.parse(objResult);
          if (resultData.strResponseStatusCode === "200") {
            this.boolTemplateAPIError = false;
            this.templateAPIData = resultData.strResponseBody;
            JSON.parse(this.templateAPIData).forEach((e) => {
              if (!e.hasOwnProperty("messageType")) {
                return false;
              }
              const Link = `<a data-masterLabel=${e.messageType[0].tagTitle} href='javascript:void(0);' class='slds-wrap'>${e.messageType[0].tagTitle}</a>`;

              const LinkData = {
                value: e.messageType[0].tagTitle,
                wrapper: Link
              };
              const description = this.convertToPlain(e.messageCopy);
              const bodyPreview = {
                value: description,
                wrapper: e.messageCopy.replace(/\n/g, "<br/>")
              };
              this.templateData.push({
                Name: e.messageType[0].tagTitle,
                MessageBodyPreview: bodyPreview,
                Link: LinkData,
                rowId: e.messageType[0].tagId
              });
            });
          } else {
            this.boolTemplateAPIError = true;
            this.templateAPIErrorMessage =
              this.label.SMSTextMessage_Communication_Api_Error_Message;
          }
          this.filteredTemplateData = this.templateData;
          this.boolTemplateLoading = false;
        }
      })
      .catch(() => {
        //do nothing
      });
  }
  getSecureMessageTemplates() {
    this.boolTemplateLoading = true;
    getSecureMessageTemplates()
      .then((objResult) => {
        if (BaseLWC.isNotUndefinedOrNull(objResult)) {
          const resultData = JSON.parse(objResult);
          if (resultData.strResponseStatusCode === "200") {
            this.boolTemplateAPIError = false;
            this.templateAPIData = resultData.strResponseBody;
            JSON.parse(this.templateAPIData).forEach((e) => {
              if (!e.hasOwnProperty("secure-message-template-type")) {
                return;
              }
              const Link = `<a data-masterLabel=${e["secure-message-template-type"][0].tagTitle} href='javascript:void(0);' class='slds-wrap'>${e["secure-message-template-type"][0].tagTitle}</a>`;

              const LinkData = {
                value: e["secure-message-template-type"][0].tagTitle,
                wrapper: Link
              };
              const body = [
                e.salutation,
                e.messagebody,
                e.personalNoteFromStaff,
                e.signature
              ]
                .filter((el) => BaseLWC.stringIsNotBlank(el))
                .join("")
                .replace(/\n/g, "<br/>");
              const [first = "", second = ""] = e.messagebody.split("\n", 2);
              const completeBody = {
                value: body,
                wrapper: body
              };
              const preview = [first, second].filter(el=>BaseLWC.stringIsNotBlank(el)).join('<br/>');
              const bodyPreview = {
                value: preview,
                wrapper: preview
              };
              this.templateData.push({
                Name: e["secure-message-template-type"][0].tagTitle,
                MessageBodyPreview: bodyPreview,
                Subject: e.subjectline,
                MessageBody: completeBody,
                Link: LinkData,
                rowId: e["secure-message-template-type"][0].tagId
              });
            });
          } else {
            this.boolTemplateAPIError = true;
            this.templateAPIErrorMessage =
              this.label.SMSTextMessage_Communication_Api_Error_Message;
          }
          this.filteredTemplateData = this.templateData;
          this.boolTemplateLoading = false;
        }
      })
      .catch(() => {
        //do nothing
      });
  }
  handleSearch = (event) => {
    const searchValue = event.target.value.toLowerCase();
    if (BaseLWC.stringIsNotBlank(searchValue)) {
      this.filteredTemplateData = this.templateData.filter((e) => {
        if (e.Name.toLowerCase().includes(searchValue)) {
          return true;
        }
      });
    } else {
      this.filteredTemplateData = this.templateData;
    }
  };
  handleRowAction = (event) => {
    const rowData = JSON.parse(event.detail);
    const sendEvent = new CustomEvent("rowactionselect", {
      detail: rowData
    });
    this.dispatchEvent(sendEvent);
  };
  handleCloseTemplateClick() {
    BaseLWC.fireNativeCustomEvent("closetemplatemodal", {}, this);
  }
}
