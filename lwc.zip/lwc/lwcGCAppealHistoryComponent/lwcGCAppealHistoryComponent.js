import { LightningElement,api,wire} from 'lwc';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
//Base Workspace functions.
import Message_error_ACE from "@salesforce/label/c.Message_error_ACE";
//CEAS-82941 Changes
import { EnclosingTabId, getTabInfo, openSubtab, setTabIcon, refreshTab, setTabLabel} from 'lightning/platformWorkspaceApi';
import ViewPlanSummary_CardHeader_Refresh_ACE from "@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE";
import Message_warning_ACE from "@salesforce/label/c.MessageLightningComponent_Warning_ACE";
import SafeMode_ToastMessage_ACE from "@salesforce/label/c.SafeMode_ToastMessage_ACE";
import IntegrationFailMessage_ACE from "@salesforce/label/c.FacetsNotesAPIErrorMessage_ACE";
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import fetchGCComplaintSummary from '@salesforce/apexContinuation/GCAppealsController_ACE.fetchGCComplaintSummary';

export default class LwcGCAppealHistoryComponent extends LightningElement {
    //CEAS-82941 Changes
    @wire(EnclosingTabId) enclosingTabId;
    label = {
        ViewPlanSummary_CardHeader_Refresh_ACE,
        Message_warning_ACE,
        SafeMode_ToastMessage_ACE,
        IntegrationFailMessage_ACE,
        Message_error_ACE,
        EnableVPSTabSpecificEvents_ACE
    };

    @api boolShowSpinnerGC = false;
    @api boolNoRecordsGC = false;
    @api boolAPIError = false;
    boolError = '';
    //CEAS-84459 AutoDoc Appeals
    strAccountId;
    @api strSubscriberId = '';
    //Initial Load
    boolShowSpinnerGC = true;
   
    //Table Data
    @api lstGCAppealsData = [];
  

        //Table Settings
        objGCAppealsSettings = {
            pageSize: 25,
            showPagination : true,
            boolViewMore: false,
            columnsData: [
                { label: 'Appeal Type', fieldName: 'strAppealType', sortable: true, type: '' },
                { label: 'Appeal Creation Date', fieldName: 'strAppealCreationDate', sortable: true, boolInitSort: true, boolAsc: false, type: 'date' },
                { label: 'Compliance Due Date', fieldName: 'strComplianceDueDate', sortable: true, type: 'date' },
                { label: 'Appeal Status', fieldName: 'strAppealStatus', sortable: true, type: '' },
                { label: 'Complaint Class', fieldName: 'strComplaintClass', sortable: true, boolAsc: false, type: '' },
                { label: 'Appeal ID', fieldName: 'strAppealID', sortable: true, type: '' }
            ],
            boolSecondaryTable: false,
            boolShowFilter: true,
            boolPagination: true,
            boolShowSearch:true,
            searchPlaceholder : 'Search Text',
            boolHasSearchandFilterCustomMargins: true,
            objSearchandFilterCustomMargins:{
                top: "0.75rem",
                bottom: "0",
                right: "0",
            },
            filterData : [
                {strType : '', intCol : -1, strFilterName : 'Select a value'},
                {strType : 'picklist', intCol : 1, strFilterName : 'Appeal Type'},
                {strType : 'date', intCol : 2, strFilterName : 'Appeal Creation Date'},
                {strType : 'date', intCol : 3, strFilterName : 'Compliance Due Date'},
                {strType : 'picklist', intCol : 4, strFilterName : 'Appeal Status'},
                {strType : 'picklist', intCol : 5, strFilterName : 'Complaint Class'},
                {strType : 'text', intCol : 6, strFilterName : 'Appeal ID'}
            ],
            boolShowCheckbox : false,
            boolShowHeader : false,
            boolShowSearchLabel: false,
            restrictedPageSize : false,
            boolPaginationwithSize: true,
            pageMenu : [25,50,75,100]
        };

        connectedCallback() {
            try {
                this.fetchTabData();
            } catch (error) {
                this.handleErrors(error);
            }
        }

        fetchTabData() {
            //CEAS-82941 Changes 
            if (this.enclosingTabId) {
                getTabInfo(this.enclosingTabId).then((tabInfo) => {
                    this.objTabData = tabInfo;
                    const strURL = this.objTabData.url;
                    this.strSubscriberId = BaseLWC.helperBaseGetUrlParameters('subscriberId', strURL);
                    //CEAS-84459 AutoDoc Appeals
                    this.strAccountId = BaseLWC.helperBaseGetUrlParameters('accountId',strURL); 
                    this.boolShowSpinnerGC = true;
                    this.fetchData();
                }).catch((error) => {
                    this.handleErrors();
                });
            }
        }

        handleErrors(error) {
            this.boolError = error;
        }

        fetchData() {
            if (!this.strSubscriberId) {
                this.boolNoRecordsGC = true;
                this.boolShowSpinnerGC = false;
                return;
            }
            let jasonreqbody = '{"strSubscriberid": "'+ (this.strSubscriberId * 1).toString() + '"}';
            this.boolShowSpinnerGC = true;
            this.lstGCAppealsData = [];
            fetchGCComplaintSummary({
                strDataJSON: jasonreqbody
            }).then(objResult => {
                    var lstAppealsGC = [];
                    const lstData=JSON.parse(objResult);
                    for(let i=0;i<lstData.length;i++) {
                        const obj={...lstData[i]};
                        lstAppealsGC.push(obj);
                    } 
                    if (!lstAppealsGC.length) {
                        this.boolNoRecordsGC = true;
                    } else {
    
                        //Format Data
                        lstAppealsGC = this.formatData(lstAppealsGC);
    
                        //Sort Array
                        lstAppealsGC.sort((a, b) => {
                            if (a.strAppealCreationDate !== '' && b.strAppealCreationDate !== ''){
                                const dateTime1 = Date.parse(a.strAppealCreationDate);
                                const dateTime2 = Date.parse(b.strAppealCreationDate);
                                
                                if (dateTime1 > dateTime2) {
                                    return -1;
                                } else if (dateTime1 < dateTime2) {
                                    return 1;
                                }
                                else {
                                    return 0;
                                }
                            }
                            else if (a.strAppealCreationDate !== '') {
                                return -1;
                            } else if (b.strAppealCreationDate !== '') {
                                return 1;
                            } else {
                                return 0;
                            }
                          });
    
                        this.lstGCAppealsData = lstAppealsGC;
                        this.boolNoRecordsGC = false;
                    }
    
                    this.boolShowSpinnerGC = false;
                        
            }).catch(error => {
                this.boolShowSpinnerGC = false;
                this.boolAPIError = true;
                this.handleErrors(error);
            });
        }

        
        convertDateFormat(strDateTime) {
            var finalDate = '';
            if(strDateTime) {
                const dateTimeArray = strDateTime.split("T");
                var strDate = dateTimeArray[0].toString();
                var strDateSplit =strDate.split("-");
                finalDate = strDateSplit[1]+"/"+strDateSplit[2]+"/"+strDateSplit[0];
            }
    
            return finalDate;
        }
    
        formatData(objData) {
            for (let i = 0; i < objData.length; i++){
                    const strAppealID = `<a data-strAppealID=${objData[i]['strAppealID']} href='javascript:void(0);'>${objData[i]['strAppealID']}</a>`;
                    const strUrl = location.origin+'/lightning/n/ViewGCAppealDetails_FlexiPage_ACE'; 
                    objData[i].strAppealID = {
                            value: objData[i]['strAppealID'],
                            subtabRecordID: objData[i]['Id'],
                            wrapper: strAppealID,
                            url: strUrl
                    };
                    objData[i].strAppealCreationDate = this.convertDateFormat(objData[i].strAppealCreationDate);
                    objData[i].strComplianceDueDate = this.convertDateFormat(objData[i].strComplianceDueDate);
            }
    
            return objData;
        }

        refreshCard = () => {
            try {
               this.fetchData();
            } catch (error) {
                this.handleErrors(error);
            }
        };

        handleRowAction(objEvent){
            const rowData = JSON.parse(objEvent.detail);
            this.openAppealDetails(rowData.activeColumnData.value.value);
        }

        openAppealDetails = (strAppealId) => {
            //CEAS-84459 AutoDoc Appeals
            const strEncodedAppealId = btoa('?appealId=' + strAppealId + '&accountId=' + this.strAccountId);
            const strFlexiPageName = 'ViewGCAppealDetails_FlexiPage_ACE';
            const strIconName = 'standard:work_plan';
            let objPageReference;
            objPageReference = {
                "type": "standard__navItemPage",
                "attributes": {
                    "apiName": strFlexiPageName,
                    "uid": strAppealId
                },
                "state": {
                    "c__BaseURLParam": strEncodedAppealId
                }
            };

            //CEAS-82941 Changes
            if (!this.enclosingTabId) {
                return;
            }
            // Navigate to the GC Appeals history view.
            const primaryTabId = this.objTabData.isSubtab ? this.objTabData.parentTabId : this.objTabData.tabId;
            openSubtab(primaryTabId, { pageReference: objPageReference, focus: true}).then((response) => {
                localStorage.strBypassCustomRefreshLogic = "true";
                const focusedSubTabId = response;
                setTabIcon(focusedSubTabId,strIconName,strFlexiPageName);
                refreshTab(focusedSubTabId);
                setTabLabel(focusedSubTabId, strAppealId);
            }).catch(function(error) {
                this.handleErrors(error);
            }); 
        } 
}