import {
	LightningElement,track,wire
} from 'lwc';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import HideComponentsByLOB_ACE from '@salesforce/label/c.HideComponentsByLOB_ACE';
import Government_Medicare_Sup_Label_ACE from '@salesforce/label/c.Government_Medicare_Sup_Label_ACE';
import BaseLWC from 'c/baseLWCFunctions_CF';
import ProfileName from '@salesforce/schema/User.Profile.Name';
import USER_ID from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi';
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
export default class LwcNotificationPreferenceContainerACE extends LightningElement {
	lstLabels = {
		EnableVPSTabSpecificEvents_ACE,
		HideComponentsByLOB_ACE,
		Government_Medicare_Sup_Label_ACE
	};
	boolVPSTabSpecificEvents = false;
	objTabData;
	strMID;
	strCorpCode;
	strGroupNumber;
	strSubId;
	strAccountId;
	parentTabId;
	objPlanDetails;
	objPlanDetailsParentData;
	//CEAS-85501
	boolIsFEP;
    @track boolRenderCards=false;
	@track boolRenderVIPCards = true;
	@track boolRenderOptOutPref = false;

	get boolRenderNotificationPrefCard() {
		return this.boolRenderCards;
	}
	get boolRenderOptOutPrefCard() {
		return this.boolRenderOptOutPref && !this.boolIsFEP;
	}

	get boolRenderVIPIndicatorCard() {
		return this.boolRenderCards && !this.boolIsFEP;
	}

	@track profileName;
	@wire(getRecord, { recordId: USER_ID, fields: [ProfileName] })
    wireUserData({ error, data }) {
        if (data) {
            this.profileName = data.fields.Profile.value.fields.Name.value;
        } else if (error) {

        }
    }

	@wire(EnclosingTabId) enclosingTabId;

	connectedCallback() {
		if (this.enclosingTabId) {
			getTabInfo(this.enclosingTabId).then((objTabData) => {
				if (this.lstLabels.EnableVPSTabSpecificEvents_ACE && this.lstLabels.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
					this.boolVPSTabSpecificEvents = true;
				}
				this.objTabData = objTabData;
				let strBaseCurrentTabUrl = objTabData.url;
				this.strMID = BaseLWC.helperBaseGetUrlParameters('mid', strBaseCurrentTabUrl);
				this.strCorpCode = BaseLWC.helperBaseGetUrlParameters('corpCode', strBaseCurrentTabUrl);
				this.strGroupNumber = BaseLWC.helperBaseGetUrlParameters('groupNumber', strBaseCurrentTabUrl);
				//CEAS-85501
				let strIsFEP = BaseLWC.helperBaseGetUrlParameters('isLineOfBusinessFEP', strBaseCurrentTabUrl);
				if(strIsFEP && strIsFEP === 'true') {
					//Set FEP variable
					this.boolIsFEP = true;
				}
				let strAdditionalParams = BaseLWC.helperBaseGetUrlParameters('ws', strBaseCurrentTabUrl);
				if (strAdditionalParams && strAdditionalParams.includes('/')) {
					let allElements = strAdditionalParams.split("/");
					if (allElements && Array.isArray(allElements) && allElements.length > 4) {
						this.strAccountId = allElements[4];
					}
				}
				this.strSubId = BaseLWC.helperBaseGetUrlParameters("subscriberId", strBaseCurrentTabUrl);
				this.parentTabId = objTabData.parentTabId;
				this.planSummaryListener();
			}).catch((objError) => {
                this.handleError(objError);
			});

			
		}
	}
	planSummaryListener() {
		if (this.parentTabId) {
			if (this.boolVPSTabSpecificEvents) {
				window.addEventListener(
					'PlanSummaryEvent_' + this.parentTabId,
					this.capturePlanSummaryListener
				);
			} else {
				window.addEventListener(
					'PlanSummaryEvent',
					this.capturePlanSummaryListener
				);
			}
		}
	}
	capturePlanSummaryListener = (objEvent) => {
		try {
			if (BaseLWC.isNotUndefinedOrNull(objEvent.detail) &&
				typeof objEvent.detail === "string"
			) {
				const objPlanSummaryData = JSON.parse(objEvent.detail);
				if (objPlanSummaryData && (objPlanSummaryData.strIdDestination === "PlanCardDetails_ACE") && objPlanSummaryData.objParameters) {
					if (objPlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strMemberId === this.strMID &&
						objPlanSummaryData.objParameters.strParentTabId === this.parentTabId) {
                        //Save Plan Summary Data
						this.objPlanDetailsParentData = objPlanSummaryData.objParameters.objMessage;
						this.objPlanDetails = objPlanSummaryData.objParameters.objMessage.objSelectedPlanDetails;
						let strLineOfBusiness;
						if(this.objPlanDetails.strAceLineOfBusiness) {
							strLineOfBusiness = this.objPlanDetails.strAceLineOfBusiness.toUpperCase();
							if(strLineOfBusiness === 'FEP') {
								this.boolIsFEP = true;
							}
						}
						if(strLineOfBusiness && (strLineOfBusiness === this.lstLabels.Government_Medicare_Sup_Label_ACE.toUpperCase() || this.lstLabels.HideComponentsByLOB_ACE.toUpperCase().includes(strLineOfBusiness))) {
							this.boolRenderCards = false;
						} else {
                        	this.boolRenderCards = true;
							if (BaseLWC.isNotUndefinedOrNull(objPlanSummaryData) && objPlanSummaryData.objParameters.objMessage.strMarketSegmentData) {
								this.template.querySelector('c-lwc-notification-v-i-p-indicator-a-c-e').loadCards(this.objPlanDetailsParentData);
							}
						}
						if (this.boolVPSTabSpecificEvents) {
							window.removeEventListener(
								'PlanSummaryEvent_' + this.parentTabId,
								this.capturePlanSummaryListener
							);
						} else {
							window.removeEventListener(
								'PlanSummaryEvent',
								this.capturePlanSummaryListener
							);
						}
						this.boolRenderOptOutPref = true;
					}
				}
			}
		} catch (objError) {
            this.handleError(objError);
		}
	}
    handleError(objError) {
		//Do Nothing.
    }
}