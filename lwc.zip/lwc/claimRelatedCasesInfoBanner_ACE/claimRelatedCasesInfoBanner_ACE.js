import { LightningElement } from 'lwc';

export default class ClaimRelatedCasesInfoBanner_ACE extends LightningElement {
    boolInfo = true;
    closeMessage() {
        this.boolInfo = false;
    }
    connectedCallback() {
        this.boolInfo = true;
    }
    handleRelatedCasesOpen() {
        const objParameterToBeSent = {
            'showRelatedCases' : true
        }
        const objCustomEvent = new CustomEvent('showrelatedcases', {
            detail: objParameterToBeSent
        });
        this.dispatchEvent(objCustomEvent);
        this.boolInfo = false;
    }
}