import { LightningElement, api } from 'lwc';
import ConfirmationButton_ACE from '@salesforce/label/c.ConfirmationButton_ACE';
import EO_DismissAllConfirmationNoLabel_ACE from '@salesforce/label/c.HIPAAAuthParty_CancelLabel_ACE';
import EO_DismissAllConfirmationLabel_ACE from '@salesforce/label/c.EO_DismissAllConfirmationLabel_ACE';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';

export default class LwcEODismissAllModalComponentACE extends LightningElement {
    label = { ConfirmationButton_ACE, EO_DismissAllConfirmationNoLabel_ACE, EO_DismissAllConfirmationLabel_ACE, IntegrationFailMessage_ACE };
    boolSpinner = false;
    boolError = false;
    strErrorMessage = this.label.IntegrationFailMessage_ACE;
    handleCancel = () => {
        BaseLWC.fireNativeCustomEvent('cancel', '', this);
    };
    handleConfirm = () => {
        this.boolError = false;
        this.boolSpinner = true;
        BaseLWC.fireNativeCustomEvent('confirm', '', this);
    };
    @api
    showError() {
        this.boolSpinner = false;
        this.boolError = true;
    }
}
