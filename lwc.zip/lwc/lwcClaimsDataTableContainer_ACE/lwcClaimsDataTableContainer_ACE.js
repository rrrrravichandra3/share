import { LightningElement,api, wire } from 'lwc';
import { EnclosingTabId, getTabInfo, openSubtab, setTabIcon, refreshTab } from 'lightning/platformWorkspaceApi';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import IDR_IntegrationError_ACE from '@salesforce/label/c.IDR_IntegrationError_ACE';
import ViewFamily_NoRecordsFound_ACE from '@salesforce/label/c.ViewFamily_NoRecordsFound_ACE';
import HCSCClaimsStaticResource_ACE from '@salesforce/resourceUrl/HCSCClaimsStaticResource_ACE';

export default class LwcClaimsDataTableContainer_ACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    @api lstColumns;
    @api lstRowsData;
    @api strUrlParam;
    @api strFlexiPage;
    @api strViewMoreParams;
    @api strHistoryIconName;
    @api strIconName;
    @api boolIsDataPresent = false;
    @api boolIsNoDataError = false;
    @api boolIsIntegrationError = false;
    @api boolFEPMember = false;
    @api strTableClasses;
    @api strMid;
    @api strClaimsFEPDirectURL;
    @api boolIsDisputeClicked = false;
    @api strDisputeClaimsUrlParam;
    @api strDisputeClaimsFlexiPage;
    @api strLineOfBusiness;
    @api boolMedicalData;
    objTabData;
    boolColDenial;
    boolColDisputeDCN;
    
    lstLabel = {
        IntegrationFailMessage_ACE,
        ViewFamily_NoRecordsFound_ACE,
        IDR_IntegrationError_ACE
    };

    infoIconURL = HCSCClaimsStaticResource_ACE + '/Images/info.png';
    
    get boolShowViewAll() {
        return this.lstRowsData && !this.lstRowsData.length || this.boolIsNoDataError || this.boolIsIntegrationError;
    }
    viewHistory(objEvent) {
        if (!this.enclosingTabId) {
            return;
        }
        getTabInfo(this.enclosingTabId)
            .then((objTabData) => {
                this.objTabData = objTabData;
                openSubtab(this.objTabData.tabId, {url: this.strViewMoreParams, focus: true})
                    .then((response) => {
                        setTabIcon(response, this.strHistoryIconName, this.strFlexiPage);
                        refreshTab(response);
                    }).catch(() => {
                        //Do nothing
                    })
                })
            .catch((error) => {
                this.handleErrors(error);
            });
    }
    display(objEvent) {
        if(objEvent && objEvent.target && objEvent.target.parentNode) {
            let target = objEvent.target.parentNode.querySelectorAll('.slds-popover');
            if(target[0]) {
                target[0].classList.remove('slds-hide');
            }
            
        }
        
    }
    displayOut(objEvent) {
        if(objEvent && objEvent.target && objEvent.target.parentNode) {
            let target = objEvent.target.parentNode.querySelectorAll('.slds-popover');
            if(target[0]) {
            target[0].classList.add('slds-hide');
            }
        } 
    }
}