//Duplicated from caseNotesViewModalLwc_ACE for use as child component of other LWC Component
//Component created for CEAS-51147
import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getCaseDetails from '@salesforce/apex/CaseNotesViewController_ACE.getContentDocuments';
import getRelatedDetails from '@salesforce/apex/CaseNotesViewController_ACE.fetchCaseRelatedDetailsRecordsMultiple';
//Import custom labels
import NotesRollUpSummary_CaseNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_CaseNotes_ACE';
import NotesRollUpSummary_ParentCaseNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_ParentCaseNotes_ACE';
import NotesRollUpSummary_ChildCaseNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_ChildCaseNotes_ACE';
import NotesRollUpSummary_CSTTimeZone_ACE from '@salesforce/label/c.NotesRollUpSummary_CSTTimeZone_ACE';
import CaseNotesModal_CASE_ACE from '@salesforce/label/c.CaseNotesModal_CASE_ACE';
import CaseNotesModal_Notes_ACE from '@salesforce/label/c.CaseNotesModal_Notes_ACE';
import CaseNotesModal_Refresh_ACE from '@salesforce/label/c.CaseNotesModal_Refresh_ACE';
import ViewCaseSummary_NoCasesError_ACE from '@salesforce/label/c.ViewCaseSummary_NoCasesError_ACE';
import CreateCasePage_CaseRelatedTable_ACE from '@salesforce/label/c.CreateCasePage_CaseRelatedTable_ACE';

//CEAS-61105
import FacetsNotesAPIErrorMessage_ACE from '@salesforce/label/c.FacetsNotesAPIErrorMessage_ACE';
import FacetsTaskTitle_ACE from '@salesforce/label/c.FacetsTaskTitle_ACE';
import getFacetsTaskNotes from '@salesforce/apexContinuation/FacetNotesController_ACE.getFacetsTaskNotes';
import BaseLWC from 'c/baseLWCFunctions_CF';
import HideContentNotesOnViewNotes_ACE from '@salesforce/label/c.HideContentNotesOnViewNotes_ACE';

export default class LwcCaseNotesViewModal extends NavigationMixin(LightningElement) {
    label = {
        NotesRollUpSummary_CaseNotes_ACE,
        NotesRollUpSummary_ParentCaseNotes_ACE,
        NotesRollUpSummary_ChildCaseNotes_ACE,
        NotesRollUpSummary_CSTTimeZone_ACE,
        CaseNotesModal_CASE_ACE,
        CaseNotesModal_Notes_ACE,
        CaseNotesModal_Refresh_ACE,
        ViewCaseSummary_NoCasesError_ACE,
        FacetsNotesAPIErrorMessage_ACE,
        FacetsTaskTitle_ACE,
        CreateCasePage_CaseRelatedTable_ACE,
        HideContentNotesOnViewNotes_ACE
    };
    boolNotesCallBackDone = false;
    boolCaseNotesAvailable = false;
    boolParentCaseNotesAvailable = false;
    boolChildCaseNotesAvailable = false;
    boolShowWarning = false;
    boolShowSpinner = true;
    caseDetails = {};
    lstOwnNotes = {};
    lstParentNotes = {};
    lstChildNotes = {};
    strCaseTypeCategory = null;
    @api fromNotepad;
    @api currTabId;
    @api strCaseId;
    @api strCaseNumber;
    @api strCaseType;
    @api strCaseSubType;
    //CEAS-61105
    @api strFacetsTaskId;
    @api strLineOfBusiness;
    @api showPrevious = false;
    @api showHeaderCenter = false;
    boolIsValidFacets = false;
    facetsTaskTitle = '';
    boolError = false;
    boolSuccess = false;
    boolSpinner = false;
    strErrorMessage = '';
    activeTabvalue = 'caseNotes';
    boolArchivedRecordNotes = false;
    lstCaseIds;
    lstOwnRelatedDetails;
    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
                this.fetchDataFromServer();
                //CEAS-61105
                this.renderTabViewForFacets();

        } catch (error) {
            //Do nothing
        }
    }
    get headerClass() {
        if (this.showHeaderCenter) {
            return 'card-header card-header-center';
        }
        return 'card-header';
    }
    get hideAllNotes() {
        return BaseLWC.stringIsNotBlank(this.label.HideContentNotesOnViewNotes_ACE) && this.label.HideContentNotesOnViewNotes_ACE.toLowerCase() === 'true';
    }
    handlePrevious = () => {
        BaseLWC.fireNativeCustomEvent('previousclick', {}, this);
    };
    fetchDataFromServer() {
        if (!this.hideAllNotes) {
            getCaseDetails({
                idParent: this.strCaseId
            }).then((result) => {
                if (result) {
                    this.caseDetails = JSON.parse(JSON.stringify(result));
                    this.strCaseTypeCategory = this.caseDetails.strCategory;
                    this.getRelatedDetailsFn();
                }
            })
            .catch(() => {
                //Do Nothing;
            });
        }
    }

    getRelatedDetailsFn() {
        this.lstCaseIds = [this.strCaseId];
        if(this.caseDetails.lstChildNotesWrapper.length) {
            this.lstCaseIds.push(...this.caseDetails.lstChildNotesWrapper.map(el => el.objCase.Id));
        }
        if(this.caseDetails.lstParentNotesWrapper.length) {
            this.lstCaseIds.push(...this.caseDetails.lstParentNotesWrapper.map(el => el.objCase.Id));
        }
        if(this.lstCaseIds.length) {         
            getRelatedDetails({
                lstCases: this.lstCaseIds
            }).then((result) => {
                if (result) {
                    const objResponse = result;
                    const wrapper = this.caseDetails;
                    for(let key in wrapper) {
                        if(key.length && (key === 'lstChildNotesWrapper' || key === 'lstParentNotesWrapper')) {
                            wrapper[key].forEach(el => {
                                if(typeof objResponse && objResponse.hasOwnProperty(el.objCase.Id)) {
                                    const tempId = el.objCase.Id;
                                    el.relatedDetails = objResponse[tempId];
                                } else {
                                    el.relatedDetails = 'no related records';
                                }
                            })
                        }
                    }
                    if(objResponse.hasOwnProperty(this.strCaseId)) {
                        this.lstOwnRelatedDetails =  objResponse[this.strCaseId];
                   	} else {
                        this.lstOwnRelatedDetails = 'no related records';
                    }
                    this.checkData();
                }
            })
            .catch(() => {
                //Do Nothing;
            });
        }
    }

    checkData() {
        if (this.caseDetails.lstNotes.length === 0 && this.caseDetails.lstParentNotesWrapper.length === 0 && this.caseDetails.lstChildNotesWrapper.length === 0) {
            this.boolShowWarning = true;
        } else {
            this.boolShowWarning = false;
            if (this.caseDetails.lstNotes.length > 0) {
                this.boolCaseNotesAvailable = true;
                this.lstOwnNotes = this.caseDetails.lstNotes;
            }
            if (this.caseDetails.lstParentNotesWrapper.length > 0) {
                this.boolParentCaseNotesAvailable = true;
                this.lstParentNotes = this.caseDetails.lstParentNotesWrapper;
            }
            if (this.caseDetails.lstChildNotesWrapper.length > 0) {
                this.boolChildCaseNotesAvailable = true;
                this.lstChildNotes = this.caseDetails.lstChildNotesWrapper;
            }
        }
        this.boolNotesCallBackDone = true;
         this.boolShowSpinner = false;
    }

    navigateToRecordViewPage(event) {
        const objResponse = {
            strIdDestination: 'CaseSummaryCallOpenTab_ACE',
            objParameters: {
                strCaseId: event.target.dataset.id,
                strCaseNumber: event.target.dataset.id
            }
        };
        window.postMessage(JSON.stringify(objResponse), '*');
    }

    refreshModal() {
        try {
            //CEAS-61105
            if (this.activeTabvalue === 'caseNotes') {
                this.fetchDataFromServer();
            } else if (this.activeTabvalue === 'facetsNotes') {
                this.boolError = false;
                this.boolSuccess = false;
                this.boolSpinner = false;
                this.strErrorMessage = '';
                this.getFacetsTaskNotesFn();
            } else {
                // do nothing
            }
        } catch (error) {
            //Do nothing
        }
    }

    //CEAS-61105
    renderTabViewForFacets() {
        if ((typeof(this.strLineOfBusiness) === 'string' &&
            (this.strLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE' || this.strLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICAID')) &&
            this.strCaseType !== 'Special Handling' && this.strCaseSubType !== 'Member Grievance' && this.strFacetsTaskId) {
                this.boolIsValidFacets = true;
                this.facetsTaskTitle = this.label.FacetsTaskTitle_ACE + this.strFacetsTaskId;
        }
    }

    //CEAS-61105
    handleTabClick(event) {
        const tabValue = event.target.value;
        this.activeTabvalue = tabValue;
        if (tabValue === 'facetsNotes') {
            if (this.boolSuccess === false) {
                this.getFacetsTaskNotesFn();
            }
        }
    }

    //CEAS-61105
    getFacetsTaskNotesFn = () => {
        this.boolSpinner = true;
        getFacetsTaskNotes({
            callID: this.strFacetsTaskId
        })
            .then((result) => {
                if (result !== undefined && result !== null && result !== '') {
                    const facetNotes = JSON.parse(result);
                    const notes = [];
                    let i = 0;
                    if (
                        BaseLWC.isNotUndefinedOrNull(facetNotes) &&
                        BaseLWC.isNotUndefinedOrNull(facetNotes.callDetails) &&
                        facetNotes.callDetails.length > 0 &&
                        BaseLWC.isNotUndefinedOrNull(facetNotes.callDetails[0].notes) &&
                        facetNotes.callDetails[0].notes.length > 0
                    ) {
                        facetNotes.callDetails[0].notes.forEach((element) => {
                            if (element !== undefined && element !== null && element !== '') {
                                if (!element.startsWith('ACE')) {
                                    notes.push({
                                        key: i++,
                                        noteFrom: 'FACET ',
                                        note: element
                                    });
                                } else {
                                    element = element.slice(4);
                                    notes.push({
                                        key: i++,
                                        noteFrom: 'ACE ',
                                        note: element
                                    });
                                }
                            }
                        });
                        this.facetNotes = [...notes];
                        this.boolError = false;
                        this.boolSuccess = true;
                    } else {
                        this.handleErrors(this.label.FacetsNotesAPIErrorMessage_ACE);
                    }
                } else {
                    this.handleErrors(this.label.FacetsNotesAPIErrorMessage_ACE);
                }
            })
            .catch(() => {
                this.handleErrors(this.label.FacetsNotesAPIErrorMessage_ACE);
            })
            .finally(() => {
                this.boolSpinner = false;
            });
    };

    //CEAS-61105
    handleErrors = (errorMessage) => {
        this.boolError = true;
        this.strErrorMessage = errorMessage;
    };

    postEventToCaseRelatedAura() {
        const selectedEvent = new CustomEvent("caseNotesRecEvt", {});
        this.dispatchEvent(selectedEvent);
    }
}