/**
 * Created by U390163 on 2/23/2021.
 */
 import {
    LightningElement,
    track,
    api
} from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
export default class DatePickerSlds extends LightningElement {

    lstYear = [];
    strMonth = '';
    objDates = [];

    @api boolRange = false;
    @api boolMultiDateSelected = false;
    @api boolStartDate;
    @api boolEndDate;
    @api strUniqueId = 'pocFromDate';
    @api boolShowLabel = false;
    @api dateLabel = 'from Date';
    @api boolFullWidth = false;
    @api boolShowLabelInline = false;
    @api boolShowPlaceholder = false;
    @api boolIsDatatableFilter = false;
    today;
    lastClass;
    month;
    year;
    day;
    @api boolIsRequired = false;
    @api isNotif;
    @api strValue;
    dateContext;
    @api selectedDate;
    dates = [];
    boolListExecuted = false;
    domRendered = false;
    @track contextDate;
    @api minDate;
    @api maxDate;
    @track datePickerDivClass="slds-form-element slds-dropdown-trigger slds-dropdown-trigger_click clsCalenderTrigger";
    boolErrorMessage = false;
    strErrorMessage = '';
    strMinErrorMessage = 'Date should be greater than ';
    strMaxErrorMessage = 'Date should be less than ';
    strInvalidErrorMessage = 'Please enter a valid date in MM/DD/YYYY format';
    boolDataValid = true;    

    //Disables default date validations
    @api boolDisableDateValidationError = false;

    //Keeps track of date input via keypress/datepicker selection
    @api strDateInput = '';

    onSelectedYear(event) {
        const strDateValue = this.strValue;
        if (BaseLWC.isNotUndefinedOrNull(strDateValue) && strDateValue.length === 10 && this.isDateValid(strDateValue)) {
            this.selectedDate = new Date(this.strValue);
        }
        this.contextDate = new Date(this.contextDate.setFullYear(parseInt(event.target.value,10)));
        const strContextDate = new Date(this.contextDate.setHours(0, 0, 0, 0));

        if (BaseLWC.isNotUndefinedOrNull(this.minDate)) {
            const strMinDate = new Date(this.minDate.setHours(0, 0, 0, 0));
            if (strContextDate < strMinDate) {
                this.contextDate = strMinDate;
            }
        }

        if (BaseLWC.isNotUndefinedOrNull(this.maxDate)) {
            const strMaxDate = new Date(this.maxDate.setHours(0, 0, 0, 0));
            if (strContextDate > strMaxDate) {
                this.contextDate = strMaxDate;
            }
        }

        this.refreshDateNodes();
    }

    refreshDateNodes() {
        this.setCalenderYears();
        this.objDates = [];
        let datSelected = this.contextDate;
        let datOriginalSelected = this.selectedDate;
        if(!BaseLWC.isNotUndefinedOrNull(this.contextDate)) {
           datSelected =  this.contextDate = new Date();
        } else if(typeof this.contextDate === 'string') {
            datSelected = new Date(datOriginalSelected);
        } else {
            //Do Nothing.
        }
        if(typeof this.selectedDate === 'string') {
            datOriginalSelected = new Date(datOriginalSelected);
        }

        const firstOfMonth = new Date(datSelected.getFullYear().toString(), datSelected.getMonth(), 1);
        const intFix = 1000 * 60 * 60 * 24;
        const calendarStartDate = new Date(new Date(firstOfMonth) - new Date(firstOfMonth.getDay() * intFix));

        let dateCalendar = calendarStartDate;
        const objEachRow = [];
        for (let intDat = 0; intDat < 5; intDat++) {
            const objEachRowData = {};
            const tdCells = [];
            for (let intCol = 0; intCol < 7; intCol++) {
                const tdCellsData = {};
                if (dateCalendar.getMonth() !== datSelected.getMonth()) {
                    tdCellsData.tdClass = 'slds-day_adjacent-month';
                } else {
                    tdCellsData.tdClass = '';
                }               

                dateCalendar = this.toDSTConvertedDateTime(dateCalendar);

                if (dateCalendar.toDateString() === new Date().toDateString()) {
                    tdCellsData.tdClass = 'slds-is-today';
                }
                if (BaseLWC.isNotUndefinedOrNull(datOriginalSelected) && dateCalendar.toDateString() === datOriginalSelected.toDateString()) {
                    tdCellsData.tdClass = 'slds-is-selected';
                }
                tdCellsData.spanClass = 'slds-day';

                if ((BaseLWC.isNotUndefinedOrNull(this.minDate) && dateCalendar.setHours(0, 0, 0, 0) < this.minDate.setHours(0, 0, 0, 0)) ||
                    (BaseLWC.isNotUndefinedOrNull(this.maxDate) && dateCalendar.setHours(0, 0, 0, 0) > this.maxDate.setHours(0, 0, 0, 0))) {
                    tdCellsData.tdClass = 'clsAvoidClick';
                    tdCellsData.spanClass = 'clsAvoidClick';
                }
                tdCellsData.datValue = dateCalendar;
                tdCellsData.value = dateCalendar.getDate();
                tdCellsData.index = intDat + '_' + intCol;
                dateCalendar = new Date(new Date(dateCalendar).getTime() + intFix);
                tdCells.push(tdCellsData);
            }
            objEachRowData.tdCells = tdCells;
            objEachRowData.index = intDat;
            objEachRow.push(objEachRowData);
        }
        this.objDates = objEachRow;
        const strMonthContextMonth = this.contextDate.toLocaleString('default', {
            month: 'long'
        });
        this.strMonth = strMonthContextMonth;
        const strMonthContextYear = this.contextDate.getFullYear();

        if (BaseLWC.isNotUndefinedOrNull(this.minDate)) {
            const strMinMonth = this.minDate.toLocaleString('default', {
                month: 'long'
            });
            const strMinYear = this.minDate.getFullYear();
            if (strMonthContextYear === strMinYear && strMonthContextMonth === strMinMonth) {
                if (!this.template.querySelector('.clsPreviousMonth').classList.contains('clsAvoidOnlyClicks')) {
                    this.template.querySelector('.clsPreviousMonth').classList.add('clsAvoidOnlyClicks');
                }
            } else {
                if (this.template.querySelector('.clsPreviousMonth').classList.contains('clsAvoidOnlyClicks')) {
                    this.template.querySelector('.clsPreviousMonth').classList.remove('clsAvoidOnlyClicks');
                }
            }
        }

        if (BaseLWC.isNotUndefinedOrNull(this.maxDate)) {
            const strMaxMonth = this.maxDate.toLocaleString('default', {
                month: 'long'
            });
            const strMaxYear = this.maxDate.getFullYear();
            if (strMonthContextYear === strMaxYear && strMonthContextMonth === strMaxMonth) {
                if (!this.template.querySelector('.clsNextMonth').classList.contains('clsAvoidOnlyClicks')) {
                    this.template.querySelector('.clsNextMonth').classList.add('clsAvoidOnlyClicks');
                }
            } else {
                if (this.template.querySelector('.clsNextMonth').classList.contains('clsAvoidOnlyClicks')) {
                    this.template.querySelector('.clsNextMonth').classList.remove('clsAvoidOnlyClicks');
                }
            }
        }
    }

    @api
    setSelectedDate(event) {
        this.boolErrorMessage = false;
        this.strErrorMessage = '';
        this.removeHideFromErrorClasses();
        this.selectedDate = new Date(event.currentTarget.dataset.date);
        this.refreshDateNodes();
        this.setDateInput();
        this.postDateUpdateEvent();
        this.postDateFormatEvent(true);
    }

    setCalenderYears() {
        const lstYearData = [];
        let startYear = this.contextDate.getFullYear() - 100;
        let endYear = this.contextDate.getFullYear() + 100;
        if (BaseLWC.isNotUndefinedOrNull(this.minDate) && this.minDate.getFullYear() > new Date().getFullYear() - 100) {
            startYear = this.minDate.getFullYear();
        } else {
            startYear = new Date().getFullYear() - 100;
        }
        if (BaseLWC.isNotUndefinedOrNull(this.maxDate) && this.maxDate.getFullYear() < new Date().getFullYear() + 100) {
            endYear = this.maxDate.getFullYear();
        } else {
            endYear = new Date().getFullYear() + 100;
        }
        for (let intYear = startYear; intYear <= endYear; intYear++) {
            const objYear = {};
            objYear.label = intYear;
            objYear.value = intYear;
            if (new Date().getFullYear() === intYear) {
                objYear.selected = 'selected';
            }
            lstYearData.push(objYear);
        }
        this.lstYear = lstYearData;
        this.boolListExecuted = true;
        if (BaseLWC.isNotUndefinedOrNull(this.contextDate)) {
            this.template.querySelector('select.clsSelectedYear').value = this.contextDate.getFullYear();
        } else {
            this.template.querySelector('select.clsSelectedYear').value = this.selectedDate.getFullYear();
        }

    }

    renderedCallback() {

        if (this.domRendered === false) {
            if(!BaseLWC.isNotUndefinedOrNull(this.strValue)) {
                this.strValue = null;
                
            }
            else{
                this.selectedDate = new Date(this.strValue.replace(/-/g, '\/'));
                const selectedDateData = this.selectedDate;
                const year = new Intl.DateTimeFormat('en', {
                    year: 'numeric'
                    }).format(selectedDateData);
                const month = new Intl.DateTimeFormat('en', {
                    month: '2-digit'
                    }).format(selectedDateData);
                const day = new Intl.DateTimeFormat('en', {
                    day: '2-digit'
                    }).format(selectedDateData);
                this.strValue = month.toString() + '/' + day.toString() + '/' + year.toString();
            }
            this.strValue = null;
            this.today = new Date();
            if (BaseLWC.isNotUndefinedOrNull(this.selectedDate)) {
                const selectedDateDate = this.selectedDate;
                if (typeof selectedDateDate === "string"){
                   this.contextDate = new Date(selectedDateDate);
                } else {
                    this.contextDate = selectedDateDate;
                }
            } else {
                this.selectedDate = null;
                this.contextDate = new Date();
            }

            this.strMonth = new Date().toLocaleString('default', {
                month: 'long'
            });
            this.refreshDateNodes();
            this.setDateInput();
            this.domRendered = true;
        }
        if(this.boolFullWidth) {
            this.datePickerDivClass="slds-form-element slds-dropdown-trigger slds-dropdown-trigger_click clsCalenderTrigger fullWidth";
        } else {
            this.datePickerDivClass="slds-form-element slds-dropdown-trigger slds-dropdown-trigger_click clsCalenderTrigger";
        }
    }

    connectedCallback() {        
        if(this.boolFullWidth) {
            this.datePickerDivClass="slds-form-element slds-dropdown-trigger slds-dropdown-trigger_click clsCalenderTrigger fullWidth";
        } else {
            this.datePickerDivClass="slds-form-element slds-dropdown-trigger slds-dropdown-trigger_click clsCalenderTrigger";
        }
    }

    previousMonth() {
        const strDateValue = this.strValue;
        if (BaseLWC.isNotUndefinedOrNull(strDateValue) && strDateValue.length === 10 && this.isDateValid(strDateValue)) {
            this.selectedDate = new Date(this.strValue);
        }
        const contextDateData = this.contextDate;
        this.contextDate = new Date(contextDateData.setMonth(contextDateData.getMonth() - 1));
        this.template.querySelector('select.clsSelectedYear').value = this.contextDate.getFullYear();
        this.strMonth = this.contextDate.toLocaleString('default', {
            month: 'long'
        });
        this.refreshDateNodes();
    }

    nextMonth() {
        const strDateValue = this.strValue;
        if (BaseLWC.isNotUndefinedOrNull(strDateValue) && strDateValue.length === 10 && this.isDateValid(strDateValue)) {
            this.selectedDate = new Date(this.strValue);
        }
        const contextDateData = this.contextDate;
        this.contextDate = new Date(contextDateData.setMonth(contextDateData.getMonth() + 1));

        this.template.querySelector('select.clsSelectedYear').value = this.contextDate.getFullYear();
        this.strMonth = this.contextDate.toLocaleString('default', {
            month: 'long'
        });
        this.refreshDateNodes();
    }


    setDateInput() {
        if (BaseLWC.isNotUndefinedOrNull(this.selectedDate)) {
            const selectedDateData = this.selectedDate;
            const year = new Intl.DateTimeFormat('en', {
                year: 'numeric'
            }).format(selectedDateData);
            const month = new Intl.DateTimeFormat('en', {
                month: '2-digit'
            }).format(selectedDateData);
            const day = new Intl.DateTimeFormat('en', {
                day: '2-digit'
            }).format(selectedDateData);
            this.strValue = this.selectedDate = month.toString() + '/' + day.toString() + '/' + year.toString();
            this.strDateInput = this.strValue;
            this.template.querySelector('select.clsSelectedYear').value = selectedDateData.getFullYear();
            const strMonthData = selectedDateData.toLocaleString('default', {
                month: 'long'
            });
            this.strMonth = strMonthData;
            if(this.boolRange === false || (this.boolRange === true && this.boolMultiDateSelected === true)) {
                this.template.querySelector('div.clsCalenderTrigger').classList.remove('slds-is-open');
                if(this.boolIsDatatableFilter){
                    const objCustomEvent = new CustomEvent('calendarstate', 
                    {
                        detail: {
                            boolIsCalendarOpen: false
                        }
                    });
                    this.dispatchEvent(objCustomEvent); 
                }
            }

        }
    }


    onClickToday() {
        this.selectedDate = new Date();
        this.contextDate = new Date();
        this.template.querySelector('select.clsSelectedYear').value = new Date().getFullYear();
        this.refreshDateNodes();
        this.setDateInput();
        this.postDateUpdateEvent();
    }

    showCalender(event) {                
        if(!this.boolIsDatatableFilter){
            if(this.isNotif) {
                this.template.querySelector('.clsDatePicker').setAttribute('style', 'top:2rem !important;' +
                'position:absolute;' + 'left: 0rem !important');
            } else {                
            this.template.querySelector('.clsDatePicker').setAttribute('style', 'top:2rem !important;' +
            'position:absolute;' + 'left: 4rem !important');
            }
        } else {
            this.template.querySelector('.clsDatePicker').setAttribute('style', 'top:2rem !important;' +
            'position:absolute;');
        }
        

        if (event.target.value === '') {
            this.strValue = null;
        }
        this.setAndUpdateCalender();

        if (this.template.querySelector('div.clsCalenderTrigger').classList.contains('slds-is-open')) {
            this.template.querySelector('div.clsCalenderTrigger').classList.remove('slds-is-open');
            if(this.boolIsDatatableFilter){
                const objCustomEvent = new CustomEvent('calendarstate', 
                {
                    detail: {
                        boolIsCalendarOpen: false
                    }
                });
                this.dispatchEvent(objCustomEvent); 
            }
        } else {
            this.template.querySelector('div.clsCalenderTrigger').classList.add('slds-is-open');
            if(this.boolIsDatatableFilter){
                const objCustomEvent = new CustomEvent('calendarstate', 
                {
                    detail: {
                        boolIsCalendarOpen: true
                    }
                });
                this.dispatchEvent(objCustomEvent); 
            }
            this.refreshDateNodes();
        }
    }

    hideCalender() {
        this.template.querySelector('div.clsCalenderTrigger').classList.remove('slds-is-open');
        if(this.boolIsDatatableFilter){
            const objCustomEvent = new CustomEvent('calendarstate', {
                detail: {boolIsCalendarOpen: false}
            });
            this.dispatchEvent(objCustomEvent); 
        }
    }

    checkDefaultEvents(objEvent) {
        const key = objEvent.key;
        return (typeof key==='string' && ((key === 'Tab') ||
            (objEvent.ctrlKey && key.toLowerCase() === 'a') ||
            (objEvent.ctrlKey && key.toLowerCase() === 'c') ||
            (objEvent.ctrlKey && key.toLowerCase() === 'v')));        

    }

    removeHideFromErrorClasses() {

        if(!this.boolDisableDateValidationError){
            if (this.boolErrorMessage === true && !this.template.querySelector('.clsCalenderTrigger').classList.contains('slds-has-error') &&
                this.template.querySelector('.idInputDateError').classList.contains('slds-hide')) {
                this.hideCalender();
                this.template.querySelector('.clsCalenderTrigger').classList.add('slds-has-error');
                this.template.querySelector('.idInputDateError').classList.remove('slds-hide');
                this.hideCalender();
            } else if (this.boolErrorMessage === false && this.template.querySelector('.clsCalenderTrigger').classList.contains('slds-has-error') &&
                !this.template.querySelector('.idInputDateError').classList.contains('slds-hide')) {
                this.template.querySelector('.clsCalenderTrigger').classList.remove('slds-has-error');
                this.template.querySelector('.idInputDateError').classList.add('slds-hide');
            } else {
                //Do Nothing.
            }
        } else if(this.boolErrorMessage === true){
            this.hideCalender();
        } else{
            //Do Nothing.
        }
    }

    @api
    removeHideFromCustomErrorClasses(boolError) {
        if (boolError === true && !this.template.querySelector('.clsCalenderTrigger').classList.contains('slds-has-error')) {
            this.hideCalender();
            this.template.querySelector('.clsCalenderTrigger').classList.add('slds-has-error');
            this.hideCalender();
        } else if (boolError === false && this.template.querySelector('.clsCalenderTrigger').classList.contains('slds-has-error')) {
            this.template.querySelector('.clsCalenderTrigger').classList.remove('slds-has-error');
        } else {
            //Do Nothing.
        }
    }

    fireEventAndBlur(event) {
        this.boolErrorMessage = true;
        this.strErrorMessage = 'Please enter a valid date in MM/DD/YYYY format';
        this.removeHideFromErrorClasses();
        event.preventDefault();
    }

    @api
    isDateValid(date) {
        try {
            const lstDate = date.split('/');
            const year = +lstDate[2];
            const month = +lstDate[0];
            const day = +lstDate[1];
            const currDate = new Date(year, (month - 1), day);
            return (Boolean(+currDate) && currDate.getDate() === day && currDate.getMonth() === month - 1 && currDate.getFullYear() === year);
        } catch (e) {
            /*Do Nothing*/
        }
    }

    doUpdate(event) {
        //Perform Calender Update.
        if (event.target.value === '') {
            this.boolErrorMessage = false;
            this.contextDate = new Date();
            this.refreshDateNodes();
            this.setDateInput();
            this.postDateUpdateEvent();
            this.removeHideFromErrorClasses();
        } else {


            const dateValidity = this.isDateValid(event.target.value);
            if (dateValidity === false) {
                this.boolErrorMessage = true;
                this.strErrorMessage = this.strInvalidErrorMessage;
            } else {
                this.selectedDate = new Date(event.target.value);
                if (BaseLWC.isNotUndefinedOrNull(this.minDate)) {
                    if (this.selectedDate.setHours(0, 0, 0, 0) < this.minDate.setHours(0, 0, 0, 0)) {
                        this.boolErrorMessage = true;
                        this.strErrorMessage = this.strMinErrorMessage + this.dateFormatterHelper(this.minDate);
                    }
                }
                if (BaseLWC.isNotUndefinedOrNull(this.maxDate)) {
                    if (this.selectedDate.setHours(0, 0, 0, 0) > this.maxDate.setHours(0, 0, 0, 0)) {
                        this.boolErrorMessage = true;
                        this.strErrorMessage = this.strMaxErrorMessage + this.dateFormatterHelper(this.maxDate);
                    }
                }
            }

            this.removeHideFromErrorClasses();
            if (this.boolErrorMessage === false) {
                this.contextDate = new Date(event.target.value);
                this.refreshDateNodes();
                this.setDateInput();
                this.postDateUpdateEvent();
            } else {
                this.hideCalender();
            }
        }
    }

    onChangeInput(event) {
        this.doUpdate(event);
    }

    dateFormatterHelper(strDate) {

        let DateData = strDate;
        if (typeof strDate === 'string') {
            DateData = new Date(strDate);
        }
        const year = new Intl.DateTimeFormat('en', {
            year: 'numeric'
        }).format(DateData);
        const month = new Intl.DateTimeFormat('en', {
            month: '2-digit'
        }).format(DateData);
        const day = new Intl.DateTimeFormat('en', {
            day: '2-digit'
        }).format(DateData);
        return month.toString() + '/' + day.toString() + '/' + year.toString();
    }

    postDateUpdateEvent() {
        const objCustomEvent = new CustomEvent('calendardataupdate', {
                detail: this.selectedDate
            });
            this.dispatchEvent(objCustomEvent);
    }

    postDatePickerKeyPressEvent(strDateData) {
        const objCustomEvent = new CustomEvent('calendarkeypressupdate', {
                detail: strDateData
            });
            this.dispatchEvent(objCustomEvent);
    }

    onKeyPressHelper(event) {
            try {
                const strKey = event.key;
                const boolNumber = !isNaN(strKey);
                const boolForwardSlash = strKey === '/';
                const checkDefaultEvents = this.checkDefaultEvents(event);

                if (!checkDefaultEvents) {
                    const cursorStart = event.target.selectionStart;
                    const cursorEnd = event.target.selectionEnd;
                    let lengthOfEnteredCode = 0;
                    this.boolErrorMessage = false;

                    //Only Numbers and slash are allowed
                    if (cursorStart < 10 && (boolNumber || boolForwardSlash)) {
                        let strEnteredCode = strKey;
                        this.boolErrorMessage = false;
                        this.strErrorMessage = '';
                        this.removeHideFromErrorClasses();
                        let strDateData = event.target.value;

                        if (!boolForwardSlash && (strDateData.length === 2 || strDateData.length === 5)) {
                            strDateData = strDateData + '/';
                        }


                        if (boolForwardSlash) {
                            strEnteredCode = '/';
                        }
                        lengthOfEnteredCode = strEnteredCode.length;
                        if ((cursorStart === 0 && cursorEnd === 0) || cursorStart && cursorEnd && cursorStart === cursorEnd) {
                            if (!boolForwardSlash) {
                                let strUpdatedCode = strEnteredCode;
                                let updatedCursorStart = cursorStart;

                                if (strDateData.slice(0, cursorStart).length === 2 || strDateData.slice(0, cursorStart).length === 5) {
                                    strUpdatedCode = '/' + strEnteredCode;
                                    if (strDateData.slice(0, cursorStart).length === 4 && strDateData.slice(cursorStart, 10).length < 4) {
                                        updatedCursorStart = cursorStart + 1;
                                    }


                                }
                                let strEndData = strDateData.slice(updatedCursorStart, 10);
                                if (cursorStart >= 5) {
                                    if (strEndData.indexOf('/') > -1) {
                                        strEndData = strEndData.split('/').join('');
                                    }

                                }
                                strDateData = [strDateData.slice(0, cursorStart), strUpdatedCode, strEndData].join('');
                            }
                            if ((strDateData.slice(0, cursorStart).length === 2 || strDateData.slice(0, cursorStart).length === 5) && boolForwardSlash) {
                                strDateData = [strDateData.slice(0, cursorStart), strEnteredCode, strDateData.slice(cursorStart, 10)].join('');
                            }

                        } else {
                            let selectionText = "";
                            if (window.getSelection) {
                                selectionText = window.getSelection().toString();
                            }
                            if (selectionText !== undefined && selectionText !== null && selectionText !== '') {
                                strDateData = strDateData.slice(0, cursorStart) + strEnteredCode + strDateData.slice(cursorEnd);
                            }
                        }

                        strDateData = strDateData.slice(0, 10);
                        if (!boolForwardSlash && (strDateData.length === 2 || strDateData.length === 5)) {
                            strDateData = strDateData + '/';
                            lengthOfEnteredCode = lengthOfEnteredCode + 1;
                        }


                        let strFinalDate = strDateData;
                        if (strDateData.indexOf('/') > -1) {
                            strFinalDate = strDateData.split('/').join('');
                        }
                        if (strFinalDate.length === 8) {
                            strDateData = event.target.value = [strFinalDate.slice(0, 2) + '/' + strFinalDate.slice(2, 4) + '/' + strFinalDate.slice(4, 10)].join('');
                        }
                        this.strValue = event.target.value = strDateData;
                        const finalCursorPoint = cursorStart + lengthOfEnteredCode;
                        if (strDateData.endsWith("\/") || strDateData[finalCursorPoint] === '\/') {
                            event.target.selectionEnd = finalCursorPoint;
                        }
                        if (strDateData.length === 10) {
                            if (this.isDateValid(strDateData) === false) {
                                this.fireEventAndBlur(event);
                            } else {
                                this.selectedDate = new Date(this.strValue);
                                this.doUpdate(event);
                                event.preventDefault(event);
                            }
                        } else if (strDateData.length > 0 && strDateData < 10) {
                            this.selectedDate = this.strValue;
                            this.postDateUpdateEvent();
                            event.preventDefault(event);
                        } else {
                            event.preventDefault(event);
                        }
                        this.strDateInput = strDateData;
                        this.postDatePickerKeyPressEvent(this.strDateInput);

                    } else {

                        event.target.value = event.target.value;
                        this.strValue = event.target.value;
                        this.strDateInput = this.strValue;
                        this.selectedDate = new Date(this.strValue);

                        //NT:Handle backspaces
                        if (strKey === 'Backspace') {
                            if (cursorStart !== cursorEnd) {
                                this.strDateInput = this.strDateInput.substring(0, cursorStart) + this.strDateInput.substring(cursorEnd, this.strDateInput.length);
                            } else {
                                this.strDateInput = this.strDateInput.substring(0, cursorStart - 1) + this.strDateInput.substring(cursorEnd, this.strDateInput.length);
                            }
                            this.postDatePickerKeyPressEvent(this.strDateInput);
                        }


                        if (strKey !== 'Backspace' && strKey !== 'Delete') {
                            event.preventDefault();
                        }

                }
                if (strKey !== 'Backspace' && strKey !== 'Delete') {
                    event.preventDefault();
                }
            }

            } catch (error) {
                //Do Nothing.
            }
        }

    setAndUpdateCalender() {
        if (this.strValue === '') {
            this.strValue = null;
        }
        if (BaseLWC.isNotUndefinedOrNull(this.strValue) && this.strValue.length === 10 && this.isDateValid(this.strValue)) {
            this.selectedDate = new Date(this.strValue);
        } else {
            this.selectedDate = null;
        }
        this.boolErrorMessage = false;
        this.strErrorMessage = '';

        let boolErrorDate = false;
        if (this.isDateValid(this.strValue) === false) {
            this.boolErrorMessage = true;
            this.strErrorMessage = this.strInvalidErrorMessage;
            boolErrorDate = true;
        }
        if (BaseLWC.isNotUndefinedOrNull(this.selectedDate)) {
            if (BaseLWC.isNotUndefinedOrNull(this.minDate)) {
                if (this.selectedDate.setHours(0, 0, 0, 0) < this.minDate.setHours(0, 0, 0, 0)) {
                    this.boolErrorMessage = true;
                    this.strErrorMessage = this.strMinErrorMessage + this.dateFormatterHelper(this.minDate);
                    boolErrorDate = true;
                }
            }
            if (BaseLWC.isNotUndefinedOrNull(this.maxDate)) {
                if (this.selectedDate.setHours(0, 0, 0, 0) > this.maxDate.setHours(0, 0, 0, 0)) {
                    this.boolErrorMessage = true;
                    this.strErrorMessage = this.strMaxErrorMessage + this.dateFormatterHelper(this.maxDate);
                    boolErrorDate = true;
                }
            }
        }
        this.removeHideFromErrorClasses();
        if (BaseLWC.isNotUndefinedOrNull(this.selectedDate) && boolErrorDate === false) {
            this.template.querySelector('select.clsSelectedYear').value = this.selectedDate.getFullYear();
            const selectedDateData = this.selectedDate
            this.contextDate = selectedDateData;
        } else {
            this.contextDate = new Date();
        }
        this.refreshDateNodes();
    }

    onKeyUpHelper(event) {
        try {
            const strKey = event.key;
            const checkDefaultEvents = this.checkDefaultEvents(event);

            if (!checkDefaultEvents) {
                if(strKey ==='Backspace' || strKey === 'Delete') {
                    if(event.target.value === "") {
                        this.strValue = null;
                        this.selectedDate = null;
                        this.contextDate = new Date();
                        this.refreshDateNodes();
                        this.doUpdate(event);
                    }
                }
            }
        } catch(error) {

        }

    }

    onPasteHelper(event) {
        if(BaseLWC.isNotUndefinedOrNull(event.clipboardData)) {
            let strDateData = event.clipboardData.getData('Text').replace(/\D/g,'');
            if(BaseLWC.isNotUndefinedOrNull(strDateData)) {
                this.boolErrorMessage = false;
                this.removeHideFromErrorClasses();
                strDateData = strDateData.toString();
                if(strDateData.indexOf('/') > -1) {
                    strDateData = strDateData.split('/').join('').trim();
                }
                if(strDateData.length >= 4) {
                  strDateData = strDateData.slice(0,2) + '/' + strDateData.slice(2,4) + '/' + strDateData.slice(4,10);
                } else if(strDateData.length >= 2 && strDateData.length < 4) {
                   strDateData = strDateData.slice(0,2) + '/' + strDateData.slice(2,10);
                } else {
                    //Do Nothing.
                }
                if(this.isDateValid(strDateData)) {
                    this.strValue = event.target.value = strDateData;
                    event.preventDefault();
                    this.selectedDate = new Date(strDateData);
                    this.contextDate = new Date();
                    this.refreshDateNodes();
                    this.doUpdate(event);
                } else {
                    this.strValue = event.target.value = strDateData;
                    event.preventDefault();
                    this.boolErrorMessage = true;
                    this.strErrorMessage = this.strInvalidErrorMessage;
                    this.removeHideFromErrorClasses();
                }
            }
        }

    }

    @api
    clearDate() {
        this.selectedDate = '';
        this.strValue = '';
        this.strDateInput = '';
        this.postDateUpdateEvent();
    }

    focusOutHelper(event) {
        let boolDateValid = true;
        if(event.target.value !== null && event.target.value !== undefined && event.target.value !== '') {
            boolDateValid = this.isDateValid(event.target.value);
        }
        
        if(boolDateValid === false) {
            this.boolErrorMessage = true;
            this.strErrorMessage = this.strInvalidErrorMessage;
            this.removeHideFromErrorClasses();
        }

        this.postDateFormatEvent(boolDateValid);
    }

    postDateFormatEvent(boolDateValid) {
        const errorEvent = new CustomEvent('dateformaterror', {
            detail: boolDateValid
        });
        this.dispatchEvent(errorEvent);
    }

    /*
        checks if the sytem timezone falls in Daylight Savings area.
        @param: year to be checked
        @return: object with boolean if falls in DST, DST start date, DST end date
    */
    isDaylightSavingTimezone(year){
        const arrDTOFF=[];
        for(let i=0;i<12;i++){
            let dt=new Date(year,i,1);
            arrDTOFF.push(dt.getTimezoneOffset());            
            if(!arrDTOFF.includes(dt.getTimezoneOffset())){
                break;                
            }
        }
        const setDTOFF = new Set(arrDTOFF);
        let startDaylightDay='';
        let endDaylightDay='';
        if(setDTOFF.size>1){
            let prevOffset=0;
            let prevDate;            
            for(let i=0;i<12;i++){
                for(let j=0;j<32;j++){
                    const dt=new Date(year,i,j);
                    if(dt.toString()!=='Invalid Date'){
                        if(prevOffset>0 && startDaylightDay && !endDaylightDay && prevOffset!==dt.getTimezoneOffset()){
                            endDaylightDay=prevDate;
                        }
                        if(prevOffset>0 && !startDaylightDay && prevOffset!==dt.getTimezoneOffset()){
                            startDaylightDay=prevDate;
                        }
                        
                        prevOffset=dt.getTimezoneOffset();
                        prevDate=dt;
                        if(startDaylightDay && endDaylightDay){
                            break;
                        }
                        
                    }
                    if(startDaylightDay && endDaylightDay){
                        break;
                    }
                }
            }
        }
        const obj={
            boolDSTTimezone:setDTOFF.size>1,
            dtDSTStartDate:startDaylightDay,
            dtDSTEndDate:endDaylightDay
        }        
        return obj;
    }

    toDSTConvertedDateTime=(objDate)=>{        
        let objDateLocal=new Date(objDate);
        const objDST= this.isDaylightSavingTimezone(objDateLocal.getFullYear());      
        const boolDSTimezone = objDST.boolDSTTimezone;
        const dtDSTStartDate = objDST.dtDSTStartDate;
        const dtDSTEndDate = objDST.dtDSTEndDate;
        if(objDateLocal.toString()==='Invalid Date'){
            return 'Invalid Date'
        }
        if(!boolDSTimezone){
            return objDateLocal;
        }
        
        const offsetGiven=objDateLocal.getTimezoneOffset();
        if(dtDSTEndDate.getFullYear()===objDateLocal.getFullYear() && 
            dtDSTEndDate.getMonth()===objDateLocal.getMonth() && dtDSTEndDate.getDate()===objDateLocal.getDate()) 
          {
              if(offsetGiven===dtDSTEndDate.getTimezoneOffset()){                  
                return objDateLocal;
              }
          }else if(dtDSTStartDate.getFullYear()===objDateLocal.getFullYear() && dtDSTStartDate.getMonth()===objDateLocal.getMonth() && dtDSTStartDate.getDate()===(objDateLocal.getDate()-1)){
            //Do nothing
          }else{
            return objDateLocal;
          }
        
        const yr=objDateLocal.getFullYear();
        const month=objDateLocal.getMonth();
        const day=objDateLocal.getDate();
        const hr=objDateLocal.getHours();
        const min=objDateLocal.getMinutes();
        const seconds=objDateLocal.getSeconds();
        const milliSeconds=objDateLocal.getMilliseconds();
        const UTCDATE=Date.UTC(yr,month,day,hr,min,seconds,milliSeconds);       
        
        if(dtDSTStartDate.getFullYear()===objDateLocal.getFullYear() && dtDSTStartDate.getMonth()===objDateLocal.getMonth() && dtDSTStartDate.getDate()===(objDateLocal.getDate()-1)){
            objDateLocal=new Date(UTCDATE+(offsetGiven-Math.abs(dtDSTStartDate.getTimezoneOffset()-dtDSTEndDate.getTimezoneOffset()))*60*1000);            
        }else{
            objDateLocal=new Date(UTCDATE+(dtDSTStartDate.getTimezoneOffset()+Math.abs(dtDSTStartDate.getTimezoneOffset()-dtDSTEndDate.getTimezoneOffset()))*60*1000);
        }
       
        return objDateLocal;
    }
    @api
    getBoolErrorMessage(){
        return this.boolErrorMessage;
    }
    @api
    setDateErrorMessage(errorMessage){
        this.boolErrorMessage = true;
        this.strErrorMessage = errorMessage;
        this.removeHideFromErrorClasses();
    }
    @api
    clearDateValue(){
        this.selectedDate = null;
        this.contextDate = new Date();
    }
}