import { LightningElement,api,track } from 'lwc';

export default class LwcMemberSearchResults extends LightningElement {
    @api objSearchData;
    @track lstMemberSearchData = [];
    objMemberSearchSettings = {
        pageSize: 25,
        showPagination : true,
        pageMenu : [25],
        boolViewMore: false,
        columnsData: [
            { label: 'FIRST NAME', fieldName: 'strFirstName', sortable: false, type: 'text' },
            { label: 'LAST NAME', fieldName: 'strLastName', sortable: false, type: 'text' },
            { label: 'DATE OF BIRTH', fieldName: 'strDateOfBirth', sortable: false, type: 'date' },
            { label: 'SSN', fieldName: 'strSSN', sortable: false, type: 'text' },
            { label: 'PREFERRED VOICE PHONE NUMBER', fieldName: 'strPhone', sortable: false, type: 'text' },
            { label: 'BILLING CYCLE', fieldName: 'badge', sortable: false, type: 'text' }],
        boolSecondaryTable: false,
        boolShowFilter: true,
        boolPagination: true,
        boolShowSearch:true,
        searchPlaceholder : 'Search Text',
        boolHasSearchandFilterCustomMargins: false,
        boolShowExpandCollpaseButton: true,
        filterData : [

        ],
        boolShowCheckbox : false,
        boolShowHeader : false,
        boolShowSearchLabel: false,
        restrictedPageSize : false,
        boolPaginationwithSize:false,
        boolSecondaryTable: true,
        boolExpandOnRowClick : true
    };
    objSecondaryTableSettings = {
        pageSize: 25,
        boolViewMore: false,
        columnsData: [
            { label: 'SUBSCRIBER ID', fieldName: 'strSubscriberId', sortable: false, type: 'text', },
            { label: 'PLAN NAME', fieldName: 'strPlan', sortable: false, type: 'text', boolHasHoverText: true, strTextTooltipContent: "The data in this field currently shows the Benefit Agreement Description and will be corrected to show the Network Name [Plan Type] in the future."},
            { label: 'ELIGIBILITY DATE', fieldName: 'strEligibilityDate', sortable: false, type: 'text' },
            { label: 'EFF. DATE', fieldName: 'strEffectiveDate', sortable: false, type: 'text' },
            { label: 'STATUS', fieldName: 'strStatus', sortable: false, type: 'text' },
            { label: 'ACCOUNT NAME', fieldName: 'strAccountName', sortable: false, type: 'text' },
            { label: 'GROUP NUMBER', fieldName: 'strGroupNumber', sortable: false, type: 'text' },
            { label: '', fieldName: 'customBtn', sortable: false, type: 'button' },
        ],
        boolShowRowCustomButton : true,
        boolSecondaryTable: false,
        boolShowFilter: false,
        boolPagination: false,
        boolShowSearch:false,
        boolShowCheckbox : false,
        boolShowHeader : false
    };
    @api renderSearchTable() {
        let memberSearchData = {};
        if(this.objSearchData !== null && this.objSearchData !== undefined && this.objSearchData !== ''){
            memberSearchData = JSON.parse(this.objSearchData);
            memberSearchData = JSON.parse(memberSearchData.objParameters.objResults);
            memberSearchData.forEach(itrRow => {
                itrRow.lstPlans.forEach(itrPlan => {
                    itrPlan["customBtn"] = new Object();
                    itrPlan["customBtn"] = {
                        strRowCustomButtonLabel : 'Select',
                        strButtonVariant: "brand",
                        boolIsTooltip: true,
                        boolIsBtnDisabled: true,
                        strTextTooltipContent: "This member is part of a secure group. Click View Notifications to identify the appropriate transfer phone number."
                    };
                });
                itrRow['boolNestedTable'] = true;
                itrRow['boolHidden'] = false;
                itrRow['boolSecTable'] = false;
                itrRow['objSecondaryTableData'] = itrRow.lstPlans;
                itrRow['objSecondaryTableSetting'] = this.objSecondaryTableSettings;
                itrRow['boolNestedSpinner'] = false;
                itrRow['boolShowRowCustomButton'] = true;
            });
            this.lstMemberSearchData = memberSearchData;
        }
    }
}