import { LightningElement, track, api } from 'lwc';
import fetchMedicalHistoryData from '@salesforce/apexContinuation/MedicalAdjustmentHistorycontroller_ACE.fetchMedicalAdjHistoryData';
import MedicalAdjustment_DCN_ACE from '@salesforce/label/c.MedicalAdjustment_DCN_ACE';
import SRSummary_Status_ACE from '@salesforce/label/c.SRSummary_Status_ACE';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import ViewClaimHistory_MedicalClaimStatusCode_ACE from '@salesforce/label/c.ViewClaimHistory_MedicalClaimStatusCode_ACE';

import CompareClaims_ServiceFrom_ACE from '@salesforce/label/c.CompareClaims_ServiceFrom_ACE';

import CompareClaims_ServiceTo_ACE from '@salesforce/label/c.CompareClaims_ServiceTo_ACE';

import CompareClaims_TotalBilledAmount_ACE from '@salesforce/label/c.CompareClaims_TotalBilledAmount_ACE';

import ViewClaimHistory_MedicalBillingProviderName_ACE from '@salesforce/label/c.ViewClaimHistory_MedicalBillingProviderName_ACE';
import ViewClaimHistory_MedicalBillingProviderNumber_ACE from '@salesforce/label/c.ViewClaimHistory_MedicalBillingProviderNumber_ACE';
import MedicalAdjustment_BillingProviderNPI_ACE from '@salesforce/label/c.MedicalAdjustment_BillingProviderNPI_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import GroupNumber_ACE from '@salesforce/label/c.GroupNumber_ACE';
import CaseNotesModal_Refresh_ACE from '@salesforce/label/c.CaseNotesModal_Refresh_ACE';
//CEAS-82979 Platform Workspace API
import {openSubtab,setTabLabel,setTabIcon} from 'lightning/platformWorkspaceApi';

export default class LwcMedicalAdjustmentHistory_ACE extends LightningElement {
    @track lstTableData = [];
    @api strUrlClaimId ;
    @api strclaimType;
    @api strUrlGroupNumber;
    @api strAdjustmentNumber;
    @api strUrlCorpCode ;
    @api strAccountId;
    @api strMemberId;
    @api strTabId;

    objError;
    boolSpinner = true;
    labels = {
        SRSummary_Status_ACE,
        MedicalAdjustment_DCN_ACE,
        ViewClaimHistory_MedicalClaimStatusCode_ACE,
        GroupNumber_ACE,
        CompareClaims_ServiceFrom_ACE,
        CompareClaims_ServiceTo_ACE,
        CompareClaims_TotalBilledAmount_ACE,
        ViewClaimHistory_MedicalBillingProviderName_ACE,
        ViewClaimHistory_MedicalBillingProviderNumber_ACE,
        MedicalAdjustment_BillingProviderNPI_ACE,
        IntegrationFailMessage_ACE,
        CaseNotesModal_Refresh_ACE
    };

    columns = [
        { label: this.labels.MedicalAdjustment_DCN_ACE, fieldName: 'dcnNumber', sortable: true, type: '' },
        { label: this.labels.SRSummary_Status_ACE, fieldName: 'strStatus', sortable: true, type: '' },
        { label: this.labels.ViewClaimHistory_MedicalClaimStatusCode_ACE, fieldName: 'strStatusCode', sortable: true, type: '' },
        { label: this.labels.GroupNumber_ACE, fieldName: 'strGroupNumber', sortable: true, type: '' },
        { label: this.labels.CompareClaims_ServiceFrom_ACE, fieldName: 'strServiceFrom', sortable: true, type: 'date' },
        { label: this.labels.CompareClaims_ServiceTo_ACE, fieldName: 'strServiceTo', sortable: true, type: 'date' },
        { label: this.labels.CompareClaims_TotalBilledAmount_ACE, fieldName: 'strTotalBilled', sortable: true, type: '' },
        { label: this.labels.ViewClaimHistory_MedicalBillingProviderName_ACE, fieldName: 'strBillingProviderName', sortable: true, type: '' },
        { label: this.labels.ViewClaimHistory_MedicalBillingProviderNumber_ACE, fieldName: 'strBillingProviderNumber', sortable: true, type: '' },
        { label: this.labels.MedicalAdjustment_BillingProviderNPI_ACE, fieldName: 'strBillingProviderNPI', sortable: true, type: '' }
    ];
    get boolShowNoRecordsFound() {
        return !BaseLWC.arrayIsNotEmpty(this.lstTableData);
    }
    boolDisplayData = false;

    connectedCallback() {
        this.fetchData();
    }
    fetchData() {
        this.boolDisplayData = false;
        this.boolSpinner = true;
        fetchMedicalHistoryData({
            strClaimId: this.strUrlClaimId,
            strclaimType: this.strclaimType
        })
            .then((result) => {
                const objData = JSON.parse(result);
                if (objData && Array.isArray(objData)) {
                    this.processCaseDataForTable(objData);
                } else {
                }
                if (objData) {
                }
            })
            .catch((error) => {
                this.handleErrors(error);
            });
    }
    refreshModal() {
        this.fetchData();
    }

    processCaseDataForTable(result) {
        try {
            const data = [...result];
            //Loop through Data to modify for Table
            this.lstTableData = [];

            this.lstTableData = data.map((el) => {
                const objMed = { ...el };
                let initiatedClaim = el.strDCN + this.strAdjustmentNumber;
                if (el.strDCN + el.strAdj === initiatedClaim) {
                    objMed.dcnNumber = el.strDCN + '-' + el.strAdj;
                } else {
                    if (el.strAdj !== 0) {
                        objMed.dcnNumber = {
                            value: `${el.strDCN}-${el.strAdj}`,
                            strDCNNumber: el.strDCN,
                            strclaimType: this.strclaimType,
                            strClaimId: el.strclaimId,
                            strAdj: el.strAdj,
                            strMemberId: el.strMemberId,
                            wrapper: `<a>${el.strDCN}-${el.strAdj}</a>`
                        };
                    } else {
                        objMed.dcnNumber = {
                            value: `${el.strDCN}`,
                            strDCNNumber: el.strDCN,
                            strclaimType: this.strclaimType,
                            strClaimId: el.strclaimId,
                            strAdj: el.strAdj,
                            strMemberId: el.strMemberId,
                            wrapper: `<a>${el.strDCN}</a>`
                        };
                    }
                }
                return objMed;
            });
            this.boolDisplayData = true;
            this.boolSpinner = false;
        } catch (error) {
            this.handleErrors(error);
        }
    }

    handleRowAction(event) {
        const rowData = JSON.parse(event.detail);
        if (rowData.activeColumnName === this.labels.MedicalAdjustment_DCN_ACE) {
            this.openClaimDetailsPage(rowData.activeColumnData.value.strDCNNumber, rowData.activeColumnData.value.strclaimType, rowData.activeColumnData.value.strClaimId, rowData.activeColumnData.value.strAdj, rowData.activeColumnData.value.strMemberId);
        } else {
            //Do nothing
        }
    }

    openClaimDetailsPage(strDCN, strClaimType, strClaimId, strAdj, strMemberId) {
        if (strMemberId) {
            const strEncodedClaimsAndMemberId =
                '?' + window.btoa(unescape(encodeURIComponent('claimNumber=' + strDCN + '&mid=' + this.strMemberId + '&claimId=' + strClaimId + '&adjNumber=' + strAdj + '&corpCode=' + this.strUrlCorpCode + '&groupNumber=' + this.strUrlGroupNumber + '&idAccount=' + this.strAccountId)));
            let flexiPageApiName = '';
            if (strClaimType === 'Medical') {
                flexiPageApiName = 'ViewMedicalClaimDetailsFlexiPage_ACE';
            }
            const objPageReference = {
                type: 'standard__navItemPage',
                attributes: {
                    apiName: flexiPageApiName,
                    uid: strDCN + '-' + strAdj
                },
                state: {
                    c__BaseURLParam: strEncodedClaimsAndMemberId
                }
            };
            openSubtab(this.strTabId, { pageReference: objPageReference,focus: true}).then(subTabId => {
                setTabIcon(subTabId, 'utility:record', 'ClaimDetail');
                setTabLabel(subTabId, strDCN + '-' + strAdj);
            });
        }
    }

    handleErrors(error) {
        this.objError = error;
        this.boolDisplayData = true;
        this.boolSpinner = false;
    }

    objInitTableSettings = {
        pageSize: 10,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: false,
        boolSecondaryTable: false,
        boolShowSearch: false,
        boolShowSearchLabel: false,
        boolShowRecordCount: false
    };

    closeModalEvent(event) {
        const closeModal = new CustomEvent('closemodal', {
            detail: { boolOpenModal: false }
        });
        // Fire the custom event
        this.dispatchEvent(closeModal);
    }
}