import { LightningElement, track, api, wire } from 'lwc';

//Import Shared JS files.

//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF'; 
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';

//import relavent Static Resource Assets
import HCSCClaimsStaticResource_ACE from '@salesforce/resourceUrl/HCSCClaimsStaticResource_ACE';

//import Relavent Labels
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import ViewClaims_NoRecordsFound_ACE from '@salesforce/label/c.ViewClaims_NoRecordsFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import MessageLightningComponent_Warning_ACE from '@salesforce/label/c.MessageLightningComponent_Warning_ACE';
import MessageLightningComponent_Error_ACE from '@salesforce/label/c.MessageLightningComponent_Error_ACE';
import Contacts_Card_ACE from '@salesforce/label/c.Contacts_Card_ACE';
import ContactsCard_PrimaryContact_ACE from '@salesforce/label/c.ContactsCard_PrimaryContact_ACE';
import ContactsCard_NameLabel_ACE from '@salesforce/label/c.ContactsCard_NameLabel_ACE';
import ContactsCard_EmailLabel_ACE from '@salesforce/label/c.ContactsCard_EmailLabel_ACE';
import ContactsCard_BAEContact_ACE from '@salesforce/label/c.ContactsCard_BAEContact_ACE';
import ContactsCard_MarketingContact_ACE from '@salesforce/label/c.ContactsCard_MarketingContact_ACE';
import ContactsCard_EffectiveDateLabel_ACE from '@salesforce/label/c.ContactsCard_EffectiveDateLabel_ACE';
import ContactsCard_EndDateLabel_ACE from '@salesforce/label/c.ContactsCard_EndDateLabel_ACE';
import ContactsCard_ProducerIDLabel_ACE from '@salesforce/label/c.ContactsCard_ProducerIDLabel_ACE';
import ContactsCard_Producers_ACE from '@salesforce/label/c.ContactsCard_Producers_ACE';
import ContactsCard_ViewMoreProducers_ACE from '@salesforce/label/c.ContactsCard_ViewMoreProducers_ACE';
import ContactsCard_ViewLessProducers_ACE from '@salesforce/label/c.ContactsCard_ViewLessProducers_ACE';
import ContactsCard_ProducersBlueStarMessage_ACE from '@salesforce/label/c.ContactsCard_ProducersBlueStarMessage_ACE';
import ContactsCard_NavigateToBlueStarHover_ACE from '@salesforce/label/c.ContactsCard_NavigateToBlueStarHover_ACE';
import ContactsCard_AdditionalMarketingContactsHover_ACE from '@salesforce/label/c.ContactsCard_AdditionalMarketingContactsHover_ACE';
import ContactsCard_AdditionalBAEContactsHover_ACE from '@salesforce/label/c.ContactsCard_AdditionalBAEContactsHover_ACE';
import ContactsCard_PrimaryBadge_ACE from '@salesforce/label/c.ContactsCard_PrimaryBadge_ACE';
import ViewPlanSummary_CardHeader_Refresh_ACE from '@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE';

//import Relavent Apex Classes
import accountSearchContinuationCall from '@salesforce/apexContinuation/AccountSearchController_ACE.accountSearchContinuationCall'
import accountSummaryRequest from '@salesforce/apexContinuation/AccountSummaryDashboardController_ACE.accountSummaryRequest';
import safeModeUserData from '@salesforce/apex/SafeModeController_ACE.fetchUserDetails'
import fetchAccountRecordType from '@salesforce/apex/AccountSummaryDashboardController_ACE.fetchAccountRecordType';

export default class LwcAccountContactCard extends LightningElement {
        @wire(EnclosingTabId) enclosingTabId;

        // relavent labels
        label= {
                SafeMode_ToastMessage_ACE,
                ViewClaims_NoRecordsFound_ACE,
                IntegrationFailMessage_ACE,
                MessageLightningComponent_Warning_ACE,
                MessageLightningComponent_Error_ACE,
                Contacts_Card_ACE,
                ContactsCard_PrimaryContact_ACE,
                ContactsCard_NameLabel_ACE,
                ContactsCard_EmailLabel_ACE,
                ContactsCard_BAEContact_ACE,
                ContactsCard_MarketingContact_ACE,
                ContactsCard_EffectiveDateLabel_ACE,
                ContactsCard_EndDateLabel_ACE,
                ContactsCard_ProducerIDLabel_ACE,
                ContactsCard_Producers_ACE,
                ContactsCard_ViewMoreProducers_ACE,
                ContactsCard_ViewLessProducers_ACE,
                ContactsCard_ProducersBlueStarMessage_ACE,
                ContactsCard_NavigateToBlueStarHover_ACE,
                ContactsCard_AdditionalBAEContactsHover_ACE,
                ContactsCard_AdditionalMarketingContactsHover_ACE,
                ContactsCard_PrimaryBadge_ACE,
                ViewPlanSummary_CardHeader_Refresh_ACE
        }


        //relavent lists
        lstProducerIds=[];
        lstInitialProducerData=[];
        lstProcessedProducerData=[];
        lstNonPrimaryproducerContactData=[];
        lstPrimaryProducerContactData = [];
        objCardError = {};

        //@track decorator
        @track lstFirstProducer=[];
        @track lstViewMoreProducerData=[];
        @track objAccountSummaryData=[];

        //@api decorator
        @api recordId;
        @api objectApiName;

        //relevant booleans
        boolHasProducerData=false;
        boolShowSpinner=false;
        boolHasPrimaryContact=false;
        boolHasMarketingContact=false;
        boolHasMarketingHover=false;
        boolHasBAEContact=false;
        boolHasBAEHover=false;
        boolShowProducerViewMore=false;
        boolIsViewMore=false;
        booShowProducerBlueStarMessage=false;
        booShowBAEBlueStarMessage=false;
        booShowMarketingBlueStarMessage=false;
        boolAccountAPIError = false;
        boolNoAccountDataError = false;
        boolProducerAPIError = false;
        boolNoProducerDataError = false;
        boolShowSafeMode = false;
        boolProducerSummaryDataAvailable = false;
        boolShowContactsCard = false;
        boolAccount = false;
        boolIsMainTab = false;
        boolAccountSummaryDataAvailable = false;

        //other variables adn constants
        objTabData = null;
        strDynamicCustomEventName = null;
        infoImageURL = HCSCClaimsStaticResource_ACE + '/Images/info.png';
        strCustomEventName = "AccountSummaryEvent";
        strSubTabCustomEventName = "ContactsCardsEvent";
        strDestinationId = "AccountSummaryDetail_ACE";
        strSubTabDestinationId = "ContactsCardDetail_ACE";
        strTriggerEventName = "TriggerAccountSummaryData";
        strTriggerSubTabEventName = "TriggerContactsCardsData";
        strCorpCode = "";
        strAccountNumber="";
        

        connectedCallback() {
                try {
                        this.boolShowSpinner=true;
                        this.fetchTabData();

                } catch(error) {
                        this.handleErrors(error);
                }
        } 

        /**
         * To Fetch tab Data from WorkspaceAPI.
         * Helps to determine the Tab info..
         * All components should have this code.
         */
        fetchTabData = ()=> {
                if (this.enclosingTabId) {
                        getTabInfo(this.enclosingTabId).then(objTabData => {
                                this.objTabData = objTabData;
                                this.showHideAccountContactsCard();
                                this.fetchSafeModeUserData();
                                this.executeInitialFunctionality();
                        }).catch((error) => {
                                this.handleErrors(error);
                        });
                }
        }

        /**
         * method to add event listeners and trigger events based on whther a main tab or sub tab is open
         */

        executeInitialFunctionality = () => {
                if(this.objTabData.isSubtab === true) {
                        this.executeSubTabFunctionality();
                } else {
                        this.addMainTabListners();
                        this.boolIsMainTab = true;
                }
        }

        /**
         * method to add Main tab event listeners
         */

        addMainTabListners = () => {
                this.strDynamicCustomEventName = this.strCustomEventName + '_' + this.objTabData.tabId;
                window.addEventListener(this.strDynamicCustomEventName, this.fetchAccountSummaryData);
                const tabIdEventName = this.strTriggerSubTabEventName + '_' + this.objTabData.tabId;
                window.addEventListener(tabIdEventName, this.compareAndSendAccountSummaryData);
        }

        /**
         * method to structure and send data to subtab
         */

        compareAndSendAccountSummaryData = (objCommEvent) => {
                const objParentTabContactsCardData = this.accumulateDataToBeSent();
                BaseLWC.sendComponentData(objCommEvent, this.strSubTabDestinationId, this.strSubTabCustomEventName,
                JSON.stringify(objParentTabContactsCardData), this.strSubTabDestinationId, true, this.objTabData.tabId);
        
        }

        /**
         * method to structure subtab response
         */
        accumulateDataToBeSent = () => {
                return {
                        recordId: this.recordId,
                        objAccountSummaryData: this.objAccountSummaryData,
                        boolHasProducerData: this.boolHasProducerData,
                        boolNoProducerDataError: this.boolNoProducerDataError,
                        boolProducerAPIError: this.boolProducerAPIError,
                        boolAccountAPIError: this.boolAccountAPIError,
                        boolNoAccountDataError: this.boolNoAccountDataError,
                        boolShowSafeMode: this.boolShowSafeMode,
                        lstProducerIds: this.lstProducerIds,
                        boolHasPrimaryContact: this.boolHasPrimaryContact,
                        boolHasBAEContact: this.boolHasBAEContact,
                        boolHasBAEHover: this.boolHasBAEHover,
                        boolHasMarketingContact: this.boolHasMarketingContact,
                        boolHasMarketingHover: this.boolHasMarketingHover,
                        boolShowProducerViewMore: this.boolShowProducerViewMore,
                        booShowProducerBlueStarMessage: this.booShowProducerBlueStarMessage,
                        lstFirstProducer: this.lstFirstProducer,
                        lstViewMoreProducerData: this.lstViewMoreProducerData
 
                };
        }

        /**
         * method to fire maintab event and add subtab listeners to get contact card data
         */

        executeSubTabFunctionality = () => {
                this.addSubTabListeners();
                this.fireEventToFetchDataFromParent();   
        }

        /**
         * method to add subtab listeners
         */
        addSubTabListeners = () => {
                this.strDynamicCustomEventName = this.strSubTabCustomEventName + '_' + this.objTabData.parentTabId;
                window.addEventListener(this.strDynamicCustomEventName, this.fetchContactsCardData);
        }

        /**
         * method to fire subtab custom event
         */
        fireEventToFetchDataFromParent = () => {
                BaseLWC.fireCustomEvent(this.strTriggerSubTabEventName, null, this.strSubTabDestinationId,
                        true, this.objTabData.parentTabId);
        }

        /**
         * method to listen to data sent from primary tab contacts card
         */
        fetchContactsCardData = (objContactsData) => {
                const objResponseData = BaseLWC.fetchComponentData(objContactsData, this.strSubTabDestinationId, true);
                try{
                        this.objAccountSummaryData = objResponseData.objAccountSummaryData;
                        this.boolHasProducerData = objResponseData.boolHasProducerData;
                        this.boolNoProducerDataError = objResponseData.boolNoProducerDataError;
                        this.boolProducerAPIError = objResponseData.boolProducerAPIError;
                        this.boolAccountAPIError = objResponseData.boolAccountAPIError;
                        this.boolNoAccountDataError = objResponseData.boolNoAccountDataError;
                        this.boolShowSafeMode = objResponseData.boolShowSafeMode;
                        this.lstProducerIds = objResponseData.lstProducerIds;
                        this.boolHasPrimaryContact = objResponseData.boolHasPrimaryContact
                        this.boolHasBAEContact = objResponseData.boolHasBAEContact;
                        this.boolHasBAEHover = objResponseData.boolHasBAEHover;
                        this.boolHasMarketingContact = objResponseData.boolHasMarketingContact;
                        this.boolHasMarketingHover = objResponseData.boolHasMarketingHover;
                        this.boolShowProducerViewMore = objResponseData.boolShowProducerViewMore;
                        this.booShowProducerBlueStarMessage = objResponseData.booShowProducerBlueStarMessage;
                        this.lstFirstProducer = objResponseData.lstFirstProducer;
                        this.lstViewMoreProducerData = objResponseData.lstViewMoreProducerData;
                        this.boolShowSpinner = false;
                } catch(strError){
                        //do nothing
                }
                
        }

        /**
         * Helps to set the safemode message for safe mode user
         */

        fetchSafeModeUserData = () => {
                safeModeUserData({}).then((objResult) => {
                        if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                                this.boolShowSafeMode = objResult.objSafeModeUser.Safe_Mode_Enabled_ACE__c;
                                if(this.boolShowSafeMode === true) {
                                        this.boolSpinner = false;
                                }
                        }
                }).catch(() => {
                        this.boolSpinner = false;
                });

        }

        /*
        * To add a listener to listen to account summary data
        */
       addAccountSummaryListeners = ()=> {
               if(!this.objTabData.isSubtab){
                        this.strDynamicCustomEventName = this.strCustomEventName + '_' + this.objTabData.tabId;
               } else {
                        this.strDynamicCustomEventName = this.strCustomEventName + '_' + this.objTabData.parentTabId;
               }
                
                window.addEventListener(this.strDynamicCustomEventName, this.fetchAccountSummaryData);
       }

       /*
       * Method with Account summary Event Listener
       */
      fetchAccountSummaryData = (objCommEventData) => {
                const objResponseData = BaseLWC.fetchComponentData(objCommEventData, this.strDestinationId, true);
                if (objResponseData.boolError === true) {
                        this.boolAccountAPIError = true;
                        this.boolShowSpinner = false;
                } else {
                        this.recordId = objResponseData.recordId;
                        this.boolShowSafeMode = objResponseData.boolShowSafeMode;
                        if(objResponseData.objAccountSummaryData.contactDetailList)     {
                                this.objAccountSummaryData = objResponseData.objAccountSummaryData.contactDetailList[0];
                                this.boolAccountSummaryDataAvailable = objResponseData.boolAccountSummaryDataAvailable;
                                if(this.boolAccountSummaryDataAvailable !== true) {
                                        this.boolAccountAPIError = true; 
                                        this.boolShowSpinner = false;
                                } else {
                                        this.processAccountData();
                                        window.removeEventListener(this.strDynamicCustomEventName, this.fetchAccountSummaryData);
                                }
                        } else {
                                this.boolAccountAPIError = true;
                                this.boolShowSpinner = false;
                        }
                }
        }

        /**
         * Process Account Summary Response to show on Front End
         */
        processAccountData = () => {
                //for Primary Contact
                if(BaseLWC.isNotUndefinedOrNull(this.objAccountSummaryData.primaryContact)) {
                        //show Primary Conotact Section
                        if(BaseLWC.isNotUndefinedOrNull(this.objAccountSummaryData.primaryContact.name) && this.objAccountSummaryData.primaryContact.name !== "") {
                                this.boolHasPrimaryContact=true;
                        } else {
                                this.boolHasPrimaryContact=false; 
                        }
                } else {
                        //hide Primary Contact section
                        this.boolHasPrimaryContact=false;
                }

                //for BAE Contacts
                if(!BaseLWC.isNotUndefinedOrNull(this.objAccountSummaryData.baeContacts) || this.objAccountSummaryData.baeContacts.length === 0){
                        this.boolHasBAEContact=false;  
                } else {
                        if(BaseLWC.isNotUndefinedOrNull(this.objAccountSummaryData.baeContacts) && this.objAccountSummaryData.baeContacts.length > 1) {
                                this.objAccountSummaryData.baeContacts.filter(data => data.name !== "");
                        }
                        if(BaseLWC.isNotUndefinedOrNull(this.objAccountSummaryData.baeContacts) && this.objAccountSummaryData.baeContacts.length > 0) {
        
                                //format BAE Conatacts Data
                                for(let iterator = 0; iterator < this.objAccountSummaryData.baeContacts.length; iterator++){
                                        if(this.objAccountSummaryData.baeContacts[iterator].email === ""){
                                                this.objAccountSummaryData.baeContacts[iterator].email = "-";    
                                        }
                                }
                                //show BAE Section
                                this.boolHasBAEContact=true;
        
                                //show BAE Hover message if there is more than 1 record
                                if(this.objAccountSummaryData.baeContacts.length > 1) {
                                        this.boolHasBAEHover = true;
        
                                        //sort data to show contact in first postion alphabetically by name
                                        this.objAccountSummaryData.baeContacts = this.objAccountSummaryData.baeContacts.sort(function(data1, data2){
                                                if(data1.name > data2.name) {
                                                        return 1;
                                                } else  {
                                                        return -1;
                                                }
                                        });
                                        this.objAccountSummaryData.baeContacts = this.objAccountSummaryData.baeContacts.slice(0,1);
                                } else {
                                        this.boolHasBAEHover = false;
                                }
                        } else {
                                //hide BAE section
                                this.boolHasBAEContact=false;
                        }
                }

                //for Marketing Contacts
                if(!BaseLWC.isNotUndefinedOrNull(this.objAccountSummaryData.marketingContacts)){
                        this.boolHasMarketingContact=false;
                } else {
                        if(this.objAccountSummaryData.marketingContacts.length > 1) {
                                this.objAccountSummaryData.marketingContacts.filter(data => data.name !== "");
                        }
                        if(BaseLWC.isNotUndefinedOrNull(this.objAccountSummaryData.marketingContacts) && this.objAccountSummaryData.marketingContacts.length > 0) {
                                this.boolHasMarketingContact=true;
        
                                //format marketing data
                                for(let iterator = 0; iterator < this.objAccountSummaryData.marketingContacts.length; iterator++){
                                        if(this.objAccountSummaryData.marketingContacts[iterator].effectiveDate !== "" && this.objAccountSummaryData.marketingContacts[iterator].effectiveDate !== "00-00-0000"){
                                                this.objAccountSummaryData.marketingContacts[iterator].effectiveDate = BaseLWC.dateFormatterHelper(this.objAccountSummaryData.marketingContacts[iterator].effectiveDate);
                                        } else if(this.objAccountSummaryData.marketingContacts[iterator].effectiveDate === "00-00-0000") {
                                                this.objAccountSummaryData.marketingContacts[iterator].effectiveDate = "00/00/0000";
                                        } else {
                                                this.objAccountSummaryData.marketingContacts[iterator].effectiveDate = "-";
                                        }
        
                                        if(this.objAccountSummaryData.marketingContacts[iterator].endDate !== "" && this.objAccountSummaryData.marketingContacts[iterator].endDate !== "00-00-0000"){
                                                this.objAccountSummaryData.marketingContacts[iterator].endDate = BaseLWC.dateFormatterHelper(this.objAccountSummaryData.marketingContacts[iterator].endDate);
                                        } else if(this.objAccountSummaryData.marketingContacts[iterator].endDate === "00-00-0000") {
                                                this.objAccountSummaryData.marketingContacts[iterator].endDate === "00/00/0000";
                                        } else {
                                                this.objAccountSummaryData.marketingContacts[iterator].endDate = "-";
                                        }
                                }
                                if(this.objAccountSummaryData.marketingContacts.length > 1){
        
                                        //sort marketing contacts data by end date (primary) and effective date (secondary)
                                        this.objAccountSummaryData.marketingContacts = this.objAccountSummaryData.marketingContacts.sort(function(data1, data2){
                                                if(data1.endDate !== "-" && data1.endDate !=="00/00/0000") {
                                                       if(data2.endDate !== "-" && data2.endDate !=="00/00/0000") {
                                                                if(new Date(data1.endDate) < new Date(data2.endDate)) {
                                                                        return 1;
                                                                } else if(new Date(data1.endDate) > new Date(data2.endDate)) {
                                                                        return -1
                                                                } else {
                                                                        if(data1.effectiveDate !== "-" && data1.effectiveDate !== "00/00/0000"){
                                                                                if(data2.effectiveDate !== "-" && data2.effectiveDate !== "00/00/0000") {
                                                                                        if(new Date(data1.effectiveDate) < new Date(data2.effectiveDate)) {
                                                                                                return 1;
                                                                                        } else {
                                                                                                return -1
                                                                                        }
                                                                                } else {
                                                                                        if(data2.effectiveDate !== "00/00/0000"){
                                                                                                return 1;    
                                                                                       } else {
                                                                                                return -1;
                                                                                       }
                                                                                }
                                                                        } else {
                                                                                if(data1.effectiveDate !== "00/00/0000"){
                                                                                        return -1;    
                                                                                } else {
                                                                                        return 1;
                                                                                }
                                                                        }
                                                                }
                                                       } else {
                                                               if(data2.endDate !== "00/00/0000"){
                                                                        return 1;    
                                                               } else {
                                                                        return -1;
                                                               }
                                                       }
                                                } else {
                                                        if(data1.endDate !== "00/00/0000"){
                                                                return -1;    
                                                        } else {
                                                                return 1;
                                                        }
                                                }
                                        });
                                }
        
                                //show only 2 records and marketing contacts hover message in case of >2 records
                                if(this.objAccountSummaryData.marketingContacts.length > 2) {
                                        this.boolHasMarketingHover = true;
                                        this.objAccountSummaryData.marketingContacts = this.objAccountSummaryData.marketingContacts.slice(0,2);
                                } else {
                                        this.boolHasMarketingHover = false;
                                }
                        } else {
                                this.boolHasMarketingContact=false;
                        }
                }
                
                //no data found scenario 
                if(!this.boolHasBAEContact && !this.boolHasMarketingContact && !this.boolHasPrimaryContact) {
                        this.boolNoAccountDataError = true;
                } else {
                        this.boolNoAccountDataError = false;
                }
                
                //for Producers data
                if(BaseLWC.isNotUndefinedOrNull(this.objAccountSummaryData.producers) && this.objAccountSummaryData.producers.length > 0) {

                        //prioritizing primary producer contacts
                        this.objAccountSummaryData.producers = this.objAccountSummaryData.producers.sort(function(data1, data2) {
                                if(data1.primaryFlag === "N" && data2.primaryFlag === "Y") {
                                        return 1;
                                } else {
                                        return -1;
                                }
                        });
                        this.boolHasProducerData = true;
                        for(let iterator = 0; iterator < this.objAccountSummaryData.producers.length; iterator++){
                                this.lstProducerIds.push(this.objAccountSummaryData.producers[iterator].producerNumber);
                        }

                        
                        //show only 5 records and producer message in case of >5 records
                        if(this.lstProducerIds.length > 5) {
                                this.booShowProducerBlueStarMessage = true;
                                //slice to query only 5 records from producer demographics API
                                this.lstProducerIds = this.lstProducerIds.slice(0,5);
                        } else {
                                this.booShowProducerBlueStarMessage = false;
                        }
                        
                        this.fetchProducerData();
                } else {
                        //show no data warning in producer section
                        this.boolHasProducerData = false;
                        this.boolNoProducerDataError = true;
                        this.boolShowSpinner=false;
                        this.sendContactsCardData();
                }  
        }

        
       /*
       * Method to fetch Producer Data from Prodocer demographics API
       */
      fetchProducerData = () => {
                accountSearchContinuationCall({
                        strRequest: JSON.stringify(this.lstProducerIds)
                }).then((objResult) => {
                        if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                                if(objResult !== ""){
                                        //hide no producer data error
                                        this.boolHasProducerData = true;
                                        //hide producer API error
                                        this.boolProducerAPIError = false; 
                                
                                        this.lstInitialProducerData = JSON.parse(objResult);
                                        if(!BaseLWC.isNotUndefinedOrNull(this.lstInitialProducerData.strResponseStatusCode)) { 
                                        //filter out producers with no name field data
                                                this.lstInitialProducerData = this.lstInitialProducerData.filter(data => (BaseLWC.isNotUndefinedOrNull(data.producerName) && data.producerName !== ""));

                                                if(this.lstInitialProducerData.length > 0) { 

                                                //format producer data
                                                        for(let iterator=0; iterator<this.lstInitialProducerData.length; iterator++){
                                                                if(this.lstInitialProducerData[iterator].producerEffectiveDate !== "" && this.lstInitialProducerData[iterator].producerEffectiveDate !== "00-00-0000") {
                                                                        this.lstInitialProducerData[iterator].producerEffectiveDate = BaseLWC.dateFormatterHelper(this.lstInitialProducerData[iterator].producerEffectiveDate);      
                                                                } else if(this.lstInitialProducerData[iterator].producerEffectiveDate === "00-00-0000"){    
                                                                        this.lstInitialProducerData[iterator].producerEffectiveDate = "00/00/0000";
                                                                } else {
                                                                        this.lstInitialProducerData[iterator].producerEffectiveDate = "-";
                                                                }

                                                                if(this.lstInitialProducerData[iterator].producerEndDate !== "" && this.lstInitialProducerData[iterator].producerEndDate !== "00-00-0000"){
                                                                        this.lstInitialProducerData[iterator].producerEndDate = BaseLWC.dateFormatterHelper(this.lstInitialProducerData[iterator].producerEndDate);  
                                                                }else if(this.lstInitialProducerData[iterator].producerEndDate === "00-00-0000"){
                                                                        this.lstInitialProducerData[iterator].producerEndDate = "00/00/0000";     
                                                                } else {
                                                                        this.lstInitialProducerData[iterator].producerEndDate = "-";
                                                                }
                                                        }

                                                        //add producer primary flag
                                                        let matchedIndex ="";
                                                        for(let iterator = 0; iterator < this.lstInitialProducerData.length; iterator++){
                                                                matchedIndex = this.objAccountSummaryData.producers.findIndex(item => item.producerNumber === this.lstInitialProducerData[iterator].producerId);
                                                                if(this.objAccountSummaryData.producers[matchedIndex].primaryFlag === "Y") {
                                                                        this.lstInitialProducerData[iterator].isPrimaryContact = true;
                                                                        this.lstPrimaryProducerContactData.push(this.lstInitialProducerData[iterator]);
                                                                } else {
                                                                        this.lstInitialProducerData[iterator].isPrimaryContact = false;
                                                                        this.lstNonPrimaryproducerContactData.push(this.lstInitialProducerData[iterator]);
                                                                }
                                                        }

                                                        if(this.lstPrimaryProducerContactData.length > 0){
                                                                this.lstPrimaryProducerContactData = this.sortProducerData(this.lstPrimaryProducerContactData);
                                                                //pushing primary producers sorted by date after first
                                                                this.lstPrimaryProducerContactData.forEach(data => this.lstProcessedProducerData.push(data));  
                                                        }

                                                        if(this.lstNonPrimaryproducerContactData.length > 0) {
                                                                this.lstNonPrimaryproducerContactData = this.sortProducerData(this.lstNonPrimaryproducerContactData);
                                                                //pushing non-primary producers sorted by date after primary producers' data 
                                                                this.lstNonPrimaryproducerContactData.forEach(data => this.lstProcessedProducerData.push(data));
                                                        } 

                                                        if(this.lstProcessedProducerData.length > 1) {
                                                                //show view more button
                                                                this.boolShowProducerViewMore = true;
                                                                //not in view more state
                                                                this.boolIsViewMore = false;
                                                                //to show onnly first producer record data
                                                                this.lstFirstProducer.push(this.lstProcessedProducerData[0]);
                                                                //to show remaining 4 producer record data
                                                                this.lstViewMoreProducerData = this.lstProcessedProducerData.slice(1,5);
                                                        }  else {
                                                                //no view more button
                                                                this.boolShowProducerViewMore = false;
                                                                //not in view more state
                                                                this.boolIsViewMore = false;
                                                                if(this.lstProcessedProducerData.length === 1) {
                                                                        //show only one producer
                                                                        this.lstFirstProducer.push(this.lstProcessedProducerData[0]);
                                                                }
                                                        }
                                                } else {
                                                        //show no producer record found warning 
                                                        this.boolHasProducerData = false;
                                                        this.boolNoProducerDataError = true;
                                                        this.boolProducerAPIError = false; 
                                                }
                                        } else {
                                                if(this.lstInitialProducerData.strResponseStatusCode !== "200" && 
                                                this.lstInitialProducerData.strResponseStatusCode !== "201"){
                                                        //show producer API error
                                                        this.boolHasProducerData = false;
                                                        this.boolNoProducerDataError = false;
                                                        this.boolProducerAPIError = true;      
                                                }
                                        }
                                } else {
                                        //show no producer record found warning 
                                        this.boolHasProducerData = false;
                                        this.boolProducerAPIError = false;
                                        this.boolNoProducerDataError = true;
                                }
                        } else {
                                //show producer API error
                                this.boolHasProducerData = false;
                                this.boolProducerAPIError = true;
                                this.boolNoProducerDataError = false;
                        }
                        this.sendContactsCardData();

                        //hide spinner
                        this.boolShowSpinner=false;
                });
        }

        /*
        * To sort Producers data by end date (primary) and effective date (secondary)
        */
        sortProducerData = (data) => {
                data.sort(function(objProducer1, objProducer2) {
                        if(objProducer1.producerEndDate !== "00/00/0000" && objProducer1.producerEndDate !== "-") {
                                if(objProducer2.producerEndDate === "00/00/0000" || objProducer2.producerEndDate === "-"){
                                        if(objProducer2.producerEndDate === "00/00/0000") {
                                                return 1;
                                        } else {
                                                return -1;
                                        }
                                } else if (new Date(objProducer1.producerEndDate) < new Date (objProducer2.producerEndDate)){
                                        return 1;
                                } else if (new Date(objProducer1.producerEndDate) > new Date (objProducer2.producerEndDate)){
                                        return -1;
                                } else {
                                        if(objProducer1.producerEffectiveDate !== "-" && objProducer1.producerEffectiveDate !== "00/00/0000"){
                                                if(objProducer2.producerEffectiveDate !== "-" && objProducer2.producerEffectiveDate !== "00/00/0000"){
                                                        if(new Date(objProducer1.producerEffectiveDate) > new Date (objProducer2.producerEffectiveDate)) {
                                                                return -1;
                                                        } else {
                                                                return 1;
                                                        }
                                                } else {
                                                        if(objProducer2.producerEffectiveDate === "00/00/0000") {
                                                                return 1;
                                                        } else {
                                                                return -1;
                                                        }
                                                }
                                        } else {
                                                if(objProducer1.producerEffectiveDate === "00/00/0000") {
                                                        return -1;
                                                } else {
                                                        return 1;
                                                }
                                        }
                                }
                        } else {
                                if(objProducer1.producerEndDate === "00/00/0000") {
                                        return -1;
                                } else {
                                        return 1;
                                } 
                        }
                        
                });
                return data;
        }

        /**
         * method to send contactd card data to subtabs on load
         */
        sendContactsCardData() {
                const objParentTabContactsCardData = this.accumulateDataToBeSent();
                BaseLWC.fireCustomEvent(this.strTriggerSubTabEventName, objParentTabContactsCardData, this.strSubTabDestinationId,
                        true, this.objTabData.tabId);
        }

        /**
        * To handle Errors.
        * Helps to show case errors.
        * All components should have this code.
        */
        handleErrors = (error) => {
                //show Account API Error
                this.objCardError = error;
                this.boolAccountAPIError = true;
                this.boolShowSpinner=false;
        }


        /*
        * To Show All Prroducer Contact Details
        */
       showAllProducerContacts = () => {
               //in view more state
               this.boolIsViewMore = true;
       }

       /*
        * To Show Less Prroducer Contact Details
        */
       showLessProducerContacts = () => {
               //not in view more state
                this.boolIsViewMore = false;
        }

        /*
        * To Show Marketing Blue Start Message on Hover
        */
       displayMarketingMessage = () => {
                this.booShowMarketingBlueStarMessage=true;
       }
        /*
        * To Hide Marketing Blue Start Message on Hover
        */
       hideMarketingMessage = () => {
                this.booShowMarketingBlueStarMessage=false;
       }
        /*
        * To Show BAE Blue Start Message on Hover
        */
       displayBAEMessage = () => {
                this.booShowBAEBlueStarMessage=true;
       }
        /*
        * To Hide BAE Blue Start Message on Hover
        */
       hideBAEMessage = () => {
                this.booShowBAEBlueStarMessage=false;
       }

       /*
       * Method on click of refresh button to call out Account and Producer Demography APIs
       */
        refreshCard = () => {
                this.lstProducerIds=[];
                this.lstInitialProducerData=[];
                this.lstProcessedProducerData=[];
                this.lstFirstProducer=[];
                this.lstViewMoreProducerData=[];
                this.lstNonPrimaryproducerContactData=[];
                this.lstPrimaryProducerContactData = []; 
                this.boolHasProducerData=false;
                this.boolShowSpinner=true;
                this.boolHasPrimaryContact=false;
                this.boolHasMarketingContact=false;
                this.boolHasMarketingHover=false;
                this.boolHasBAEContact=false;
                this.boolHasBAEHover=false;
                this.boolShowProducerViewMore=false;
                this.boolIsViewMore=false;
                this.booShowProducerBlueStarMessage=false;
                this.booShowBAEBlueStarMessage=false;
                this.booShowMarketingBlueStarMessage=false;
                this.boolAccountAPIError = false;
                this.boolNoAccountDataError = false;
                this.boolProducerAPIError = false;
                this.boolNoProducerDataError = false;
                this.boolShowSafeMode = false;
                this.boolProducerSummaryDataAvailable=false;
                this.fetchSafeModeUserData();
                const strUrl = this.objTabData.url;
                this.strAccountNumber = BaseLWC.helperBaseGetUrlParameters('accountNumber', strUrl);
                this.boolAccount = BaseLWC.helperBaseGetUrlParameters('boolAccount', strUrl);
                this.strCorpCode = BaseLWC.helperBaseGetUrlParameters('corpCode', strUrl);
                this.fetchAccountData();
        }

        /**
     * Used to fetch data from Communication callout from Apex.
     *
     */
        fetchAccountData = () => {
                accountSummaryRequest({
                        strCorpCode: this.strCorpCode,
                        strAccountNumber:  this.strAccountNumber
                        }).then((objResult) => {
                                if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                                        this.boolAccountAPIError = false;
                                        this.objAccountSummaryData = JSON.parse(objResult).contactDetailList[0];
                                        this.boolShowSpinner = false;
                                        this.processAccountData();
                                } else {
                                        this.boolAccountSummaryDataAvailable = false;
                                        this.boolShowSpinner = false;
                                        this.boolAccountAPIError = true;
                                        this.objAccountSummaryData = objResult;
                                }
                        }).catch((strError) => {
                        this.boolAccountSummaryDataAvailable = false;
                        this.boolAccountAPIError = true;
                        this.strErrorMessage = this.label.MessageLightningComponent_Error_ACE;
                        this.boolShowSpinner = false;
                        this.boolAccountSummaryDataExecuted = true;
                        this.objCardError = strError;
                });
        }
        /**
         * Used to hide and show the cmp from the case details page depending on recordType Name.
         */
        showHideAccountContactsCard = () => {
                if(this.objectApiName === 'Case'){
                fetchAccountRecordType({
                        strCaseRecordId : this.recordId
                }).then((objResult) => {
                        if (BaseLWC.isNotUndefinedOrNull(objResult) && objResult === 'Account_ACE') {
                                if (!this.boolShowContactsCard) {
                                        this.boolShowContactsCard = true;  
                                }                              
                        } else {
                                this.boolShowContactsCard = false;
                        }
                }).catch(() => {
                        //do nothing
                });
                } else {
                        if (!this.boolShowContactsCard) {
                                this.boolShowContactsCard = true;
                        }
                }
        }
        //CEAS-56383-CHANGES      
        disconnectedCallback() {
                if(this.objTabData.tabId) {
                this.strDynamicCustomEventName = this.strCustomEventName + '_' + this.objTabData.tabId;
                window.removeEventListener(this.strDynamicCustomEventName, this.fetchAccountSummaryData);
                const tabIdEventName =this.strTriggerSubTabEventName + '_' + this.objTabData.tabId;
                window.removeEventListener(tabIdEventName,this.compareAndSendAccountSummaryData);
                }
                if(this.objTabData.parentTabId) {
                this.strDynamicCustomEventName =this.strSubTabCustomEventName + '_' + this.objTabData.parentTabId;
                window.removeEventListener(this.strDynamicCustomEventName,this.fetchContactsCardData);
                }
        }
}