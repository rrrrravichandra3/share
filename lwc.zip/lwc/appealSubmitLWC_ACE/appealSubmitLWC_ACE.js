//Standard Salesforce imports
import { LightningElement, api, wire} from 'lwc';
import { EnclosingTabId, getTabInfo, refreshTab } from 'lightning/platformWorkspaceApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

//Apex controller method import
import submitAppeal from '@salesforce/apex/SubmitAppealController_ACE.submitAppealToEAA';
import getRecordDetails from '@salesforce/apex/SubmitAppealController_ACE.getRecordDetails';

//Custom label imports
import strSAVEM_Start from '@salesforce/label/c.SubmitAppealValidationErrorMessage_ACE';
import strSAVEM_End from '@salesforce/label/c.SubmitAppealValidationErrorMessage_End_ACE';
import strSA_Error_Message from '@salesforce/label/c.SubmitAppealErrorMessage_ACE';
import strSA_Success_Message from '@salesforce/label/c.SubmitAppealSucessMessage_ACE';
import strFEPSubmitError from '@salesforce/label/c.FEPAppealsInitiationSubmissionErrorMessage';
import SubmitToEAA_Success_ACE from '@salesforce/label/c.SubmitToEAA_MemberGrievance_Success_ACE';
import SubmitToEAA_Error_ACE from '@salesforce/label/c.SubmitToEAA_MemberGrievance_Error_ACE';

import * as support from './appealSubmitLWCSupport_ACE';

export default class AppealSubmitLWCACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;

    //Create public interface to consume record Id
    @api recordId;

    //declare component variables
    error;
    lob;
    productType;
    accountNumber;
    inquirerRelationship;
    providerNetworkStatus;
    routerTransactionCode;
    sourceSystemIdentifier;
    status;
    subStatus;
    //CEAS-69291
    boolShowSubmitAppeal = true;
    boolError = false;
    @api isSubmitToEAA;


    //Initialize to false = show spinner
    loaded = false;

    closeModal() {
        this.loaded = true;
    }

    //CEAS-69291
    connectedCallback() {
        try {
           if(this.isSubmitToEAA) {
                this.boolShowSubmitAppeal = false;
           }
        } catch(error) {
             //Handle Error
        }
    }

    /**
     * Public interface to submit appeal processing
     * @param all parameters are class level data = "this.*****"
     * Note: this method can be called even if the @wire method did not execute correctly.
     *       Check for presence of required data to continue, or show transaction error.
     */
    @api
    openSubmitAppealModal(){
        if(this.recordId && this.lob && this.productType) {
            this.continueSubmitAppeal();
        } else {
            if(this.isSubmitToEAA) {
                //CEAS-69291
                this.showNotification('', SubmitToEAA_Error_ACE,support.WORD_ERROR,support.WORD_STICKY);
            } else {
                this.showNotification(support.TRANSACTION_ERROR_TITLE, support.MISSING_DATA_MESSAGE, support.WORD_ERROR, support.WORD_STICKY);
            }
        }
    }

    continueSubmitAppeal() {
        //if the spinner is not showing, show the spinner
        this.loaded = false;

        if(this.processForFEP() || this.isSubmitToEAA) {
            const objParameters = {
                "idCase": this.recordId
            };
            //call Apex controller method, process results in "then" method
            submitAppeal(objParameters)
            .then(result => {
                //pass results to processing function
                if(this.isSubmitToEAA) { //CEAS-69291
                    this.processSubmitToEAAResult(JSON.parse(result));
                } else {
                    this.processAppealResults(JSON.parse(result));
                }
            })
            .catch(error => {
                if(this.isSubmitToEAA) {
                    this.showNotification('', SubmitToEAA_Error_ACE,support.WORD_ERROR,support.WORD_STICKY);
                } else {
                    this.showNotification(support.TRANSACTION_ERROR_TITLE, error.body.message, support.WORD_ERROR, support.WORD_STICKY);
                }
            });
        }
    }

    processAppealResults(objSubmitWrapper) {

        if (objSubmitWrapper.boolIsValidationError === true) {
            this.showNotification(
                support.VALIDATION_ERROR_TITLE,
                strSAVEM_Start + objSubmitWrapper.strInValidFieldLabels + strSAVEM_End,
                support.WORD_ERROR,
                support.WORD_STICKY
                );
        } else if (objSubmitWrapper.boolIsError === true) {
            this.showNotification(
                support.WORD_ERROR,
                strSA_Error_Message,
                support.WORD_ERROR,
                support.WORD_STICKY
                );
        } else {
            this.showNotification(
                support.SUCCESS_TITLE,
                strSA_Success_Message,
                support.WORD_SUCCESS
                );
            //Reload the page 3 seconds after success
            this.refreshCaseTab();
        }

    }

    showNotification(title, message, variant, mode) {

        //CEAS-69291
        if(!mode) {
            mode = support.WORD_PESTER;
        }
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(evt);
        //Turn off spinner if notification is shown
        if(!this.isSubmitToEAA) {//CEAS-69291
            setTimeout(function(){this.loaded = true;}.bind(this), support.MODAL_VIEW_DEPLAY);
        }

    }

    populateInstanceFields(data) {
        this.lob = data.LineOfBusiness_ACE__c;
        this.productType = data.Product_Type_ACE__c;
        this.accountNumber = data.Account_Number_ACE__c;
        this.inquirerRelationship = data.InquirerRelationship_ACE__c;
        this.providerNetworkStatus = data.ProviderNetworkStatus_ACE__c;
        this.routerTransactionCode = data.RouterTransactionCode_ACE__c;
        this.sourceSystemIdentifier = data.Source_System_Identifier_ACE__c;
        this.status = data.Status;
        this.subStatus = data.Sub_Status_ACE__c;
    }

    getDataValue(data, fieldName) {
        return data.fields[fieldName].value;
    }

    processForFEP() {
        if (
            this.routerTransactionCode === support.WORD_AVA && !this.sourceSystemIdentifier &&
                (
                    (
                        this.accountNumber.includes(support.WORD_FEP) && this.inquirerRelationship === support.WORD_PROVIDER
                        && !this.providerNetworkStatus
                    )
                    ||
                    (
                        this.status === support.WORD_PENDED && !this.subStatus
                    )
                )
            ) {
            this.showNotification(support.FEP_VALIDATION_ERROR_TITLE, strFEPSubmitError, support.WORD_ERROR);
            return false;
        } else {
            return true;
        }
    }

    @wire (getRecordDetails,{idCase: '$recordId'})
    processAndContinue({error, data}) {
        if(!data && !error) {
            //do nothing, component initializing
        } else if(data) {
            //Load values into instance variables
            this.populateInstanceFields(data);
            //once we have our data from the case/record ID, call openSubmitAppealModal for further processing
            this.openSubmitAppealModal();
        } else {
            if(this.isSubmitToEAA) {
                //CEAS-69291
                this.showNotification('', SubmitToEAA_Error_ACE,support.WORD_ERROR,support.WORD_STICKY);
            } else {
                this.showNotification(support.TRANSACTION_ERROR_TITLE, error.body.message, support.WORD_ERROR, support.WORD_STICKY);
            }
        }
    }

    //CEAS-69291
    processSubmitToEAAResult(objSubmitWrapper) {
        if (objSubmitWrapper.boolIsError === true) {
            this.showNotification(
                '',
                SubmitToEAA_Error_ACE,
                support.WORD_ERROR,
                support.WORD_STICKY
                );
        } else {
            this.showNotification(
                '',
                SubmitToEAA_Success_ACE,
                support.WORD_SUCCESS,
                support.WORD_STICKY
                );
        }
    }

    refreshCaseTab() {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objResponse => {
                setTimeout(function() {
                    refreshTab(objResponse.tabId);
                }, support.REFRESH_DELAY);
            }).catch(error => {
                this.handleErrors(error);
            });
        }
    }

    // method to catch error
    handleErrors(error) {
        this.boolError = error;
    }
}
