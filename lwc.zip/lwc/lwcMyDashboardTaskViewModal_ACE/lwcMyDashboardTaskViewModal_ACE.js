//Duplicated from caseNotesViewModalLwc_ACE for use as child component of other LWC Component
//Component created for CEAS-51147
import { LightningElement, api,wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getTasks from '@salesforce/apex/MyCaseListDashboardController_ACE.getTaskList';
import CaseNotesModal_Refresh_ACE from '@salesforce/label/c.CaseNotesModal_Refresh_ACE';
import getCaseCategory from '@salesforce/apex/CaseNotesViewController_ACE.getCaseCategory';
//CEAS-82979 Platform Workspace API
import {openTab,openSubtab} from 'lightning/platformWorkspaceApi';


export default class LwcMyDashboardTaskViewModal_ACE extends NavigationMixin(LightningElement) {
    label = {
        CaseNotesModal_Refresh_ACE
    };
    boolShowWarning = false;
    boolShowSpinner = true;
    @api strCaseId;
    @api strAccountId;
    @api strCaseNumber;
    @api strCaseTypeCategory;
    @api strCaseType;
    @api strCaseSubType;
    boolDisplayData = false;
    //CEAS-61105
    @api strFacetsTaskId;
    boolError = false;
    boolSuccess = false;
    boolSpinner = false;
    strErrorMessage = '';
    lstTableData=[];
    columns = [
        { label: 'TASK ID', fieldName: 'Id', sortable: true, type: '' },
        { label: 'TASK TYPE', fieldName: 'Type', sortable: true, type: '' },
        { label: 'SUBJECT', fieldName: 'Subject', sortable: true, type: ''},
        { label: 'DUE DATE', fieldName: 'ActivityDate', sortable: true, type: 'date' },        
        { label: 'STATUS', fieldName: 'Status', sortable: true,type: '' }
                    
    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize:5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: false,
        boolSecondaryTable: false,
        boolShowSearch: false,
        boolShowSearchLabel:false,
    };
    boolShowNoRecordFound = false;

    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
                this.fetchDataFromServer();

        } catch (error) {
            this.handleErrors(error);
        }
    }
    fetchDataFromServer() {
        this.boolDisplayData = false;
        getCaseCategory({
            idParent: this.strCaseId
        }).then((result) => {
            if (result) {
                this.strCaseTypeCategory = JSON.parse(JSON.stringify(result));
            }
        })
        getTasks({
            idCase: this.strCaseId
        }).then((result) => {
            if (result) {
                this.formatTableData(result);
                this.boolDisplayData = true;
                if(result.length === 0) {
                    this.boolShowNoRecordFound = true;
                }
            } else {
                this.boolShowNoRecordFound = true;
            }
        })
        .catch((error) => {
            this.handleErrors(error);
            this.boolShowNoRecordFound = true;
        });  
    }
    refreshModal() {
        try {
            this.fetchDataFromServer();
        } catch (error) {
            this.handleErrors(error);
        }
    }
    //CEAS-61105
    handleErrors = (errorMessage) => {
        this.boolError = true;
        this.strErrorMessage = errorMessage;
    };
    formatTableData (lstTasksData) {

        const data=[...lstTasksData];
        //Loop through Data to modify for Table   
        this.lstTableData = [];             
        this.lstTableData=data.map((el,i)=>{ 
            const objTask={...el};
            objTask['Id']={
                value:el['Id'],
                strAccountId:this.strAccountId,
                wrapper:`<a data-taskNumber="${el.Id}">${el.Id}</a>`
            };

            objTask['actionLink']={
                value:el['Id'],
                wrapper:`<a data-casenumber="${el.CaseNumber}">View Notes</a>`
            }

            return objTask;
        })
        this.boolDisplayData = true;
    }

    handleRowAction(event){
        try {
            const column = JSON.parse(event.detail).activeColFieldName;
            const rowData=JSON.parse(event.detail);
            if(column === 'Id'){
                this.openTask(rowData.activeColumnData.value.value,rowData.activeColumnData.value.strAccountId)
            }
        } catch(error) {
            //Handle Error
            this.handleErrors(error);
        }
    }

    openTask (strTaskId, strAccountId) {
        const strAccountURL=location.origin+'/lightning/r/Account/'+strAccountId+'/view';
        openTab({
            url: strAccountURL,
            focus: true
        }).then(response=>{
            openSubtab(response , { recordId: this.strCaseId,focus: false});
            openSubtab(response , { recordId: strTaskId,focus: true});
        });
    }
}