import {
    LightningElement,
    api,
    wire,
    track
} from 'lwc';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
//CEAS-82979 Platform Workspace API
import { EnclosingTabId, getTabInfo, openSubtab,refreshTab,setTabLabel,setTabIcon} from 'lightning/platformWorkspaceApi';
import lblAdjustementHistoryDetails_ACE from '@salesforce/label/c.AdjustementHistoryDetails_ACE';
import lblMedicalAdjustment_VFPage_ACE from '@salesforce/label/c.MedicalAdjustment_VFPage_ACE';

export default class LwcMedicalAdjustmentModal extends LightningElement {

    //Standard Variables
    objTabData = {};
    boolError = false;
    //API Variables
    @api boolIsOpen = false;
    @api strUrlClaimId;
    @api strclaimType;
    @api strclaimAdjustmentNumber;
    @api strUrlGroupNumber;
    @api strUrlCorpCode;
    @api strAccountId;
    @api strMemberId;
    @track varMedicalAdjustmentVFPage;

    objClaimHistoryListenerX;
    @wire(EnclosingTabId) enclosingTabId;

    //Error Handling Method.
    handleErrors(error) {
        this.boolError = error;
    }

    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.fetchTabData();
            this.varMedicalAdjustmentVFPage = lblMedicalAdjustment_VFPage_ACE;
        } catch (error) {
            //Handle Error
            this.handleErrors(error);
        }
    }

    fetchTabData() {
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objTabData => {
            this.objTabData = objTabData;
            //Always add executeInitialFunctionality function which can be reused for refresh.

            this.fetchSafeModeUserData();
            this.executeInitialFunctionality();
        }).catch((error) => {
            this.handleErrors(error);
        });
    }
    }
    //Init Method.
    executeInitialFunctionality() {
        if (this.objClaimHistoryListenerX === undefined || this.objClaimHistoryListenerX === null) {
            const objClaimHistoryListener = function(objEventData) {
                if (this.objClaimHistoryListener === undefined) {
                    window.removeEventListener('message', this.objClaimHistoryListenerX, false);
                }
                const strBaseResponse = BaseLWC.helperBaseGetDataForCustomEvents(objEventData, null, lblAdjustementHistoryDetails_ACE);

                if (strBaseResponse === undefined) {
                    return;
                } else {
                    if (JSON.parse(strBaseResponse).strIdDestination === lblAdjustementHistoryDetails_ACE) {
                        const claimInfo = JSON.parse(strBaseResponse).objParameters.strClaimId;
                        const claimType = JSON.parse(strBaseResponse).objParameters.strClaimType;
                        const strId = JSON.parse(strBaseResponse).objParameters.strId;
                        const strAdjNumber = JSON.parse(strBaseResponse).objParameters.strAdjNumber;
                        const mid = JSON.parse(strBaseResponse).objParameters.strMemberId;
                        let labelname = claimInfo;
                        if (strAdjNumber !== '0') {
                            labelname += '-' + strAdjNumber;
                        }
                        const callBackForRefreshSubTab = function() {
                            getFocusedTabInfo().then(refereshresponseMed => {
                                setTimeout(function() {
                                    const focusedSubTabId = refereshresponseMed.tabId;
                                    refreshTab(refereshresponseMed.tabId);
                                    setTabLabel(refereshresponseMed.tabId, labelname);
                                    setTabIcon(focusedSubTabId, 'utility:record','ClaimDetail');

                                }, 100);
                            }).catch(error => {
                                reject(error);
                            });
                        }

                        if (this.enclosingTabId) {
                            getFocusedTabInfo().then(function(response) {
                                const focusedTabId = response.tabId;
                                if (claimType === 'Pharmacy') {
                                    if (this.strMemberId !== "undefined" && this.strMemberId !== undefined &&
                                        this.strMemberId === mid) {
                                        const strEncodedClaimsAndMemberId = '?' + window.btoa(unescape(encodeURIComponent('claimNumber=' + claimInfo + '&mid=' + this.strMemberId + '&claimId=' + strId + '&adjNumber=' + JSON.parse(strBaseResponse).objParameters.strAdjNumber + '&corpCode=' + this.strUrlCorpCode + '&groupNumber=' + strUrlGroupNumber + '&idAccount=' + this.strAccountId)));

                                        const objPageReference = {
                                            "type": "standard__navItemPage",
                                            "attributes": {
                                                "apiName": "Claims_Details_FlexiPage_ACE",
                                                "uid": claimInfo + '-' + strAdjNumber
                                            },
                                            "state": {
                                                "c__BaseURLParam": strEncodedClaimsAndMemberId
                                            }
                                        };
                                        openSubtab(focusedTabId, { url: objPageReference,focus: true}).then(callBackForRefreshSubTab).catch(function() {
                                            /* Do Nothing */
                                        });
                                    }
                                } else {
                                    if (this.strMemberId !== "undefined" && this.strMemberId !== undefined &&
                                        this.strMemberId === mid) {
                                        const strEncodedClaimsAndMemberId = '?' + window.btoa(unescape(encodeURIComponent('claimNumber=' + claimInfo + '&mid=' + this.strMemberId + '&claimId=' + strId + '&adjNumber=' + strAdjNumber +
                                            '&corpCode=' + this.strUrlCorpCode + '&groupNumber=' + strUrlGroupNumber + '&idAccount=' + this.strAccountId)));
                                        let flexiPageApiName;
                                        if(claimType === 'Medical') {
                                            flexiPageApiName = "ViewMedicalClaimDetailsFlexiPage_ACE"
                                        } else {
                                            flexiPageApiName = "ViewDentalClaimDetailsFlexiPage_ACE";
                                        } 
                                        const objPageReference = {
                                            "type": "standard__navItemPage",
                                            "attributes": {
                                                "apiName": flexiPageApiName,
                                                "uid": claimInfo + '-' + strAdjNumber
                                            },
                                            "state": {
                                                "c__BaseURLParam": strEncodedClaimsAndMemberId

                                            }
                                        };
                                        openSubtab(focusedTabId, { url: objPageReference,focus: true}).then(callBackForRefreshSubTab).catch(function() {
                                            /* Do Nothing */
                                        });

                                    }
                                }

                            }).catch(function() {
                                /* Do Nothing */
                            });
                        } else {

                            //do nothing
                        }
                    } else {

                        //do nothing
                    }
                }
            }
            this.objClaimHistoryListenerX = objClaimHistoryListener;
            window.addEventListener('message', objClaimHistoryListener, false);
        }
    }
    //Iframe On Load
    onLoadOfIframe() {
        //Posting the message to apex controller
        const iframe = this.template.querySelector('idMedicalAdjustmentHistoryVfIFrame');
        const objVFPage = iframe.contentWindow;
        const message = {
            strIdDestination: 'MedicalAdjustmentHistory_ACE',
            strClaimId: this.strUrlClaimId,
            strclaimType: this.strclaimType,
            strclaimAdjustmentnumber: this.strclaimAdjustmentNumber,
            strMid: this.strMemberId
        };
        objVFPage.postMessage(message, '*');
    }
}