import { LightningElement, wire, api } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import { openSubtab } from 'lightning/platformWorkspaceApi';
import { publish, MessageContext } from 'lightning/messageService';
import bridgeHelper from '@salesforce/messageChannel/LWCAuraVFBridgeHelper__c';

import getCASFeedback from '@salesforce/apex/ViewCasFeedbackController_ACE.getCasFeedback'


//import labels
import ViewCaseSummary_CaseNumber_ACE from '@salesforce/label/c.ViewCaseSummary_CaseNumber_ACE';
import ViewCaseSummary_DateTimeOpened_ACE from '@salesforce/label/c.ViewCaseSummary_DateTimeOpened_ACE';
import ViewCaseSummary_InquirerName_ACE from '@salesforce/label/c.ViewCaseSummary_InquirerName_ACE';
import ViewCaseSummary_SubscriberId_ACE from '@salesforce/label/c.MemberSearch_SUBCRIBERID_ACE';
import ViewCaseSummary_GroupNumber_ACE from '@salesforce/label/c.ViewCaseSummary_GroupNumber_ACE';
import ViewCaseSummary_TypeAndSubType_ACE from '@salesforce/label/c.ViewCaseSummary_TypeAndSubType_ACE';
import ViewCaseSummary_Status_ACE from '@salesforce/label/c.ViewCaseSummary_Status_ACE';
import ViewCaseSummary_Origin_ACE from '@salesforce/label/c.ViewCaseSummary_Origin_ACE';
import ViewCaseSummary_CaseOwner_ACE from '@salesforce/label/c.ViewCaseSummary_CaseOwner_ACE';
import ViewCaseSummary_Action_ACE from '@salesforce/label/c.ViewCaseSummary_Action_ACE';
import ViewCaseSummary_InquirerRelationship_ACE from '@salesforce/label/c.ViewCaseSummary_InquirerRelationship_ACE';
import ViewCaseSummary_RecordType_ACE from '@salesforce/label/c.ViewCaseSummary_RecordType_ACE';
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import InteractionHistoryPage_NoRecordFound_ACE from '@salesforce/label/c.InteractionHistoryPage_NoRecordFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';

export default class LwcCasFedbackCaseCardComponent extends LightningElement {
    label = {
        ViewCaseSummary_CaseNumber_ACE,
        ViewCaseSummary_DateTimeOpened_ACE,
        ViewCaseSummary_InquirerName_ACE,
        ViewCaseSummary_InquirerRelationship_ACE,
        ViewCaseSummary_SubscriberId_ACE,
        ViewCaseSummary_GroupNumber_ACE,
        ViewCaseSummary_TypeAndSubType_ACE,
        ViewCaseSummary_Status_ACE,
        ViewCaseSummary_Origin_ACE,
        ViewCaseSummary_CaseOwner_ACE,
        ViewCaseSummary_Action_ACE,
        ViewCaseSummary_RecordType_ACE,
        SafeMode_ToastMessage_ACE,
        InteractionHistoryPage_NoRecordFound_ACE,
        IntegrationFailMessage_ACE
    }

    @api tabData;
    @api globalData;
    strRecordId = '';
    strCaseIntent = '';
    boolDisplayData = false;
    boolSpinner = false;
    @api boolSafeMode;
    boolShowNoRecorsFound = false;
    boolAPIError = false;
    boolShowNotesModal = false;
    objError;
    @wire(MessageContext)
    messageContext

    notesModal = {};
    lstTableData = [];
    columns = [
        { label: this.label.ViewCaseSummary_CaseNumber_ACE, fieldName: 'CaseNumber', sortable: true, type: '' },
        { label: this.label.ViewCaseSummary_DateTimeOpened_ACE, fieldName: 'CreatedDate', sortable: true, type: 'date', boolInitSort: true, boolAsc: false, boolIsTooltip: true },
        { label: this.label.ViewCaseSummary_InquirerName_ACE, fieldName: 'InquirerName_ACE__c', sortable: true, type: '', boolIsTooltip: true },
        { label: this.label.ViewCaseSummary_SubscriberId_ACE, fieldName: 'SubscriberID_ACE__c', sortable: true, type: '' },
        { label: this.label.ViewCaseSummary_GroupNumber_ACE, fieldName: 'GroupNumber_ACE__c', sortable: true, type: '', boolIsTooltip: true },
        { label: this.label.ViewCaseSummary_TypeAndSubType_ACE, fieldName: 'TypeAndSubType_ACE__c', sortable: true, type: '' },
        { label: this.label.ViewCaseSummary_Status_ACE, fieldName: 'Status', sortable: true, type: '' },
        { label: this.label.ViewCaseSummary_Origin_ACE, fieldName: 'Origin', sortable: true, type: '' },
        { label: this.label.ViewCaseSummary_CaseOwner_ACE, fieldName: 'OwnerName', sortable: true, type: '' },
        { label: this.label.ViewCaseSummary_Action_ACE, fieldName: 'Action', sortable: false, type: '' },
        { label: '', fieldName: 'InquirerRelationship_ACE__c', boolHidden: true, sortable: true, type: '' },
        { label: '', fieldName: 'RecordTypeName', boolHidden: true, sortable: true, type: '', },
        { label: '', fieldName: 'CaseRecordType_ACE__c', sortable: true, boolIsTooltip: true, type: '' }
    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: false,
        boolShowSearch: true,
        boolShowSearchLabel: true,
        filterData: []
    };

    handleErrors(error) {
        this.objError = error;
    }

    connectedCallback() {
        try {

            let filterCols = [
                { strType: '', intCol: -1, strFilterName: 'Select a value' }
            ];
            if (this.globalData.boolProducer || this.globalData.boolAccount || this.globalData.boolProspectAccount) {
                const columns1 = { ...this.columns[3], boolHidden: true };
                const columns2 = { ...this.columns[4], boolHidden: true };
                this.columns[3] = { ...columns1 };
                this.columns[4] = { ...columns2 };
                this.objInitTableSettings.columnsData = [...this.columns];
                filterCols.push({ strType: 'text', intCol: 5, strFilterName: this.label.ViewCaseSummary_GroupNumber_ACE });
            }

            filterCols = [...filterCols,
            { strType: 'picklist', intCol: 6, strFilterName: this.label.ViewCaseSummary_TypeAndSubType_ACE },
            { strType: 'picklist', intCol: 7, strFilterName: this.label.ViewCaseSummary_Status_ACE },
            { strType: 'picklist', intCol: 11, strFilterName: this.label.ViewCaseSummary_InquirerRelationship_ACE },
            { strType: 'picklist', intCol: 12, strFilterName: this.label.ViewCaseSummary_RecordType_ACE }
            ]
            this.objInitTableSettings.filterData = [...filterCols];
            this.fetchTabData();
        } catch (error) {
            this.handleErrors(error);
        }
    }

    fetchTabData = () => {
        this.strRecordId = this.tabData.recordId;
        this.strCaseIntent = this.globalData.strCaseIntent;
        this.boolDisplayData = false;
        this.boolShowNoRecorsFound = false;
        this.boolAPIError = false;
        this.boolSpinner = true;

        getCASFeedback({ idAccount: this.strRecordId, strIntent: this.strCaseIntent })
            .then(result => {

                for (let i = 0; i < result.length; i++) {
                    const obj = { ...result[i] };
                    obj['OwnerName'] = obj.Owner.Name;
                    obj['CaseNumber'] = {
                        value: obj['CaseNumber'],
                        strCaseId: obj['Id'],
                        wrapper: `<a data-casenumber="${obj.CaseNumber}">${obj.CaseNumber}</a>`
                    };

                    //CEAS-69441
                    obj['Sub_Type_ACE__c'] = this.convertAPIToLabelForSubtype(obj['Sub_Type_ACE__c']);
                    obj['TypeAndSubType_ACE__c'] = this.convertAPIToLabelForTypeAndSubtype(obj['TypeAndSubType_ACE__c']);
                    let strFacetsTaskId = '';
                    if (obj['Facets_Task_ID_ACE__c']) {
                        strFacetsTaskId = obj['Facets_Task_ID_ACE__c'];
                    }
                    obj['Action'] = {
                        value: obj['CaseNumber'],
                        strCaseId: obj['Id'],
                        strType: obj['Type'],
                        strSubType: obj['Sub_Type_ACE__c'],
                        strFacetsTaskId: strFacetsTaskId,
                        wrapper: `<a data-casenumber="${obj.CaseNumber}">View Notes</a>`
                    }

                    let datDateToShow = '';
                    if (BaseLWC.dtDateTimeISOtoLocal(obj.CreatedDate) !== 'Invalid Date') {
                        datDateToShow = BaseLWC.dtDateTimeISOtoLocal(obj.CreatedDate)
                    }
                    obj['CreatedDate'] = {
                        value: obj.CreatedDate,
                        wrapper: datDateToShow,
                        strCellValue: `<p>Case Age:<br/>${obj.CaseAge_ACE__c} Days</p>`,
                        strTextTooltipContent: `<p>Case Age:<br/>${obj.CaseAge_ACE__c} Days</p>`
                    }

                    if (obj['InquirerName_ACE__c']) {
                        obj['InquirerName_ACE__c'] = {
                            value: obj.InquirerName_ACE__c,
                            wrapper: obj.InquirerName_ACE__c,
                            strCellValue: `<p>Inquirer Relationship:<br/>${obj.InquirerRelationship_ACE__c}</p>`,
                            strTextTooltipContent: `<p>Inquirer Relationship:<br/>${obj.InquirerRelationship_ACE__c}</p>`
                        }
                    } else {
                        obj['InquirerName_ACE__c'] = {
                            value: '',
                            wrapper: '',
                            strCellValue: '',
                            strTextTooltipContent: ''
                        }
                    }
                    const strGroupNumberTooltip = `<p>Section: ${obj.SectionNumber_ACE__c || ''}<br/>Corporation Code: ${obj.CorporationCode_ACE__c || ''}
                                    <br/>Performance Guarantee: ${obj.PerformanceGuarantee_ACE__c || ''}</p>`;


                    if (obj['GroupNumber_ACE__c']) {
                        obj['GroupNumber_ACE__c'] = {
                            value: obj.GroupNumber_ACE__c,
                            wrapper: obj.GroupNumber_ACE__c,
                            strCellValue: strGroupNumberTooltip,
                            strTextTooltipContent: strGroupNumberTooltip
                        }
                    } else {
                        obj['GroupNumber_ACE__c'] = '';
                    }
                    const RecordType = ['CAS_Case_ACE', 'CAS_Case_Retail_and_Producer_ACE', 'CAS_Case_Account', 'CAS_Provider_Case_ACE'];
                    if (obj.RecordType && obj.RecordType.DeveloperName && obj.RecordType.Name && RecordType.includes(obj.RecordType.DeveloperName)) {
                        let strOperatorName = '';
                        if (obj.Operator_ACE__r && obj.Operator_ACE__r.Name) {
                            strOperatorName = obj.Operator_ACE__r.Name;
                        }
                        obj['CaseRecordType_ACE__c'] = {
                            value: obj.RecordType.Name,
                            wrapper: `<span class="slds-badge slds-p-horizontal_small colorBGBrand">CAS</span>`,
                            strCellValue: `<p>Operator Name: ${strOperatorName}</p>`,
                            strTextTooltipContent: `<p>Operator Name: ${strOperatorName}</p>`
                        }
                    } else {
                        obj['CaseRecordType_ACE__c'] = {
                            value: '',
                            wrapper: `<span></span>`
                        }
                    }
                    obj['RecordTypeName'] = obj.RecordType.Name;
                    result[i] = { ...obj };

                }
                this.lstTableData = [...result];
                this.boolSpinner = false;
                this.boolDisplayData = true;
                if (!this.lstTableData.length) {
                    this.boolShowNoRecorsFound = true;
                }

            })
            .catch(() => {
                this.boolSpinner = false;
                this.boolAPIError = true;
            });



    }

    handleRowAction(event) {
        const rowData = JSON.parse(event.detail);
        if (rowData.activeColumnName === this.label.ViewCaseSummary_Action_ACE) {
            if (typeof rowData.activeColumnData.value.value === 'string') {
                this.notesModal.strCaseNumber = rowData.activeColumnData.value.value
            } else {
                this.notesModal.strCaseNumber = rowData.activeColumnData.value.value.value;
            }
            this.notesModal.strCaseId = rowData.activeColumnData.value.strCaseId;
            this.notesModal.strCaseType = rowData.activeColumnData.value.strType;
            this.notesModal.strCaseSubType = rowData.activeColumnData.value.strSubType;
            this.notesModal.strFacetsTaskId = rowData.activeColumnData.value.strFacetsTaskId;
            this.boolShowNotesModal = true;
        } else if (rowData.activeColumnName === this.label.ViewCaseSummary_CaseNumber_ACE) {
            this.openCaseDetails(rowData.activeColumnData.value.strCaseId, rowData.activeColumnData.value.value)
        } else {
            //Do nothing
        }
    }

    closeModal() {
        this.boolShowNotesModal = false;
    }

    refreshData = () => {
        this.fetchTabData();
    }

    openCaseDetails = (strCaseId, strCaseNumber) => {
        try {
            if (!this.tabData) {
                return;
            }
            const objParsedTabData = JSON.parse(JSON.stringify(this.tabData));
            if (objParsedTabData.url) {
                const strDecodedURL = BaseLWC.helperBaseDecodeUrl(objParsedTabData.url);
                if (!BaseLWC.isValidUrl(strDecodedURL)) {
                    return
                }

                const objUrl = new URL(strDecodedURL);
                const strProducerId = objUrl.searchParams.get("producerId");
                let strParams = '?mid=' + this.globalData.strUrlMemberId + '&caseNumber=' + strCaseNumber;
                if (this.globalData.boolProspectMember) {
                    strParams += '&boolProspectMember=true&boolProducer=false&boolURLFormed=true'
                } else {
                    if (this.globalData.objAccRecords.RecordType.value.fields.DeveloperName.value === 'Producer_ACE') {
                        strParams += '&boolProducer=true&producerId=' + strProducerId;
                    } else {
                        strParams += '&boolProducer=false';
                    }
                }
                const strUrl = '/lightning/r/Case/' + strCaseId + '/view' + BaseLWC.helperBaseEncodeUrl(strParams);

                openSubtab(this.tabData.tabId, {url: strUrl, focus: true})
                    .then(() => {
                        //Do nothing
                    }).catch(() => {
                        //Do nothing
                    })
            }
        } catch (error) {

        }
    }

    openCreateCaseSubTab = () => {
        if (!this.tabData) {
            return;
        }
        try {
            const objParsedTabData = JSON.parse(JSON.stringify(this.tabData));
            if (objParsedTabData.url) {
                const strDecodedURL = BaseLWC.helperBaseDecodeUrl(objParsedTabData.url);
                if (!BaseLWC.isValidUrl(strDecodedURL)) {
                    return
                }
                const objAcc = this.globalData.objAccRecords;
                const strcallBack = objAcc.Phone.value;
                const strRecordType = objAcc.RecordType.value.fields.DeveloperName.value;
                const strSubscriber = objAcc.SubscriberId_ACE__c.value;
                const strTempMemberLOB = objAcc.TempMemberLOB_ACE__c.value; // CEAS-45893
                const strBillingState = objAcc.BillingState.value;
                const objUrl = new URL(strDecodedURL);
                const strProducerId = objUrl.searchParams.get("producerId");

                let strEncodedParams = '';
                let strFlexiPageURL;

                if (strRecordType === 'Producer_ACE') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now() + '&boolProducer=true&producerId=' + strProducerId);
                    strFlexiPageURL = '/lightning/n/ManualCaseCreate_Producer_ACE' + strEncodedParams;
                } else if (strRecordType === 'ProspectMember_ACE') {
                    if (strSubscriber !== null) {
                        //CEAS-63769
                        if (strTempMemberLOB && strTempMemberLOB.toUpperCase() === 'GOVERNMENT-MEDICARE') {
                            const strCorpCode = this.assignCorpCodeFromBillingState(strBillingState);
                            strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now() + '&tempMemberLOB=' + strTempMemberLOB + '&corpCode=' + strCorpCode);
                            strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectMember_ACE' + strEncodedParams + '&boolProspectMember=true';
                        } else {
                            strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now());
                            strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectMember_ACE' + strEncodedParams + '&boolProspectMember=true';
                        }

                    } else {
                        strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now() + '&tempMemberLOB=' + strTempMemberLOB);
                        strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectMemberNoSub_ACE' + strEncodedParams + '&boolProspectMember=true';
                    }
                } else if (strRecordType === 'Out_of_State_FEP_Member' || strRecordType === 'BlueCard_Member_ACE') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now());
                    strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectMemberNoSub_ACE' + strEncodedParams + '&boolProspectMember=true';
                } else if (strRecordType === 'Retail_Applicant_ACE') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now() + '&isRetailApplicant=true&strCallBackNumber=' + strcallBack);
                    strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectMemberNoSub_ACE' + strEncodedParams + '&boolProspectMember=true';
                } else if (strRecordType === 'Account_ACE') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now());
                    strFlexiPageURL = '/lightning/n/ManualCaseCreate_AccountServicing_ACE' + strEncodedParams;
                } else if (strRecordType === 'ProspectAccount_ACE') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now());
                    strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectAccount_ACE' + strEncodedParams;
                    // CEAS-57152 Design for NMCC
                } else if (strRecordType === 'PersonAccount') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now() + '&boolLoadAfterPlanEvent=true');
                    strFlexiPageURL = '/lightning/n/Manual_Case_Create_ACE' + strEncodedParams;
                } else {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now());
                    strFlexiPageURL = '/lightning/n/Manual_Case_Create_ACE' + strEncodedParams;
                }

                openSubtab(this.tabData.tabId, {url: strFlexiPageURL, focus: true})
                    .then(() => {
                        //Do nothing
                    }).catch(() => {
                        //Do nothing
                    })

                const objRequestFromNewButton = {
                    boolFromNewButton: true
                };
                const objData = {
                    key: 'requestFromNewButton_' + objAcc.Id.value,
                    value: JSON.stringify(objRequestFromNewButton)
                }
                this.postMessageHelper(objData, true, false, 'setLocalStorageViaIframe');
            }
        } catch (error) {
            //do nothing
        }
    }

    postMessageHelper(objDataToBeSent, boolLocalStorage, boolPostMessage, strDestinationId) {
        try {
            const objParameterData = {
                strDestinationId: strDestinationId,
                objMessage: objDataToBeSent
            };
            const objPayload = {
                bridgeMessageData: objParameterData
            };
            if (this.messageContext !== undefined && this.messageContext !== null) {
                publish(this.messageContext, bridgeHelper, objPayload);
            }
        } catch (exception) {
            //No handling Needed.
        }

    }
    assignCorpCodeFromBillingState = (strBillingState) => {
        let strCorpCode = '';
        if (strBillingState === undefined || strBillingState === null || strBillingState === '') {
            return strCorpCode;
        } else {
            if (strBillingState === 'New Mexico') {
                strCorpCode = 'NM1';
            } else if (strBillingState === 'Illinois') {
                strCorpCode = 'IL1';
            } else if (strBillingState === 'Texas') {
                strCorpCode = 'TX1';
            } else if (strBillingState === 'Oklahoma') {
                strCorpCode = 'OK1';
            } else if (strBillingState === 'Montana') {
                strCorpCode = 'MT1';
            } else {
                //Do nothing
            }
            return strCorpCode;
        }
    }

    //CEAS-69441 start
    convertAPIToLabelForSubtype(strSubType) {
        let strNewSubtype = strSubType;
        if (strNewSubtype === 'Grievance / Complaint') {
            strNewSubtype = 'Grievance / Member Complaint';
        } else if (strNewSubtype === 'Member Portal (BAM)') {
            strNewSubtype = 'Member Portal';
        } else if (strNewSubtype === 'PCP Update') {
            strNewSubtype = 'MG / PCP Update';
        } else if (strNewSubtype === 'Prior Authorization') {
            strNewSubtype = 'Preauth';
        } else if (strNewSubtype === 'Prospective Member') {
            strNewSubtype = 'Temporary Member';
        } else {
            //Do nothing
        }
        return strNewSubtype;
    }

    convertAPIToLabelForTypeAndSubtype(strTypeSubtype) {
        let strNewTypeSubtype = strTypeSubtype;

        const strGMC = 'Grievance / Complaint';
        if (strNewTypeSubtype.includes(strGMC)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strGMC, 'Grievance / Member Complaint');
        }
        const strMemberPortal = 'Member Portal (BAM)';
        if (strNewTypeSubtype.includes(strMemberPortal)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMemberPortal, 'Member Portal');
        }
        const strMGPCP = 'PCP Update';
        if (strNewTypeSubtype.includes(strMGPCP)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMGPCP, 'MG / PCP Update');
        }
        const strPreAuth = 'Prior Authorization';
        if (strNewTypeSubtype.includes(strPreAuth)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strPreAuth, 'Preauth');
        }
        const strProspectiveMember = 'Prospective Member';
        if (strNewTypeSubtype.includes(strProspectiveMember)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strProspectiveMember, 'Temporary Member');
        }
        return strNewTypeSubtype;
    }
    //CEAS-69441 end
}