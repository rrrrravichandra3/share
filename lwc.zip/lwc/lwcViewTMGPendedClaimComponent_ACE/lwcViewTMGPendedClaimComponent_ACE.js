import BaseLWC from 'c/baseLWCFunctions_CF';
import { LightningElement, track, api, wire } from 'lwc';
import { EnclosingTabId, getTabInfo, openSubtab } from 'lightning/platformWorkspaceApi'; 
import fetchTMGPendedClaimsRecords from '@salesforce/apexContinuation/TMGPendedClaimsController_ACE.fetchTMGPendedClaimsRecords';
import ViewBenefits_ViewAll_ACE from '@salesforce/label/c.ViewBenefits_ViewAll_ACE';
import claimsRed from '@salesforce/resourceUrl/HCSCClaimsStaticResource_ACE';
import { CurrentPageReference } from 'lightning/navigation';
import fetchCaseRuleId from '@salesforce/apex/NewCaseCheckClass_ACE.sendCaseRuleId';
import ClaimMedicalRecordType_ACE from '@salesforce/label/c.ClaimMedicalRecordType_ACE';
import fetchRecordTypeId from '@salesforce/apex/NewCaseCheckClass_ACE.sendCaseRecordTypeId';
import CreateCasePage_GovMediciadValue_ACE from '@salesforce/label/c.CreateCasePage_GovMediciadValue_ACE';
import ViewClaimHistory_AddtoCaseButton_ACE from "@salesforce/label/c.ViewClaimHistory_AddtoCaseButton_ACE";
import fetchCases from '@salesforce/apex/AddToCaseController_ACE.addToCaseDetails';
import Read_Only_Profile from "@salesforce/label/c.Read_Only_Profile";
export default class LwcTMGPendedClaims extends LightningElement {

@wire(EnclosingTabId) enclosingTabId;

get claimsRedImage() {
    return `${claimsRed}/Images/claims-red.svg`;
}
label = {
    ViewBenefits_ViewAll_ACE,
    ViewClaimHistory_AddtoCaseButton_ACE,
    CreateCasePage_GovMediciadValue_ACE,
    ClaimMedicalRecordType_ACE,
    Read_Only_Profile     
};

@api tabId;
lstTMGClaimsRecords = [];
lstData;
@api subscriberId = '';
@track boolNoRecs = false;
@track boolAPIError = false;
boolShowSpinner = false;
objTMGReqParams=null;
boolShowResultsTable = true;
boolShowData = true;
boolShowViewAllLink = true;t
objTabData;
objGlobalParams;
boolSafeModeEnabled;
boolDisableNewCaseButton = true;
boolDisableAddCaseButton = true;
strLineOfBusiness;
boolReadOnly = false;
showmodal=false;
boolAddToCase;
parenttabId;
caseStrNotes;
claimNumber;
strURL;
strCMID;
showNewCaseButton = true;
grpNo;
caseRuleId;
boolTXMAppealsAddToCase = 'false'; 
lstCaseData;
boolshowTooltiponAddtoCase = true;

columns = [
    { label: '', fieldName: '', sortable: true, type: 'selectRow' },
    { label: 'DCN/CLAIM NUMBER', fieldName: 'claimNumber', sortable: true, type: '' },
    { label: 'SERVICE FROM', fieldName: 'fromDate', sortable: true, type: 'date', boolInitSort: true, boolAsc: false },
    { label: 'SERVICE TO', fieldName: 'toDate', sortable: false, type: 'date', boolInitSort: true, boolAsc: false },
    { label: 'GROUP NUMBER', fieldName: 'groupNumber', sortable: true, type: '' },
    { label: 'Status', fieldName: 'status', sortable: true, type: '' },
    { label: 'TOTAL BILLED', fieldName: 'billedAmt', sortable: true, type: '' },
    { label: 'BILLING PROVIDER NAME', fieldName: 'providerName', sortable: true, type: '' },
    { label: 'Billing Provider Number', fieldName: 'providerNum', sortable: true, type: '' },
    { label: 'Billing Provider NPI', fieldName: 'npi', sortable: true, type: '' },
    { label: '', fieldName: 'strTextTooltipContent', sortable: false, boolHidden: false, type: '', boolIsTooltip: true, boolIsInfoIconTooltip: true }
    ];
objTMGClaimsInitSetting = {
    pageSize: 5,
    restrictedPageSize: 5, 
    boolViewMore: true,
    columnsData: this.columns,
    boolShowFilter: true,
    boolSecondaryTable: false,
    boolPagination: false,
    boolShowSearch: false,
    boolShowSearchLabel: false,
    searchPlaceholder : 'Search Text',
    boolShowCheckbox : true,
        boolShowHeader : false,
        filterData : [
            {strType : '', intCol : -1, strFilterName : 'Select a value'},
            {strType : 'text', intCol : 1, strFilterName : 'DCN/CLAIM NUMBER'},
            {strType : 'date', intCol : 2, strFilterName : 'SERVICE FROM'},
            {strType : 'date', intCol : 3, strFilterName : 'SERVICE TO'},
            {strType : 'text', intCol : 4, strFilterName : 'GROUP NUMBER'},
            {strType : 'text', intCol : 5, strFilterName : 'Status'},
            {strType : 'text', intCol : 6, strFilterName : 'TOTAL BILLED'},
            {strType : 'text', intCol : 7, strFilterName : 'BILLING PROVIDER NAME'},
            {strType : 'text', intCol : 7, strFilterName : 'Billing Provider Number'},
            {strType : 'text', intCol : 7, strFilterName : 'Billing Provider NPI'}
        ]
        
}

@wire(CurrentPageReference)
currentPageReference;

connectedCallback() {
    this.subscriberId = this.currentPageReference.state.c__subId;
    this.boolAddToCase = false; 
    this.getCaseRuleId(); 
    this.getRecordTypeId();          
    this.fetchTabData();
    this.fetchData();

}
getRecordTypeId() {
    fetchRecordTypeId({ caseRecordType: this.label.ClaimMedicalRecordType_ACE})
        .then((result) => {
            this.strRecordTypeId = result;
            
    })
    .catch(() => {
        this.handleErrors();
    });
}

getCaseRuleId() {
    fetchCaseRuleId({ caseRule: this.label.ClaimMedicalRecordType_ACE, strLineOfBusiness: this.label.CreateCasePage_GovMediciadValue_ACE})
        .then((result) => {
            this.caseRuleId = result.Id;
            
    })
    .catch(() => {
        this.handleErrors();
    });
}

//CEAS-80167 get the open and pended cases
getCases() {
        if (BaseLWC.isNotUndefinedOrNull(this.strCMID) && BaseLWC.isNotUndefinedOrNull(this.grpNo)) {
            fetchCases({ CmId: this.strCMID, groupNumber: this.grpNo })
            .then((result) => {
                this.lstCaseData = result;
               return result;
            })
            .catch(() => {
                this.boolShowButtons = false;
                this.boolDisableAddCaseButton = true;
                this.boolDisableNewCaseButton = true;
            });
        }
}
 
fetchData = () => {
    
    if (!this.subscriberId) {
        return;
    }
    const strSubscriberId = this.subscriberId;
    this.boolShowResultsTable = false;
    this.lstData = '';
    const startDate = new Date();
    const endDate = new Date();
    let curMonth = startDate.getMonth();
    startDate.setMonth(curMonth - 11);
    
    const startDateFormatTest = startDate.getFullYear() + "-" + (((startDate.getMonth()+8) < 10 ? '0' : '') + (startDate.getMonth()+1)) + "-" + (((startDate.getDate()-22) < 10 ? '0' : '') + (startDate.getDate()));
    const endDateFormatTest = endDate.getFullYear() + "-" + (((endDate.getMonth()-4) < 10 ? '0' : '') + (endDate.getMonth()-4)) + "-" + (((endDate.getDate()-20) < 10 ? '0' : '') + (endDate.getDate()-20));
    
    
    var strStartDt = this.convertDate(startDate);
    var strEndDt = this.convertDate(endDate);    
    let    jasonreqbody = '{"subscriberid": "'+strSubscriberId.substring(3) + '", "claimFromDate": "'+strStartDt + '",' + '"claimToDate": "' + strEndDt + '"}';
    
    fetchTMGPendedClaimsRecords({
        strDataJSON: jasonreqbody
    }).then(objResult => {
        this.boolShowSpinner = false;
            this.boolShowResultsTable = true;  
            this.boolAPIError = false;
            this.boolNoRecs = false;
            this.boolShowViewAllLink = true;
            if (this.profileName && (this.label.Read_Only_Profile.split(',').includes(this.profileName) || this.profileName === this.label.AMS_profile_ACE)) {
                    this.boolReadOnly = true;
                    this.boolDisableAddCaseButton = true;
                    this.boolDisableNewCaseButton = true;
                }
            
            const lstData=JSON.parse(objResult).lstClaimsHistory;
            this.lstData = lstData;
            for(let i=0;i<lstData.length;i++) {
                const obj={...lstData[i]};
                obj.fromDate = this.convertDateFormat(obj.fromDate);
                obj.toDate = this.convertDateFormat(obj.toDate);
                obj.billedAmt = '$' + obj.billedAmt;
                obj.providerName = (obj.providerFirstName ? obj.providerFirstName + ' ' : '') + (obj.providerLastName ? obj.providerLastName : '');
                obj['strTextTooltipContent']={
                    value:'',
                  //  wrapper:true,
                    strCellValue: `<div>
                    Description: ${obj.status}</br>
                </div>`,
                    strTextTooltipContent: `<div>
                    Description: ${obj.status}</br>
                </div>`
                }
                this.lstTMGClaimsRecords.push(obj);
            } 

            if (!this.lstTMGClaimsRecords.length)
            {
                this.boolNoRecs = true;
                this.boolShowViewAllLink = false;
            }
            //CEAS-80167
            //this.enableDisableAddToCaseNewCase();
        }).catch(error => {
            this.boolShowSpinner = false;
            this.boolShowResultsTable = true;
            this.boolAPIError = true;
        });

}

convertDate(dateConvert){
    var strDate = dateConvert.getFullYear() + "-" + (((dateConvert.getMonth()+1) < 10 ? '0' : '') + (dateConvert.getMonth()+1)) + "-" + ((dateConvert.getDate() < 10 ? '0' : '') + (dateConvert.getDate()));  
    return strDate;
}

convertDateFormat(dateObj) {
    const dateTimeArray = dateObj.split("T");

    var strDate = dateTimeArray[0].toString();
    var strDateSplit =strDate.split("-");
    var finalDate = strDateSplit[1]+"/"+strDateSplit[2]+"/"+strDateSplit[0];
    return finalDate;
}

refreshCard = () => {
    try {
        
        this.lstTMGClaimsRecords = [];
        this.boolAddToCase = false;            
        this.boolShowSpinner =  true;
        this.fetchData();
    } catch (error) {
        this.handleErrors(error);
    }
};


fetchTabData = () => { 
    this.boolAddToCase = false;
    getTabInfo(this.enclosingTabId).then((objTabData) => {
            this.objTabData = objTabData;
            this.parenttabId = this.objTabData.parentTabId;
            this.strURL = this.objTabData.url;
            this.strCMID = BaseLWC.helperBaseGetUrlParameters('strcmid', this.strURL);
            if (this.strCMID == '') {
                this.strCMID = BaseLWC.helperBaseGetUrlParameters('Cmid', this.strURL);
            }
            this.grpNo = BaseLWC.helperBaseGetUrlParameters('groupNumber', this.strURL);
            if(this.grpNo == '') {
                this.grpNo = BaseLWC.helperBaseGetUrlParameters('groupName', this.strURL);
            }
          // this.fetchCaseData();
           this.getCases();
        })
        .catch(() => {
           
        });
}


    handleAddToCase() {
        this.boolTXMAppealsAddToCase = 'true';
        this.showmodal = true;
    }
    closemodal() {
        this.showmodal = false;
        this.boolDisableAddCaseButton = true;
        this.refreshCard();
    }
navigateToNewCase(){
    try{

         //CEAS-80167 updated logic for Claim - Medical recordtype
         let lstCaseRelatedDetail = [];
         this.lstTMGClaimsRecords.forEach(item => {                   
                 const hoverdetails = {
                     "Total_Billed":item.billedAmt, 
                     "Provider_Name":item.providerName
                 };

                 const claimRecordDetails = {
                     "RecordType": this.label.ClaimMedicalRecordType_ACE,
                     "Claim_Number_ACE__c": item.claimNumber,
                     "Date_ACE__c": item.fromDate,
                     "Status_ACE__c": item.status,
                     "Hover_Related_Field_Medical_ACE__c": hoverdetails,
                     "Status_Reason_ACE__c": item.Status_Reason_ACE__c,
                     "Total_Billed_ACE__c":item.billedAmt, 
                     "Billing_Provider_Name_Medical_Claim_ACE__c":item.providerName,
                     "CorpCode_ACE__c": 'TX1',
                     "LineOfBusiness_ACE__c"  : this.label.CreateCasePage_GovMediciadValue_ACE

                 };
                 lstCaseRelatedDetail.push(claimRecordDetails);
             });
             
             const objCasedetails = {
                 "RecordTypeId": this.strRecordTypeId,
                 "LineOfBusiness_ACE__c"  : this.label.CreateCasePage_GovMediciadValue_ACE
             };
       
        let strIframeId = 'idCreateNewCaseLightningComponent';
        if (this.strURL) {
            let strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.strURL);
            strDecodedURL = strDecodedURL.split('/view?')
            if(strDecodedURL && strDecodedURL.length > 0) {
                const arrFrameId = strDecodedURL[0].split("Account/");
                strIframeId = strIframeId + '_' + arrFrameId[1];
            }
        }
        const strFlexipageNameUrl = '/lightning/n/Manual_Case_Create_ACE';
        const strUrl = '?&Dynamic=true&timeInMillis=' + Date.now();
        const strFlexiPageUrl = strFlexipageNameUrl +  BaseLWC.helperBaseEncodeUrl(strUrl);
        openSubtab(this.parenttabId, {url: strFlexiPageUrl, focus: true});
        
        this.sendToFoundationCreateCasePage(objCasedetails,lstCaseRelatedDetail , strIframeId);
    }catch(exception){

    }
}

sendToFoundationCreateCasePage(objCasedetails,lstCaseRelatedDetail ,strIframeId) {
    try {
            
        let intCasePageInterval = 0;
            const objErrorData = {};
            objErrorData.strComponentName = 'medicalRecordStatusViewerButtonLWCACE';
            objErrorData.strMessage = 'SetIntervals';
            objErrorData.strFunctionName = 'sendToFoundationCreateCasePage';
            objErrorData.strStackTrace = 'MaxIntervalReached;\nClearedInterval;\n';
            objErrorData.strError = 'IframeId Not Found: ' +strIframeId;
                
            const postMessageFunction = setInterval(() => { 
            try {
                    intCasePageInterval++;
                    const strDynamicCasePage = document.getElementById(strIframeId);
                    
                    if (strDynamicCasePage !== undefined && strDynamicCasePage !== null && strDynamicCasePage.dataIsLoaded === 1) {
                    
                    clearInterval(postMessageFunction);
                        this.postDataToCasePage(objCasedetails,lstCaseRelatedDetail , strIframeId);
                        clearInterval(postMessageFunction);
                    }
                    
                    BaseLWC.clearLoopedIntervalsInBase(this, intCasePageInterval, 1, postMessageFunction, objErrorData);
                } catch (objException) {
                    
                    clearInterval(postMessageFunction);
                }
            }, 1000);
        } catch (exception) {
            return;
        }
    }

    postDataToCasePage(objCasedetails, lstCaseRelatedDetail, strIframeId) {
        const objClaimSummaryFrame = document.getElementById(strIframeId).contentWindow;
        const objResponse = {
        strIdDestination: 'Manual_Case_Creation_Case_Related_Details',
        objParameters: {
                caseObject: objCasedetails,
                lstCaseRelatedDetail : lstCaseRelatedDetail ,
                strLOBViewClaimHistory :   CreateCasePage_GovMediciadValue_ACE 
                }
            };
            // Posting message
            objClaimSummaryFrame.postMessage(JSON.stringify(objResponse), '*');
    }
    async enableDisableAddToCaseNewCase() {
    try {
        //CEAS-80167 modified logic for enbale/disable buttons
        this.getCases();
        if(this.lstCaseData.length === 0) {
           this.boolDisableAddCaseButton = true;
           this.boolDisableNewCaseButton = false;
       }
       else {
           this.boolDisableAddCaseButton = false;
           this.boolDisableNewCaseButton = true;
       }

        this.boolShowButtons = true;
    } catch (objError) {
        this.boolShowButtons = false;
        this.boolDisableAddCaseButton = true;
        this.boolDisableNewCaseButton = true;
    }
}
handleRowAction(e){
    let caseStrNotesList;
    if(this.caseStrNotes != undefined && this.caseStrNotes != ''){
        caseStrNotesList = JSON.parse(this.caseStrNotes);
    }else{
        caseStrNotesList = [];
    }
    const column = JSON.parse(e.detail).activeColumnData.key;
    const rowData = JSON.parse(JSON.parse(e.detail).renderedRowData);
    let isChecked = JSON.parse(e.detail).isChecked;
    let claimNum;
    if(column === ''){
    claimNum = rowData[1].value;
        this.boolDisableAddCaseButton = false;
        //this.boolDisableNewCaseButton = false;
    } 
    let filterRecords = this.lstTMGClaimsRecords.filter(record => record.claimNumber === claimNum);
    filterRecords.forEach(item => {
        if(isChecked){
            let data = caseStrNotesList.find(record => record.claimNumber === claimNum);
            if(data == undefined){
                caseStrNotesList.push(item);
            }
        }else{
            //Based on the Checkbox check and uncheck add or remove the elements from the list.
            let index = caseStrNotesList.findIndex(item => item.claimNumber === claimNum);
             // added the condition to make sure, the clim which is not selected should not be removed.
            if(index != -1){
                caseStrNotesList.splice(index, 1);
            }
        }
    })
     // checking if caseStrNotesList has values to display button else disabled it.
     //CEAS-80167
     if(caseStrNotesList !== undefined && caseStrNotesList.length !== 0){
        this.enableDisableAddToCaseNewCase();
     }
     else{
        this.boolDisableNewCaseButton = true;
        this.boolDisableAddCaseButton = true;
    }
    this.caseStrNotes = JSON.stringify(caseStrNotesList);
}

    // CEAS-80187
    handleSelectAllList(e){
        let rowData = JSON.parse(e.detail).rowInfo;
        let action = JSON.parse(e.detail).action;
        let target = JSON.parse(e.detail).target;
        let allData = [];
        this.lstTMGClaimsRecords.forEach(item => {
            allData.push(item);
        })
        
        if(action === 'ADD' && target === 'selectAllCheckBox'){
            this.caseStrNotes = JSON.stringify(allData);
            this.enableDisableAddToCaseNewCase();
        }else if(action === 'REMOVE' && target === 'selectAllCheckBox'){
            this.caseStrNotes = '';
            this.boolDisableAddCaseButton = true;
            this.boolDisableNewCaseButton = true;
            this.getCases();
        }
    }

    
    // CEAS-80167
    showTooltip() {
        const btnNewCase = this.template.querySelector('.btnNewCases')
        const btnAddtoCase = this.template.querySelector('.btnAddtoCase')
      
        if(this.boolDisableNewCaseButton && this.boolDisableAddCaseButton)
        {
            btnNewCase.title = "";
            btnAddtoCase.title = "";
        }
        else if (!this.boolDisableNewCaseButton) {
            btnNewCase.title = "";
            btnAddtoCase.title = "There are no existing open/pended cases for this Member. Please create a new case.";
        }
        else
        {
            btnAddtoCase.title = "";
            btnNewCase.title = "Please click on the Add to Case button to attach claims to an existing case or create a new case.";
        }
     }

    
}