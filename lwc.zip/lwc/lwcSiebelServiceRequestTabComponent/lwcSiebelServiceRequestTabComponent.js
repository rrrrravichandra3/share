import { LightningElement, api, wire } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';

//import platformWorkspaceApi
import { EnclosingTabId, getTabInfo, openSubtab, setTabIcon, setTabLabel } from 'lightning/platformWorkspaceApi';

import fetchSRDetailsLWc from '@salesforce/apexContinuation/SRSummaryController_ACE.fetchSRDetailsLWc'
//Custom Labels
import SRSummary_SRNumber_ACE from '@salesforce/label/c.SRSummary_SRNumber_ACE';
import SRSummary_DateOrTimeOpened_ACE from '@salesforce/label/c.SRSummary_DateOrTimeOpened_ACE';
import SRSummary_InquirerName_ACE from '@salesforce/label/c.SRSummary_InquirerName_ACE';
import SRSummary_SubscriberID_ACE from '@salesforce/label/c.SRSummary_SubscriberID_ACE';
import SRSummary_GroupNumber_ACE from '@salesforce/label/c.GroupNumber_ACE';
import SRSummary_InquiryTopic_ACE from '@salesforce/label/c.SRSummary_InquiryTopic_ACE';
import SRSummary_InquiryReason_ACE from '@salesforce/label/c.SRSummary_InquiryReason_ACE';
import SRSummary_Status_ACE from '@salesforce/label/c.SRSummary_Status_ACE';
import SRSummary_SROwner_ACE from '@salesforce/label/c.SRSummary_SROwner_ACE';
import SRSummary_Notes_ACE from '@salesforce/label/c.CaseNotesModal_Notes_ACE';
import SRSummary_InquirerRelationship_ACE from '@salesforce/label/c.SRSummary_InquirerRelationship_ACE';
import SRSummary_CurrentSectionNumber_ACE from '@salesforce/label/c.SRSummary_CurrentSectionNumber_ACE';
import SRSummary_CorporationCode_ACE from '@salesforce/label/c.SRSummary_CorporationCode_ACE';
import SRSummary_SRAGE_ACE from '@salesforce/label/c.SRSummary_SRAGE_ACE';
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import InteractionHistoryPage_NoRecordFound_ACE from '@salesforce/label/c.InteractionHistoryPage_NoRecordFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';

export default class LwcSiebelServiceRequestTabComponent extends LightningElement {

    label = {
        SRSummary_SRNumber_ACE,
        SRSummary_DateOrTimeOpened_ACE,
        SRSummary_InquirerName_ACE,
        SRSummary_SubscriberID_ACE,
        SRSummary_GroupNumber_ACE,
        SRSummary_InquiryTopic_ACE,
        SRSummary_InquiryReason_ACE,
        SRSummary_Status_ACE,
        SRSummary_SROwner_ACE,
        SRSummary_Notes_ACE,
        SRSummary_InquirerRelationship_ACE,
        SRSummary_CurrentSectionNumber_ACE,
        SRSummary_CorporationCode_ACE,
        SRSummary_SRAGE_ACE,
        SafeMode_ToastMessage_ACE,
        InteractionHistoryPage_NoRecordFound_ACE,
        IntegrationFailMessage_ACE
    }

    @api tabData;
    @api globalData;
    @api srReqParams;
    @api boolSafeMode;

    //wire
    @wire(EnclosingTabId) enclosingTabId;


    boolSpinner = false;
    boolShowNoRecorsFound = false;
    boolAPIError = false;
    boolDisplayData = false;
    lstTableData = [];
    columns = [
        { label: this.label.SRSummary_SRNumber_ACE, fieldName: 'SRNumber', sortable: true, type: '' },
        { label: this.label.SRSummary_DateOrTimeOpened_ACE, fieldName: 'OpenedDate', sortable: true, type: 'date', boolInitSort: true, boolAsc: false, boolIsTooltip: true },
        { label: this.label.SRSummary_InquirerName_ACE, fieldName: 'InquirerName', sortable: true, type: '', boolIsTooltip: true },
        { label: this.label.SRSummary_SubscriberID_ACE, fieldName: 'SubscriberID', sortable: true, type: '' },
        { label: this.label.SRSummary_GroupNumber_ACE, fieldName: 'GroupNumber', sortable: true, type: '', boolIsTooltip: true },
        { label: this.label.SRSummary_InquiryTopic_ACE, fieldName: 'InquiryTopic', sortable: true, type: '' },
        { label: this.label.SRSummary_InquiryReason_ACE, fieldName: 'InquiryReason', sortable: true, type: '' },
        { label: this.label.SRSummary_Status_ACE, fieldName: 'Status', sortable: true, type: '' },
        { label: this.label.SRSummary_SROwner_ACE, fieldName: 'OwnerID', sortable: true, type: '' },
        { label: '', fieldName: 'AttachmentIndicator', sortable: false, type: '' },
        { label: '', fieldName: 'InquirerRelationship', sortable: true, boolHidden: true, type: '' },
        { label: '', fieldName: 'CurrentSectionNumber', boolHidden: true, sortable: true, type: '' },
        { label: '', fieldName: 'CorporationCode', boolHidden: true, sortable: true, type: '' },
        { label: '', fieldName: 'SRStatusOrder', boolHidden: true, sortable: true, type: '' },
        { label: '', fieldName: 'SRAge', boolHidden: true, sortable: true, type: '' }
    ];
    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: true,
        boolShowSearch: true,
        boolShowSearchLabel: true,
        filterData: [
            { strType: 'Select a value', intCol: -1, strFilterName: 'Select a value' },
            { strType: 'text', intCol: 5, strFilterName: this.label.SRSummary_GroupNumber_ACE },
            { strType: 'picklist', intCol: 6, strFilterName: this.label.SRSummary_InquiryTopic_ACE },
            { strType: 'picklist', intCol: 7, strFilterName: this.label.SRSummary_InquiryReason_ACE },
            { strType: 'picklist', intCol: 8, strFilterName: this.label.SRSummary_Status_ACE },
            { strType: 'picklist', intCol: 11, strFilterName: this.label.SRSummary_InquirerRelationship_ACE }
        ],
    };

    connectedCallback() {
        this.fetchData();
    }

    fetchData = () => {

        let lstPolicies = []
        if (this.srReqParams) {
            lstPolicies = [...this.srReqParams]
        }

        if (this.globalData.boolProducer || this.globalData.boolAccount) {
            lstPolicies = this.getProducerPoliciesDetails();
        }
        let strPolicies = '[]';
        if (lstPolicies.length) {
            strPolicies = JSON.stringify(lstPolicies)
        }
        this.boolSpinner = true;
        this.boolShowNoRecorsFound = false;
        this.boolAPIError = false;
        this.boolDisplayData = false;
        if (!lstPolicies.length) {
            this.boolShowNoRecorsFound = true;
            this.lstTableData = [];
            this.boolDisplayData = true;
            this.boolSpinner = false;
            return;
        }

        fetchSRDetailsLWc({ srPoliciesParam: strPolicies })
            .then(result => {

                let lstData = [];
                if (result) {
                    lstData = JSON.parse(result);
                }
                const lstStatus = [
                    "OPEN",
                    "PENDED",
                    "CLOSED",
                    "WITHDRAWN",
                    "REGISTERED",
                    "REDIRECTED CALL/TOOK MESSAGE",
                    "CALL COUNT/WRONG BUSINESS/WRONG NUMBER",
                    "AUTO REQUEST"
                ]
                const lstFinalData = [];
                for (let i = 0; i < lstData.length; i++) {
                    const objSR = { ...lstData[i] };

                    objSR.SRNumber = {
                        value: objSR.SRNumber,
                        strSRId: objSR.SRNumber,
                        wrapper: `<a>${objSR.SRNumber}</a>`
                    }

                    //Status Order Modification
                    if (objSR.Status === undefined) {
                        objSR.Status = '';
                    } else {
                        if (lstStatus.indexOf(objSR.Status) > -1) {
                            objSR.SRStatusOrder = Number(lstStatus.indexOf(objSR.Status)) + 1
                        } else {
                            objSR.SRStatusOrder = 9;
                        }
                    }

                    //Attachment indicator Modification
                    if (objSR.AttachmentIndicator === 'Y') {
                        objSR.AttachmentIndicator = {
                            value: '',
                            strIndicator: objSR.AttachmentIndicator,
                            wrapper: '<i></i>',
                            icon: {
                                name: 'utility:attach',
                                variant: '',
                                size: 'small'
                            }
                        }
                    } else {
                        objSR.AttachmentIndicator = {
                            value: '',
                            strIndicator: objSR.AttachmentIndicator,
                            wrapper: '<i></i>'
                        }
                    }

                    //Notes modification
                    let strNotes = '';
                    if (objSR.ServiceRequestNoteList && objSR.ServiceRequestNoteList.length > 0) {
                        objSR.ServiceRequestNoteList.forEach(el => {
                            if (el.SRNoteText) {
                                strNotes += el.SRNoteText
                            }

                        })
                    }

                    if (strNotes.length > 500) {
                        objSR.SRNotes = strNotes.substr(0, 500) + "...";
                    } else {
                        objSR.SRNotes = strNotes;
                    }
                    objSR['boolSecTable'] = true;
                    objSR['strSecTable'] = `<p>${this.label.SRSummary_Notes_ACE} : ${objSR.SRNotes}</p>`;

                    //date modification
                    let objTodayDate = '';
                    let dtPast30Date = '';
                    let dtTodayDate = '';
                    let dtSROpenedDate = '';
                    const openedDate = objSR.OpenedDate;
                    objSR.OpenedDate = objSR.OpenedDate.replace(".000Z", "");
                    const objDateTime = new Date(objSR.OpenedDate);

                    let intMonth = objDateTime.getMonth() + 1;
                    let intDay = objDateTime.getDate();
                    const intYear = objDateTime.getFullYear();
                    if (intMonth < 10) {
                        intMonth = "0" + intMonth;
                    }
                    if (intDay < 10) {
                        intDay = "0" + intDay;
                    }
                    objTodayDate = new Date(new Date().setDate(new Date().getDate() - 30));
                    dtPast30Date = (objTodayDate.getMonth() + 1) + "/" + objTodayDate.getDate() + "/" + objTodayDate.getFullYear();
                    dtSROpenedDate = intMonth + "/" + intDay + "/" + intYear;

                    objTodayDate = new Date(new Date().setDate(new Date().getDate()));
                    dtTodayDate = (objTodayDate.getMonth() + 1) + "/" + objTodayDate.getDate() + "/" + objTodayDate.getFullYear();
                    objSR.SRAge = (Date.parse(dtTodayDate) - Date.parse(dtSROpenedDate)) / (1000 * 60 * 60 * 24);

                    //Attaching the Hover Over code to the data before passing the result set to datatable.
                    let datDateToShow = '';
                    if (BaseLWC.dtDateTimeISOtoLocal(openedDate) !== 'Invalid Date') {
                        datDateToShow = BaseLWC.dtDateTimeISOtoLocal(openedDate)
                    }
                    objSR['OpenedDate'] = {
                        value: openedDate,
                        wrapper: datDateToShow,
                        strCellValue: `<span>SR Age:<br/>${objSR.SRAge} Days</span>`,
                        strTextTooltipContent: `<span>SR Age:<br/>${objSR.SRAge} Days</span>`
                    }

                    objSR['InquirerName'] = {
                        value: objSR.InquirerName,
                        wrapper: objSR.InquirerName,
                        strCellValue: `<span>${this.label.SRSummary_InquirerRelationship_ACE}:<br/>${objSR.InquirerRelationship}</span>`,
                        strTextTooltipContent: `<span>${this.label.SRSummary_InquirerRelationship_ACE}:<br/>${objSR.InquirerRelationship}</span>`
                    }
                    if (!objSR.PerformanceGuarantee) {
                        objSR.PerformanceGuarantee = '';
                    }
                    objSR['GroupNumber'] = {
                        value: objSR.GroupNumber,
                        wrapper: objSR.GroupNumber,
                        strCellValue: `<span>Section Number:${objSR.CurrentSectionNumber}
                    <br/>Corporation Code:${objSR.CorporationCode} <br/>
                    Performance Guarantee: ${objSR.PerformanceGuarantee}</span>`,
                        strTextTooltipContent: `<span>Section Number:${objSR.CurrentSectionNumber}
                    <br/>Corporation Code:${objSR.CorporationCode} <br/>
                    Performance Guarantee: ${objSR.PerformanceGuarantee}</span>`
                    }

                    lstFinalData.push({ ...objSR });
                }

                this.lstTableData = [...lstFinalData];
                if (!this.lstTableData.length) {
                    this.boolShowNoRecorsFound = true;
                }
                this.boolDisplayData = true;
                this.boolSpinner = false;
            }).catch((error) => {
                if (error.body && error.body.exceptionType === 'System.JSONException') {
                    this.lstTableData = [];
                    this.boolShowNoRecorsFound = true;
                    this.boolDisplayData = true;
                } else {
                    this.boolAPIError = true;
                }
                this.boolSpinner = false;
            });

    }

    getProducerPoliciesDetails = () => {
        const lstPolicies = [];
        const boolProducer = this.globalData.boolProducer;
        const boolAccount = this.globalData.boolAccount;
        if (boolProducer || boolAccount) {
            let strSubId = '';
            let strGrpnum = '';
            if (boolProducer) {
                strSubId = "0U" + this.globalData.strPhoneNumber;
                strGrpnum = "0000" + this.globalData.strGroupNumber + "000";
            } else {
                strSubId = "000000" + this.globalData.strAccountNumber;
                strGrpnum = "000" + this.globalData.strAccountNumber;
            }
            const objStrPolicies = {
                subscriberId: strSubId,
                groupNumber: strGrpnum
            }
            lstPolicies.push(objStrPolicies);
        }
        return lstPolicies;
    }

    handleRowAction(event) {
        const rowData = JSON.parse(event.detail);
        if (rowData.activeColumnName === this.label.SRSummary_SRNumber_ACE) {
            this.openSRDetails(rowData.activeColumnData.value.strSRId)
        }
    }

    openSRDetails = (strSRNumber) => {
        let mid = '';
        if (this.globalData.strCmid) {
            mid = this.globalData.strCmid
        }
        const strEncodedURL = window.btoa((encodeURIComponent('SRNumber=' + strSRNumber + '&mid=' + mid)));

        const objPageReference = {
            "type": "standard__navItemPage",
            "attributes": { "apiName": "SR_Summary_Details", "uid": strSRNumber },
            "state": { "c__BaseURLParam": strEncodedURL }
        };
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
                openSubtab(objTabData.tabId, { pageReference: objpageReference, focus: true})
                .then(objTabData => {
                    setTabLabel(objTabData, strSRNumber)
                        .then(() => {
                            setTabIcon(objTabData, "standard:case", strSRNumber) 
                                .then(() => {
                                    //Do nothing
                                }).catch(() => {
                                    //Do nothing
                                })
                        }).catch(() => {
                            //Do nothing
                        })
                });
        })
    }

    }

    refreshData = () => {
        this.fetchData();
    }
}
