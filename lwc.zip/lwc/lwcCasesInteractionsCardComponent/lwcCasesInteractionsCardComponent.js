import { LightningElement, wire, track, api } from 'lwc';

//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import { EnclosingTabId, getTabInfo} from 'lightning/platformWorkspaceApi';
import fetchBluecardFepMemberDetails from '@salesforce/apex/CaseSummaryController_ACE.fetchBluecardFepMemberDetails';

import { getRecord } from 'lightning/uiRecordApi';
import USER_ID from '@salesforce/user/Id';
import USERPROFILE_NAME from '@salesforce/schema/User.Profile.Name';


import ACCOUNT_ID_FIELD from '@salesforce/schema/Account.Id';
import DEVELOPER_NAME_FIELD from '@salesforce/schema/Account.RecordType.DeveloperName';
import SUBSCRIBER_ID_FIELD from '@salesforce/schema/Account.SubscriberId_ACE__c';
import TEMPMEMBER_LOB_FIELD from '@salesforce/schema/Account.TempMemberLOB_ACE__c';
import PHONE_FIELD from '@salesforce/schema/Account.Phone';
import BILLING_STATE_FIELD from '@salesforce/schema/Account.BillingState';
const fields = [ACCOUNT_ID_FIELD, DEVELOPER_NAME_FIELD, SUBSCRIBER_ID_FIELD, TEMPMEMBER_LOB_FIELD, PHONE_FIELD, BILLING_STATE_FIELD];



//Custom Labels
import Cases_Tittle_ACE from '@salesforce/label/c.Cases_Tittle_ACE';
import Interactions_Tittle_ACE from '@salesforce/label/c.Interactions_Tittle_ACE';
import SRSummary_Tittle_ACE from '@salesforce/label/c.SRSummary_Tittle_ACE';
import CASFeedbackCase_ACE from '@salesforce/label/c.CASFeedbackCase_ACE';
import SecureMessage_Title_ACE from '@salesforce/label/c.SecureMessage_Title_ACE';
import SMSTextMessage_Title_ACE from '@salesforce/label/c.SMSTextMessage_Title_ACE';
import CaseSummary_Title_ACE from '@salesforce/label/c.CaseSummary_Title_ACE';
import OKMGroupNumber_ACE from '@salesforce/label/c.OKMGroupNumber_ACE';
import TMGCallHistory_DisableTabDate_ACE from '@salesforce/label/c.TMGCallHistory_DisableTabDate_ACE';
import TMGCallHistory_DisableTabDateILM_ACE from '@salesforce/label/c.TMGCallHistory_DisableTabDateILM_ACE';
import CasfeedbackUserProfileId_ACE from '@salesforce/label/c.CasfeedbackUserProfileId_ACE';
import HideSiebelTab_ACE from '@salesforce/label/c.HideSiebelTab_ACE';
//CEAS-75947
import lblEnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import lblEnableTimeout_ACE from '@salesforce/label/c.EnableTimeout_ACE';

export default class LwcCasesInteractionsCardComponent extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    @api recordId;
    label = {
        Cases_Tittle_ACE,
        Interactions_Tittle_ACE,
        SRSummary_Tittle_ACE,
        CASFeedbackCase_ACE,
        SecureMessage_Title_ACE,
        SMSTextMessage_Title_ACE,
        CaseSummary_Title_ACE,
        TMGCallHistory_DisableTabDate_ACE,
        TMGCallHistory_DisableTabDateILM_ACE,
        CasfeedbackUserProfileId_ACE,
        HideSiebelTab_ACE,
        lblEnableTimeout_ACE,
        lblEnableVPSTabSpecificEvents_ACE
    }

    @track error;    
    @track strProfileName;
    boolWiredFuncExecuted=false;
    objTabData;
    objError;
    objPlanSummaryEventHandler;
    objGlobalParams = {};
    strBaseTabId;
    strBaseTabURL;
    boolLoadSRTabComponent =false;
    strRecordId;
    boolProfileFetched=false;
    boolAccRecordsFetched =false;
    //CEAS-75947
    boolPlanListned = false;
    
    @wire(getRecord,{
        recordId:USER_ID,
        fields:[USERPROFILE_NAME]
    }) wiredHandleUser({
        error,
        data
    }) {
        if(error){
            this.error =error;
        } else if(data){
            this.strProfileName=data.fields.Profile.displayValue;
            this.boolProfileFetched=true;

            if(this.boolProfileFetched && this.boolAccRecordsFetched){
                this.boolWiredFuncExecuted=true;
                this.validateTabVisibility();
            }
        } else {
            //do nothing
        }
    }

    @wire(getRecord, {
        recordId: '$recordId',
        fields: fields
    }) wireuser({
        error,
        data
    }) {
        if (error) {
            this.error = error;
        } else if (data) {
            this.objGlobalParams.objAccRecords=data.fields;
            this.boolAccRecordsFetched=true;
            if(this.boolProfileFetched && this.boolAccRecordsFetched){
                this.boolWiredFuncExecuted=true;
                this.validateTabVisibility();
            }
        } else {
            //do nothing
        }
    }

    //Variables
    boolShowCaseNotesModal = false;
    boolShowTabComponent = false;
    strFacetsTaskId = '';
    boolSpinner = false;
    @track boolSafeModeEnabled=false;

    @track boolShowSRTabComponent=false;
    @track boolShowTMGCallTabComponent=false;
    @track boolShowMagellanHistTabComponent=false; //NT: CEAS-81132
    @track boolShowSecureMessageTabComponent=false;
    @track boolShowSMSTextMessageTabComponent = false;
    @track boolShowCasFeedbackTabComponent =false;
    @track boolShowCaseTabComponent = false;
    @track boolShowInteractionsTabComponent = false;

    handleErrors(error) {
        this.objError = error;
    }

    connectedCallback() {
        try {
            this.label.HideSiebelTab_ACE = this.label.HideSiebelTab_ACE.toLowerCase() === 'true';
            this.fetchTabData();
        } catch(error) {
            this.handleErrors(error);
        }
    }


    disconnectedCallback() {
        const strTabId = this.objTabData.tabId;
        if (BaseLWC.stringIsNotBlank(this.label.lblEnableVPSTabSpecificEvents_ACE) && this.label.lblEnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {                        
            window.removeEventListener('PlanSummaryChangeEvent_' + this.strBaseTabId, this.objPlanSummaryListener, false);
        } else {
        window.removeEventListener('PlanSummaryChangeEvent', this.objPlanSummaryListener, false);
        }
        if (this.objGlobalParams.boolProducer) {
            const strProducerEvent = 'ProviderSummaryEvent_' + strTabId;
            window.removeEventListener(strProducerEvent, this.objProducerSummaryListener, false);
        }
        if (this.objGlobalParams.boolAccount) {
            const strAccountEvent = 'AccountSummaryEvent_' + strTabId;
            window.removeEventListener(strAccountEvent, this.objAccountSummaryListener, false);
        }
        window.removeEventListener('AllPlanSummaryEvent', this.objAllPlanSummaryListener, false);

        const strPlanSummaryEvent = 'PlanSummaryInteractionEvent_' + strTabId;
        window.removeEventListener(strPlanSummaryEvent, this.objPlanSummaryLocalStorageEventHandler, false);

        const strSafeModeModalEventName = 'SafeModeModalEventOnTab_ACE_' + strTabId;
        window.removeEventListener(strSafeModeModalEventName, this.objSafeModeSummaryListener, false);

        const strSafeModeModalGenericEventName = 'SafeModeModalHCDEvent_ACE';
        window.removeEventListener(strSafeModeModalGenericEventName, this.objSafeModeUtilityGenericListener, false);
        //CEAS-75947
        if (BaseLWC.stringIsNotBlank(this.label.lblEnableVPSTabSpecificEvents_ACE) && this.label.lblEnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {      
            window.removeEventListener('PlanChangedCustomEvent_' + this.strBaseTabId, this.objPlanSummaryChangeCustomEventListener, false);
        } else {
        window.removeEventListener('PlanChangedCustomEvent', this.objPlanSummaryChangeCustomEventListener, false);
        }
    }

    handleActive() {
        //Do nothing
    }

    validateTabVisibility=()=> {
        if(this.boolWiredFuncExecuted){
            try {
                this.boolSpinner = false;
                this.handleTabVisibility();
            } catch(error) {
               // Do nothing
            }
        }
    }

    handleTabVisibility=()=>{
        if(!(this.objTabData && this.objGlobalParams)){
            return;
        }
        this.boolShowCaseTabComponent = true;
        this.boolShowInteractionsTabComponent = true;
        let strLOB = '';
        //CEAS-80066
        let strCorpCode = this.objGlobalParams.strCorpCode != undefined ? this.objGlobalParams.strCorpCode : '';
        if (this.objGlobalParams.strLOB) {
            strLOB = this.objGlobalParams.strLOB.toUpperCase();
        } else if (this.objGlobalParams.objAccRecords.TempMemberLOB_ACE__c.value) {
            strLOB = this.objGlobalParams.objAccRecords.TempMemberLOB_ACE__c.value.toUpperCase();
        } else {
            strLOB = '';
        }
        const lstShowProfiles=['Supervisor', 'Specialist'];        
        const lstCASVisibilityProfiles =this.label.CasfeedbackUserProfileId_ACE.split(',');
        if(this.objGlobalParams.boolProspectMember && strLOB === 'GOVERNMENT-MEDICARE SUPPLEMENTAL') {
            this.boolShowCasFeedbackTabComponent = lstShowProfiles.includes(this.strProfileName);
        } else {
            if((strLOB==='GOVERNMENT-MEDICARE' || strLOB === 'GOVERNMENT-MEDICARE SUPPLEMENTAL') && !this.objGlobalParams.boolProspectAccount){
                this.boolShowCasFeedbackTabComponent = lstShowProfiles.includes(this.strProfileName);
            }else{
                this.boolShowCasFeedbackTabComponent = lstCASVisibilityProfiles.includes(this.strProfileName);
            }
            if(this.objGlobalParams.boolProspectMember==='true'){
                if(lstShowProfiles.includes(this.strProfileName)){
                    this.boolShowCasFeedbackTabComponent=true;
                }else{
                    this.boolShowCasFeedbackTabComponent=false;
                }
            }
            //Visibility for Siebel
            if((this.objGlobalParams.boolProspectAccount || this.objGlobalParams.boolIsOKM || strLOB.toUpperCase() === 'GOVERNMENT-MEDICARE') ||
                (this.objGlobalParams.objAccRecords &&
                    this.objGlobalParams.objAccRecords.TempMemberLOB_ACE__c &&
                    typeof this.objGlobalParams.objAccRecords.TempMemberLOB_ACE__c.value ==='string' &&
                    this.objGlobalParams.objAccRecords.TempMemberLOB_ACE__c.value.toUpperCase().includes('GOVERNMENT') &&
                    this.objGlobalParams.objAccRecords.TempMemberLOB_ACE__c.value.toUpperCase() !== 'GOVERNMENT-MEDICARE SUPPLEMENTAL' )){
                this.boolShowSRTabComponent=false;
                this.boolLoadSRTabComponent=false;

            }else{
                this.boolShowSRTabComponent=true;
                if(this.objGlobalParams.boolProducer || this.objGlobalParams.boolAccount || this.objGlobalParams.boolBlueCardOOS || this.objGlobalParams.boolFEPOOS || this.objGlobalParams.boolProspectMember){
                this.boolLoadSRTabComponent=true;
            }
            }
            //CEAS-80066
            if(strLOB != undefined && strLOB != null){
                if((strCorpCode === 'TX1' || strCorpCode === 'IL1') && strLOB.toUpperCase() === 'GOVERNMENT-MEDICAID'){ //NT: CEAS-81132
                    this.boolShowTMGCallTabComponent = true;
                    if (strCorpCode === 'TX1') { //NT: CEAS-81132
                        this.boolShowMagellanHistTabComponent = true;
                    } else if (strCorpCode === 'IL1') {
                        //NT: CEAS-81132 - IL Medicaid Disable Logic 2 years after ACE activation
                        this.boolShowTMGCallTabComponent = (new Date() < new Date(this.label.TMGCallHistory_DisableTabDateILM_ACE));
                    }
                }else{
                     this.boolShowTMGCallTabComponent = (strLOB.toUpperCase() === 'GOVERNMENT-MEDICARE' && (new Date() < new Date(this.label.TMGCallHistory_DisableTabDate_ACE))) ||  (this.objGlobalParams.boolProspectMember && strLOB.includes('GOVERNMENT-MEDICAID'));
                     this.boolShowMagellanHistTabComponent = this.boolShowTMGCallTabComponent;
                }
                 this.boolShowSecureMessageTabComponent = !(this.objGlobalParams.boolProducer || this.objGlobalParams.boolAccount || this.objGlobalParams.boolProspectAccount || (this.objGlobalParams.boolProspectMember && strLOB.includes('GOVERNMENT-MEDICARE')) || (this.objGlobalParams.boolProspectMember && strLOB.includes('GOVERNMENT-MEDICAID')));
                this.boolShowSMSTextMessageTabComponent = (!strLOB.includes('GOVERNMENT-MEDICARE') && this.objGlobalParams.StrAge>18 && (this.objGlobalParams.lstCoverageCodes.includes('HAS') || this.objGlobalParams.lstCoverageCodes.includes('BVA')));
            }
        }

    }
    fetchTabData = () => {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objTabData => {
                this.objTabData = JSON.parse(JSON.stringify(objTabData));

                this.strBaseTabId = this.objTabData.tabId;
                this.strBaseTabURL = this.objTabData.url;
                this.initializeAfterWorkspaceAPI();
                this.handlePlanSummaryLocalStorageListener();
                this.validateTabVisibility();

            }).catch(() => {
                //Do nothing
            });
        }
    }

    objPlanSummaryLocalStorageEventHandler = (objListenerEvent)=> {
        let objLocalStorageData;
        if (objListenerEvent !== undefined && objListenerEvent !== null && typeof objListenerEvent.detail === 'string') {
            try {
                objLocalStorageData = JSON.parse(objListenerEvent.detail);
            } catch (objException) {
                // Do nothing
            }
        }
        this.objGlobalParams.objLocalStorageData=objLocalStorageData;
    }

    handlePlanSummaryLocalStorageListener = () => {
        //Checking for Aura to LWC Sibling Listener Event
        const strPlanSummaryEvent = 'PlanSummaryInteractionEvent_' + this.objTabData.tabId;
        window.addEventListener(strPlanSummaryEvent, this.objPlanSummaryLocalStorageEventHandler, false);
    }

    initializeAfterWorkspaceAPI = () => {
        this.boolSpinner = true;
        const strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.strBaseTabURL);
        const objUrl = new URL(strDecodedURL);
        const boolProducer = objUrl.searchParams.has('boolProducer') && objUrl.searchParams.get('boolProducer') === 'true';
        const boolAccount = objUrl.searchParams.has('boolAccount') && objUrl.searchParams.get('boolAccount') === 'true';
        const boolFEPOOS = objUrl.searchParams.has('isFEPOOS') && objUrl.searchParams.get('isFEPOOS') === 'true';
        const boolBlueCardOOS = objUrl.searchParams.has('isBlueCardOOS') && objUrl.searchParams.get('isBlueCardOOS') === 'true';
        const boolProspectMember = objUrl.searchParams.has("boolProspectMember") && objUrl.searchParams.get("boolProspectMember") === 'true';
        const strCmid = objUrl.searchParams.get('Cmid');
        const strGroupName = objUrl.searchParams.get('groupName');
        const strSubscriberId = objUrl.searchParams.get('subscriberId');
        const strAccountIdURL = objUrl.searchParams.get('AccountId');
        const strCorpCode = objUrl.searchParams.get('corpCode');
        let strCaseIntent = objUrl.searchParams.get('strIntent');
        if (strCaseIntent) {
            strCaseIntent = strCaseIntent.replace("null", "");
        }
        //Set Global Booleans from URL parameters
        this.objGlobalParams.boolAccount = boolAccount;
        this.objGlobalParams.boolProducer = boolProducer;
        this.objGlobalParams.boolFEPOOS = boolFEPOOS;
        this.objGlobalParams.boolBlueCardOOS = boolBlueCardOOS;
        this.objGlobalParams.boolProspectMember = boolProspectMember;
        this.objGlobalParams.strCmid = strCmid;
        this.objGlobalParams.strGroupName = strGroupName;
        this.objGlobalParams.strSubscriberId = strSubscriberId;
        this.objGlobalParams.strCorpCode = strCorpCode;
        this.objGlobalParams.strCaseIntentToSend = strCaseIntent;
        this.objGlobalParams.strAccountId = strAccountIdURL;
        //DO INIT START
        const boolProspectAccount = objUrl.searchParams.get("boolProspectAccount") === 'true';
        this.objGlobalParams.boolProspectAccount = boolProspectAccount;
        const strUrlMemberId = objUrl.searchParams.get("mid");
        this.objGlobalParams.strUrlMemberId = strUrlMemberId;

        let boolIsOKM = false;
        if (objUrl.searchParams.get('planId') !== undefined && objUrl.searchParams.get('planId') !== null) {
            const strGroupNumber = objUrl.searchParams.get('groupNumber');
            boolIsOKM = (strGroupNumber === OKMGroupNumber_ACE);
        }
        this.objGlobalParams.boolIsOKM = boolIsOKM;

        const boolIsLineOfBusinessFEP = objUrl.searchParams.has('isLineOfBusinessFEP') === true && objUrl.searchParams.get('isLineOfBusinessFEP') === 'true';
        this.objGlobalParams.boolIsLineOfBusinessFEP = boolIsLineOfBusinessFEP;

        const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + this.strAccountIdForCTI;
        let strInteractionLogIdForPlanSummary = BaseLWC.helperBaseGetUrlParameters('strInteractionLogId');

        // If the strInteraction is null or undefined, check if its present in LS.
        if (BaseLWC.isUndefinedOrNullOrBlank(strInteractionLogIdForPlanSummary)) {
            strInteractionLogIdForPlanSummary = BaseLWC.helperBaseGetItem(localStorageKey);
        }
        this.objGlobalParams.strInteractionLogIdForPlanSummary = strInteractionLogIdForPlanSummary;

        //DO INIT END

        if (!(boolProducer || boolAccount)) {
            this.setPlanSummaryChangeCustomEventListener();
            this.listenToPlanSummaryEvent();
        } else {
            this.listenToProducerSummaryEvent();
        }
        this.listenToAllPlanDetailsEvent();

        this.safeModeUtilityComponentListenerForCaseCard();
        this.safeModeUtilityGenericComponentListenerForCaseCard();


        if (boolFEPOOS || boolBlueCardOOS || boolProspectMember) {
            this.fetchProspectDetails();
        }

    }
    validateData(data) {
        if (data) {
            return data;
        } 
        return '';
    }
    fetchProspectDetails() {
        const idAccount = this.objTabData.recordId;
        if (idAccount !== undefined) {
            fetchBluecardFepMemberDetails({
                idRecordId: idAccount
            }).then(result => {
                try {
                    const objResult = JSON.parse(result);
                    if (objResult) {
                        if (objResult.RecordType.DeveloperName === 'BlueCard_Member_ACE' || objResult.RecordType.DeveloperName === 'Out_of_State_FEP_Member' || objResult.RecordType.DeveloperName==='Retail_Applicant_ACE' ||
                            (objResult.RecordType.DeveloperName === 'ProspectMember_ACE' && (objResult.TempMemberLOB_ACE__c === 'GMS' || objResult.TempMemberLOB_ACE__c === 'FEP' || objResult.TempMemberLOB_ACE__c === 'GOVERNMENT-MEDICARE'))) {
                            //CEAS-63718
                            this.objGlobalParams.strSubscriberId = this.validateData(objResult.SubscriberId_ACE__c);
                            this.objGlobalParams.strGroupName = this.validateData(objResult.GroupNumber_ACE__c);
                            this.objGlobalParams.strCorpCode = this.validateData(objResult.Corporate_Entity_Code_ACE__c);
                            //CEAS-60598
                            this.objGlobalParams.strPatientFirstName = this.validateData(objResult.FirstName_ACE__c);
                            this.objGlobalParams.strPatientLastName = this.validateData(objResult.LastName_ACE__c);
                            this.objGlobalParams.strPrefix = this.validateData(objResult.Prefix_ACE__c);
                            this.objGlobalParams.strPatientDOB = this.validateData(objResult.BirthDate_ACE__c);
                            this.boolSpinner =false;
                            this.validateTabVisibility();
                        }
                    }
                } catch (exception) {
                    this.handleErrors(exception);
                }
            }).catch((error) => {
                this.handleErrors(error);
            })

        }
    }

    objSafeModeSummaryListener = (objEventData) => {
        const strSafeModeModalEventDestinationId = 'SafeModeModalEventIdOnTab_ACE_' + this.objTabData.strTabId
        if (objEventData !== null && objEventData.detail !== null && typeof objEventData.detail === 'string') {
            const strParsedData = JSON.parse(objEventData.detail);
            if (strParsedData.strIdDestination && strParsedData.strIdDestination === strSafeModeModalEventDestinationId) {
                this.boolSafeModeEnabled = strParsedData.boolSafeModeEnabled;
            }
        }
    }

    safeModeUtilityComponentListenerForCaseCard() {
        try {
            const strSafeModeModalEventName = 'SafeModeModalEventOnTab_ACE_' + this.objTabData.strTabId;
            window.addEventListener(strSafeModeModalEventName, this.objSafeModeSummaryListener, false);
        } catch (objException) {
            this.handleErrors(objException);
        }
    }

    objSafeModeUtilityGenericListener=(objEventData)=>{
        const strParsedData = JSON.parse(objEventData.detail);
        const strSafeModeModalEventGenericDestinationId = 'SafeModeModalHCDEventId_ACE';
        if (strParsedData.strIdDestination && strParsedData.strIdDestination === strSafeModeModalEventGenericDestinationId) {
            this.boolSafeModeEnabled=strParsedData.objMessage;
        }
    }

    safeModeUtilityGenericComponentListenerForCaseCard() {
        try{
            const strSafeModeModalGenericEventName = 'SafeModeModalHCDEvent_ACE';
            window.addEventListener(strSafeModeModalGenericEventName, this.objSafeModeUtilityGenericListener, false);
        } catch(e){
            this.handleErrors(e);
        }

    }
    objPlanSummaryChangeCustomEventListener = (objEvent) => {

        if (objEvent && objEvent.detail && typeof objEvent.detail === 'string') {
            try {
                const strParsedData = JSON.parse(objEvent.detail);
                if (strParsedData === undefined || strParsedData === null) {
                    return;
                }

                if (strParsedData.strIdDestination && strParsedData.strIdDestination === "PlanChangedDetails_PlanSummary_ACE" &&
                    strParsedData.objParameters && strParsedData.objParameters.strParentTabId && strParsedData.objParameters.strParentTabId === this.objTabData.tabId &&
                    strParsedData.objParameters.objMessage) {
                    const objMessage = strParsedData.objParameters.objMessage;
                    if (!objMessage.strCorporationCode && !objMessage.strSubscriberId && !objMessage.strGroupNumber) {
                        return;
                    }

                    this.getPlanSummaryDetails(objMessage);
                }
            } catch (objException) {
                this.handleErrors(objException);
            }
        }
    }
    setPlanSummaryChangeCustomEventListener() {
        //CEAS-75947
        if (BaseLWC.stringIsNotBlank(this.label.lblEnableVPSTabSpecificEvents_ACE) && this.label.lblEnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {      
            window.addEventListener('PlanChangedCustomEvent_' + this.strBaseTabId, this.objPlanSummaryChangeCustomEventListener, false);
        } else {
        window.addEventListener('PlanChangedCustomEvent', this.objPlanSummaryChangeCustomEventListener, false);
    }
    }
    objPlanSummaryListener = (objEvent) => {

        if (objEvent && objEvent.detail && typeof objEvent.detail === 'string') {
            let strParsedData;
            try {
                strParsedData = JSON.parse(objEvent.detail);
                if (strParsedData === undefined || strParsedData === null) {
                    return;
                }

                if (strParsedData.strIdDestination && strParsedData.strIdDestination === "PlanDetails_PlanSummary_ACE" &&
                    strParsedData.objParameters && strParsedData.objParameters.strParentTabId && strParsedData.objParameters.strParentTabId === this.strBaseTabId &&
                    strParsedData.objParameters.objMessage) {
                    const objMessage = strParsedData.objParameters.objMessage;
                    if (!objMessage.strCorporationCode && !objMessage.strSubscriberId && !objMessage.strGroupNumber) {
                        return;
                    }

                    this.getPlanSummaryDetails(objMessage);
                    if (BaseLWC.stringIsNotBlank(this.label.lblEnableVPSTabSpecificEvents_ACE) && this.label.lblEnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {                        
                        window.removeEventListener('PlanSummaryChangeEvent_' + this.strBaseTabId, this.objPlanSummaryListener, false);
                    } else {
                    window.removeEventListener('PlanSummaryChangeEvent', this.objPlanSummaryListener, false);
                }
                }
                this.boolSpinner = false;
                this.handleTabVisibility();
            } catch (objException) {
                this.handleErrors(objException);
            }
        }
    }
    getPlanSummaryDetails(objMessage) {
        if (objMessage.strMemberId) {
            //CEAS-75947
            this.boolPlanListned = true;
            const Age = new Date().getFullYear() - new Date(objMessage.strdateOfBirth).getFullYear();
            this.objGlobalParams.strCorpCode = objMessage.strCorporationCode;
            this.objGlobalParams.strSubscriberId = objMessage.strSubscriberId;
            //CEAS-74787
            this.objGlobalParams.strFacetsGroupId = objMessage.strFacetsGroupId;
            this.objGlobalParams.strGroupName = objMessage.strGroupNumber;
            this.objGlobalParams.strCmid = objMessage.strClientMemberId;
            this.objGlobalParams.strLOB = objMessage.strAceLineOfBusiness;
            this.objGlobalParams.StrAge = Age;
            const boolIsFEPPolicy = objMessage.boolIsLineOfBusinessFEP;
            const strLOB = this.objGlobalParams.strLOB;
            const boolShowSM = ((!boolIsFEPPolicy && Age > 18) || boolIsFEPPolicy || (Age <= 18 && strLOB && (strLOB.toUpperCase() === 'GMS' || strLOB.toUpperCase() === 'RETAIL')));
            const boolShowMinor = (Age <= 18 && strLOB && (strLOB.toUpperCase() === 'GMS' || strLOB.toUpperCase() === 'RETAIL'));
            this.objGlobalParams.boolShowSM = boolShowSM;
            this.objGlobalParams.boolShowMinor = boolShowMinor;
            const lstCoverageCodes=objMessage.coverageCodesList.map(el => el.strCode);
            this.objGlobalParams.lstCoverageCodes=lstCoverageCodes;
            this.objGlobalParams.planData=objMessage;

            this.boolSpinner = false;
            this.handleTabVisibility();
        }
    }

    listenToPlanSummaryEvent() {
        //CEAS-71659 Removing setTimeout and moving the listner above the trigger callout.
        //CEAS-75947 Added logic for the baseTabId in the event name.
        if (BaseLWC.stringIsNotBlank(this.label.lblEnableVPSTabSpecificEvents_ACE) && this.label.lblEnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
            window.addEventListener('PlanSummaryChangeEvent_' + this.strBaseTabId, this.objPlanSummaryListener, false);
        } else {
        window.addEventListener('PlanSummaryChangeEvent', this.objPlanSummaryListener, false);
        }
        if (BaseLWC.stringIsNotBlank(this.label.lblEnableTimeout_ACE) && this.label.lblEnableTimeout_ACE.toLowerCase() === 'true' && !this.boolPlanListned) {
            if (BaseLWC.stringIsNotBlank(this.label.lblEnableVPSTabSpecificEvents_ACE) && this.label.lblEnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                BaseLWC.helperBasePostTabIdMessageCustomEvents('TriggerPlanSummaryData_' + this.strBaseTabId, null, null, 'PlanCardDetails_ACE', this.strBaseTabId).catch(() => {});
            } else {
                BaseLWC.helperBasePostTabIdMessageCustomEvents('TriggerPlanSummaryData', null, null, 'PlanCardDetails_ACE', this.strBaseTabId).catch(() => {});
            }
        }
    }

    objProducerSummaryListener = (objEvent) => {

        if (objEvent && objEvent.detail && typeof objEvent.detail === 'string') {
            let strParsedData;
            try {
                strParsedData = JSON.parse(objEvent.detail);

                if (strParsedData === undefined || strParsedData === null) {
                    return;
                }

                this.objGlobalParams.strPhoneNumber = strParsedData.strMessage.objProducerSummaryData.workPhone;
                this.objGlobalParams.strGroupNumber = strParsedData.strMessage.objProducerSummaryData.producerState;
                this.objGlobalParams.strLOB = strParsedData.strMessage.strLineOfBusiness;
                this.boolSpinner = false;
                this.handleTabVisibility();
                //Fetch data from View plan summary component.
                if (strParsedData.strIdDestination && strParsedData.strIdDestination === "ProviderSummaryDetail_ACE") {
                    window.removeEventListener(`ProviderSummaryEvent_${this.objTabData.tabId}`, this.objProducerSummaryListener, false);
                }
            } catch (objException) {
                // Do Nothing
            }
        }
    }

    objAccountSummaryListener = (objEvent) => {

        if (objEvent && objEvent.detail && typeof objEvent.detail === 'string') {
            let strParsedData;
            try {
                strParsedData = JSON.parse(objEvent.detail);

                if (strParsedData === undefined || strParsedData === null) {
                    return;
                }
                this.objGlobalParams.strAccountNumber = strParsedData.strMessage.strAccountNumber;
                this.objGlobalParams.strCorpCode= strParsedData.strMessage.strCorporationCode;
                this.objGlobalParams.strLOB = strParsedData.strMessage.strLineOfBusiness;
                this.boolSpinner=false;
                this.handleTabVisibility();

                //Fetch data from View plan summary component.
                if (strParsedData.strIdDestination && strParsedData.strIdDestination === "ProviderSummaryDetail_ACE") {
                    window.removeEventListener(`AccountSummaryEvent_${this.objTabData.tabId}`, this.objAccountSummaryListener, false);
                }
            } catch (objException) {
                // Do Nothing
            }
        }
    }

    listenToProducerSummaryEvent() {
        if (this.objGlobalParams.boolProducer) {
            const strProducerEvent = 'ProviderSummaryEvent_' + this.objTabData.tabId;
            window.addEventListener(strProducerEvent, this.objProducerSummaryListener, false);
        }
        if (this.objGlobalParams.boolAccount) {
            const strAccountEvent = 'AccountSummaryEvent_' + this.objTabData.tabId;
            window.addEventListener(strAccountEvent, this.objAccountSummaryListener, false);
        }
        //Adding SetTimeout as the Custom event is triggered when Plan Summary Component is ready to listen
            BaseLWC.helperBasePostTabIdMessageCustomEvents(`TriggerProviderSummaryData_${this.objTabData.tabId}`, null, null, 'ProviderSummaryDetail_ACE', this.objTabData.tabId).catch(() => {
            });

    }
    objAllPlanSummaryListener = (objEvents) => {

        if (objEvents !== null && objEvents.detail !== null && typeof objEvents.detail === 'string') {
            const strParsedData = JSON.parse(objEvents.detail);

            if (strParsedData === undefined || strParsedData === null) {
                return;
            }

            //Fetch data from View plan summary component.
            if (strParsedData.strIdDestination && strParsedData.strIdDestination === "PlanCardAllPlanDetails_ACE" &&
                strParsedData.objParameters && strParsedData.objParameters.strParentTabId &&
                strParsedData.objParameters.strParentTabId === this.objTabData.tabId) {
                let objSRRequestParameters = {};
                const lstObjSRRequestParameters = [];
                const setSubscriberIds = [];
                const mapPlanDetails = strParsedData.objParameters.objMessage.mapPlanDetails;

                //Iterate over plans to make list object.
                if (mapPlanDetails) {
                    Object.keys(mapPlanDetails).forEach(function(strKey) {
                        if (mapPlanDetails[strKey].objViewEmployerGroupWrapper.boolUserHasAccess) {
                            if (!setSubscriberIds.includes(mapPlanDetails[strKey].strSubscriberId + mapPlanDetails[strKey].strGroupNumber)) {
                                setSubscriberIds.push(mapPlanDetails[strKey].strSubscriberId + mapPlanDetails[strKey].strGroupNumber);
                                objSRRequestParameters = {
                                    subscriberId: mapPlanDetails[strKey].strSubscriberId,
                                    groupNumber: mapPlanDetails[strKey].strGroupNumber.padStart(9, '0'),
                                    srNumber: ""
                                };
                                lstObjSRRequestParameters.push(objSRRequestParameters);
                            }
                        }
                    });
                    this.lstObjSRRequestParameters=[...lstObjSRRequestParameters];
                    this.boolLoadSRTabComponent=true;
                    window.removeEventListener("AllPlanSummaryEvent", this.objAllPlanSummaryListener, false);
                }
            }
        }
    }
    listenToAllPlanDetailsEvent(){
        window.addEventListener('AllPlanSummaryEvent', this.objAllPlanSummaryListener, false);
    }

}