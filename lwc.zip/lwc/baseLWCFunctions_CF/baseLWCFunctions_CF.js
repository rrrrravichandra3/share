/**
 * JS helper for Base Reusable Functions.
 * <p /><p />
 * @author Prateek Jain.
 */
import BaseLightningComponent_Error_ACE from '@salesforce/label/c.BaseLightningComponent_Error_ACE';
import EnableIntervals_ACE from '@salesforce/label/c.EnableIntervals_ACE';
import NumberOfIntervals_ACE from '@salesforce/label/c.NumberOfIntervals_ACE';
import CaptureErrorLogs_ACE from '@salesforce/label/c.CaptureErrorLogs_ACE';

import captureBaseInErrorLogsFunction from '@salesforce/apex/ErrorLogInterval_ACE.captureBaseInErrorLogs';

const label = { BaseLightningComponent_Error_ACE, EnableIntervals_ACE, NumberOfIntervals_ACE, CaptureErrorLogs_ACE };
/**
 * Used to Check Blank String.
 * @param strString: String Data.
 * @return Boolean.
 */
export const stringIsNotBlank = (strString) => {
    if (!(typeof strString === 'string')){
        if(strString || strString === false){
            //NT: Convert to String
            strString = JSON.stringify(strString);
        } else {
            //NT: Null/Undefined
            return false;
        }
    }
    return strString !== undefined && strString !== null && strString !== '' && strString.trim() !== '';
}

/**
 * Used to Check Empty Array.
 * @param lstInputArray: Array Data.
 * @return Boolean.
 */
export const arrayIsNotEmpty = (lstInputArray) => {
    return lstInputArray !== undefined && lstInputArray !== null && Array.isArray(lstInputArray) && lstInputArray.length > 0
}

/**
 * Used to Check Undefined or null.
 * @param strVariable: Variable Data.
 * @return Boolean.
 */
export const isNotUndefinedOrNull = (strVariable) => {
    return strVariable !== undefined && strVariable !== null && strVariable !== '';
}

/**
 * Used to Check Undefined or null.
 * @param strVariable: Variable Data.
 * @return Boolean.
 */
export const isUndefinedOrNullOrBlank = (strVariable) => {
    return strVariable === undefined || strVariable === null || strVariable === '';
}

/**
 * Used to fetch URL Parameters from URL.
 * @param strParam: strParam to be fetched.
 * @param strURL: URl from which param to be Fetched.
 * @return Param Data.
 */
export const helperBaseGetUrlParameters = (strParam, strURL) => {

    //variables
    const listParam = strParam.split(",");
    const strAtobDecodedURL = helperBaseDecodeUrl(strURL);
    const strUrlDecoded = decodeURIComponent(strAtobDecodedURL);
    const lstDecodedParams = strUrlDecoded.split('?');
    let strParamValue = '';

    //Used to Decode the URL parameter.
    for (let letLoopVariable = 0; letLoopVariable < lstDecodedParams.length; letLoopVariable++) {
        const strURLVariables = lstDecodedParams[letLoopVariable].split('&');
        let strParameterName, letInnerLoop;
        for (letInnerLoop = 0; letInnerLoop < strURLVariables.length; letInnerLoop++) {
            strParameterName = strURLVariables[letInnerLoop].split('=');
            for (let i = 0; i < listParam.length; i++) {
                if (strParameterName[0] === listParam[i]) {
                    if (strParameterName[1] === undefined) {

                        //do nothing
                    } else {
                        strParamValue = decodeURIComponent(strParameterName[1]);
                    }
                }
            }
        }
    }
    return strParamValue;
}

/**
 * Used to Decode URL.
 * @param strURL: URL to be decoded.
 * @return Decoded Url.
 */
export const helperBaseDecodeUrl = (strUrl) => {
    let strLocalURL = helperGetBaseURL(strUrl);
    try {
        strLocalURL = decodeURIComponent(strUrl).replace(/&0.source=alohaHeader/g, '');
        const strDecodedURLFromSalesforce = decodeURIComponent(strLocalURL);
        const strSplitedURL = strDecodedURLFromSalesforce.split('?');
        if (strDecodedURLFromSalesforce.split('?').length > 2) {
            const strParamsSplitted = strSplitedURL[1].split('&ws');
            if (strSplitedURL[2][strSplitedURL[2].length - 1] === '=') {
                if (strSplitedURL[2].startsWith('c__BaseURLParam')) {
                    strSplitedURL[2] = strSplitedURL[2].substring(16, strSplitedURL[2].length).replace(new RegExp("\\=", "g"), '');
                } else {
                    strSplitedURL[2] = strSplitedURL[2].replace(new RegExp("\\=", "g"), '');
                }
            }
            if (strParamsSplitted[0][strParamsSplitted[0].length - 1] === '=') {
                if (strParamsSplitted[0].startsWith('c__BaseURLParam')) {
                    strParamsSplitted[0] = strParamsSplitted[0].substring(16, strParamsSplitted[0].length).replace(new RegExp("\\=", "g"), '');
                } else {
                    strParamsSplitted[0] = strParamsSplitted[0].replace(new RegExp("\\=", "g"), '');
                }
            }
            try {
                return strSplitedURL[0] + '?' + decodeURIComponent(escape(window.atob(strParamsSplitted[0]))) + '&ws' + strParamsSplitted[1] + '?' +
                    decodeURIComponent(escape(window.atob(strSplitedURL[2])))
            } catch (objError) {
                let urlToBeReturned = null;
                try {
                    urlToBeReturned = strSplitedURL[0] + '?' + strParamsSplitted[0] + '&ws' + strParamsSplitted[1] + '?' +
                        decodeURIComponent(escape(window.atob(strSplitedURL[2])));
                } catch (objErrorInternal) {
                    const newEncodedURL = new URL(strDecodedURLFromSalesforce);
                    try {
                        if (newEncodedURL.searchParams.get('c__BaseURLParam') !== undefined && newEncodedURL.searchParams.get('c__BaseURLParam') !== null) {
                            const decodeURIComponentToBePassed = decodeURIComponent(escape(window.atob(newEncodedURL.searchParams.get('c__BaseURLParam'))));
                            if (strParamsSplitted[1]) {
                                const decodingExtraParams = decodeURIComponent(escape(window.atob(strSplitedURL[2].split('c__BaseURLParam=')[1])));
                                urlToBeReturned = strSplitedURL[0] + '?' + '&ws' + strParamsSplitted[1] + '&' + decodeURIComponentToBePassed + '&' + decodingExtraParams;
                            } else {
                                urlToBeReturned = strSplitedURL[0] + '?' + strParamsSplitted[0] + '&ws' + '?' + decodeURIComponentToBePassed;
                            }
                        } else {
                            const decodedNewParams = newEncodedURL.searchParams.get('ws').split('c__BaseURLParam=')[1];
                            const decodeURIComponentToBePassed = decodeURIComponent(escape(window.atob(decodedNewParams)));
                            if (strParamsSplitted[1]) {
                                urlToBeReturned = strSplitedURL[0] + '?' + strParamsSplitted[0] + '&ws' + strParamsSplitted[1] + '?' + decodeURIComponentToBePassed;
                            } else {
                                urlToBeReturned = strSplitedURL[0] + '?' + strParamsSplitted[0] + '&ws' + '?' + decodeURIComponentToBePassed;
                            }
                        }
                    } catch (objFinalError) {
                        let uidOrWs = null;
                        if (newEncodedURL.searchParams.get('uid')) {
                            uidOrWs = newEncodedURL.searchParams.get('uid');
                        } else {
                            uidOrWs = newEncodedURL.searchParams.get('ws')
                        }
                        const decodedUrlWithUID = uidOrWs.split('c__BaseURLParam')[1];
                        const decodeURIComponentToBePassedURI = window.atob(decodedUrlWithUID.replace(new RegExp("\\=", "g"), ''))
                        if (strParamsSplitted[1] !== undefined) {
                            urlToBeReturned = strSplitedURL[0] + '?' + '&ws' + strParamsSplitted[1] + '&' + decodeURIComponentToBePassedURI;
                        } else {
                            if (uidOrWs !== undefined && uidOrWs !== null && uidOrWs !== '') {
                                const wsparam = uidOrWs.split('?')[0];
                                urlToBeReturned = strSplitedURL[0] + '?' + '&ws=' + wsparam + '&' + strSplitedURL[1] + '&' + decodeURIComponentToBePassedURI;
                            } else {
                                urlToBeReturned = strSplitedURL[0] + '?' + '&' + strSplitedURL[1] + '&' + decodeURIComponentToBePassedURI;
                            }
                        }
                    }
                }

                return urlToBeReturned;
            }

        } else {
            if (strSplitedURL[1][strSplitedURL[1].length - 1] === '=') {
                strSplitedURL[1] = strSplitedURL[1].replace(new RegExp("\\=", "g"), '')
            }
            let urlToBeReturned = null;
            try {
                urlToBeReturned = strSplitedURL[0] + '?' + decodeURIComponent(escape(window.atob(strSplitedURL[1])));
            } catch (objError) {
                const newEncodedURL = new URL(strDecodedURLFromSalesforce);
                const decodedNewParams = newEncodedURL.searchParams.get('c__BaseURLParam');
                const strWsParam = newEncodedURL.searchParams.get('ws');
                const decodeURIComponentToBePassed = decodeURIComponent(escape(window.atob(decodedNewParams)));
                if (strWsParam !== null && strWsParam !== undefined && strWsParam !== '') {
                    urlToBeReturned = strSplitedURL[0] + '?' + decodeURIComponentToBePassed + '&ws=' + strWsParam;
                } else {
                    urlToBeReturned = strSplitedURL[0] + '?' + decodeURIComponentToBePassed;
                }
            }
            return urlToBeReturned;
        }
    } catch (objError) {
        return strLocalURL;
    }
}

/**
 * Used to form and get url.
 * @param strurl: URL to be modified.
 * @return Url.
 */
const helperGetBaseURL = (strurl) => {
    let objTempURL = null;
    try {
        objTempURL = new URL(strurl);
    } catch (exception) {
        //do nothing
    }
    const objURL = objTempURL;
    if (objURL !== null && objURL !== undefined && objURL.searchParams.get('c__BaseURLParam')) {
        return objURL.href + '/?' + objURL.searchParams.get('c__BaseURLParam');
    } else {
        return null;
    }
}

/**
 * Used to fire Custom Event.
 * @param strEventName: Custom Event Name.
 * @param strParameterToBeSent: Parameter to be sent.
 * @param strDestinationId: Destination Id.
 * @param boolRestrictTabSpecificEvent: To Restrict event to Primary Tab and its Subtab.
 * @param strTabId: Tab id to the Event Dynamic.
 */
export const fireCustomEvent = (strEventName, strParameterToBeSent, strDestinationId, boolRestrictTabSpecificEvent, strTabId) => {
    const objResponse = {
        strIdDestination: strDestinationId,
        strMessage: strParameterToBeSent,
        strTabId: strTabId
    };
    let strCustomEventName = strEventName;
    if (boolRestrictTabSpecificEvent) {
        strCustomEventName = strEventName + '_' + strTabId;
    }
    const objCustomEvent = new CustomEvent(strCustomEventName, {
        detail: JSON.stringify(objResponse)
    });
    window.dispatchEvent(objCustomEvent);
}

/**
 * Used to fire Native Custom Event.
 * @param strEventName: Custom Event Name.
 * @param objParameterToBeSent: Parameter to be sent.
 */
export const fireNativeCustomEvent = (strEventName, objParameterToBeSent, objInstance) => {
    const objCustomEvent = new CustomEvent(strEventName, {
        detail: JSON.stringify(objParameterToBeSent)
    });
    objInstance.dispatchEvent(objCustomEvent);
}

export const helperBasePostTabIdMessageCustomEvents = (objCustomEventName, idVfFrame, strParameterToBeSent, strIdDestination, strTabId) => {
    return new Promise((resolve, reject) => {
        if (strTabId !== null) {
            //Post Message
            if (idVfFrame !== null) {
                if (document.getElementById(idVfFrame)) {
                    //Message which needs to be posted.
                    const objVFFrame = document.getElementById(idVfFrame).contentWindow;

                    // Post message
                    const objResponse = {
                        strIdDestination: strIdDestination,
                        objParameters: {
                            strMessage: strParameterToBeSent,
                            strParentTabId: strTabId
                        }
                    };

                    // Here we create Custom Event and the dispatch the event
                    const objSubTabEvents = new CustomEvent(objCustomEventName, { detail: JSON.stringify(objResponse) });
                    objVFFrame.dispatchEvent(objSubTabEvents);
                }
            } else {
                //Post message Window
                const objResponse = {
                    strIdDestination: strIdDestination,
                    objParameters: {
                        objMessage: strParameterToBeSent,
                        strParentTabId: strTabId
                    }
                };

                // Here we create Custom Event and the dispatch the event
                const objSubTabEvents = new CustomEvent(objCustomEventName, { detail: JSON.stringify(objResponse) });
                window.dispatchEvent(objSubTabEvents);
            }
            resolve();
        } else {
            reject();
        }
    });
};


/**
 * Compare and fire the event with Primary Component Data only for SubTab Events.
 * @param objCommEvent: Event Data from SubTab.
 * @param strDestinationIdToBeCompared: Destination Id to be Compared.
 * @param strEventName: Custom Event Name.
 * @param strParameterToBeSent: Parameter to be sent.
 * @param strDestinationId: Destination Id.
 * @param boolRestrictTabSpecificEvent: To Restrict event to Primary Tab and its Subtab.
 * @param strTabId: Tab id to the Event Dynamic.
 */
export const sendComponentData = (objCommEvent, strDestinationIdToBeCompared, strEventName, strParameterToBeSent,
    strDestinationIdToBeSent, boolRestrictTabSpecificEvent, strTabId) => {
    if (isNotUndefinedOrNull(objCommEvent.detail) && typeof objCommEvent.detail === 'string') {
        const strResponseData = JSON.parse(objCommEvent.detail);
        if (isNotUndefinedOrNull(strResponseData.strIdDestination) &&
            strResponseData.strIdDestination === strDestinationIdToBeCompared) {
            fireCustomEvent(strEventName, strParameterToBeSent, strDestinationIdToBeSent,
                boolRestrictTabSpecificEvent, strTabId);
        }
    }
}

/**
 * fetch Component Data.
 * @param objCommEvent: Event Data Tab.
 * @param strDestinationIdToBeCompared: Destination Id to be Compared.
 * @param boolFetchOnlyMessage: Fetch Only Message Part.
 * @return Response Data.
 */
export const fetchComponentData = (objCommEvent, strDestinationIdToBeCompared, boolFetchOnlyMessage) => {
    if (isNotUndefinedOrNull(objCommEvent.detail) && typeof objCommEvent.detail === 'string') {
        const strResponseData = JSON.parse(objCommEvent.detail);
        if (isNotUndefinedOrNull(strResponseData.strIdDestination) &&
            strResponseData.strIdDestination === strDestinationIdToBeCompared) {
            if (boolFetchOnlyMessage === true && isNotUndefinedOrNull(strResponseData.strMessage)) {
                if (typeof strResponseData.strMessage === 'string') {
                    return JSON.parse(strResponseData.strMessage);
                } else {
                    return strResponseData.strMessage;
                }
            } else {
                return strResponseData;
            }
        } else {
            return null;
        }
    } else {
        return null;
    }
}

/**
 * Encode the URL Component
 *
 * @param strUrl URL to be encoded.
 * @returns The encoded URL.
 */
export const helperBaseEncodeUrl = (strUrl) => {
    const strUrlSplited = strUrl.split('?');
    //If condition added because of member search navigation issues via case search to Hipaa
    if (strUrlSplited.length === 3 && strUrlSplited[1].includes('ws=/lightning/r/Account/') && strUrlSplited[2].includes('strSource=memberSearch&strAccountIdForCaseSearch=')) {
        let strBaseParam = 'c__BaseURLParam=' + window.btoa(unescape(encodeURIComponent(strUrlSplited[2])));
        const strAccount = strUrlSplited[1].split('ws=')[1];
        const strAccountEncoded = 'ws=' + encodeURIComponent(strAccount + '?');

        if (strBaseParam.endsWith("=")) {
            strBaseParam = strBaseParam.substring(0, strBaseParam.length - 1);
            if (strBaseParam.endsWith("=")) {
                strBaseParam = strBaseParam.substring(0, strBaseParam.length - 1);
            }
        }
        return strUrlSplited[0] + '?' + strAccountEncoded + strBaseParam;
    } else {
        let strBaseParam = 'c__BaseURLParam=' + window.btoa(unescape(encodeURIComponent(strUrlSplited[1])));
        //Removing = & == as btoa adds them if they are required to pad the string out to the proper length
        if (strBaseParam.endsWith("=")) {
            strBaseParam = strBaseParam.substring(0, strBaseParam.length - 1);
            if (strBaseParam.endsWith("=")) {
                strBaseParam = strBaseParam.substring(0, strBaseParam.length - 1);
            }
        }
        return strUrlSplited[0] + '?' + strBaseParam;
    }
}

/**
 * Format Date to MM/DD/YYY
 *
 * @param strDate to be formatted.
 * @returns formatted Date.
 */
export const dateFormatterHelper = (strDate) => {
    let DateData = strDate;
    if (typeof strDate === 'string') {
        DateData = new Date(strDate).toISOString(); 
    }
    const dateCompos = DateData.split("-");
    const year = dateCompos[0];
    const month = dateCompos[1];
    const day = dateCompos[2].slice(0,2);
     return month.toString() + '/' + day.toString() + '/' + year.toString();
}
/**
 * @returns formatted current Date time in MM/DD/YYYY HH:MM AM format.
 */
export const currentDateFormat = () => {
    //CEAS-83469
    let current_date = new Date();
    let month = ((current_date.getMonth() + 1) >= 10) ? (current_date.getMonth() + 1) : '0' + (current_date.getMonth() + 1);
    let day = (current_date.getDate() >= 10) ? current_date.getDate() : '0' + current_date.getDate();
    let year = current_date.getFullYear();
    let hours = (current_date.getHours() > 12) ? current_date.getHours() - 12 : current_date.getHours();
    let am_pm = (current_date.getHours() >= 12) ? 'PM' : 'AM';
    hours = (hours < 10) ? '0' + hours : hours;
    let minutes = (current_date.getMinutes() < 10) ? '0' + current_date.getMinutes() : current_date.getMinutes();
    let formatted_date = month + "/" + day + "/" + year + " " + hours + ":" + minutes + " " + am_pm;
    return formatted_date;
}

/**
 * Function check Date validity.
 *
 * @param strDate to be Validated.
 * @returns Boolean Date Validity.
 */
export const isDateValid = (strDate) => {
    try {
        const lstDate = strDate.split('/');
        const year = +lstDate[2];
        const month = +lstDate[0];
        const day = +lstDate[1];
        const currDate = new Date(year, (month - 1), day);
        return (Boolean(+currDate) && currDate.getDate() === day && currDate.getMonth() === month - 1 && currDate.getFullYear() === year);
    } catch (error) {
        /*Do Nothing*/
    }
}

/**
 * Sets Cookie
 * @param name Cookie name
 * @param value Cookie value
 * @param days Cookie day
 */
export const helperBaseSetItem = (name, value, days) => {
   let expires = "";
   if (days !== undefined && days !== null && days > 1 && (name.indexOf('strInteractionLogIdForPlanSummaryStamp') > -1 ||
   value.startsWith('IL-'))) {
       const date = new Date();
       date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
       expires = "; expires=" + date.toUTCString();
   } else {
       expires = "; expires=" + "Max-Age=0";
   }
   document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

/**
 * Get Cookie
 * @param name Cookie name
 * @returns {string|null}
 */
export const helperBaseGetItem = (name) => {
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') {
            c = c.substring(1, c.length);
        }
        if (c.indexOf(nameEQ) === 0) {
            return c.substring(nameEQ.length, c.length);
        }
    }
    return null;
}

/**
 * Remove Cookie
 * @param name Cookie name
 */
export const helperBaseRemoveItem = (name) => {
     document.cookie = name + "=" + "" + "; expires=" + 'Thu, 01 Jan 1970 00:00:00 GMT' + "; path=/";
}

/**
 * Set Account Id.
 * @param strRecordId : @api RecordId
 * @param strCurrentTabUrl : Tab Url
 *
 * @return Account record Id.
 */
export const helperGetAccountRecordId = (strRecordId, strCurrentTabUrl) => {
    //Set Record Id.
    try {
        let strRecordIdData = strRecordId
        const strDecodedURL = helperBaseDecodeUrl(strCurrentTabUrl);
        if (strRecordIdData !== undefined && strRecordIdData !== null && strRecordIdData.startsWith('001')) {
            return strRecordIdData;
        } else {
            try {
                const fetchAccountFromURL = strDecodedURL.split('/');
                if (fetchAccountFromURL !== undefined && fetchAccountFromURL !== null && fetchAccountFromURL.length > 0) {
                    strRecordIdData = fetchAccountFromURL[fetchAccountFromURL.indexOf('Account') + 1];
                }
                if (strRecordIdData === undefined || strRecordIdData === null) {
                    strRecordIdData = helperBaseGetUrlParameters('strAccountIdForCaseSearch',strCurrentTabUrl);
                }
            } catch (error) {
                /*Do nothing*/
            }
            // Account id if the tab is not focused.
            if (strRecordIdData === undefined || strRecordIdData === null || strRecordIdData === '') {
                try {
                    const checkURLAgain = new URL(strDecodedURL);
                    strRecordIdData = checkURLAgain.href.split("/")[6];
                } catch (error) {
                    /*Do nothing*/
                }
            }
            return strRecordIdData;
        }
    } catch (objError) {
        /*Do nothing*/
    }
}

export const helperBaseGetDataForCustomEvents = (objEventData, strClassName, strIdDestination) => {
    // Read the event and parse it and return
    if (objEventData.detail !== undefined) {
        try {
            const objControllerResult = JSON.parse(objEventData.detail);

            //check if strDestination is defined or not
            if (objControllerResult.strIdDestination !== undefined) {
                if (isNotUndefinedOrNull(strIdDestination) && strIdDestination.includes(objControllerResult.strIdDestination)) {
                    // loop through all destinations
                    const strBaseIdDestination = strIdDestination.split(',');
                    for (let i = 0; i < strBaseIdDestination.length; i++) {
                        if (objControllerResult.strIdDestination === strBaseIdDestination[i]) {
                            return JSON.stringify(objControllerResult);
                        }
                    }
                    return;
                } else {
                    return;
                }
            }

            //Return if the result listened is null.
            if (
                isNotUndefinedOrNull(objControllerResult) &&
                (objControllerResult.objResult == null ||
                    (typeof objControllerResult.objResult.strResponseStatusCode !== 'undefined' &&
                        objControllerResult.objResult.strResponseStatusCode &&
                        objControllerResult.objResult.strResponseStatusCode !== '200'))
            ) {
                if (objControllerResult.objEvent.action === strClassName) {
                    if (
                        isNotUndefinedOrNull(objControllerResult.objResult) &&
                        isNotUndefinedOrNull(objControllerResult.objResult.strResponseStatusCode) &&
                        isNotUndefinedOrNull(objControllerResult.objResult.strResponseBody) &&
                        objControllerResult.objResult.strResponseStatusCode === '403'
                    ) {
                        const strRedirectUrl = objControllerResult.objResult.strResponseBody;
                        window.open(strRedirectUrl.replace(/&amp;/g, '&'), '_top');
                        return label.BaseLightningComponent_Error_ACE;
                    }
                    if (
                        objControllerResult.objEvent &&
                        (objControllerResult.objEvent.action === strClassName ||
                            (objControllerResult.objEvent.type &&
                                objControllerResult.objEvent.type === 'exception' &&
                                objControllerResult.objEvent.transaction &&
                                objControllerResult.objEvent.transaction.action &&
                                objControllerResult.objEvent.transaction.action === strClassName))
                    ) {
                        return label.BaseLightningComponent_Error_ACE;
                    }
                }
                return;
            }

            //condition to read the data from the response and set the attribute
            if (
                objControllerResult &&
                objControllerResult.objEvent &&
                objControllerResult.objEvent.statusCode &&
                objControllerResult.objEvent.statusCode === 200 &&
                objControllerResult.objEvent.action &&
                objControllerResult.objEvent.action === strClassName
            ) {
                return JSON.stringify(objControllerResult);
            }
        } catch (objError) {
            //do nothing
        }
    }
};

export const clearLoopedIntervalsInBase = (objLwcComponent, intCounter, intMultiplyInterval, objIntervalFunction, objErrorData) => {
    let intMultiplier = intMultiplyInterval;

    if (intMultiplier === null || intMultiplier === undefined || intMultiplier === '') {
        intMultiplier = 1;
    }

    if (!objLwcComponent.template.isConnected || (label.EnableIntervals_ACE === 'true' && intCounter >= parseInt(label.NumberOfIntervals_ACE, 10) * intMultiplier)) {
        clearInterval(objIntervalFunction);

        if (label.CaptureErrorLogs_ACE === 'true' && objLwcComponent.template.isConnected) {
            captureErrorInBaseServer(objLwcComponent, objErrorData);
        }
    }
};

export const captureErrorInBaseServer = (objLwcComponent, objErrorData) => {
    let strErrorData = objErrorData.strError;
    if (typeof objErrorData.strError === 'object') {
        try {
            strErrorData = JSON.stringify(objErrorData.strError);
        } catch (objException) {
            //Do Nothing.
        }
    }
    const strStackTrace = 'Root Component: ' + objErrorData.strComponentName + '\n' + objErrorData.strStackTrace + '\n' + strErrorData;
    const objParam = {
        clsName: objErrorData.strComponentName,
        strMessage: objErrorData.strMessage,
        strMethodName: objErrorData.strFunctionName,
        strStackTrace: strStackTrace
    };
    captureBaseInErrorLogsFunction(objParam);
};

/**
 * get local date and time from the ISO format Date.
 * @param strISODate : DateTime in ISO format
 *
 * @return Local Date Time.
 */
export const dtDateTimeISOtoLocal=(strISODate)=>{
    if(isNaN(Date.parse(strISODate))){
        return 'Invalid Date'
    }

    const dateLocalDateTime=new Date(strISODate);
    const dateUTCDate=dateLocalDateTime.getUTCDate();
    const dateUTCMonth=dateLocalDateTime.getUTCMonth();
    const dateUTCYear=dateLocalDateTime.getUTCFullYear();
    const dateUTCminutes=dateLocalDateTime.getUTCMinutes();
    const dateUTCseconds=dateLocalDateTime.getUTCSeconds();
    const dateUTChours=dateLocalDateTime.getUTCHours();

    const UTCDateTime=Date.UTC(dateUTCYear,dateUTCMonth,dateUTCDate,dateUTChours,dateUTCminutes,dateUTCseconds);

    const dateLocalTime = new Date(UTCDateTime);

    const datePading=(inp)=>{
        let intInput=inp;
        if(inp<10){
            intInput='0'+inp;
        }
        return intInput;
    }
    const strPaddedDate=[datePading(dateLocalTime.getMonth()+1), datePading(dateLocalTime.getDate()), dateLocalTime.getFullYear()].join('/')
    return (strPaddedDate+' '+dateLocalTime.toLocaleTimeString());
};

/**
 * To check if the string is valid URL or not.
 * @param strURL : url
 *
 * @return Boolean true/false depending on if the URL is valid .
 */
 export const isValidUrl = (strURL) =>{
     if(strURL===null || (typeof strURL==='string' && strURL.trim()==='')){
         return false;
     }
     const inputElement = document.createElement('input');
     inputElement.type = 'url';
     inputElement.value = strURL;

     if (!inputElement.checkValidity()) {
       return false;
     } else {
       return true;
     }
 };