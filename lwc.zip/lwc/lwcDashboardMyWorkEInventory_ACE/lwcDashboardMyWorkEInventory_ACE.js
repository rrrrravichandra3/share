import { LightningElement, track, api } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import fetchWorkStatus from '@salesforce/apexContinuation/MydashboardEinventoryStatsController.fetchWorkStatus';
import fetchAuxIn from '@salesforce/apexContinuation/MydashboardEinventoryStatsController.fetchAuxIn';
import upsertEinventory from '@salesforce/apex/MydashboardEinventoryStatsController.upsertEinventory';
import fetchWork from '@salesforce/apexContinuation/MydashboardEinventoryStatsController.fetchWork';
import workComplete from '@salesforce/apexContinuation/MydashboardEinventoryStatsController.workComplete';
import { openTab } from 'lightning/platformWorkspaceApi';
import { NavigationMixin } from 'lightning/navigation';
import Get_Work_No_Filters_Message from '@salesforce/label/c.Get_Work_No_Filters_Message';
import Get_Aux_In_Response_Message from '@salesforce/label/c.Get_Aux_In_Response_Message';
import Get_Work_No_Groups_Message from '@salesforce/label/c.Get_Work_No_Groups_Message';
import Get_Work_No_Profiles_Message from '@salesforce/label/c.Get_Work_No_Profiles_Message';
import Work_Complete_API_Error_Message from '@salesforce/label/c.Work_Complete_API_Error_Message';
import My_Work_API_Error_Message from '@salesforce/label/c.My_Work_API_Error_Message';
import eInventory_URL from '@salesforce/label/c.eInventory_External_URL';


export default class LwcDashboardMyWorkEInventoryACE extends NavigationMixin(LightningElement) {
    apiError = false;
    strMessage;
    boolShowMessage;
    boolError;
    boolWarning;
    boolSpinner = false;
    strLabelGetWork = 'Get Work';
    strLabelFinishWork = 'Work Complete';
    strFinishWorkTooltip;
    strRedirectURL; 
    lstWorkAreaOptions = [
        { label: 'Assignments', value: 'Assignments' },
        { label: 'Filters', value: 'Filters' },
        { label: 'Groups', value: 'Groups' },
        { label: 'Manual', value: 'Manual' }
    ];
    objWorkArea = '';
    strButtonLabel;
    label = {
        IntegrationFailMessage_ACE,
        Get_Work_No_Filters_Message,
        Get_Work_No_Groups_Message,
        Get_Work_No_Profiles_Message,
        Work_Complete_API_Error_Message,
        Get_Aux_In_Response_Message,
        My_Work_API_Error_Message,
        eInventory_URL
    };
    lstFilterOptions = [];
    lstProfileOptions = [];
    disableFilterOption = true;
    disableGroup = true;
    disableProfileOption = true;
    objFilter;
    objProfile;

    lstGroupOptions = [];
    disableCaseNumber = true;
    get messageCmpCSS() {
        if (this.boolError) {
            return 'messageCmpErrorDiv';
        } else if (this.boolWarning) {
            return 'messageCmpWarningDiv';
        }
    }
    objGroup;

    lstAuxAreaOption = [];
    objAuxArea;

    @track lstAuxCodeOption = [];
    objAuxCode;

    @track caseNumber;

    disableWorkArea = false;
    disableAuxArea = false;
    disableAuxOutButton = true;
    disableAuxInButton = true;
    disableAuxCode = true;
    disableResetButton = false;
    disableGetWorkButton = false;
    showGroup = false;
    showFilter = false;
    showProfile = false;
    @track timer = '00h:00m:00s';
    timerRef;
    @track startTime;
    @track timerTimeSecondsFinalValue;
    @track auxArea = [];
    @track auxAreaCode = [];
    @track selectedAuxArea;
    @track selectedAuxCode;
    @track workAreaResponse;
    federationIdentifier;
    eInvRecord;
    sessionActive = false;

    @api
    refreshCmp() {
        this.clearAllMessages();
        this.init();
    }
    connectedCallback() {
        //do nothing
    }
    handleSession() {
        this.sessionActive = true;
        this.init();
    }

    init() {
        this.apiError = false;
        this.objWorkArea = 'Assignments';
        this.boolSpinner = true;
        fetchWorkStatus()
            .then((strResponse) => {
                if (strResponse) {
                    const objResponse = strResponse.responseData;
                    if (objResponse) {
                        this.workAreaResponse = JSON.parse(objResponse);
                        this.setValues();
                        BaseLWC.fireNativeCustomEvent('showrefresh', {'showRefresh' : true}, this);
                    } else {
                        this.setApiError();
                    }
                    if (strResponse.strLanId) {
                        this.federationIdentifier = strResponse.strLanId;
                    }
                    if (strResponse.lstFetchEInvRecords) {
                        const lstResultInvData = JSON.parse(strResponse.lstFetchEInvRecords);
                        if (lstResultInvData && lstResultInvData.length > 0) {
                            this.eInvRecord = lstResultInvData[0];
                            let auxedOut = false;
                            for(let key in lstResultInvData) {
                                this.selectedAuxArea = lstResultInvData[key].Aux_Area_ACE__c ? lstResultInvData[key].Aux_Area_ACE__c : '';
                                this.selectedAuxCode = lstResultInvData[key].Aux_Code_ACE__c ? lstResultInvData[key].Aux_Code_ACE__c : '';
                                if (lstResultInvData[key] && lstResultInvData[key].Aux_Out_ACE__c) {
                                    auxedOut = true;
                                    let datDateToShow = '';
                                    if (BaseLWC.dtDateTimeISOtoLocal(lstResultInvData[key].Aux_Out_ACE__c) !== 'Invalid Date') {
                                        datDateToShow = BaseLWC.dtDateTimeISOtoLocal(lstResultInvData[key].Aux_Out_ACE__c);
                                    }
                                    this.startTime = new Date(datDateToShow);
                                    this.getAuxCodeOption();
                                    this.setTimer();
                                }
                                //If there is a case in the inventory the Work Complete label is displayed
                                if (lstResultInvData[key].Inventory_Case_ACE__c && lstResultInvData[key].Inventory_Case_ACE__c !== '') {
                                    this.strButtonLabel = this.strLabelFinishWork;
                                    this.strFinishWorkTooltip = `Your last assigned case: ${lstResultInvData[key].Inventory_Case_ACE__r.CaseNumber}`;
                                    this.enableDefaultInputFields();
                                    this.disableInputFields();
                                } else {
                                    this.strButtonLabel = this.strLabelGetWork;
                                    this.enableDefaultInputFields();
                                    if (auxedOut) {
                                        this.disableInputFields();
                                        this.disableGetWorkButton = true;
                                    }
                                }
                            }
                            
                        } else {
                            this.strButtonLabel = this.strLabelGetWork;
                        }
                    }
                } else {
                    this.setApiError();
                }
                this.boolSpinner = false;
            })
            .catch((error) => {
                this.boolSpinner = false;
                this.setApiError();
            });
    }
    setApiError() {
        this.apiError = true;
        BaseLWC.fireNativeCustomEvent('showrefresh', {'showRefresh' : true},this);
    }
    get showWorkToolTip() {
        return BaseLWC.isNotUndefinedOrNull(this.strButtonLabel) && this.strButtonLabel === this.strLabelFinishWork;
    }
    get disableAuxCodeGet() {
        return this.disableAuxCode || !BaseLWC.stringIsNotBlank(this.selectedAuxArea);
    }
    get disableAuxOutButtonGet() {
        return this.disableAuxOutButton || !BaseLWC.stringIsNotBlank(this.selectedAuxCode) || !BaseLWC.stringIsNotBlank(this.selectedAuxArea);
    }
    disableInputFields() {
        this.disableWorkArea = true;
        this.disableAuxArea = true;
        this.disableAuxCode = true;
        this.disableFilterOption = true;
        this.disableGroup = true;
        this.disableProfileOption = true;
        this.disableCaseNumber = true;
        this.disableGetWorkButton = false;
    }
    upsertEinvDetails() {
        this.boolSpinner = true;
        upsertEinventory({ auxArea: this.selectedAuxArea, auxCode: this.selectedAuxCode, startTime: this.startTime })
            .then((lstResultCaseData) => {
                this.setTimer();
                this.boolSpinner = false;
                this.enableDefaultInputFields();
                this.disableInputFields();
                this.disableGetWorkButton = true;
            })
            .catch((_error) => {
                this.boolSpinner = false;
                this.setErrorMessage('Aux is unavailable for the selected Aux Code. Select another value and if issue persists please create a help desk ticket.');
            });
    }
    setValues() {
        if (this.workAreaResponse.filters && this.workAreaResponse.filters.length) {
            this.lstFilterOptions = this.workAreaResponse.filters.map((el) => ({
                label: el.name,
                value: el.strId.toString()
            }));
            this.disableFilterOption = false;
        }
        if (this.workAreaResponse.groups && this.workAreaResponse.groups.length) {
            this.lstGroupOptions = this.workAreaResponse.groups.map((el) => ({
                label: el.name,
                value: el.strId.toString()
            }));
            this.disableGroup = false;
        }
        if (this.workAreaResponse.profiles && this.workAreaResponse.profiles.length) {
            this.lstProfileOptions = this.workAreaResponse.profiles.map((el) => ({
                label: el.name,
                value: el.strId.toString()
            }));
            this.disableProfileOption = false;
        }

        let auxAreaOptions = [];
        let auxCodeOptions = [];
        for (let area in this.workAreaResponse.auxAreas) {
            auxAreaOptions.push({ label: this.workAreaResponse.auxAreas[area].name, 
                                  value: this.workAreaResponse.auxAreas[area].strId ? this.workAreaResponse.auxAreas[area].strId.toString() : '' });
            for (let code in this.workAreaResponse.auxAreas[area].auxCodes) {
                if (this.workAreaResponse.auxAreas[area].auxCodes[code].name && this.workAreaResponse.auxAreas[area].auxCodes[code].strId) {
                    auxCodeOptions.push({ label: this.workAreaResponse.auxAreas[area].auxCodes[code].name, 
                        value: this.workAreaResponse.auxAreas[area].auxCodes[code].strId ? this.workAreaResponse.auxAreas[area].auxCodes[code].strId.toString() : '', 
                        auxAreaKey: this.workAreaResponse.auxAreas[area].strId ? this.workAreaResponse.auxAreas[area].strId.toString() : '' });
                }
            }
        }
        this.auxArea = auxAreaOptions;
        this.auxAreaCode = auxCodeOptions;
    }

    get showCaseNumber() {
        if (this.objWorkArea === 'Manual' && this.objProfile) {
            return true;
        } else {
            return false;
        }
    }
    handleChangeWorkArea(event) {
        this.clearAllMessages();
        this.disableGetWorkButton = true;
        if (event && event.detail) {
            this.objWorkArea = event.detail.value;
        }
        if (this.objWorkArea === 'Filters') {
            this.showFilter = true;
            this.showGroup = false;
            this.showProfile = false;
            this.objFilter = '';
            if (!this.lstFilterOptions.length) {
                this.setWarningMessage(this.label.Get_Work_No_Filters_Message);
                this.disableFilterOption = true;
            } else {
                this.disableFilterOption = false;
            }
        } else if (this.objWorkArea === 'Groups') {
            this.showFilter = false;
            this.showGroup = true;
            this.showProfile = false;
            this.objGroup = '';
            if (!this.lstGroupOptions.length) {
                this.disableGroup = true;
                this.setWarningMessage(this.label.Get_Work_No_Groups_Message);
            } else {
                this.disableGroup = false;
            }
        } else if (this.objWorkArea === 'Assignments') {
            this.showFilter = false;
            this.showGroup = false;
            this.showProfile = false;
            this.disableGetWorkButton = false;
        } else if (this.objWorkArea === 'Manual') {
            this.showProfile = true;
            this.showFilter = false;
            this.showGroup = false;
            this.caseNumber = '';
            this.objProfile = '';
            this.disableCaseNumber = false;
            if (!this.lstProfileOptions.length) {
                this.setWarningMessage(this.label.Get_Work_No_Profiles_Message);
            } else {
                this.disableProfileOption = false;
            }
        }
    }

    handleChangeFilter(event) {
        this.objFilter = event.detail.value;
        if (this.objFilter) {
            this.disableGetWorkButton = false;
        } else {
            this.disableGetWorkButton = true;
        }
    }
    

    handleProfileChange(event) {
        this.objProfile = event.detail.value;
        if (this.objProfile) {
            this.disableCaseNumber = false;
        } else {
            this.disableCaseNumber = true;
        }
        if (this.caseNumber && this.objProfile) {
            this.disableGetWorkButton = false;
        } else {
            this.disableGetWorkButton = true;
        }
    }

    handleChangeGroup(event) {
        this.objGroup = event.detail.value;
        if (this.objGroup) {
        this.disableGetWorkButton = false;
        } else {
            this.disableGetWorkButton = true;
        }
    }

    

    handleChangeCaseNum(event) {
        let strInputVal = event.target.value;
        if (strInputVal) {
            strInputVal = strInputVal.replace(/\D/g, '');
            if (strInputVal.length > 9) {
                strInputVal = strInputVal.slice(0, 9);
            }
            this.caseNumber = strInputVal;
        } else {
            this.caseNumber = '';
        }
        event.target.value = this.caseNumber;
        if (this.caseNumber && this.caseNumber.length >= 8) {
            this.disableGetWorkButton = false;
        } else {
            this.disableGetWorkButton = true;
        }
    }

    handleCaseNumber(event) {
         if (this.caseNumber && this.caseNumber.length > 0 && this.caseNumber.length < 8) {
            this.caseNumber = this.caseNumber.padStart(8, '0');
        }
        event.target.value = this.caseNumber;
        if (this.caseNumber && this.caseNumber.length >= 8) {
            this.disableGetWorkButton = false;
        } else {
            this.disableGetWorkButton = true;
        }
    }


    handleChangeAuxArea(event) {
        this.selectedAuxArea = event.detail.value;
        this.selectedAuxCode = null;
        this.disableAuxOutButton = true;
        this.disableAuxCode = false;
        this.getAuxCodeOption();
    }
    getAuxCodeOption() {
        this.lstAuxCodeOption = this.auxAreaCode.filter((auxCode) => auxCode.auxAreaKey === this.selectedAuxArea);
        return this.lstAuxCodeOption;
    }
    async handleGetWork(event) {
        this.clearAllMessages();
        this.boolSpinner = true;
        if (this.showWorkToolTip) {
            this.processWorkComplete();
            return;
        }
        let selection;
        if (this.objWorkArea === 'Filters') {
            selection = this.objFilter;
        } else if (this.objWorkArea === 'Groups') {
            selection = this.objGroup;
        } else if (this.objWorkArea === 'Assignments') {
            selection = '';
        } else if (this.objWorkArea === 'Manual') {
            selection = this.caseNumber;
        }
        try {
            const objResult = await fetchWork({ optionSelected: this.objWorkArea, selectedValue: selection, profileSelected: this.objProfile, fedId: this.federationIdentifier });
            if (objResult) {
                let workResult = JSON.parse(objResult);
                if (workResult && workResult.postToWorkComplete) {
                    const completeResult = await workComplete({ fedId: this.federationIdentifier, existRequest: workResult.workCompleteReq, objWorkWrapper: objResult });
                    if (completeResult && completeResult.isSuccess) {
                        workResult = JSON.parse(completeResult.strWorkWrapper);
                    }  else {
                        this.setErrorMessage(this.label.Work_Complete_API_Error_Message);
                        this.boolSpinner = false;
                        return;
                    }
                }
                if (workResult && workResult.showError) {
                    this.setErrorMessage(workResult.errorMessage);
                    this.boolSpinner = false;
                } else if (workResult && workResult.showWarning) {
                    if (workResult && workResult.workableObject && workResult.workableObject.identifier && !workResult.workableObject.identifier.isAceCase) {
                        this.setWarningMessage(workResult.warnMessage);
                        this.boolSpinner = false;
                        this.strRedirectURL = eInventory_URL.replace('Data_Index',workResult.workableObject.dataIndex).replace('Log_Index',workResult.workableObject.logIndex);
                        this.handleNavigate();
                        return;
                    }
                    this.setWarningMessage(workResult.warnMessage);
                    this.boolSpinner = false;
                } else if (workResult && workResult.workableObject && workResult.workableObject.identifier) {
                    //CEAS-78486
                        if (workResult.objCase && workResult.objCase.Id) {
                            const strCaseSearch ='CaseSearchFromMember';
                            let strCaseSearchFromMember = BaseLWC.helperBaseGetItem(strCaseSearch);
                            if (strCaseSearchFromMember != '' && strCaseSearchFromMember != null
                            && strCaseSearchFromMember == strCaseSearch) {
                                BaseLWC.helperBaseRemoveItem(strCaseSearch);
                            } 
                            BaseLWC.helperBaseSetItem(strCaseSearch, strCaseSearch, 30);
                            const openCase = await this.openCaseDetails(workResult.objCase.Id);
                            this.strButtonLabel = this.strLabelFinishWork;
                            this.strFinishWorkTooltip = `Your last assigned case: ${workResult.objCase.CaseNumber}`;
                            this.disableInputFields();
                            this.boolSpinner = false;
                        } else if (workResult && workResult.showError) {
                            this.setErrorMessage(workResult.errorMessage);
                            this.boolSpinner = false;
                        } else if (workResult && workResult.showWarning) {
                            this.setWarningMessage(workResult.warnMessage);
                            this.boolSpinner = false;
                        } else {
                            this.clearAllMessages();
                            this.boolSpinner = false;
                        }
                } else {
                    this.clearAllMessages();
                    this.boolSpinner = false;
                }
            }
        } catch (objError) {
            this.clearAllMessages();
            this.boolSpinner = false;
        }
    }

    async processWorkComplete() {
        try {
            const objResult = await workComplete({ fedId: this.federationIdentifier });
            if (objResult && objResult.isSuccess) {
                if (objResult.lstEinv && objResult.lstEinv.length) {
                    this.eInvRecord = objResult.lstEinv[0];
                }
                this.strButtonLabel = this.strLabelGetWork;
            } else {
                this.setErrorMessage(this.label.Work_Complete_API_Error_Message);
            }
            this.boolSpinner = false;
            this.enableDefaultInputFields();
        } catch (onjError) {
        }
    }
    enableInputFields() {
        this.disableWorkArea = false;
        this.disableAuxArea = false;
        this.disableFilterOption = false;
        this.disableGroup = false;
        this.disableProfileOption = false;
        this.objWorkArea = 'Assignments';
        this.showFilter = false;
        this.showGroup = false;
        this.showProfile = false;
        this.disableGetWorkButton = false;
    }
    enableDefaultInputFields() {
        this.enableInputFields();
        if (this.eInvRecord) {
            this.objWorkArea = this.eInvRecord.Work_Area__c || 'Assignments';
            if (this.objWorkArea === 'Filters') {
                this.objFilter = this.eInvRecord.Work_Area_Value__c;
                this.showFilter = true;
                this.showGroup = false;
                this.showProfile = false;
                if (this.objFilter) {
                    this.disableGetWorkButton = false;
                } else {
                    this.disableGetWorkButton = true;
                }
                if (!this.lstFilterOptions.length) {
                    this.setWarningMessage(this.label.Get_Work_No_Filters_Message);
                    this.disableFilterOption = true;
                } else {
                    this.disableFilterOption = false;
                }
            } else if (this.objWorkArea === 'Groups') {
                this.objGroup = this.eInvRecord.Work_Area_Value__c;
                this.showFilter = false;
                this.showGroup = true;
                this.showProfile = false;
                if (this.objGroup) {
                    this.disableGetWorkButton = false;
                    } else {
                        this.disableGetWorkButton = true;
                    }
                if (!this.lstGroupOptions.length) {
                    this.disableGroup = true;
                    this.setWarningMessage(this.label.Get_Work_No_Groups_Message);
                } else {
                    this.disableGroup = false;
                }
            } else if (this.objWorkArea === 'Manual') {
                this.showProfile = true;
                this.showFilter = false;
                this.showGroup = false;
                this.caseNumber = '';
                this.objProfile = '';
                this.disableCaseNumber = false;
                if (!this.lstProfileOptions.length) {
                    this.setWarningMessage(this.label.Get_Work_No_Profiles_Message);
                } else {
                    this.disableProfileOption = false;
                }
                if (this.objProfile) {
                    this.disableCaseNumber = false;
                } else {
                    this.disableCaseNumber = true;
                }
                if (this.caseNumber && this.objProfile) {
                    this.disableGetWorkButton = false;
                } else {
                    this.disableGetWorkButton = true;
                }
            } else if (this.objWorkArea === 'Assignments') {
                this.disableWorkArea = false;
                this.disableAuxArea = false;
                this.disableFilterOption = false;
                this.disableGroup = false;
                this.disableProfileOption = false;
                this.objWorkArea = 'Assignments';
                this.showFilter = false;
                this.showGroup = false;
                this.showProfile = false;
                this.disableGetWorkButton = false;
            }
        }
    }

    openCaseDetails = (strCaseId) => {
        return openTab({recordId: strCaseId, focus: true});
    };


    handleAuxIn (event) {
        this.clearAllMessages();
        if (!this.selectedAuxCode) {
            this.setErrorMessage('Aux is unavailable for the selected Aux Code. Select another value and if issue persists please create a help desk ticket.');
            return;
        }
        this.boolSpinner = true;
        const day = String(this.startTime.getDate()).padStart(2,'0');
        const month = String(this.startTime.getMonth() + 1).padStart(2,'0');
        const year = this.startTime.getFullYear();
        const hours = String(this.startTime.getHours()).padStart(2,'0');
        const Min = String(this.startTime.getMinutes()).padStart(2,'0');
        const sec = String(this.startTime.getSeconds()).padStart(2,'0');
        const miliSec = String(this.startTime.getMilliseconds()).padStart(3,'0');

        let jsonRequestBody = '{ "beginAux": "' + year + '-' + month + '-' + day + ' ' + hours + ':' + Min + ':' + sec + '.' + miliSec + '"}';
        
        fetchAuxIn({ requestbody: jsonRequestBody ,strFedId: this.federationIdentifier ,auxCode: this.selectedAuxCode})
            .then((strResponse) => {
                if (strResponse) {
                    this.selectedAuxArea = null;
                    this.selectedAuxCode = null;
                    this.disableAuxCode = true;
                    this.disableAuxArea = false;
                    this.disableResetButton = false;
                    this.disableGetWorkButton = false;
                    this.disableWorkArea = false;
                    this.disableAuxOutButton = true;
                    this.disableAuxInButton = true;
                    window.clearInterval(this.timerRef);
                    this.timer = '00h:00m:00s';
                    this.enableDefaultInputFields();
                } else {
                    this.setErrorMessage(this.label.Get_Aux_In_Response_Message);
                    this.disableAuxInButton = false;
                    this.disableAuxOutButton = true;
                    this.disableGetWorkButton = true;
                    this.disableResetButton = true;
                    this.disableWorkArea = true;
                    this.disableAuxCode = true;
                    this.disableAuxArea = true;
                }
                this.boolSpinner = false;
            })
            .catch((error) => {
                this.boolSpinner = false;
            });
    }

    handleAuxOut(event) {
        this.clearAllMessages();
        this.startTime = new Date();
        this.upsertEinvDetails();
    }
    setTimer(){
        if (this.startTime === null || this.startTime === undefined) {
            this.startTime = new Date();
        }
        this.disableAuxOutButton = true;
        this.disableAuxInButton = false;
        this.disableAuxArea = true;
        this.disableAuxCode = true;
        this.disableResetButton = true;
        this.disableWorkArea = true;
        this.disableGetWorkButton = true;
        this.objWorkArea = 'Assignments';
        this.timerRef = setInterval(() => {
            const secsDiff = new Date().getTime() - this.startTime.getTime();
            this.timer = this.secondToHms(Math.floor(secsDiff / 1000));
        }, 1000);
    }
    secondToHms(d){
        d = Number(d);
        const h = (Math.floor(d / 3600) < 10 ? '0' : '') + Math.floor(d / 3600);
        const m = (Math.floor((d % 3600) / 60) < 10 ? '0' : '') + Math.floor((d % 3600) / 60);
        const s = (Math.floor((d % 3600) % 60) < 10 ? '0' : '') + Math.floor((d % 3600) % 60);
    
        return h + 'h:' + m + 'm:' + s + 's';
    }
    handleChangeAuxCode(event) {
        this.selectedAuxCode = event.detail.value;
        this.disableAuxOutButton = false;
    }
    handleReset(event) {
        this.objWorkArea = 'Assignments';
        this.showFilter = false;
        this.showGroup = false;
        this.showProfile = false;
        this.selectedAuxArea = null;
        this.selectedAuxCode = null;
        this.disableAuxOutButton = true;
        this.clearAllMessages();
        this.objFilter ='';
        this.objGroup = '';
        this.objProfile = '';
        this.caseNumber = '';
        this.disableAuxCode = true;
    }
    setErrorMessage(errorMessage) {
        this.boolError = true;
        this.boolWarning = false;
        this.strMessage = errorMessage;
        this.boolShowMessage = true;
    }
    setWarningMessage(warningMessage) {
        this.boolWarning = true;
        this.boolError = false;
        this.strMessage = warningMessage;
        this.boolShowMessage = true;
    }
    clearAllMessages() {
        this.boolWarning = false;
        this.boolError = false;
        this.strMessage = false;
        this.boolShowMessage = false;
    }
    hideMessage() {
        this.boolShowMessage = false;
    }

    handleNavigate() {
        let newLocation = new URL(this.strRedirectURL);
        const config = {
            type: 'standard__webPage',
            attributes: {
                url: newLocation
            }
        };
        this[NavigationMixin.Navigate](config);
        
    }
}
