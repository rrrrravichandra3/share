/**
 * @author Ritika Singh.
 */

import { LightningElement, track } from 'lwc';

//import Static Resource
import Search_ACE from '@salesforce/resourceUrl/Search_ACE';

import BaseLWC from 'c/baseLWCFunctions_CF';
import {openTab } from 'lightning/platformWorkspaceApi';

// importing Custom Label
import AssignedAdvocate_Title_ACE from '@salesforce/label/c.AssignedAdvocate_Title_ACE';
import AssignedAdvocate_HeaderSearch_ACE from '@salesforce/label/c.AssignedAdvocate_HeaderSearch_ACE';
import AssignedAdvocate_SubHeadingSearch_ACE from '@salesforce/label/c.AssignedAdvocate_SubHeadingSearch_ACE';
import AssignedAdvocate_EmployeeId_ACE from '@salesforce/label/c.AssignedAdvocate_EmployeeId_ACE';
import AssignedAdvocate_AddAssignmentButton_ACE from '@salesforce/label/c.AssignedAdvocate_AddAssignmentButton_ACE';
import MemberSearch_SearchButton_ACE from '@salesforce/label/c.MemberSearch_SearchButton_ACE';
import MemberSearch_ResetButton_ACE from '@salesforce/label/c.MemberSearch_ResetButton_ACE';
import MemberSearch_SUBCRIBERID_ACE from '@salesforce/label/c.MemberSearch_SUBCRIBERID_ACE';
import getAssignedAdvocateRecords from '@salesforce/apex/ManageAssignedAdvocateController_ACE.getAssignedAdvocateRecords';
import noRecordsMessage from '@salesforce/label/c.Manage_Assigned_Advocate_Search_No_Records_Found_ACE';

export default class MaintainAssignedAdvocate extends LightningElement {

    searchIcon = Search_ACE;
    label = {
        AssignedAdvocate_Title_ACE,
        AssignedAdvocate_HeaderSearch_ACE,
        AssignedAdvocate_SubHeadingSearch_ACE,
        AssignedAdvocate_EmployeeId_ACE,
        AssignedAdvocate_AddAssignmentButton_ACE,
        MemberSearch_SearchButton_ACE,
        MemberSearch_ResetButton_ACE,
        MemberSearch_SUBCRIBERID_ACE,
        noRecordsMessage
    };

    disableAddAssignmentBtn = true;
    disableReset = true;
    disableSearch = true;
    disableEmpId;
    disableSubId;
    strSubscriberId = '';
    strEmployeeId='';

    boolNewAdvocateModal = false;
    @track advocateData;
    boolIsConfirmModalOpen = false;
    selectedActionValue = '';
    boolShowAdvocates = false;
    boolSearchComplete = false;
    pageSize = 10;
    actionData= [
        {label : 'Remove', value : 'Remove'},
        {label : 'Reassign', value : 'Reassign'}
    ];
    columns = [
        { label: 'Subscriber ID', fieldName: 'subscriberId', sortable: false, boolAsc: true, type: 'text' },
        { label: 'Account Number', fieldName: 'accountNumber', sortable: false, type: 'text' },
        { label: 'Corp Code', fieldName: 'corpCode', sortable: false, type: 'text'},
        { label: 'Employee ID', fieldName: 'empId', sortable: false, type: 'text'},
        { label: 'Created Date/Time', fieldName: 'createdDateTime', sortable: false, type: 'text', boolInitSort: false, boolAsc: false},
        { label: '', fieldName: 'Link', type: 'text' },
        { label: 'Record Id', fieldName: 'recId', sortable: false, type: 'text', boolHidden: true }];
    objInitTableSettings = {
        pageSize: this.pageSize,
        boolViewMore: false,
        columnsData: this.columns,
        boolSecondaryTable: false,
        boolShowFilter: true,
        boolPagination: true,
        filterData : [
            {strType : 'text', intCol : 1, strFilterName : 'Subscriber ID'},
            {strType : 'text', intCol : 2, strFilterName : 'Account Number'},
            {strType : 'picklist', intCol : 3, strFilterName : 'Corporation Code'},
            {strType : 'text', intCol : 4, strFilterName : 'Employee ID'},
            {strType : 'dateRangeMF', intCol : 5, strFilterName : 'Created Date/Time'}
        ],
        boolShowCheckbox : true,
        boolShowHeader : true
    };
    rowDataMap=new Map();
    rowIdList=[];
    shouldDisableActionDropdown = true;
    boolSpinner = false;

    validateTextField(objEvent) {
        const objTarget = objEvent.target;
        let strInitValue = objTarget.value;
        let maxLength;

        if(objTarget.classList.contains('SubscriberId')) {
            maxLength = 12; 
        }  else if(objTarget.classList.contains('EmployeeId')) {
            maxLength = 7;
        } else {
            //do nothing
        }
        if(strInitValue !== undefined && strInitValue !== null && strInitValue !== '') {
        strInitValue = strInitValue.replace(/[^0-9A-Za-z]/g, '').slice(0,maxLength);
        objTarget.value = strInitValue;
        } else {
            //do nothing
        }
    }

    handleEmpIdChange(objEvent) {
        const empIdValue =  objEvent.target.value;
        const intEmpIdLength = empIdValue.length ;

        if(intEmpIdLength !== 0 && intEmpIdLength > 0) {
            this.disableSubId = true;
            this.disableReset = false;
            this.disableSearch = false;
        } else {
            this.disableSubId = false;
            this.disableReset = true;
            this.disableSearch = true;
            this.disableAddAssignmentBtn = true;
        }
        this.strEmployeeId = empIdValue;
        this.handleEnter(objEvent);
    }

    handleCloseModal() {
        this.boolIsConfirmModalOpen = false;
        this.selectedActionValue = '';
    }

    handleSubIdChange(objEvent) {
        let subIdValue =  objEvent.target.value;
        const intSubIdLength = subIdValue.length ;
        if(intSubIdLength !== 0 && intSubIdLength > 0) {
            this.disableEmpId = true;
        } else {
            this.disableEmpId = false;
        }
        if(intSubIdLength !== 0 && intSubIdLength < 12) {
            subIdValue = subIdValue.padStart(12,'0');
        }
        this.strSubscriberId = subIdValue;
    }

    handleReset() {
        this.template.querySelectorAll('input').forEach(element => {
          if(element.type === 'text'){
            element.value = null;
          }
        });
        this.disableAddAssignmentBtn = true;
        this.strEmployeeId = '';
        this.strSubscriberId = '';
        this.disableEmpId = false;
        this.disableSubId = false;
        this.boolSearchComplete = false;
        this.boolShowAdvocates = false;
        this.shouldDisableActionDropdown = true;
    }

    handleEnter(objEvent){
        if(objEvent.keyCode === 13){
          this.handleSearch(objEvent);
        }
    }
    
    handleSearch(objEvent) {
        this.disableAddAssignmentBtn = false;
       const className = objEvent.target.className;
        if (className.includes('SubscriberId')) {
            this.strSubscriberId = objEvent.target.value;
        } else if(className.includes('EmployeeId')) {
            this.strEmployeeId = objEvent.target.value;
        } else {
            //do nothing
        }
        this.performSearch();
    }

    disableEmployeeIdField(objEvent) {
        const subIdValue = objEvent.target.value; 
        const intSubIdLength = subIdValue.length ;
        if(intSubIdLength !== 0 && intSubIdLength > 0) {
            this.disableEmpId = true;
            this.disableReset = false;
            this.disableSearch = false;
        } else {
            this.disableEmpId = false;
            this.disableReset = true;
            this.disableSearch = true;
            this.disableAddAssignmentBtn = true;
        }
        this.strSubscriberId = subIdValue;
        this.handleEnter(objEvent);
    }

    performSearch () {
        this.boolSpinner = true;
        this.shouldDisableActionDropdown = true;
        this.rowIdList = [];
        this.rowDataMap.clear();
        getAssignedAdvocateRecords({
            subscriberId : this.strSubscriberId,
            empId : this.strEmployeeId
        }).then((objResult)=>{
            this.boolSearchComplete = true;
            const linkLabel = 'View/Edit';
            const tempResult = JSON.parse(objResult);
            this.advocateData = tempResult.advocateDetailList;
            this.advocateData.forEach(row=>{
                const link = `<a data-masterLabel=${linkLabel} href='javascript:void(0);'>${linkLabel}</a>`;
                row.Link = {
                    value : linkLabel,
                    wrapper : link,
                    url : `/${row.recId}`
                };
            })
            if(this.advocateData["length"] === 0) {
                this.disableSearch = true;
            } else {
                this.disableSearch = false;
            }
            this.boolShowAdvocates = tempResult.advocatesFound;
            this.boolSpinner = false;
        }).catch((error)=>{
            this.error = error;
            this.boolShowAdvocates = false;
            this.boolSearchComplete = true;
            this.boolSpinner = false;
        })
    }
    handleRowAction(event) {
        try {
            const objEventData = JSON.parse(event.detail);           
            if (objEventData.activeColumnData && objEventData.activeColumnData.value && objEventData.activeColumnData.value.url) {
                const recordUrl = '/lightning/r/AssignedAdvocateRecord_ACE__c' + objEventData.activeColumnData.value.url + '/view';
                openTab({
                    url: recordUrl,
                    focus: true
                });
            }
        } catch (error) {
        }
    }

    handleRowSelection(event) {
        try {
            if (BaseLWC.isNotUndefinedOrNull(event.detail)) {
                const eventDetail = JSON.parse(event.detail);
                const rowInfo = eventDetail.rowInfo;
                if (eventDetail.action === 'ADD') {
                    rowInfo.forEach(el=>{
                        if(!this.rowIdList.includes(el[6].value)) {
                            this.rowIdList.push(el[6].value);
                        } else {
                           //do nothing 
                        }
                        this.rowDataMap.set(el[6].value, el);
                    })
                } else if (eventDetail.action === 'REMOVE') {
                    rowInfo.forEach(el=>{
                        this.rowIdList.splice(this.rowIdList.indexOf(el[6].value), 1);
                        if(this.rowDataMap.has(el[6].value)) {
                            this.rowDataMap.delete(el[6].value);
                        } else {
                           //do nothing 
                           
                        }  
                    })
                } else {
                    //do nothing
                }
                if(this.rowIdList.length > 0) {
                    this.shouldDisableActionDropdown = false;
                } else {
                    this.shouldDisableActionDropdown = true;
                }
                if(this.rowIdList.length === 0) {
                    this.selectedActionValue = '';
                    this.template.querySelector('.slds-combobox').classList.remove('slds-is-open');
                } else {
                    //do nothing
                }
            }
        } catch (error) {

        }
    }
    toggleCombobox(objEvent) {
        const objCmbx = objEvent.target.closest('.slds-combobox');
        if (objCmbx.querySelector('.highlight') && objCmbx.querySelector('.highlight').classList) {
            objCmbx.querySelector('.highlight').classList.remove('highlight');
        }
        const objDimensions = objCmbx.getBoundingClientRect();
        const objDropdown = objCmbx.querySelector('.slds-dropdown');
        objDropdown.style.top = objDimensions.top + 34 + 'px';
        objDropdown.style.width = objDimensions.width + 'px';
        objDropdown.style.left = objDimensions.left  + 'px';
        if (objCmbx && objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]') && objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]').classList) {
            objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]').classList.add('highlight');
        }
        objCmbx.classList.toggle('slds-is-open');
    }
    openCloseCombobox(objCmbxInput) {
        const objCmbx = objCmbxInput.closest('.slds-combobox');
        if (objCmbx.querySelector('.highlight') && objCmbx.querySelector('.highlight').classList) {
            objCmbx.querySelector('.highlight').classList.remove('highlight');
        }
        const objDimensions = objCmbx.getBoundingClientRect();
        const objDropdown = objCmbx.querySelector('.slds-dropdown');
        objDropdown.style.top = objDimensions.top + 34 + 'px';
        objDropdown.style.width = objDimensions.width + 'px';
        objDropdown.style.left = objDimensions.left  + 'px';
        objDropdown.style.position = 'sticky';
        if (objCmbx && objCmbx.querySelector('[data-label="' + objCmbxInput.value + '"]') && objCmbx.querySelector('[data-label="' + objCmbxInput.value + '"]').classList) {
            objCmbx.querySelector('[data-label="' + objCmbxInput.value + '"]').classList.add('highlight');
        }
        objCmbx.classList.toggle('slds-is-open');
    }
    handleComboboxSelect(event){
        try {
            this.selectedActionValue = event.currentTarget.getAttribute('data-label');
            event.currentTarget.closest('.slds-combobox').querySelector('.slds-combobox__input').setAttribute('value', this.selectedActionValue);
            event.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
            this.boolIsConfirmModalOpen = true;
        } catch (error) {
        }
    }
    handleSuccess(event) {
        let actionPerformed;
        if (BaseLWC.isNotUndefinedOrNull(event.detail)) {
            const eventDetailData = JSON.parse(event.detail);
            if (eventDetailData.type === 'Reassign') {
                const employeeId = JSON.parse(event.detail).data.employeeId;
                actionPerformed = 'UPDATE';
                this.rowDataMap.forEach((row) => {
                    row[3].value = employeeId;
                });
            }  else if (eventDetailData.type === 'Remove') {
                actionPerformed = 'DELETE';
            } else {
                //do nothing
            }
        }
        const objParams = {
            action : actionPerformed,
            source : 'maintainAssignedAdocate',
            newData : this.rowDataMap
        };
        this.template.querySelector('c-lwc-customized-datatable').refreshData(objParams);
        if (actionPerformed === 'DELETE') {
            this.rowDataMap.clear();
            this.rowIdList = [];
            this.shouldDisableActionDropdown = true;
            this.template.querySelector('.slds-combobox').classList.remove('slds-is-open');
        }
    }

    closeNewAdvocateModal() {
        this.boolNewAdvocateModal = false;
    }

    openNewAdvocateModal() {
        this.boolNewAdvocateModal = true;
    }
}