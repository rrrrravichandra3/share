import { LightningElement, track, wire} from 'lwc';

//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
//Base Workspace functions.
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
import getTMGCallDetails from '@salesforce/apexContinuation/TMGCallDetailsController_ACE.getTMGCallDetails';
import TMGCallID_ACE from '@salesforce/label/c.TMGCallID_ACE';
import CallerName_ACE from '@salesforce/label/c.TMGCallerName_ACE';
import Subject_ACE from '@salesforce/label/c.CreateCasePage_Subject_ACE';
import Category_ACE from '@salesforce/label/c.TMGCategory_ACE';
import Status_ACE from '@salesforce/label/c.SRSummary_Status_ACE';
import Route_To_Group_ACE from '@salesforce/label/c.TMGRouteToGroup_ACE';
import Route_To_User_ACE from '@salesforce/label/c.TMGRouteToUser_ACE';
import Summary_ACE from '@salesforce/label/c.ViewClaimDetails_Summary_ACE';
import SubscriberFirstName from '@salesforce/label/c.SRDetailsView_SubscriberFirstName_ACE';
import SubscriberLastName from '@salesforce/label/c.SRDetailsView_SubscriberLastName_ACE';
import SubscriberID from '@salesforce/label/c.SRSummary_SubscriberID_ACE';
import GroupNumber from '@salesforce/label/c.GroupNumber_ACE';
import Contract from '@salesforce/label/c.TMGContract_ACE';
import PBPCode from '@salesforce/label/c.TMG_PBPCode_ACE';
import Prefix from '@salesforce/label/c.ViewEmployerGroup_AlphaPrefix_ACE';
import NPINumber from '@salesforce/label/c.SRDetailsView_NPINumber_ACE';
import ProviderName from '@salesforce/label/c.ProviderName_ACE';
import CreatedDate from '@salesforce/label/c.ViewBroad_CreatedDate_ACE';
import ComplaintType from '@salesforce/label/c.SRDetailsView_ComplaintType_ACE';
import AppealID from '@salesforce/label/c.SRDetailsView_AppealID_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import CallerType_ACE from '@salesforce/label/c.TMGCallerType_ACE';
import CallersNumber_ACE from '@salesforce/label/c.SRDetailsView_CallersNumber_ACE';
import CallerExtension_ACE from '@salesforce/label/c.SRDetailsView_CallersExtension_ACE';
import LastUpdatedDate_ACE from '@salesforce/label/c.LastUpdatedDate_ACE';
import CreatedUser_ACE from '@salesforce/label/c.CreatedUser_ACE';
import LastUpdatedUser_ACE from '@salesforce/label/c.LastUpdatedUser_ACE';
import TMGCallInMethod_ACE from '@salesforce/label/c.TMGCallInMethod_ACE';

export default class LwcTMGCallDetailsACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    label = {
        TMGCallID_ACE,
        CallerName_ACE,
        Subject_ACE,
        Category_ACE,
        Status_ACE,
        Route_To_Group_ACE,
        Route_To_User_ACE,
        Summary_ACE,
        SubscriberFirstName,
        SubscriberLastName,
        SubscriberID,
        GroupNumber,
        Contract,
        PBPCode,
        Prefix,
        NPINumber,
        ProviderName,
        CreatedDate,
        ComplaintType,
        AppealID,
        IntegrationFailMessage_ACE,
        CallerType_ACE,
        CallersNumber_ACE,
        CallerExtension_ACE,
        LastUpdatedDate_ACE,
        CreatedUser_ACE,
        LastUpdatedUser_ACE,
        TMGCallInMethod_ACE
    };

    // variables declaration
    //Used to store tab Data.
    objTabData = null;
    callIDParameter = '';
    boolShowSpinner = true;
    boolCallDetailsAPIError = false;
    
    @track strCallerName ;
    @track strSubject ;
    @track strCategory ;
    @track strStatus ; 
    @track strRouteToGroup ;
    @track strRouteToUser ;
    @track strSummary ;
    @track strSubscriberFirstName ;
    @track strSubscriberLastName ;
    @track strSubscriberId ;
    @track strGroupNumber ;
    @track strContract ;
    @track strPbpCode ;
    @track strPrefix ;
    @track strCallerType ;
    @track strCallersNumber ;
    @track strCallersExtension ;
    @track strNpiNumber ;
    @track strProviderName ; 
    @track strLastUpdatedDate ;
    @track strCreatedDate ;
    @track strCreatedUser ;
    @track strLastUpdatedUser ; 
    @track strCallInMethod ;
    @track strComplaintType ;
    @track strAppealID ;
    @track strNotes ;

    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.boolShowSpinner=true;
            this.fetchTabData();
        } catch (error) {
            //Handle Error
            this.handleErrors(error);
        }
    }

     /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     */
    fetchTabData = ()=> {
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objTabData => {
                this.objTabData = objTabData;
                const strUrl = this.objTabData.url;
                this.callIDParameter = BaseLWC.helperBaseGetUrlParameters('callId', strUrl);
                this.fetchDataFromServer();
            }).catch((error) => {
                this.handleErrors(error);
            });
        }
    }

    /**
     * To Fetch Call ID Details data using CallID as a parameter from Controller.
     * Mapping response fields on UI..
     */
    fetchDataFromServer() {
        getTMGCallDetails({
            callIDParameter: this.callIDParameter
        }).then(objResult => {
            if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                const objCallIdDetails=JSON.parse(objResult)?.callDetails[0];                
                this.strCallerName = objCallIdDetails.callerFirstName + ' ' + objCallIdDetails.callerLastName;
                this.strSubject = objCallIdDetails.subject;
                this.strCategory = objCallIdDetails.category;
                this.strStatus = objCallIdDetails.status;
                this.strRouteToGroup = objCallIdDetails.routeToGroup;
                this.strRouteToUser = objCallIdDetails.routeToUser;
                this.strSummary = objCallIdDetails.summary;
                this.strSubscriberFirstName = objCallIdDetails.subscriberFirstName;
                this.strSubscriberLastName = objCallIdDetails.subscriberLastName;
                this.strSubscriberId = objCallIdDetails.subscriberId;
                this.strGroupNumber = objCallIdDetails.groupNumber;
                this.strContract = objCallIdDetails.contract;
                this.strPbpCode = objCallIdDetails.pbpCode;
                this.strPrefix = objCallIdDetails.prefix;
                this.strCallerType = objCallIdDetails.callerType;
                this.strCallersNumber = objCallIdDetails.callersNumber;
                this.strCallersExtension = objCallIdDetails.callersExtension;
                this.strNpiNumber = objCallIdDetails.npiNumber;
                this.strProviderName = objCallIdDetails.providerName;
                this.strLastUpdatedDate = this.formatDateAndTime(objCallIdDetails.lastUpdatedDate);
                this.strCreatedDate = this.formatDateAndTime(objCallIdDetails.createdDate);
                this.strCreatedUser = objCallIdDetails.createdUser;
                this.strLastUpdatedUser = objCallIdDetails.lastUpdatedUser;
                this.strCallInMethod = objCallIdDetails.callInMethod;
                this.strComplaintType = objCallIdDetails.complaintType;
                this.strAppealID = objCallIdDetails.appealID;
                if (BaseLWC.arrayIsNotEmpty(objCallIdDetails.notes)) {
                    this.strNotes = objCallIdDetails.notes.join('');
                } 
                this.boolShowSpinner = false;
            }
        }).catch(() => {
            this.handleErrors();
        });
    }
    
    /**
     * Handle API failure errors
     */
    handleErrors() {
        //Handle Errors
        this.boolCallDetailsAPIError = true;
        this.boolShowSpinner = false;
    }

    /**
     * Handle Tab Change between Details and Notes Roll-Up field
     */
    handleTabChange(event){
        const currTarget=event.currentTarget;
        [...currTarget.closest('ul').querySelectorAll('li')].forEach(el=>{
            el.classList.remove('slds-is-active');
            el.querySelector('[aria-selected]').setAttribute('aria-selected',false)
        })
        currTarget.closest('li').classList.add('slds-is-active');
        currTarget.setAttribute('aria-selected',true);
        const strActiveId=currTarget.getAttribute('aria-controls');
        [...currTarget.closest('.slds-tabs_scoped').querySelectorAll('.slds-tabs_scoped__content')].forEach(el=>{            
            if(el.id===strActiveId){
                el.classList.add('slds-show');
                el.classList.remove('slds-hide');
            }else{
                el.classList.remove('slds-show');
                el.classList.add('slds-hide');
            }            
        });        
    }

    /**
    * Method to refresh Component on click of refresh button and call out callDetails API
    */
     refreshCard = () => {
        this.boolShowSpinner = true;
        this.fetchDataFromServer();
    }

    /**
    * To format Date and Time in (MM/DD/YYYY HH:MM:SS AM/PM) format
    */
    formatDateAndTime(dateTime){
        if (!BaseLWC.stringIsNotBlank(dateTime)) {
            return '';
        }
        const objDate=new Date(dateTime);
        const strDate=BaseLWC.dateFormatterHelper(dateTime);
        if(objDate.toLocaleTimeString()==='Invalid Date') {
            return strDate;
        } else {            
            return strDate+' '+objDate.toLocaleTimeString('en-us')
        }
    }
}