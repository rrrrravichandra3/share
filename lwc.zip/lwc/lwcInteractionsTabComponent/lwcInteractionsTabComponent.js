import { LightningElement,api,wire } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
//CEAS-82979 Platform Workspace API
import { EnclosingTabId, getTabInfo, openSubtab} from 'lightning/platformWorkspaceApi';

import fetchInteractionHistoryLwc from '@salesforce/apexContinuation/InteractionHistoryController_ACE.fetchInteractionHistoryLWC';

//Interaction History Specific Labels
import InteractionHistory_InteractionLog_ACE from '@salesforce/label/c.InteractionHistory_InteractionLog_ACE';
import InteractionHistory_Channel_ACE from '@salesforce/label/c.InteractionHistory_Channel_ACE';
import InteractionHistory_DateTime_ACE from '@salesforce/label/c.InteractionHistory_DateTime_ACE';
import InteractionHistory_Direction_ACE from '@salesforce/label/c.InteractionHistory_Direction_ACE';
import InteractionHistory_Description_ACE from '@salesforce/label/c.InteractionHistory_Description_ACE';
import InteractionHistory_TotalCases_ACE from '@salesforce/label/c.InteractionHistory_TotalCases_ACE';
import InteractionHistory_OpenCases_ACE from '@salesforce/label/c.InteractionHistory_OpenCases_ACE';
import InteractionHistory_System_ACE from '@salesforce/label/c.InteractionHistory_System_ACE';
import InteractionHistory_HeaderChannel_ACE from '@salesforce/label/c.InteractionHistory_HeaderChannel_ACE';
import InteractionHistory_HeaderSystem_ACE from '@salesforce/label/c.InteractionHistory_HeaderSystem_ACE';
import InteractionHistory_InboundOutbound_ACE from '@salesforce/label/c.InteractionHistory_InboundOutbound_ACE';
import InteractionHistoryPage_TableHeader_InteractionID_ACE from '@salesforce/label/c.MemberSearch_InteractionID_ACE';
import InteractionHistoryPage_TableHeader_Channel_ACE from '@salesforce/label/c.InteractionHistory_HeaderChannel_ACE';
import InteractionHistoryPage_TableHeader_DateTime_ACE from '@salesforce/label/c.InteractionHistoryPage_TableHeader_DateTime_ACE';
import InteractionHistoryPage_TableHeader_InboundOutbound_ACE from '@salesforce/label/c.InteractionHistory_InboundOutbound_ACE';
import InteractionHistoryPage_TableHeader_Description_ACE from '@salesforce/label/c.General_Description_ACE';
import InteractionHistoryPage_TableHeader_TotalCases_ACE from '@salesforce/label/c.InteractionHistoryPage_TableHeader_TotalCases_ACE';
import InteractionHistoryPage_TableHeader_OpenCases_ACE from '@salesforce/label/c.InteractionHistoryPage_TableHeader_OpenCases_ACE';
import InteractionHistoryPage_TableHeader_System_ACE from '@salesforce/label/c.InteractionHistory_HeaderSystem_ACE';
import InteractionHistory_ChannelCall_ACE from '@salesforce/label/c.InteractionHistory_ChannelCall_ACE';
import InteractionHistory_ChannelPhone_ACE from '@salesforce/label/c.General_Phone_ACE';
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import InteractionHistoryPage_NoRecordFound_ACE from '@salesforce/label/c.InteractionHistoryPage_NoRecordFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';

export default class LwcInteractionsTabComponent extends LightningElement {

    label = {
        InteractionHistory_InteractionLog_ACE,
        InteractionHistory_Channel_ACE,
        InteractionHistory_DateTime_ACE,
        InteractionHistory_Direction_ACE,
        InteractionHistory_Description_ACE,
        InteractionHistory_TotalCases_ACE,
        InteractionHistory_OpenCases_ACE,
        InteractionHistory_System_ACE,
        InteractionHistory_HeaderChannel_ACE,
        InteractionHistory_HeaderSystem_ACE,
        InteractionHistory_InboundOutbound_ACE,
        InteractionHistoryPage_TableHeader_InteractionID_ACE,
        InteractionHistoryPage_TableHeader_Channel_ACE,
        InteractionHistoryPage_TableHeader_DateTime_ACE,
        InteractionHistoryPage_TableHeader_InboundOutbound_ACE,
        InteractionHistoryPage_TableHeader_Description_ACE,
        InteractionHistoryPage_TableHeader_TotalCases_ACE,
        InteractionHistoryPage_TableHeader_OpenCases_ACE,
        InteractionHistoryPage_TableHeader_System_ACE,
        InteractionHistory_ChannelCall_ACE,
        InteractionHistory_ChannelPhone_ACE,
        SafeMode_ToastMessage_ACE,
        IntegrationFailMessage_ACE,
        InteractionHistoryPage_NoRecordFound_ACE

    }

    @api tabData;
    @api globalData;
    @api boolSafeMode;
    @wire(EnclosingTabId) enclosingTabId;

    boolDisplayData = false;
    boolSpinner = false;
    boolShowNoRecorsFound = false;
    boolAPIError = false;

    lstTableData = [];
    columns = [
        { label: this.label.InteractionHistoryPage_TableHeader_InteractionID_ACE, fieldName: this.label.InteractionHistory_InteractionLog_ACE, sortable: true, type: '' },
        { label: this.label.InteractionHistoryPage_TableHeader_Channel_ACE, fieldName: this.label.InteractionHistory_Channel_ACE, sortable: true, type: '' },
        { label: this.label.InteractionHistoryPage_TableHeader_DateTime_ACE, fieldName: this.label.InteractionHistory_DateTime_ACE, sortable: true, type: 'date', boolInitSort: true, boolAsc: false },
        { label: this.label.InteractionHistoryPage_TableHeader_InboundOutbound_ACE, fieldName: this.label.InteractionHistory_Direction_ACE, sortable: true, type: '' },
        { label: this.label.InteractionHistoryPage_TableHeader_Description_ACE, fieldName: this.label.InteractionHistory_Description_ACE, sortable: true, type: '' },
        { label: this.label.InteractionHistoryPage_TableHeader_TotalCases_ACE, fieldName: this.label.InteractionHistory_TotalCases_ACE, sortable: true, type: '' },
        { label: this.label.InteractionHistoryPage_TableHeader_OpenCases_ACE, fieldName: this.label.InteractionHistory_OpenCases_ACE, sortable: true, type: '' },
        { label: this.label.InteractionHistoryPage_TableHeader_System_ACE, fieldName: this.label.InteractionHistory_System_ACE, sortable: true, type: '' }

    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: false,
        boolShowSearch: true,
        boolShowSearchLabel: true,
        filterData: [
            { strType: 'picklist', intCol: 2, strFilterName: this.label.InteractionHistory_HeaderChannel_ACE },
            { strType: 'picklist', intCol: 8, strFilterName: this.label.InteractionHistory_HeaderSystem_ACE },
            { strType: 'picklist', intCol: 4, strFilterName: this.label.InteractionHistory_InboundOutbound_ACE }
        ],
    };

    connectedCallback() {
        this.listenToPlanSummaryInteractionEvent();
        this.fetchData();

    }

    fetchData = () => {
        let acctId = this.tabData.recordId;
        if (this.globalData.strAccountId) {
            acctId = this.globalData.strAccountId
        }

        //Fetch Data from Controller
        const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + acctId;
        const strLSInteractionId = BaseLWC.helperBaseGetItem(localStorageKey);

        this.boolShowNoRecorsFound = false;
        this.boolAPIError = false;
        this.boolDisplayData = false;
        this.boolSpinner = true;
        let strProspectMemberParam = this.globalData.boolProspectMember;
        if (this.globalData.boolProducer) {
            strProspectMemberParam = true;
        }
        let strLSInteraction = '';
        if (strLSInteractionId !== null) {
            strLSInteraction = strLSInteractionId;
        }
        fetchInteractionHistoryLwc({
            strProspectMember: strProspectMemberParam,
            strAccountIdParam: acctId,
            strInteractionLogIdParam: strLSInteraction
        }).then(result => {
            if (result) {

                if (result.boolOauthTokenExpired) {
                    window.open(result.strRedirectionUrl, '_top');
                    return;
                }

                let objData;
                if (Array.isArray(JSON.parse(result))) {
                    objData = JSON.parse(result);
                } else {
                    objData = JSON.parse(JSON.parse(result));
                }

                //Loop through Data to modify for Table
                this.lstTableData = [];
                objData.forEach(el => {
                    //For fixing the null value
                    if (!el['strInteractionLogId'] || el['strInteractionLogId'] === 'null') {
                        return;
                    }
                    const obj = { ...el };
                    obj[this.label.InteractionHistory_InteractionLog_ACE] = {
                        value: el[this.label.InteractionHistory_InteractionLog_ACE],
                        strInteractionLogId: el['strInteractionLogId'],
                        wrapper: `<a data-interaction=${el['strInteractionLogId']}>${el[this.label.InteractionHistory_InteractionLog_ACE]}</a>`
                    };

                    if (el.strChannel === this.label.InteractionHistory_ChannelCall_ACE) {
                        obj.strChannel = this.label.InteractionHistory_ChannelPhone_ACE;
                    }

                    if (el.strDateTime && new Date(el.strDateTime).toString() !== 'Invalid Date') {
                        let strDateTime = '';
                        if (BaseLWC.dtDateTimeISOtoLocal(el.strDateTime) !== 'Invalid Date') {
                            strDateTime = BaseLWC.dtDateTimeISOtoLocal(el.strDateTime)
                        }

                        obj[this.label.InteractionHistory_DateTime_ACE] = {
                            value: el['strDateTime'],
                            wrapper: strDateTime
                        }
                    } else {
                        obj[this.label.InteractionHistory_DateTime_ACE] = {
                            value: '',
                            wrapper: ''
                        }
                    }

                    this.lstTableData.push(obj);
                });

                if (!this.lstTableData.length) {
                    this.boolShowNoRecorsFound = true;
                }
                this.boolDisplayData = true;
                this.boolSpinner = false;
            }
        }).catch(() => {
            this.boolSpinner = false;
            this.boolAPIError = true;
        });
    }

    handleRowAction(event) {
        const rowData = JSON.parse(event.detail);
        if (rowData.activeColumnName === this.label.InteractionHistoryPage_TableHeader_InteractionID_ACE) {
            this.openInteractionLogDetailsPage(rowData.activeColumnData.value.strInteractionLogId);
        }
    }

    openInteractionLogDetailsPage = (strInteractionLogId) => {
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objTabData => {
            const objParsedTabData = JSON.parse(JSON.stringify(objTabData));
            if (objParsedTabData.url) {
                if (!BaseLWC.isValidUrl(objParsedTabData.url)) {
                    return
                }
                const strBaseParam = atob(objParsedTabData.url.split('?c__BaseURLParam=')[1]);
                const strUrl = '/lightning/r/InteractionLog_ACE__c/' + strInteractionLogId + '/view?c__BaseURLParam=' + btoa(strBaseParam);
                    openSubtab(this.tabData.tabId, { url: strUrl,focus: true}).then(() => {
                        //Do nothing
                    }).catch(() => {
                        //Do nothing
                    });
            }
        }).catch(() => {
            //Do nothing
            });
        }
    }

    refreshData = () => {
        this.fetchData();
    }

    storageEventHandler = (objDataReceived) => {
        if (objDataReceived.detail) {
            const objData = JSON.parse(objDataReceived.detail);
            if (objData && objData.objParameters && objData.objParameters.objMessage && this.tabData.recordId === objData.objParameters.objMessage.interactionId) {
                this.refreshData();
            }
        }

    }
    listenToPlanSummaryInteractionEvent = () => {
        // Listener to listen message from localStorage
        const strPlanSummaryEvent = 'PlanSummaryInteractionEvent_' + this.tabData.tabId;
        window.addEventListener(strPlanSummaryEvent, this.storageEventHandler);
    }

    disconnectedCallback() {
        const strPlanSummaryEvent = 'PlanSummaryInteractionEvent_' + this.tabData.tabId;
        window.removeEventListener(strPlanSummaryEvent, this.storageEventHandler);
    }
}
