import { LightningElement, api } from "lwc";

//import required static resource assets
import HCSCClaimsStaticResource_ACE from "@salesforce/resourceUrl/HCSCClaimsStaticResource_ACE";

//Base LWC functions.
import BaseLWC from "c/baseLWCFunctions_CF";


import HIPAAAuthParty_CloseLabel_ACE from "@salesforce/label/c.HIPAAAuthParty_CloseLabel_ACE";
import UpdateHIPPARestrictions_PersonRestricted_ACE from "@salesforce/label/c.UpdateHIPPARestrictions_PersonRestricted_ACE";
import UpdateHIPAARestrictions_RRFHeaderName_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_RRFHeaderName_ACE";
import UpdateHIPPARestrictions_PHIRestricted_ACE from "@salesforce/label/c.UpdateHIPPARestrictions_PHIRestricted_ACE";
import HIPAAAuthParty_HIPAARestrictionDisclosureLabel_ACE from "@salesforce/label/c.HIPAAAuthParty_HIPAARestrictionDisclosureLabel_ACE";
import HIPAAAuthParty_HIPAARestrictionFSALabel_ACE from "@salesforce/label/c.HIPAAAuthParty_HIPAARestrictionFSALabel_ACE";
import ViewAuthorization_ImageRefNumberLabel_ACE from "@salesforce/label/c.ViewAuthorization_ImageRefNumberLabel_ACE";
import HIPAAAuthParty_Status_ACE from "@salesforce/label/c.SRSummary_Status_ACE";
import HIPAAAuthParty_AuthorizedPartyHeader_ACE from "@salesforce/label/c.HIPAAAuthParty_AuthorizedPartyHeader_ACE";
import ViewAuthorization_AuthorizedPersonEntityLabel_ACE from "@salesforce/label/c.ViewAuthorization_AuthorizedPersonEntityLabel_ACE";
import ViewAuthorization_RelationshipLabel_ACE from "@salesforce/label/c.ViewAuthorization_RelationshipLabel_ACE";
import ViewAuthorizedParty_InformationforDisclosure_ACE from "@salesforce/label/c.ViewAuthorizedParty_InformationforDisclosure_ACE";
import ViewAuthorizedParty_EffectiveDate_ACE from "@salesforce/label/c.ViewAuthorizedParty_EffectiveDate_ACE";
import ViewAuthorizedParty_ExpirationDate_ACE from "@salesforce/label/c.ViewAuthorizedParty_ExpirationDate_ACE";
import ViewAuthorizedParty_SignatureDate_ACE from "@salesforce/label/c.ViewAuthorizedParty_SignatureDate_ACE";
import ViewStandardAuthorization_ImageRefNumber_ACE from "@salesforce/label/c.ViewStandardAuthorization_ImageRefNumber_ACE";
import AuthorizedPartyFormType_ACE from "@salesforce/label/c.ViewCaseSummary_Type_ACE";
import HIPAAAuthParty_Active_ACE from "@salesforce/label/c.HIPAAAuthParty_Active_ACE";
import ViewStandardAuthorization_Header_ACE from "@salesforce/label/c.ViewStandardAuthorization_Header_ACE";
import ViewStandardAuthorization_SPHIRelease_ACE from "@salesforce/label/c.ViewStandardAuthorization_SPHIRelease_ACE";
import ViewStandardAuthorization_DisclosureInformation_ACE from "@salesforce/label/c.ViewStandardAuthorization_DisclosureInformation_ACE";
import ViewAuthorization_InformationDisclosureLabel_ACE from "@salesforce/label/c.ViewAuthorization_InformationDisclosureLabel_ACE";
import ViewStandardAuthorization_Selected_ACE from "@salesforce/label/c.ViewStandardAuthorization_Selected_ACE";
import ViewStandardAuthorization_From_ACE from "@salesforce/label/c.ViewStandardAuthorization_From_ACE";
import ViewStandardAuthorization_To_ACE from "@salesforce/label/c.ViewStandardAuthorization_To_ACE";
import ViewStandardAuthorization_HPBI_ACE from "@salesforce/label/c.ViewStandardAuthorization_HPBI_ACE";
import ViewStandardAuthorization_HealthPlanBenefitInfo_ACE from "@salesforce/label/c.ViewStandardAuthorization_HealthPlanBenefitInfo_ACE";
import ViewStandardAuthorization_FromDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_FromDate_ACE";
import ViewStandardAuthorization_ToDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_ToDate_ACE";
import ViewStandardAuthorization_ClaimsInformation_ACE from "@salesforce/label/c.ViewStandardAuthorization_ClaimsInformation_ACE";
import ViewStandardAuthorization_ClaimsInformationFromDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_ClaimsInformationFromDate_ACE";
import ViewStandardAuthorization_ClaimsInformationToDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_ClaimsInformationToDate_ACE";
import ViewStandardAuthorization_SID_ACE from "@salesforce/label/c.ViewStandardAuthorization_SID_ACE";
import ViewStandardAuthorization_ServiceInfo_ACE from "@salesforce/label/c.ViewStandardAuthorization_ServiceInfo_ACE";
import ViewStandardAuthorization_ServiceFromDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_ServiceFromDate_ACE";
import ViewStandardAuthorization_ServiceToDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_ServiceToDate_ACE";
import ViewStandardAuthorization_PI_ACE from "@salesforce/label/c.ViewStandardAuthorization_PI_ACE";
import ViewStandardAuthorization_PremiumInfo_ACE from "@salesforce/label/c.ViewStandardAuthorization_PremiumInfo_ACE";
import ViewStandardAuthorization_PremiumFromDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_PremiumFromDate_ACE";
import ViewStandardAuthorization_PremiumToDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_PremiumToDate_ACE";
import ViewStandardAuthorization_SPSInfo_ACE from "@salesforce/label/c.ViewStandardAuthorization_SPSInfo_ACE";
import ViewStandardAuthorization_SPSFromDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_SPSFromDate_ACE";
import ViewStandardAuthorization_Others_ACE from "@salesforce/label/c.ViewStandardAuthorization_Others_ACE";
import ViewStandardAuthorization_OtherInfo_ACE from "@salesforce/label/c.ViewStandardAuthorization_OtherInfo_ACE";
import ViewStandardAuthorization_OtherFromDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_OtherFromDate_ACE";
import ViewStandardAuthorization_OtherToDate_ACE from "@salesforce/label/c.ViewStandardAuthorization_OtherToDate_ACE";
import ViewStandardAuthorization_Notes_ACE from "@salesforce/label/c.ViewCaseSummary_Notes_ACE";

//NT: CEAS-66245
import HIPAAAuthPartyState_AuthorizedPartyStateHeader_ACE from "@salesforce/label/c.HIPAAAuthPartyState_AuthorizedPartyStateHeader_ACE";
export default class LwcHIPAAAuthModal extends LightningElement {
    label = {
        UpdateHIPPARestrictions_PersonRestricted_ACE,
        HIPAAAuthParty_CloseLabel_ACE,
        UpdateHIPAARestrictions_RRFHeaderName_ACE,
        UpdateHIPPARestrictions_PHIRestricted_ACE,
        HIPAAAuthParty_HIPAARestrictionDisclosureLabel_ACE,
        HIPAAAuthParty_HIPAARestrictionFSALabel_ACE,
        ViewAuthorization_ImageRefNumberLabel_ACE,
        HIPAAAuthParty_Status_ACE,
        HIPAAAuthParty_AuthorizedPartyHeader_ACE,
        ViewAuthorization_AuthorizedPersonEntityLabel_ACE,
        ViewAuthorization_RelationshipLabel_ACE,
        ViewAuthorizedParty_InformationforDisclosure_ACE,
        ViewAuthorizedParty_EffectiveDate_ACE,
        ViewAuthorizedParty_ExpirationDate_ACE,
        ViewAuthorizedParty_SignatureDate_ACE,
        ViewStandardAuthorization_ImageRefNumber_ACE,
        AuthorizedPartyFormType_ACE,
        HIPAAAuthParty_Active_ACE,
        ViewStandardAuthorization_Header_ACE,
        ViewStandardAuthorization_SPHIRelease_ACE,
        ViewStandardAuthorization_DisclosureInformation_ACE,
        ViewAuthorization_InformationDisclosureLabel_ACE,
        ViewStandardAuthorization_Selected_ACE,
        ViewStandardAuthorization_From_ACE,
        ViewStandardAuthorization_To_ACE,
        ViewStandardAuthorization_HPBI_ACE,
        ViewStandardAuthorization_HealthPlanBenefitInfo_ACE,
        ViewStandardAuthorization_FromDate_ACE,
        ViewStandardAuthorization_ToDate_ACE,
        ViewStandardAuthorization_ClaimsInformation_ACE,
        ViewStandardAuthorization_ClaimsInformationFromDate_ACE,
        ViewStandardAuthorization_ClaimsInformationToDate_ACE,
        ViewStandardAuthorization_SID_ACE,
        ViewStandardAuthorization_ServiceInfo_ACE,
        ViewStandardAuthorization_ServiceFromDate_ACE,
        ViewStandardAuthorization_ServiceToDate_ACE,
        ViewStandardAuthorization_PI_ACE,
        ViewStandardAuthorization_PremiumInfo_ACE,
        ViewStandardAuthorization_PremiumFromDate_ACE,
        ViewStandardAuthorization_PremiumToDate_ACE,
        ViewStandardAuthorization_SPSInfo_ACE,
        ViewStandardAuthorization_SPSFromDate_ACE,
        ViewStandardAuthorization_Others_ACE,
        ViewStandardAuthorization_OtherInfo_ACE,
        ViewStandardAuthorization_OtherFromDate_ACE,
        ViewStandardAuthorization_OtherToDate_ACE,
        ViewStandardAuthorization_Notes_ACE
    }

    //Parameters from Parent Component : HIPAA_AuthorizedLightningComponent_ACE
    @api objHIPAA;
    @api objAuthorization;
    @api strHeader;
    @api boolOpenModal;

    //Boolean variables
    viewStandardAuth = false;
    updateHippaaRes = false;
    authPartyHeader = false;
    hideButton = true;

    //Global Variables
    objHIPAAToggle;
    objAuthorizationToggle;
    objAuthorizationFinal = {};
    successLabel = 'label-success';
    defLabel = 'label-default';
    objCardError;

    //Initial method
    connectedCallback() {
        try {
            //Setting up the header value.
            this.checkHeader();
            //Setting up the other labels in the component.
            this.labelToggle();
        } catch (error) {
            this.handleErrors(error);
        }
    }

    /**
     * Header method.
     * CEAS-65574
     */
    checkHeader() {

        switch (this.strHeader) {
            case ViewStandardAuthorization_Header_ACE:
                this.viewStandardAuth = true;
                break;
            case UpdateHIPAARestrictions_RRFHeaderName_ACE:
                this.hideButton = false;
                this.updateHippaaRes = true;
                break;
            case HIPAAAuthParty_AuthorizedPartyHeader_ACE:
                this.authPartyHeader = true;
                break;
            case HIPAAAuthPartyState_AuthorizedPartyStateHeader_ACE:
                //NT: CEAS-66245
                this.authPartyHeader = true;
                break;
            default:
                //do nothing;
        }
    }

    /**
     * Closing the modal.
     * CEAS-65574
     */
    onClose() {
        const closeModal = new CustomEvent('modalclose', {
            detail: { modalClose: false }
        });
        // Fire the custom event
        this.dispatchEvent(closeModal);
    }

    /**
     * labels will be set up in this method.
     * CEAS-65574
     */
    labelToggle() {

        if (this.objHIPAA) {
            if (this.objHIPAA.Active_ACE__c === HIPAAAuthParty_Active_ACE) {
                this.objHIPAAToggle.Active = this.successLabel;
            } else {
                this.objHIPAAToggle.Active = this.defLabel;
            }
        }

        if (this.objAuthorization) {
            this.objAuthorizationToggle = Object.keys(this.objAuthorization);
            for (let i = 1; i < Object.keys(this.objAuthorization).length; i++) {

                if (Object.values(this.objAuthorization)[i] === HIPAAAuthParty_Active_ACE) {
                    this.objAuthorizationFinal[this.objAuthorizationToggle[i]] = this.successLabel;
                } else if (!this.objAuthorizationToggle[i]) {
                    this.objAuthorizationFinal[this.objAuthorizationToggle[i]] = '';
                } else {
                    this.objAuthorizationFinal[this.objAuthorizationToggle[i]] = this.defLabel;
                }
            }
        }
    }

    /**
         * To handle Errors.
         * Helps to show case errors.
         * All components should have this code.
         */
    handleErrors = (error) => {
        //show Account API Error
        this.objCardError = error;
    };
}