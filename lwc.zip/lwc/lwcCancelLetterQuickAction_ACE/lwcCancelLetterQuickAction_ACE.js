import { LightningElement,api,wire } from 'lwc';
import { CloseActionScreenEvent } from 'lightning/actions';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecordNotifyChange } from 'lightning/uiRecordApi';
import cancelLetter from "@salesforce/apexContinuation/CreateChildCaseController_ACE.cancelLetter";
import { getRecord } from "lightning/uiRecordApi";
import STRING_API_ERROR from '@salesforce/label/c.FacetsNotesAPIErrorMessage_ACE';
import updateLetterRecord from '@salesforce/apex/PreviewLetterController_ACE.updateLetterRecord';

const FIELDS = ["Letter_ACE__c.Status_ACE__c"];

export default class LwcCancelLetterQuickAction_ACE extends LightningElement {
    @api recordId;
    label = {
        STRING_API_ERROR
    };
    showSpinner = false;
    boolDisableCancelLetter = false;
    boolDisabledontCancelLetter = false;
    @wire(getRecord, { recordId: "$recordId", fields: FIELDS })
     objLetter;
    boolCancelLetterResponse = false;
    strDisplayMessage = 'Are you sure you want to cancel this letter? Cancelling a letter cannot be undone.';

    closeModal(event) {
        this.dispatchEvent(new CloseActionScreenEvent());
    }

    async cancelLetter(event) {
        try{
            this.showSpinner = true;
            this.boolDisableCancelLetter = true;
            this.boolDisabledontCancelLetter = true;
            if(this.objLetter && this.objLetter.data && this.objLetter.data.fields && this.objLetter.data.fields.Status_ACE__c 
                && this.objLetter.data.fields.Status_ACE__c.value === 'Pending') {
                let respBody;
                let result = await cancelLetter({ strRecordId:this.recordId});
                result = JSON.parse(result);
                if(result.strResponseBody){
                    respBody = JSON.parse(result.strResponseBody);
                }
                if ( result && result !='' && result.strResponseStatusCode && result.strResponseStatusCode === '200'
                && respBody && respBody.cancelResponse && respBody.cancelResponse.status=='SUCCESS') {
                    this.dispatchEvent(new CloseActionScreenEvent());
                    this.updateLetRec();
                    this.dispatchEvent(
                        new ShowToastEvent({
                            message: 'Letter cancelled successfully',
                            variant: 'success'
                        })
                    );
                    getRecordNotifyChange([{ recordId: this.recordId }]);
                } else {
                    this.dispatchEvent(new CloseActionScreenEvent());
                    this.dispatchEvent(
                        new ShowToastEvent({
                            message: this.label.STRING_API_ERROR,
                            variant: 'error'
                        })
                    );
                }
            } else {
                this.dispatchEvent(new CloseActionScreenEvent());
                this.dispatchEvent(
                    new ShowToastEvent({
                        message: 'Cancel letter option is only available on letters with the status of pending',
                        variant: 'error'
                    })
                );
            } 
            this.showSpinner = false;
            this.boolDisableCancelLetter = false;
            this.boolDisabledontCancelLetter =false;
        }catch (error){
            this.showSpinner = false;
            this.boolDisableCancelLetter = false;
            this.boolDisabledontCancelLetter = false;
            this.dispatchEvent(new CloseActionScreenEvent());
                    this.dispatchEvent(
                        new ShowToastEvent({
                            message: this.label.STRING_API_ERROR,
                            variant: 'error'
                        })
                    );
        }
    }

    updateLetRec(){
        try{
            updateLetterRecord({letterId :this.recordId });
        } catch( error){

        }        
    }
}