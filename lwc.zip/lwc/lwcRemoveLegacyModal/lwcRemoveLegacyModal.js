import { LightningElement, api } from 'lwc';

import RemoveLegacy_Description_ACE from '@salesforce/label/c.RemoveLegacyModal_Description_ACE';
import ViewAuthorizedParty_EffectiveDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_EffectiveDate_ACE';
import ViewAuthorizedParty_ExpirationDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_ExpirationDate_ACE';
import ViewStandardAuthorization_Success_ACE from '@salesforce/label/c.ViewStandardAuthorization_Success_ACE';


export default class LwcRemoveLegacyModal extends LightningElement {

    label = {  
        RemoveLegacy_Description_ACE,
        ViewAuthorizedParty_EffectiveDate_ACE,
        ViewAuthorizedParty_ExpirationDate_ACE,
        ViewStandardAuthorization_Success_ACE
    }

    //params passed from  parent component
    @api boolOpenRemoveLegacy;
    @api boolSuccesOfRemoveLegacy;
    @api strLegacyId;
    @api strAuthPerson 
    @api strEffectiveDateFormat;
    @api strExpirationDateFormat;
    boolSpinner;
    //close the modal
    closeModal() {
        this.closeModalEvent();
        this.boolOpenRemoveLegacy=false;
    }
    //firing event for loading component from aura 
    closeModalEvent() {
        const casecloseModal = new CustomEvent('RemoveLegacyModal', {
            detail: { boolOpenRemoveLegacy: false }
        });
        this.dispatchEvent(casecloseModal);
    }
    //method to fire event to parent on click of back
    goBacktoCreation() {
        const navigateBackModal = new CustomEvent('NavigateBack', {
            detail: { boolShowBackSection: false }
        });
        this.dispatchEvent(navigateBackModal);
    }
    //method to fire event to parent on click of remove
    goAndRemove() {
        this.boolSpinner = true;
        const goAndRemove = new CustomEvent('goAndRemove', {
            detail: { boolRemove: true }
        });
        this.dispatchEvent(goAndRemove);

    }
}
