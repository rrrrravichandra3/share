import { LightningElement, track } from 'lwc';
import BaseLWC from "c/baseLWCFunctions_CF";
import ClaimTypeHelpText_ACE from '@salesforce/label/c.ClaimTypeHelpText_ACE';

import ClaimDetailSearch_CPT_Tooltip_ACE from '@salesforce/label/c.ClaimDetailSearch_CPT_Tooltip_ACE';
import ClaimDetailSearch_Diagnosis_Tooltip_ACE from '@salesforce/label/c.ClaimDetailSearch_Diagnosis_Tooltip_ACE';
import ClaimDetailSearch_Ineligible_Tooltip_ACE from '@salesforce/label/c.ClaimDetailSearch_Ineligible_Tooltip_ACE';
import ClaimDetailSearch_Provision_Tooltip_ACE from '@salesforce/label/c.ClaimDetailSearch_Provision_Tooltip_ACE';
import ClaimDetailSearch_StatReason_Tooltip_ACE from '@salesforce/label/c.ClaimDetailSearch_StatReason_Tooltip_ACE';

export default class ClaimDetailSearchComponentACE extends LightningElement {
    strClaimTypeValue = 'Medical';
    strClaimTypeHelpText = ClaimTypeHelpText_ACE;

    objDispDateFromDatePicker;
    objDispDateToDatePicker;
    objServDateFromDatePicker;
    objServDateToDatePicker;

    @track lstDispDateFromErrors = [];
    @track lstDispDateToErrors = [];
    @track lstServDateFromErrors = [];
    @track lsServDateToErrors = [];
    @track lstAddtCriteriaRows = [];
    @track intAddtCriteriaRowCount = 0;
    @track boolDisableSearch = true;

    get lstClaimTypeOptions() {
        return [
            { label: '--None--', value: '--None--' },
            { label: 'Pharmacy', value: 'Pharmacy' },
            { label: 'Medical', value: 'Medical' },
            { label: 'Dental', value: 'Dental' },
        ];
    }

    get lstSearchParamOptions() {
        return [
            { label: '--None--', value: '--None--' },
            { label: 'CPT/CDT Code', value: 'CPT/CDT Code' },
            { label: 'Diagnosis Code', value: 'Diagnosis Code' },
            { label: 'Ineligible Reason Code', value: 'Ineligible Reason Code' },
            { label: 'Provision ID', value: 'Provision ID' },
            { label: 'Status Reason Code', value: 'Status Reason Code' },
        ];
    }

    renderedCallback(){
        //Get references to datepickers.
        this.objDispDateFromDatePicker = this.getDatePicker('.ddFromDiv');
        this.objDispDateToDatePicker = this.getDatePicker('.ddToDiv');
        this.objServDateFromDatePicker = this.getDatePicker('.sdFromDiv');
        this.objServDateToDatePicker = this.getDatePicker('.sdToDiv');

        //Disable default datepicker valdations
        this.objDispDateFromDatePicker.boolDisableDateValidationError = true;
        this.objDispDateToDatePicker.boolDisableDateValidationError = true;
        this.objServDateFromDatePicker.boolDisableDateValidationError = true;
        this.objServDateToDatePicker.boolDisableDateValidationError = true;
    }

    handleClaimTypeChange(event) {
        this.strClaimTypeValue = event.detail.value;
    }

    resetFieldValues() {
        this.boolDisableSearch = true;
        this.lstAddtCriteriaRows = [];
        this.intAddtCriteriaRowCount = 0;
        this.template.querySelector('.claimType').value = 'Medical';
        this.template.querySelectorAll('c-date-picker-slds').forEach(objElement => {
            objElement.clearDate();
        });
        this.resetValidations();
    }

    onDateUpdate(){
        this.validateFieldCompletion();
    }

    getDatePicker(strDivClass){
        const objDiv = this.template.querySelector(strDivClass);
        const objDatePicker = objDiv.querySelector('c-date-picker-slds');
        return objDatePicker;
    }

    validateDates(){

        let boolErrors = false;

        const objDispDateFromDatePicker = this.objDispDateFromDatePicker;
        const objDispDateToDatePicker = this.objDispDateToDatePicker;
        const objServDateFromDatePicker = this.objServDateFromDatePicker;
        const objServDateToDatePicker = this.objServDateToDatePicker;

        const lstDispDateFromErrors = this.lstDispDateFromErrors;
        const lstDispDateToErrors = this.lstDispDateToErrors;
        const lstServDateFromErrors = this.lstServDateFromErrors;
        const lsServDateToErrors = this.lsServDateToErrors;

        //Check Format
        const boolValidDispFrom = this.validateDateFormat(objDispDateFromDatePicker, lstDispDateFromErrors);
        const boolValidDispTo = this.validateDateFormat(objDispDateToDatePicker, lstDispDateToErrors);
        const boolValidServFrom =this.validateDateFormat(objServDateFromDatePicker, lstServDateFromErrors);
        const boolValidFormatServTo = this.validateDateFormat(objServDateToDatePicker, lsServDateToErrors);

        //Validate for missing pairs
        if(objDispDateFromDatePicker.strDateInput !== '' && objDispDateToDatePicker.strDateInput === ''){
            lstDispDateFromErrors.push({strErrorMessage:''});
            lstDispDateToErrors.push({strErrorMessage:'Disposition Date (To) is required'});
        }else if (objDispDateFromDatePicker.strDateInput === '' && objDispDateToDatePicker.strDateInput !== ''){
            lstDispDateFromErrors.push({strErrorMessage:'Disposition Date (From) is required'});
            lstDispDateToErrors.push({strErrorMessage:''});
        } else {
            // Do Nothing
        }

        if(objServDateFromDatePicker.strDateInput !== '' && objServDateToDatePicker.strDateInput === ''){
            lstServDateFromErrors.push({strErrorMessage:''});
            lsServDateToErrors.push({strErrorMessage:'Service Date (To) is required'});
        }else if (objServDateFromDatePicker.strDateInput === '' && objServDateToDatePicker.strDateInput !== ''){
            lstServDateFromErrors.push({strErrorMessage:'Service Date (From) is required'});
            lsServDateToErrors.push({strErrorMessage:''});
        } else {
            //Do Nothing
        }

        //Validate Future Dates
        const objTodaysDate = new Date(); //Get Today's date
        objTodaysDate.setHours(0, 0, 0, 0);

        if(boolValidDispFrom && new Date(objDispDateFromDatePicker.selectedDate) > objTodaysDate){
            lstDispDateFromErrors.push({strErrorMessage:'Disposition Date cannot be a future date'});
        }

        if(boolValidDispTo && new Date( objDispDateToDatePicker.selectedDate) > objTodaysDate){
            lstDispDateToErrors.push({strErrorMessage:'Disposition Date cannot be a future date'});
        }

        if(boolValidServFrom && new Date(objServDateFromDatePicker.selectedDate) > objTodaysDate){
            lstServDateFromErrors.push({strErrorMessage:'Service Date cannot be a future date'});
        }

        if(boolValidFormatServTo && new Date(objServDateToDatePicker.selectedDate) > objTodaysDate){
            lsServDateToErrors.push({strErrorMessage:'Service Date cannot be a future date'});
        }

        //Validate From Before To
        if(boolValidDispFrom && boolValidDispTo && (new Date(objDispDateFromDatePicker.selectedDate) > new Date(objDispDateToDatePicker.selectedDate)) ){
            lstDispDateFromErrors.push({strErrorMessage:'Disposition Date (From) must be prior to Disposition Date (To)'});
        }

        if(boolValidServFrom && boolValidFormatServTo && (new Date(objServDateFromDatePicker.selectedDate) > new Date(objServDateToDatePicker.selectedDate))){
            lstServDateFromErrors.push({strErrorMessage:'Service Date (From) must be prior to Service Date (To)'});
        }

        //Add Errors to Picklist
        if(this.lstDispDateFromErrors.length){
            boolErrors = true;
            this.objDispDateFromDatePicker.removeHideFromCustomErrorClasses(true);
        }

        if(this.lstDispDateToErrors.length){
            boolErrors = true;
            this.objDispDateToDatePicker.removeHideFromCustomErrorClasses(true);
        }

        if(this.lstServDateFromErrors.length){
            boolErrors = true;
            this.objServDateFromDatePicker.removeHideFromCustomErrorClasses(true);
        }

        if(this.lsServDateToErrors.length){
            boolErrors = true;
            this.objServDateToDatePicker.removeHideFromCustomErrorClasses(true);
        }
        return boolErrors;
    }

    validateDateFormat(objDatePicker, lstErrors) {

        if(!objDatePicker.isDateValid(objDatePicker.strDateInput) && objDatePicker.strDateInput !== ''){
            lstErrors.push({strErrorMessage:'Enter a valid date in MM/DD/YYYY format'});
            return false;
        }
        else if (objDatePicker.strDateInput === ''){
            return false;
        }

        return true;
    }

    doSearch() {
        this.resetValidations();
        const boolErrors = this.validateDates();

        //Don't perform search if errors present
        if(!boolErrors){
            return;
        }
    }

    resetValidations() {

        this.lstDispDateFromErrors = [];
        this.lstDispDateToErrors = [];
        this.lstServDateFromErrors = [];
        this.lsServDateToErrors = [];

        const objDatePickers = this.template.querySelectorAll('c-date-picker-slds');

        objDatePickers.forEach((objDatePicker) => {
            objDatePicker.removeHideFromCustomErrorClasses(false);
          });
    }

    addSearchCriteriaRow() {
       this.intAddtCriteriaRowCount += 1;
       const strRowId = 'row' + this.intAddtCriteriaRowCount;
       this.lstAddtCriteriaRows.push({strRowid:strRowId,
                                    boolSelectedParameter: false,
                                    strLabel:'',
                                    strTooltipMessage:''});
    }

    removeSearchCriteriaRow(event) {
        const strRowId = event.currentTarget.dataset.item;
        const objParameter = this.template.querySelector('lightning-combobox[data-item=' + strRowId +']');
        objParameter.value = '--None--';

        if (event.currentTarget.dataset.item !== undefined && event.currentTarget.dataset.item !== null && event.currentTarget.dataset.item !== '') {
            const objRowToRemove = event.currentTarget.dataset.item;
            const intIndexToRemove = this.lstAddtCriteriaRows.findIndex((objRow) => objRow.strRowid === objRowToRemove);
            if (intIndexToRemove > -1) {
                this.lstAddtCriteriaRows.splice(intIndexToRemove, 1);
            }
        }
        this.validateFieldCompletion();
    }

    handleSearchParamChange(event) {
        const strRowId = event.currentTarget.dataset.item;
        const intRowIndex = this.lstAddtCriteriaRows.findIndex((objRow) => objRow.strRowid === strRowId);

        if(event.detail.value != null){
            if(event.detail.value === '--None--'){
                this.lstAddtCriteriaRows[intRowIndex].strLabel = '';
                this.lstAddtCriteriaRows[intRowIndex].strTooltipMessage = '';
                this.lstAddtCriteriaRows[intRowIndex].boolSelectedParameter = false;
            } else if(event.detail.value === 'CPT/CDT Code'){
                this.lstAddtCriteriaRows[intRowIndex].strLabel = 'CPT/CDT Code ';
                this.lstAddtCriteriaRows[intRowIndex].strTooltipMessage = ClaimDetailSearch_CPT_Tooltip_ACE;
                this.lstAddtCriteriaRows[intRowIndex].boolSelectedParameter = true;
            } else if(event.detail.value === 'Diagnosis Code'){
                this.lstAddtCriteriaRows[intRowIndex].strLabel = 'DIAGNOSIS CODE';
                this.lstAddtCriteriaRows[intRowIndex].strTooltipMessage = ClaimDetailSearch_Diagnosis_Tooltip_ACE;
                this.lstAddtCriteriaRows[intRowIndex].boolSelectedParameter = true;
            } else if(event.detail.value === 'Ineligible Reason Code'){
                this.lstAddtCriteriaRows[intRowIndex].strLabel = 'INELEGIBLE REASON CODE';
                this.lstAddtCriteriaRows[intRowIndex].strTooltipMessage = ClaimDetailSearch_Ineligible_Tooltip_ACE;
                this.lstAddtCriteriaRows[intRowIndex].boolSelectedParameter = true;
            } else if(event.detail.value === 'Provision ID'){
                this.lstAddtCriteriaRows[intRowIndex].strLabel = 'PROVISION ID';
                this.lstAddtCriteriaRows[intRowIndex].strTooltipMessage = ClaimDetailSearch_Provision_Tooltip_ACE;
                this.lstAddtCriteriaRows[intRowIndex].boolSelectedParameter = true;
            } else if(event.detail.value === 'Status Reason Code'){
                this.lstAddtCriteriaRows[intRowIndex].strLabel = 'STATUS REASON CODE';
                this.lstAddtCriteriaRows[intRowIndex].strTooltipMessage = ClaimDetailSearch_StatReason_Tooltip_ACE;
                this.lstAddtCriteriaRows[intRowIndex].boolSelectedParameter = true;
            } else {
                // Do Nothing
            }
        }
        this.validateFieldCompletion();
    }

    validateFieldCompletion() {
        
        let boolDateFields = false;
        let boolTextFields = false;
        this.template.querySelectorAll('c-date-picker-slds').forEach(objElement => {
            if (BaseLWC.isNotUndefinedOrNull(objElement.strDateInput) && objElement.strDateInput !== '') {
                boolDateFields = true;
            }
        });
        if (this.lstAddtCriteriaRows.length > 0) {
            this.template.querySelectorAll('lightning-input').forEach(objElement => {
                const objParameter = this.template.querySelector('lightning-combobox[data-item=' + objElement.dataset.item +']');
                if (BaseLWC.isNotUndefinedOrNull(objElement.value) && BaseLWC.isNotUndefinedOrNull(objParameter.value) && objParameter.value !== '--None--') {
                    boolTextFields = true;
                }
            });
        } else {
            boolTextFields = false;
        }
        if (boolDateFields || boolTextFields) {
            this.boolDisableSearch = false;
        } else {
            this.boolDisableSearch = true;
        }
    }
}