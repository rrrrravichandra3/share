import { LightningElement , api ,track, wire} from 'lwc';
import checkIfAnyCasesAreOpen from '@salesforce/apex/NewCaseCheckClass_ACE.checkIfAnyCasesAreOpen';
import BaseLWC from 'c/baseLWCFunctions_CF';
import view_medical_claims_label from '@salesforce/label/c.ViewMedicalDetails_Claims_ACE';
import view_pas_due_claim_label from '@salesforce/label/c.ViewMedical_PastDue_ACE';
import HCSC_StaticResource from '@salesforce/resourceUrl/HCSCStaticResource_ACE';
//CEAS-83660
import NotepadTransmissionChannel_ACE from '@salesforce/messageChannel/NotepadTransmissionChannel__c';
import {
    MessageContext,
    publish,
} from 'lightning/messageService';


export default class ClaimDetailsSectionComponentACE extends LightningElement {
    //CEAS-83660
    NotepadTransmissionChannel = NotepadTransmissionChannel_ACE;
    @wire(MessageContext)
    messageContext;
    strNotePadNotes;
    @track
    _section;
    @api 
    strinteractionlogid;
    @api strClaimNumber;
    _boolAutoDocDisable;
    @api strMemeberId;
    @api strDDValue;
    @api strDOSValue;
    @api strUrlAdjNumber;
    @api strDcnNumber;
    @api groupNumber;
    @api strCMID;
    lstTrackEvents = 'click';
    @api strAccountId;
    @api boolIsInternalInteraction;
    @track boolAutoDoc;
    @api tabName;
    @track iconCss ='cardIconColor';
    @track labelCss ='';
    @track labelSize ='4';
    @track valueSize ='8';
    @track medicareIcon;
    @track isMedicare = false;
    @api
    get section() {
        return this._section;
    }

    
    set section(value) {
        if (value) {
            this._section = value;
        }
    }
    get borderClass() {
        if (this.section && this.section.noBorder) {
            return '';
        }
        return 'slds-card_boundary';
    }
    @api
    get boolHideAutoDoc() {
        return this.boolAutoDoc;
    }
    
    set boolHideAutoDoc(value) {
        this.boolAutoDoc = value;
    }
    get hideAutoDoc() {
        if (this.section && this.section.boolHideAutodoc) {
            return true;
        }
        return false;
    }

    get iconName() {
        if (this.section && this.section.boolHideCardIcon) {
            return '';
        }
        if(this.section && this.tabName && this.tabName === 'medicareInfo') {
            return 'utility:description';
        }
        return 'standard:contact';
    }

    connectedCallback() {
        if(this.tabName && this.tabName === 'medicareInfo') {
            this.medicareIcon = HCSC_StaticResource + '/Images/COB_Icon.svg';
            this.isMedicare = true;
            this.labelSize ='5';
            this.valueSize ='7';
        }
        //CEAS-80678
        if(this.tabName && this.tabName === 'otherInsuranceInfo') {
            this.labelSize ='7';
            this.valueSize ='5';
        }
    }
    
    handleAutoDoc(event) {
        //CEAS-83660
        let strNotes = '';
        let sectionId = 'id'+this.section.sectionLabel.replace(/ /g,"_").toUpperCase() +'-' + this.strDcnNumber+this.strUrlAdjNumber;
        //CEAS-83660 | Removing Logic for disabling autodoc & Interaction Check
        if (!BaseLWC.isUndefinedOrNullOrBlank(this.section.sectionLabel) && !this.boolHideAutoDoc) {
            this.getCurrentOpenCases();
        }

        
        let TotalPattern = [];
        let pattern = {
            strInteractionLogId: this.strinteractionlogid
        };
        let lstValuesData = [];
        let lstTitles = [];
        let lstTitleValues = [];
        let objMedicalDetailsdetails;
        let strSection = '';
        let lstMedicalClaimData = [];
        let strClaim;
        let sectionFieldsArray =[];

            objMedicalDetailsdetails = this.section;
            if (BaseLWC.isUndefinedOrNullOrBlank(objMedicalDetailsdetails)) {
                return;
            }
            strSection = this.section.sectionLabel;

            strClaim = ' DCN NUMBER - ' + ' ' + this.strDcnNumber + ' - ' + this.strUrlAdjNumber;
            lstMedicalClaimData = [view_medical_claims_label, strClaim, strSection];

            const lstMedicalSectionsData = [];

            for (let i = 0; i < lstMedicalClaimData.length; i++) {
                const subPatternForLstSections = {
                    "strLabel": lstMedicalClaimData[i].toUpperCase()
                };
                strNotes += lstMedicalClaimData[i].toUpperCase().trim() + '\n\n';
                if (i === 0) {
                    subPatternForLstSections.strIcon = 'add_contact';
                    subPatternForLstSections.strIconFamily = 'action';
                    subPatternForLstSections.strIconColor = '#5876a3';
                } else {
                    subPatternForLstSections.strIcon = '';
                    subPatternForLstSections.strIconFamily = '';
                    subPatternForLstSections.strIconColor = '';
                }
                lstMedicalSectionsData.push(subPatternForLstSections);
            }

            pattern.lstSections = lstMedicalSectionsData;


           sectionFieldsArray = this.section.fields;
           lstTitles = sectionFieldsArray.map(item => item.label);
           lstTitleValues = sectionFieldsArray.map(item => item.value);

           for (let i = 0; i < lstTitles.length; i++) {
            const objFieldData = {};
            objFieldData.strFieldLabel = lstTitles[i].toUpperCase();
            if (lstTitleValues[i] && lstTitleValues[i].includes('Navigate to Claims GUI.')) {
                objFieldData.strFieldValue = lstTitleValues[i].replace("Navigate to Claims GUI.", "");
            } else if (lstTitleValues[i] && lstTitleValues[i].includes('Navigate to Blue 2.')) {
                objFieldData.strFieldValue = lstTitleValues[i].replace("Navigate to Blue 2.", "");
            } else if (lstTitleValues[i] && lstTitleValues[i].includes(view_pas_due_claim_label + this.strDDValue)) {
                objFieldData.strFieldValue = lstTitleValues[i].replace(view_pas_due_claim_label + this.strDDValue, "");
            } else if (lstTitleValues[i] && lstTitleValues[i].includes(view_pas_due_claim_label + this.strDOSValue)) {
                objFieldData.strFieldValue = lstTitleValues[i].replace(view_pas_due_claim_label + this.strDOSValue, "");
            } else {
                if(BaseLWC.isUndefinedOrNullOrBlank(lstTitleValues[i])) {
                    objFieldData.strFieldValue = ''; 
                } else {
                    objFieldData.strFieldValue = lstTitleValues[i];
                }
                
            }
            strNotes += objFieldData.strFieldLabel + '\t\t' + objFieldData.strFieldValue + '\n';
            lstValuesData.push(objFieldData);
        }
        pattern.lstValues = lstValuesData;
        TotalPattern.push(pattern);

        const strAutoDocStorageKey = sectionId + '-' + this.strinteractionlogid + '-' + this.strMemeberId + '-' + this.strClaimNumber;
        this.strNotePadNotes = strNotes;
        this.publishToNotepad();
        this.sendAutoDocData( TotalPattern, strAutoDocStorageKey);
        }
    //CEAS-83660
    publishToNotepad() {
        const message = {
            method: 'POST',
            reqSource: "lwcNotepadAce",
            boolIsFromAutdoc : true,
            notes : this.strNotePadNotes
        };
        publish(this.messageContext, this.NotepadTransmissionChannel, message);
    }
    sendAutoDocData( TotalPattern, strAutoDocStorageKey) {
        if (this.strinteractionlogid && !this.boolHideAutoDoc) {
        const objIframe = document.createElement("iframe");
        objIframe.src = "/apex/ClaimsSetlocalstoragePage_ACE";
        objIframe.style.display = "none";
        document.body.appendChild(objIframe);
        objIframe.onload = function() {
            objIframe.contentWindow.postMessage({
                key: 'strAutodoc',
                value: JSON.stringify(TotalPattern),
                boolIsClaimsAutoDoc: true
            }, '*');
            
                    objIframe.contentWindow.postMessage({
                        key: 'strAutoDocIconInfo_ACE',
                        value: strAutoDocStorageKey,
                        boolIsClaimsAutoDoc: false
                    }, '*');
                objIframe.contentWindow.postMessage({
                    key: 'strKeepAutodocActive',
                    value: 'true',
                    boolIsClaimsAutoDoc: true
                }, '*');
            }
        }

    }
    getCurrentOpenCases = () => {
        checkIfAnyCasesAreOpen({
            mid: this.strMemeberId,
            type: 'Claims',
            subType: 'Claim Status_Claim Adjustment',
            strGroupNumber: this.groupNumber,
            strCmId: this.strCMID,
            strInteractionLogId: this.strInteractionLogId
        })
        .then(result => {
            try {
                if (!result) {
                    if (this,this.strinteractionlogid !== '') {
                        this.dispatchEvent(new CustomEvent('openmanualcase', {
                            detail: {
                                message: 'openmanualcase'
                            }
                        }));
                    }
                }
            } catch (exception) {
            }
        }
    ).catch(function() {
    });
    }
    handleFieldClick = (ev) => {
        const textContent = ev.detail.textContent;
        let index = ev.currentTarget.closest('div.rowData').getAttribute('data-index');
        if (index === null || index === undefined) {
            return;
        }
        index = Number(index);
        let renderedRowData = this.section.fields[index];
        const objParams = {
            renderedRowData: renderedRowData,
            sectionInfo: JSON.stringify(this.section),
            textContent: textContent
        };
        BaseLWC.fireNativeCustomEvent('rowaction', objParams, this);
    }
    /**
     * method to hide certifications hover
     */
    hideHoverDetails(event) {
        event.target.closest("div").querySelector(".slds-popover_tooltip").classList.add("slds-hide");
    }

    /**
     * method to show certifications hover
     */
    displayHoverDetails(event) {
        event.target.closest("div").querySelector(".slds-popover_tooltip").classList.remove("slds-hide");
    }
    

    
}