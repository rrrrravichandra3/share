import { LightningElement, wire} from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
import HCSC_StaticResource from '@salesforce/resourceUrl/HCSCStaticResource_ACE';
import fetchCOBAPIDetails from '@salesforce/apexContinuation/ViewPlanSummaryController_ACE.fetchCOBAPIDetails';
import COB_CoordinationOfBenefits_ACE from '@salesforce/label/c.COB_CoordinationOfBenefits_ACE';
import COB_DuplicateCoverage_ACE from '@salesforce/label/c.COB_DuplicateCoverage_ACE';
import COB_LastUpdated_ACE from '@salesforce/label/c.COB_LastUpdated_ACE';
import ViewPlanSummary_LaunchCOBBtn_ACE from '@salesforce/label/c.ViewPlanSummary_LaunchCOBBtn_ACE';
import ViewPlanSummary_LaunchCOB1_ACE from '@salesforce/label/c.ViewPlanSummary_LaunchCOB1_ACE';
import ViewPlanSummary_LaunchCOB2_ACE from '@salesforce/label/c.ViewPlanSummary_LaunchCOB2_ACE';
import ViewPlanSummary_LaunchCOB3_ACE from '@salesforce/label/c.ViewPlanSummary_LaunchCOB3_ACE';
import ViewPlanSummary_LaunchCOB4_ACE from '@salesforce/label/c.ViewPlanSummary_LaunchCOB4_ACE';
import ViewPlanSummary_CardHeader_Refresh_ACE from '@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE';
import SafeModeModalEventName from '@salesforce/label/c.SafeMode_NotificationEvent_ACE';
import SafeModeEventDestinationId from '@salesforce/label/c.SafeMode_DestinationId_ACE';
import planSummaryMID from '@salesforce/label/c.ViewPlanSummary_MID_ACE';
import readOnlyProfile from '@salesforce/label/c.ReadOnly_Profile_ACE';
import ViewPlanSummary_NoOfDaysCOB_ACE from '@salesforce/label/c.ViewPlanSummary_NoOfDaysCOB_ACE';
import cobCardButtonEventName from '@salesforce/label/c.COBCARDButtonEventName_ACE';
import createCaseButtonName from '@salesforce/label/c.Create_Case_COB_CARD_ACE';
import strErrorMessage from '@salesforce/label/c.COB_ErrorMessage_ACE';
import dash from '@salesforce/label/c.ViewPlanSummary_Dash_ACE';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import Government_Medicare_Sup_Label_ACE from '@salesforce/label/c.Government_Medicare_Sup_Label_ACE';

export default class CoordinationOfBenefitsLightningWebComponentACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    //Console Tab Variables.
    //Primary Tab Indicator.
    boolPrimaryTab = false;
    //Used to store tab Data.
    objTabData = null;
    //LWC Card Icon for COB CMP
    COBIconTitle = HCSC_StaticResource + '/Images/COB_Icon.svg'
    label = {
        COB_CoordinationOfBenefits_ACE,
        COB_DuplicateCoverage_ACE,
        COB_LastUpdated_ACE,
        ViewPlanSummary_LaunchCOBBtn_ACE,
        ViewPlanSummary_LaunchCOB1_ACE,
        ViewPlanSummary_LaunchCOB2_ACE,
        ViewPlanSummary_LaunchCOB3_ACE,
        ViewPlanSummary_LaunchCOB4_ACE,
        ViewPlanSummary_CardHeader_Refresh_ACE,
        SafeModeModalEventName,
        SafeModeEventDestinationId,
        planSummaryMID,
        readOnlyProfile,
        ViewPlanSummary_NoOfDaysCOB_ACE,
        cobCardButtonEventName,
        createCaseButtonName,
        strErrorMessage,
        dash,
        EnableVPSTabSpecificEvents_ACE,
        Government_Medicare_Sup_Label_ACE
    }

    //Result/Response Data Variables.
    objCOBResponse = null;
    objCOBReqParams = null;
    boolCOBDataAvailable =  false;
    boolCOBButtonEnable = true;
    showCOBSpinner = true;
    boolShowCOBButton = false;
    boolShowNewCaseLink = true;
    showNewCaseSpinner = true;
    strDuplicateCoverage = null;
    strCOBLastUpdateDate = null;
    boolIsLineOfBusinessFEP = false;
    objViewPlanSummaryResult = null;

    strLaunchCOBLink;
    strCOBCaseDefaults;
    strCurrentUserProfile;
    objSelectedPlanDetailsWrapper;
    objPlanSummaryChangeCustomEventListener;
    //Common Indicator variables.
    //To show safe Mode error.
    boolShowSafeMode = false;
    //Used for Show/hide spinner.
    boolSpinner = true;
    //Used for show/hide Error Block.
    boolError = false;
    //Event Variables.
    strPlanSummaryEvent = 'PlanSummaryEvent';
    strPlanChangedCustomEvent = 'PlanChangedCustomEvent'
    boolVPSTabSpecificEvents = false;
    boolIsGovMedSupp =false;
    boolHideCOBCard =false;
    /**
     * Connected Call back function.
     */
    connectedCallback() {

        //Always run this below function in Connected Callback.
        try {
            this.fetchTabData();
        } catch (error) {
            //Handle Error
        }
    }
    fetchTabData() {
        if (!this.enclosingTabId) {
            return;
        }
        getTabInfo(this.enclosingTabId).then(objTabData => {
            this.objTabData = objTabData;
            if (BaseLWC.stringIsNotBlank(this.label.EnableVPSTabSpecificEvents_ACE) && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                this.boolVPSTabSpecificEvents = true;
            }
             const strIsLineOfBusinessFEP= BaseLWC.helperBaseGetUrlParameters('isLineOfBusinessFEP',this.objTabData.url);
const strCorpCode =  BaseLWC.helperBaseGetUrlParameters('corpCode',this.objTabData.url);
             const strLOB =  BaseLWC.helperBaseGetUrlParameters('urlLob',this.objTabData.url);
             this.boolIsLineOfBusinessFEP = (strIsLineOfBusinessFEP === 'true' || strIsLineOfBusinessFEP === true)
             if(this.boolIsLineOfBusinessFEP || (strLOB=='GMCaid' && (strCorpCode =='TX1' || strCorpCode =='IL1' || strCorpCode =='MT1' || strCorpCode =='OK1'))) {
                this.boolHideCOBCard =true;
             }
             if(!this.boolIsLineOfBusinessFEP && !(strLOB=='GMCaid' && strCorpCode =='TX1')) {
                //Always add executeInitialFunctionality function which can be reused for refresh.
                this.executeInitialFunctionality();
            }
        }).catch(() => {
            this.handleErrors();
        });
    }

    /**
     * To handle Errors.
     * Helps to show case errors.
     * All components should have this code.
     */
    handleErrors() {

        //Handle Errors
        this.boolSpinner = true;

    }

    /**
     * Executes the initialization of component.
     * Helps to execute main tab and sub tab functionality.
     * All components should have this code.
     */
    executeInitialFunctionality() {
        if (this.objTabData.isSubtab === true) {

            //Always segregate the Main tab and Sub tab functions.
            this.executeSubTabFunctionality();
        } else if (this.objTabData.isSubtab === false) {

            //Always segregate the Main tab and Sub tab functions.
            this.executeMainTabFunctionality();
        } else {
            //Do Nothing
        }
    }

    executeSubTabFunctionality() {
        this.boolPrimaryTab = false;

    }

    /**
     * Executes Main Tab functions.
     * Helps to add listeners & fire events.
     * All components should have this code.
     */
    executeMainTabFunctionality() {
        this.boolPrimaryTab = true;
        this.primaryCardEventListeners();
    }

    /**
     * Helps to add listeners.
     * All components should have this code.
     */
    primaryCardEventListeners() {
        if(this.objTabData.tabId) {
            if (this.boolVPSTabSpecificEvents) {
                this.strPlanSummaryEvent = 'PlanSummaryEvent_' + this.objTabData.tabId;
                this.strPlanChangedCustomEvent = 'PlanChangedCustomEvent_' + this.objTabData.tabId;
            }
            window.addEventListener(this.strPlanSummaryEvent, this.fetchDataFromPlanSummaryEvent);
            window.addEventListener(this.strPlanChangedCustomEvent,this.fetchDataFromPlanChangedCustomEvent);
                    }
    }
    //This listener function will be listened whenever different plan is selected on HCD and based on the data received it will do callout
    fetchDataFromPlanChangedCustomEvent=(objCOBData) =>{
        const objResponseData = BaseLWC.fetchComponentData(objCOBData, 'PlanChangedDetails_PlanSummary_ACE', true);
        if (objResponseData.boolError === true) {
            this.boolError = true;
        } else {

            if (BaseLWC.isNotUndefinedOrNull(objResponseData) && BaseLWC.isNotUndefinedOrNull(objResponseData.objParameters)
            && objResponseData.objParameters.strParentTabId && objResponseData.objParameters.strParentTabId === this.objTabData.tabId
            && BaseLWC.isNotUndefinedOrNull(objResponseData.objParameters.objMessage)) {
                this.boolSpinner = true;
                this.showCOBSpinner = true;
                this.boolCOBDataAvailable = false;
                this.objViewPlanSummaryResult = objResponseData.objParameters.objMessage
                    if(this.objViewPlanSummaryResult.boolIsLineOfBusinessFEP) {
                        this.boolIsLineOfBusinessFEP = true;
                    } else {
                        this.boolIsLineOfBusinessFEP = false;
                        this.createRequestForCOBCallout()
                    }

                    if(this.objViewPlanSummaryResult.strAceLineOfBusiness === this.label.Government_Medicare_Sup_Label_ACE){
                        this.boolIsGovMedSupp = true;
                    }
    
                    if(this.boolIsLineOfBusinessFEP || this.boolIsGovMedSupp){
                        this.boolHideCOBCard =true;
                    }
                }
            }

    }
    //This function will do the callout and get response
    fetchCOBDetails(){
        if(this.boolPrimaryTab){

            fetchCOBAPIDetails({
                objCOBRequestParams : this.objCOBReqParams
            }).then(objresponseCOB => {
                if (objresponseCOB !== null && objresponseCOB !== '') {
                    this.objCOBResponse = objresponseCOB;
                    if (this.objCOBResponse.boolIsSuccess) {
                        this.showCOBButton();
                        this.lastUpdatedDate();
                        this.duplicateCoverage();
                        this.boolSpinner = false;
                        this.boolCOBDataAvailable = true;
                        this.boolError = false;
                        this.showNewCaseSpinner = false;
                        this.boolCOBButtonEnable = true;
                    } else {
                        this.boolCOBButtonEnable= false;
                        this.boolError = true;
                        this.boolCOBDataAvailable = false;
                        this.boolSpinner = false;
                        this.boolShowNewCaseLink = false;
                        this.showNewCaseSpinner = false;
                    }

                } else {
                        this.boolCOBButtonEnable= false;
                        this.boolError = true;
                        this.boolCOBDataAvailable = false;
                        this.boolSpinner = false;
                        this.boolShowNewCaseLink = false;
                        this.showNewCaseSpinner = false;
                }
            }).catch(() => {
                this.handleErrors();
            });
        }
    }
    //this function will check whether cobLastUpdatedate or csqGeneratedDate is greater than 275 days or not if yes then show bell icon in launch cob button
    showCOBButton() {
        let intNumberDaysCOB, intNumberDaysCSQ;
        let datCOBLastUpdateDate, datCSQGeneratedDate, datCurrentDate;

        // To show Launch COB Button on Dashboard
        const strCOBLastUpdateDate = this.objCOBResponse.strCOBLastUpdateDate;
        const strCSQGeneratedDate = this.objCOBResponse.strCSQGeneratedDate;
        if (strCOBLastUpdateDate || strCSQGeneratedDate) {
            datCOBLastUpdateDate = new Date(strCOBLastUpdateDate);
            datCSQGeneratedDate = new Date(strCSQGeneratedDate);

            datCurrentDate = new Date();
            intNumberDaysCOB = Math.floor((Date.UTC(datCurrentDate.getFullYear(), datCurrentDate.getMonth(), datCurrentDate.getDate()) - Date.UTC(datCOBLastUpdateDate.getFullYear(), datCOBLastUpdateDate.getMonth(), datCOBLastUpdateDate.getDate())) / (1000 * 60 * 60 * 24));
            intNumberDaysCSQ = Math.floor((Date.UTC(datCurrentDate.getFullYear(), datCurrentDate.getMonth(), datCurrentDate.getDate()) - Date.UTC(datCSQGeneratedDate.getFullYear(), datCSQGeneratedDate.getMonth(), datCSQGeneratedDate.getDate())) / (1000 * 60 * 60 * 24));
            if (intNumberDaysCOB > this.label.ViewPlanSummary_NoOfDaysCOB_ACE || intNumberDaysCSQ > this.label.ViewPlanSummary_NoOfDaysCOB_ACE) {

                this.boolShowCOBButton=true;
            } else {
                this.boolShowCOBButton=false;
            }
        }
        this.showCOBSpinner= false;

     }
     //this function will convert string date coming in response to the required format for UI
     lastUpdatedDate(){
         let lastUpdateDate = this.objCOBResponse.strCOBLastUpdateDate
         if(lastUpdateDate) {
            lastUpdateDate =  lastUpdateDate.split("-");
            this.strCOBLastUpdateDate = lastUpdateDate[1] + "/" + lastUpdateDate[2] + "/" + lastUpdateDate[0];

         }
     }
     //this function check strResponseType from response and show Yes,No or Unknown based on response
     duplicateCoverage(){
        const strResponseType = this.objCOBResponse.strResponseType
        this.boolShowNewCaseLink = true
        if(strResponseType){
            if(strResponseType === 'Y'){
                this.strDuplicateCoverage = 'Yes';
                this.boolShowNewCaseLink = false;
            } else if(strResponseType === 'N') {
                this.strDuplicateCoverage = 'No'
            } else if(strResponseType === 'U') {
                this.strDuplicateCoverage = 'Unknown'
            } else {
                //Do Nothing
            }
        } else if(strResponseType === '') {
            this.strDuplicateCoverage = 'Unknown'
        } else {
            //Do Nothing
        }
     }
     //this function creates request for API Callout
    createRequestForCOBCallout(){
        const strGroup = this.objViewPlanSummaryResult.strGroupNumber;
        const strCorp = this.objViewPlanSummaryResult.strCorporationCode;
        const strSub = this.objViewPlanSummaryResult.strSubscriberId;
        const strGrpSecNumber = this.objViewPlanSummaryResult.strGroupSectionNumber;
        const strCMID = this.objViewPlanSummaryResult.objViewEmployerGroupWrapper.strCMID;
        const objCOBReqParams = {
            "subscriberId": strSub,
            "groupNumber": strGroup,
            "corporationCode": strCorp,
            "groupSectionNumber": strGrpSecNumber,
            "memberId": strCMID
        };
        this.objCOBReqParams = JSON.stringify(objCOBReqParams)
        this.fetchCOBDetails()
    }
    //this function will listen from plan summary cmp when the HCD loads once data is available then listener will be removed
    fetchDataFromPlanSummaryEvent =(objCOBData) =>{
        const objResponseData = BaseLWC.fetchComponentData(objCOBData, 'PlanCardDetails_ACE', true);
        if (BaseLWC.isNotUndefinedOrNull(objResponseData) && BaseLWC.isNotUndefinedOrNull(objResponseData.objParameters)
            && objResponseData.objParameters.strParentTabId && objResponseData.objParameters.strParentTabId === this.objTabData.tabId
            && BaseLWC.isNotUndefinedOrNull(objResponseData.objParameters.objMessage)) {
                window.removeEventListener(this.strPlanSummaryEvent, this.fetchDataFromPlanSummaryEvent);
                                this.boolSpinner = true;
                this.objViewPlanSummaryResult = objResponseData.objParameters.objMessage.objSelectedPlanDetails
                if(this.objViewPlanSummaryResult.boolIsLineOfBusinessFEP) {
                    this.boolIsLineOfBusinessFEP = true;

                } else {
                    this.boolIsLineOfBusinessFEP = false;
                    this.createRequestForCOBCallout()
                }

                if(this.objViewPlanSummaryResult.strAceLineOfBusiness === this.label.Government_Medicare_Sup_Label_ACE){
                    this.boolIsGovMedSupp = true;
                }

                if(this.boolIsLineOfBusinessFEP || this.boolIsGovMedSupp){
                    this.boolHideCOBCard =true;
                }
                

            }

    }
    //this function wll be called from refresh button and it will initiate callout again
    refreshComponent() {
        this.boolSpinner = true;
        this.showCOBSpinner = true;
        this.showNewCaseSpinner = true;
        this.boolCOBDataAvailable = false;
        this.fetchCOBDetails();
    }
    /**
     * Method to Set URL for Launch COB and Create Case Button.
     *
     * @param event To access event information.
     */
    showURL = (event => {
        const buttonName = event.currentTarget.title;
        const objParameterData = {
            buttonName : buttonName,
            strDuplicateCoverage : this.strDuplicateCoverage
        };
        const strCOBButtonDestinationId = this.label.cobCardButtonEventName + '_' + this.objTabData.tabId;
        BaseLWC.fireCustomEvent(this.label.cobCardButtonEventName, objParameterData, strCOBButtonDestinationId,
            true, this.objTabData.tabId);
    })

    disconnectedCallback() {
        if(this.objTabData.tabId) {
            window.removeEventListener(this.strPlanSummaryEvent, this.fetchDataFromPlanSummaryEvent);
            window.removeEventListener(this.strPlanChangedCustomEvent, this.fetchDataFromPlanChangedCustomEvent)
                    }
    }

}