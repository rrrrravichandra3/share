import {LightningElement,api,wire,track} from 'lwc';
import {getPicklistValues,getObjectInfo} from 'lightning/uiObjectInfoApi';
import CreateCasePage_IdCardRequest_ACE from '@salesforce/label/c.CreateCasePage_IdCardRequest_ACE';
import IDCardRecipient_ACE from '@salesforce/label/c.IDCardRecipient_ACE';
import IDCardDeliveryMethod_ACE from '@salesforce/label/c.IDCardDeliveryMethod_ACE';
import IDCardRequiredError_ACE from '@salesforce/label/c.IDCardRequiredError_ACE';
import IDCardCaseOrigin_ACE from '@salesforce/label/c.IDCardCaseOrigin_ACE';
import IDCardEmailToMember_ACE from '@salesforce/label/c.IDCardEmailToMember_ACE';
import IDCardEmailToProv_ACE from '@salesforce/label/c.IDCardEmailToProv_ACE';
import IDCardCardType_ACE from '@salesforce/label/c.IDCardCardType_ACE';
import IDCardFaxToMember_ACE from '@salesforce/label/c.IDCardFaxToMember_ACE';
import IDCardStatus_ACE from '@salesforce/label/c.IDCardStatus_ACE';
import IDCardSUBStatus_ACE from '@salesforce/label/c.IDCardSUBStatus_ACE';
import IDCardFaxNotAvailable_ACE from '@salesforce/label/c.IDCardFaxNotAvailable_ACE';
import IDCardFaxToProvider_ACE from '@salesforce/label/c.IDCardFaxToProvider_ACE';
import IDCardSupressLabels_ACE from '@salesforce/label/c.IDCardSupressLabels_ACE';
import IDCardMailToMember_ACE from '@salesforce/label/c.IDCardMailToMember_ACE';
import IDCardMember_ACE from '@salesforce/label/c.IDCardMember_ACE';
import IDCardAddress_ACE from '@salesforce/label/c.IDCardAddress_ACE';
import IDCardAlternateAddress_ACE from '@salesforce/label/c.IDCardAlternateAddress_ACE';
import IDCardState_ACE from '@salesforce/label/c.IDCardState_ACE';
import IDCardZipCodeError_ACE from '@salesforce/label/c.IDCardZipCodeError_ACE';
import IDCardProviderName_ACE from '@salesforce/label/c.IDCardProviderName_ACE';
import IDCardFaxNumber_ACE from '@salesforce/label/c.IDCardFaxNumber_ACE';
import IDCardFaxCaseCreatedSuccessMessage_ACE from '@salesforce/label/c.IDCardFaxCaseCreatedSuccessMessage_ACE';
import IDCardInCareOf_ACE from '@salesforce/label/c.IDCardInCareOf_ACE';
import IDCardCity_ACE from '@salesforce/label/c.IDCardCity_ACE';
import IDCardZipCode_ACE from '@salesforce/label/c.IDCardZipCode_ACE';
import IDCardCaseSubmited_ACE from '@salesforce/label/c.IDCardCaseSubmited_ACE';
import IDCardType_ACE from '@salesforce/label/c.IDCardType_ACE';
import IDCardSubType_ACE from '@salesforce/label/c.IDCardSubType_ACE';
import IDCardPendedCaseMessagePRefix_ACE from '@salesforce/label/c.IDCardPendedCaseMessagePRefix_ACE';
import IDCardPendedCaseMessageSuffix_ACE from '@salesforce/label/c.IDCardPendedCaseMessageSuffix_ACE';
import IDCardIntegrationError_ACE from '@salesforce/label/c.IDCardIntegrationError_ACE';
import RetailIdCardWarning_ACE from '@salesforce/label/c.RetailIdCardWarning_ACE'; 
import RetailIdCardPCPWarning_ACE from '@salesforce/label/c.RetailIdCardPCPWarning_ACE'; 
import case_object from '@salesforce/schema/Case';
import submitCaseFromIdCard from '@salesforce/apexContinuation/IdCardController_ACE.submitCaseFromIdCard';
import getIdCardTypeForMembers from '@salesforce/apexContinuation/IdCardController_ACE.getIdCardTypeForMembers';
import getRetailIDCardCallout from '@salesforce/apexContinuation/IdCardController_ACE.getRetailIDCardCallout';
import submitRetailIDCard from '@salesforce/apexContinuation/IdCardController_ACE.submitRetailIDCard';
import SelfServiceRecipient_Field from '@salesforce/schema/Case.SelfServiceRecipient_ACE__c';
import DeliveryMethod_Field from '@salesforce/schema/Case.DeliveryMethod_ACE__c';
import CaseOrigin_Field from '@salesforce/schema/Case.Origin';
import Status_Field from '@salesforce/schema/Case.Status';
import SubStatus_Field from '@salesforce/schema/Case.Sub_Status_ACE__c';
import {getRecord} from 'lightning/uiRecordApi';
import InquirerName_Field from '@salesforce/schema/InteractionLog_ACE__c.InquirerName_ACE__c';
import InquirerNameRelationship_Field from '@salesforce/schema/InteractionLog_ACE__c.Inquirer_Relationship_ACE__c';
import RecordTypeFormula_Field from '@salesforce/schema/InteractionLog_ACE__c.RecordTypeFormulaACE__c';
import CallType_Field from '@salesforce/schema/InteractionLog_ACE__c.Call_Type_ACE__c';
import IVRAuthenticated_Field from '@salesforce/schema/InteractionLog_ACE__c.IVRAuthenticated_ACE__c';
import ProviderInformationDetails_Field from '@salesforce/schema/InteractionLog_ACE__c.ProviderInformationDetails_ACE__c';
import State_Field from '@salesforce/schema/Case.StateIdCard_ACE__c';

export default class IdcardlightningwebcomponentACE extends LightningElement {
    @track showModal = false;
    /*Api Variables*/
    @api currentTabId;
    @api strPlanSummaryData;
    @api recordTypeId;
    @api objCommunicationPreferenceData;
    @api strEmail;
    @api strLanguage;
    @api strAccountId;
    @api strInteractionLogId;
    @api boolFEPIndicator;
    @api boolBoeingDrugOnlyPlan;
    @api objPCPDetailsSubtab;
    //CEAS-62221
    @api boolIsProvider;
    lstRecipient = [];
    lstDeliveryMethod = [];
    /*List Variables*/
    lstDeliveryMethodBackup = [];
    lstFamilyMemberNameOfOrderCard = [];
    objRequestForCardType = [];
    listOfFamilyname = [];
    lstHeaderOrder = [];
    lstStatus = [];
    lstCardType = [];
    lstState = [];
    lstSubStatus = [];
    lstCaseOrigin = [];
    lstsupressedLables = [];
    lstRetailIDCardData = [];
    strPhoneError = 'Please Enter Valid Phone Number';
    caseOriginDefaultValues = '';
    caseOriginDefaultValuesBackup = '';
    strUniqueIdentifier = '';
    strCaseIdEmail = '';
    strCaseAccount = '';
    strCaseURL = '';
    objFamilyCardTypeHeader;
    recipientDefaultValue;
    recipientBoeingDefaultValue;
    deliveryMethodDefaultValue;
    strAddressOfMember = '';
    strFaxNumber;
    strProvider = '';
    strAlternateAddressOfMember = '';
    strIdCardLevelIndicator;
    SubstatusDefaultValue = '';
    strSubscriberName = '';
     strErrorMessageFor9Member = ': Please note, only 8 members may be selected at one time.';
     strErrorMessageFor9MemberOnSelect = 'The maximum of 8 members have been selected. You may submit this request, then select any additional members in a second request.';
    strCMIDUI = '';
    statusDefaultValue;
    strCardTypeDefaultValue = '';
    objPlanData;
    isSubmitResultText;
    caseNumbers;
    caseNumbersPended;
    caseType;
    caseSubtype;
    strInCareOf = '';
    strADDRESS = '';
    strCity = '';
    strState = '';
    strZipCode = '';
    strInquirerName = '';
    strInquirerRelationship = '';
    strRecordTypeName = '';
    strEmailDefault = '';
    strErrorSectionName = '';
    strErrorSection = '';
    statusEmailDefaultValue = 'Closed';
    strFaxNumberFormatted = '';
    strProviderInfoIdCard = '';
    strMIDRetail = '';
    boolSupressedLables = false;
     boolShowMemberMessage=false;
     boolFepMoreThan8Member=false;
    boolEmailStatus = false;
    boolEmailCondition = false;
    isLoaded = false;
    boolStatusDisabled = false;
    isSubmitResultSuccess = false;
    boolIsRecipientAndMail = false;
    boolFaxIsRecipientAndMail = false;
    boolfaxCondition = false;
    boolEmailIsRecipientAndMail = false;
    boolTempToast = false;
    boolFaxIsRecipientAndProv = false;
    boolEmailIsRecipientAndProv = false;
    isSubmitEnabled = true;
    boolSubstatus = false;
    boolzipError = false;
    boolMailAddress = true;
    boolAlteranteMailAddress = false;
    boolAddressNotAvailable = false;
    isError = false;
    isResultPendedSuccess = false;
    isResultPendedSuccessWithNoCases = false;
    isResultSuccess = false;
    boolCaseOrigin = false;
    boolrefresh = true;
    boolApiError = false;
    boolStandAloneCards = false;
    boolEmailDefault = true;
    isApiError = false;
    isdeliveryMethodDefault = false;
    boolIsRetail = false;
    boolPCPMGNull = false;
    boolHMO = true;

    /*Map Variables*/
    mapOfFamilyMemberAndMemberNumber = {};
    MapOfFamilyMemberNameAndMemberId = {};
    MapOfFamilyMemberNumberAndMid = {};
    MapOfFamilyMemberIdAndCMID = {};
    MapOfDataforEmail = {};


    label = {
        CreateCasePage_IdCardRequest_ACE,
        IDCardRecipient_ACE,
        IDCardDeliveryMethod_ACE,
        IDCardRequiredError_ACE,
        IDCardCaseOrigin_ACE,
        IDCardEmailToMember_ACE,
        IDCardEmailToProv_ACE,
        IDCardCardType_ACE,
        IDCardFaxToMember_ACE,
        IDCardStatus_ACE,
        IDCardSUBStatus_ACE,
        IDCardFaxNotAvailable_ACE,
        IDCardFaxToProvider_ACE,
        IDCardSupressLabels_ACE,
        IDCardMailToMember_ACE,
        IDCardMember_ACE,
        IDCardAddress_ACE,
        IDCardAlternateAddress_ACE,
        IDCardState_ACE,
        IDCardZipCodeError_ACE,
        IDCardProviderName_ACE,
        IDCardFaxNumber_ACE,
        IDCardFaxCaseCreatedSuccessMessage_ACE,
        IDCardInCareOf_ACE,
        IDCardCity_ACE,
        IDCardZipCode_ACE,
        IDCardCaseSubmited_ACE,
        IDCardType_ACE,
        IDCardSubType_ACE,
        IDCardPendedCaseMessagePRefix_ACE,
        IDCardPendedCaseMessageSuffix_ACE,
        IDCardIntegrationError_ACE,
        RetailIdCardWarning_ACE, 
        RetailIdCardPCPWarning_ACE
    };


    /*To Get Case Object Info*/
    @wire(getObjectInfo, {
        objectApiName: case_object
    })
    objectInfo;
    /*To Fetch Recipeint PickList Value*/
    @wire(getPicklistValues, {recordTypeId: '$recordTypeId',fieldApiName: SelfServiceRecipient_Field})
    recipientPicklistValues({error, data}) {
        if (data && data.values) {
            this.isError = false;
            const lstLocalRecipientValues = [];
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                //CEAS-55766
                if((this.strPlanSummaryData.strAceLineOfBusiness === 'Government-Medicare' && objType.value ==='Member') || (this.strPlanSummaryData.strAceLineOfBusiness!=='Government-Medicare')) {
                    lstLocalRecipientValues.push(objType);
                }
            }
            this.recipientDefaultValue = 'Member';
            this.recipientBoeingDefaultValue = 'Member';
            this.lstRecipient = lstLocalRecipientValues;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Fetch Case Origin PickList Value*/
    @wire(getPicklistValues, { recordTypeId: '$recordTypeId', fieldApiName: CaseOrigin_Field})
    originPicklistValues({error, data}) {
        if (data && data.values) {
            this.isError = false;
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocaloriginvalues = [];
            lstLocaloriginvalues.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocaloriginvalues.push(objType)
            }
            this.caseOriginDefaultValues = 'TELEPHONE';
            this.caseOriginDefaultValuesBackup = 'TELEPHONE';
            this.lstCaseOrigin = lstLocaloriginvalues;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    @wire(getPicklistValues, {recordTypeId: '$recordTypeId', fieldApiName: DeliveryMethod_Field})
    deliveryPicklistValues({error,data}) {
        if (data && data.values) {
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocalDeliveryMethodValues = [];
            lstLocalDeliveryMethodValues.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                //CEAS-55766
                if((this.strPlanSummaryData.strAceLineOfBusiness==='Government-Medicare' && objType.value==='Directed to Self-Service') || (this.strPlanSummaryData.strAceLineOfBusiness!=='Government-Medicare')) {
                    lstLocalDeliveryMethodValues.push(objType);
                }
            }
            this.deliveryMethodDefaultValue = 'Directed to Self-Service';
            this.lstDeliveryMethod = lstLocalDeliveryMethodValues;
            this.lstDeliveryMethodBackup = lstLocalDeliveryMethodValues;
            this.isError = false;
            this.showDisableSubmitButton()
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    @wire(getPicklistValues, {recordTypeId: '$recordTypeId',fieldApiName: Status_Field})
    statusPicklistValues({error,data}) {
        if (data && data.values) {
            const lstLocalStatus = [];
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalStatus.push(objType);
            }
            this.statusDefaultValue = 'Closed';
            this.lstStatus = lstLocalStatus;
            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Fetch Sub Status PickList Value*/
    @wire(getPicklistValues, {recordTypeId: '$recordTypeId',fieldApiName: SubStatus_Field})
    subStatusPicklistValues({error,data}) {
        if (data && data.values) {
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocalSubStatus = [];
            lstLocalSubStatus.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalSubStatus.push(objType);
            }
            this.SubstatusDefaultValue = lstLocalSubStatus[0].label;
            this.lstSubStatus = lstLocalSubStatus;
            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Fetch State PickList Value*/
    @wire(getPicklistValues, {recordTypeId: '$recordTypeId',fieldApiName: State_Field})
    statePicklistValues({error,data}) {
        if (data && data.values) {
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocalstate = [];
            lstLocalstate.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalstate.push(objType);

            }
            this.strState = lstLocalstate[0].label;
            this.lstState = lstLocalstate;
            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Get Interaction Log Id and Other Paramters*/
    @wire(getRecord, {recordId: '$strInteractionLogId',fields: [InquirerName_Field, InquirerNameRelationship_Field, RecordTypeFormula_Field, CallType_Field, IVRAuthenticated_Field, ProviderInformationDetails_Field]})
    wiredInteractionRecord({error,data}) {
        if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else if (data) {
            if (data.recordTypeInfo !== undefined && data.recordTypeInfo !== null) {
                let strDefaultCaseOrigin = '';
                this.strRecordTypeName = data.recordTypeInfo.name;
                if (data.recordTypeInfo.name === 'Secure Message') {
                    strDefaultCaseOrigin = 'SECURE MESSAGING';
                } else if (data.recordTypeInfo.name === 'Letter') {
                    strDefaultCaseOrigin = 'LETTER';
                } else if (data.recordTypeInfo.name === 'Email') {
                    strDefaultCaseOrigin = 'EMAIL';
                } else if (data.recordTypeInfo.name === 'Chat') {
                    strDefaultCaseOrigin = 'WEB CHAT';
                } else if (data.recordTypeInfo.name === 'Call') {
                    if (data.fields.Call_Type_ACE__c !== undefined && data.fields.Call_Type_ACE__c !== null &&
                        data.fields.Call_Type_ACE__c.value === 'Inbound') {
                        if (data.fields.IVRAuthenticated_ACE__c !== undefined && data.fields.IVRAuthenticated_ACE__c !== null &&
                            data.fields.IVRAuthenticated_ACE__c.value === 'Yes' || data.fields.IVRAuthenticated_ACE__c.value === 'Y') {
                            strDefaultCaseOrigin = 'IVR DEFAULT';
                        } else {
                            strDefaultCaseOrigin = 'TELEPHONE';
                        }
                    } else if (data.fields.Call_Type_ACE__c !== undefined && data.fields.Call_Type_ACE__c !== null &&
                        data.fields.Call_Type_ACE__c.value === 'Outbound') {
                        strDefaultCaseOrigin = 'OUTBOUND CALL';
                    } else {
                        /*Do Nothing*/
                    }
                } else {
                    if (data.recordTypeInfo.name === 'Internal') {
                        strDefaultCaseOrigin = 'TELEPHONE';
                    } else {
                        strDefaultCaseOrigin = data.recordTypeInfo.name.toUpperCase();
                    }
                }
                this.caseOriginDefaultValues = strDefaultCaseOrigin;
                this.caseOriginDefaultValuesBackup = strDefaultCaseOrigin;
            }
            if (data.fields !== undefined && data.fields !== null && data.fields.ProviderInformationDetails_ACE__c.value !== undefined &&
                data.fields.ProviderInformationDetails_ACE__c.value !== null) {
                this.strProviderInfoIdCard = JSON.parse(data.fields.ProviderInformationDetails_ACE__c.value);
            }
            if (data.fields !== undefined && data.fields !== null && data.fields.Inquirer_Relationship_ACE__c.value !== undefined &&
                data.fields.Inquirer_Relationship_ACE__c.value !== null) {
                this.strInquirerRelationship = data.fields.Inquirer_Relationship_ACE__c.value.toUpperCase();
            }
            if (data.fields !== undefined && data.fields !== null && data.fields.Inquirer_Relationship_ACE__c.value !== undefined &&
                data.fields.InquirerName_ACE__c.value !== null) {
                this.strInquirerName = data.fields.InquirerName_ACE__c.value;
            }
            this.enableCaseOrigin();
        } else {
            /*do nothing*/
        }
    }
    constructor() {
        super();
        this.isLoaded = !this.isLoaded;
        this.showModal = true;
        this.isSubmitResultSuccess = false;
    }
    connectedCallback() {
        this.planSummaryValue();
        if(!this.boolBoeingDrugOnlyPlan) {
        this.handleLoad();
        } else {
            this.isLoaded = !this.isLoaded;
        }
    }
    enableCaseOrigin() {
        if (this.strInteractionLogId !== undefined && this.strInteractionLogId !== null) {
            if (this.caseOriginDefaultValues === 'TELEPHONE' && this.strRecordTypeName === 'Internal') {
                this.boolCaseOrigin = true;
            } else {
                this.boolCaseOrigin = false;
            }
        } else {
            this.boolCaseOrigin = true;
        }
    }
    /*To handle Activity After the Load of Picklists */
    handleLoad() {
        //CEAS-44374       
        //Checking if the Line of Business is Retail
        if (this.strPlanSummaryData.strAceLineOfBusiness === 'Retail') {
            if(!this.boolPCPMGNull) {
                getRetailIDCardCallout({strMID: this.strPlanSummaryData.objViewEmployerGroupWrapper.strMid,strPolicyID: this.strPlanSummaryData.strPolicyId}).then(result => {
                        if (result !== undefined && result !== null && result.lstMembers !== undefined 
                            && result.strStatusCode !== undefined && result.strStatusCode !== null && result.strStatusCode === '200'
                            && result.lstMembers !== undefined && result.lstMembers !== null && result.objRetailCardHeader !== undefined 
                            && result.objRetailCardHeader !== null) {
                                
                                //Setting API Errors to false
                                this.boolApiError = false;
                                this.isApiError = false;
                                this.isError = false;
                                this.boolIsRetail = true;
                                this.boolHMO = result.boolHMO;
                                this.strMIDRetail = this.strPlanSummaryData.objViewEmployerGroupWrapper.strMid;
                                //Assigning all values to UI
                                this.listOfFamilyname = result.lstMembers;
                                this.objFamilyCardTypeHeader = result.objRetailCardHeader; 
                                //Adding shading to alternate rows of family member
                                for(let iterator=0; iterator<this.listOfFamilyname.length; iterator++) {
                                    if(iterator % 2 === 0) {
                                        this.listOfFamilyname[iterator].boolShaded = false;
                                    } else {
                                        this.listOfFamilyname[iterator].boolShaded = true;
                                    }
                                }
                                //Populating ID Card Types 
                                this.lstCardType = [];
                                const objTypeNull = {
                                    label: '--None--',
                                    value: ''
                                };
                                this.lstCardType.push(objTypeNull);
                                let objCardType = {};
                                if(result.lstMembers.length > 0) {
                                    objCardType = {
                                        label: result.lstMembers[0].lstCheckBoxWrapper[0].strCardType,
                                        value: result.lstMembers[0].lstCheckBoxWrapper[0].strCardType
                                    };
                                }
                                this.lstCardType.push(objCardType);
                            } else {
                                    this.isApiError = true;
                            }
                            for(let i=0; i < this.strPlanSummaryData.lstFamilyWrapper.length; i++) {
                                if(this.strPlanSummaryData.strMemberId === this.strPlanSummaryData.lstFamilyWrapper[i].strMemberId) {
                                    if(this.strPlanSummaryData.lstFamilyWrapper[i].strRelation === 'Subscriber') {
                                        this.strIdCardLevelIndicator = 'S';
                                    } else {
                                        this.strIdCardLevelIndicator = 'M';
                                    }
                                }
                            }
                            this.isLoaded = !this.isLoaded;
                            this.enableCaseOrigin();
                        })
                .catch(()=> {
                    this.methodCatch();
                });
            }
        } else if (this.strPlanSummaryData.strAceLineOfBusiness === 'GMS' || this.strPlanSummaryData.strAceLineOfBusiness === 'FEP') {
            /*To get the Available Card Types for the Member */
            //CEAS-50627 begin
            for (let i = 0; i < this.lstFamilyMemberNameOfOrderCard.length; i++) {
                const intMemberNumber = this.lstFamilyMemberNameOfOrderCard[i].split('_')[1];
                this.lstFamilyMemberNameOfOrderCard[i] = this.mapOfFamilyMemberAndMemberNumber[intMemberNumber];
            }
            //CEAS-50627 begin
            getIdCardTypeForMembers({
                    strRequestWrapperForCardType: this.objRequestForCardType,
                    lstFamilymembers: this.lstFamilyMemberNameOfOrderCard,
                    mapOfFamilyMemberAndMemberNumber: this.mapOfFamilyMemberAndMemberNumber,
                    boolCheckAvailblity: false,
                    strOldFamilyDetails: null,
                    boolFEPIndicator: this.boolFEPIndicator
                }).then(result => { 
                    if (result !== undefined && result !== null && result.lstFamilyCardWrapper !== undefined && result.lstFamilyCardWrapper !== null &&
                        result.objFamilyCardHeader !== undefined && result.objFamilyCardHeader !== null && result.strHeaderAndOrderValues !== undefined && 
                        result.strHeaderAndOrderValues !== null) {
                        this.boolApiError = false;
                        this.isApiError = false;
                        this.boolIsRetail = false;
                        this.listOfFamilyname = result.lstFamilyCardWrapper;
                        this.lstHeaderOrder = JSON.parse(result.strHeaderAndOrderValues);
                        //Setting Order only for GMS
                        if(this.strPlanSummaryData.strAceLineOfBusiness === 'GMS') { 
                            //Setting order
                            const lstNewHeader=[];
                            for(let i=0;i<this.lstHeaderOrder.length;i++){
                                if(result.objFamilyCardHeader.lstOfHeader.indexOf(this.lstHeaderOrder[i])>-1){
                                    lstNewHeader.push(this.lstHeaderOrder[i]);
                                }
                            }
                            result.objFamilyCardHeader.lstOfHeader=[...lstNewHeader];
                            //Setting order end
                        }
                        for(let iterator=0; iterator<this.listOfFamilyname.length; iterator++) {
                            if(iterator % 2 === 0) {
                                this.listOfFamilyname[iterator].boolShaded = false;
                            } else {
                                this.listOfFamilyname[iterator].boolShaded = true;
                            }
                        }
                        if(this.boolFEPIndicator && this.listOfFamilyname!==undefined && this.listOfFamilyname!==null && this.listOfFamilyname.length>=9){
                            this.boolShowMemberMessage=true;
                        }
                        this.objFamilyCardTypeHeader = result.objFamilyCardHeader;
                        if(this.boolBoeingDrugOnlyPlan === false) {
                            this.setStatusForSuppressAndExisting();
                            this.setStatusForSuppressAndExistingLabels();
                        }
                        this.strIdCardLevelIndicator = result.strIdCardLevelIndicator;
                        this.isError = false;
                        this.lstCardType = [];
                        const objTypeNull = {
                            label: '--None--',
                            value: ''
                        };
                        //Setting Order only for GMS
                        if(this.strPlanSummaryData.strAceLineOfBusiness === 'GMS') {
                            //Setting order
                            result.lstFamilyCardWrapper.forEach(el=>{
                                if(el.lstCheckBoxWrapper && el.lstCheckBoxWrapper.length){
                                    const lstNewCheckBoxWrapper=[];
                                    for(let i=0;i<this.lstHeaderOrder.length;i++){
                                        for(let j=0;j<el.lstCheckBoxWrapper.length;j++){
                                            const strCardType=el.lstCheckBoxWrapper[j].strCardType.replace(/\//g,'/ ');
                                            if(strCardType===this.lstHeaderOrder[i]){
                                                lstNewCheckBoxWrapper.push(el.lstCheckBoxWrapper[j]);
                                                break;
                                            }
                                        }
                                        
                                    }
                                    el.lstCheckBoxWrapper=[...lstNewCheckBoxWrapper];
                                }
                            });
                            //Setting order end 
                        }
                        this.lstCardType.push(objTypeNull);
                        if (result.lstFamilyCardWrapper.length > 0) {
                            for (let i = 0; i < result.lstFamilyCardWrapper.length; i++) {
                                if (result.lstFamilyCardWrapper[i].strCmid === this.strCMIDUI &&
                                    result.lstFamilyCardWrapper[i].lstCheckBoxWrapper != null && result.lstFamilyCardWrapper[i].lstCheckBoxWrapper !== undefined &&
                                    result.lstFamilyCardWrapper[i].lstCheckBoxWrapper.length > 0) {
                                    for (let k = 0; k < result.lstFamilyCardWrapper[i].lstCheckBoxWrapper.length; k++) {
                                        if(result.lstFamilyCardWrapper[i].lstCheckBoxWrapper[k].strCardType !== 'Supplemental Medical' 
                                        && result.lstFamilyCardWrapper[i].lstCheckBoxWrapper[k].strCardType !== 'Supplemental Vision'
                                        && result.lstFamilyCardWrapper[i].lstCheckBoxWrapper[k].strCardType !== 'Supplemental Pharmacy') {
                                            this.lstCardType.push({
                                                label: result.lstFamilyCardWrapper[i].lstCheckBoxWrapper[k].strCardType,
                                                value: result.lstFamilyCardWrapper[i].lstCheckBoxWrapper[k].strCardType
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        this.isApiError = true;
                    }
                    this.enableCaseOrigin();
                    this.isLoaded = !this.isLoaded;
                })
                .catch(() => {
                    this.methodCatch();
                });
        } else if(this.strPlanSummaryData.strAceLineOfBusiness === 'Government-Medicare') {
            this.enableCaseOrigin();
            this.isLoaded = !this.isLoaded;
        } else {
            //Do Nothing
        }
    }
    
    //Method for catch method calls
    methodCatch() {
        this.enableCaseOrigin();
        this.isApiError = true;
        this.isLoaded = !this.isLoaded;
    }
    /*Method To Set Status For Supressed And Existing Cards */
    setStatusForSuppressAndExisting() {
        try {
            if (this.recipientDefaultValue === 'Member' && this.deliveryMethodDefaultValue === 'Mail') {
                const lstfamilyMemberNew = this.listOfFamilyname;
                let boolIsSupressed = false;
                let boolIsExisting = false;
                for (let i = 0; i < lstfamilyMemberNew.length; i++) {
                    for (let k = 0; k < lstfamilyMemberNew[i].lstCheckBoxWrapper.length; k++) {
                        if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType === 'Supplemental Medical'
                        || lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType === 'Supplemental Vision'
                        || lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType === 'Supplemental Pharmacy') {
                            if (!lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardDisabled) {
                                if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisSupressed) {
                                    boolIsSupressed = true;
                                }
                                if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisExisting) {
                                    boolIsExisting = true;
                                }
                            }
                        } else { 
                            if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisSupressed) {
                                boolIsSupressed = true;
                            }
                            if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisExisting) {
                                boolIsExisting = true;
                            }
                        }
                    }
                }
                if (boolIsSupressed && boolIsExisting) {
                    this.statusDefaultValue = 'Pended';
                    this.SubstatusDefaultValue = 'Suppressed & Existing Request';
                    this.boolSubstatus = true;
                    this.boolStatusDisabled = true;
                } else if (boolIsSupressed && !boolIsExisting) {
                    this.statusDefaultValue = 'Pended';
                    this.SubstatusDefaultValue = 'Suppressed';
                    this.boolSubstatus = true;
                    this.boolStatusDisabled = true;
                } else if (!boolIsSupressed && boolIsExisting) {
                    this.statusDefaultValue = 'Pended';
                    this.SubstatusDefaultValue = 'Existing Request';
                    this.boolSubstatus = true;
                    this.boolStatusDisabled = true;
                } else {
                    this.statusDefaultValue = 'Closed';
                    this.SubstatusDefaultValue = this.lstSubStatus[0].label;
                    if (this.SubstatusDefaultValue !== '' && this.SubstatusDefaultValue !== this.lstSubStatus[0].label) {
                        this.boolSubstatus = true;
                    } else {
                        this.boolSubstatus = false;
                    }
                    this.boolStatusDisabled = false;
                }
            } else {
                this.statusDefaultValue = 'Closed';
                this.SubstatusDefaultValue = this.lstSubStatus[0].label;
                this.boolSubstatus = false;
            }
        } catch (objexception) {
            /*Do Nothing*/
        }
    }
    /*Method To Set Labels For Supressed And Existing Cards */
    setStatusForSuppressAndExistingLabels() {
        const supressedLables = [];
        try {
            if (this.recipientDefaultValue === 'Member' && this.deliveryMethodDefaultValue === 'Mail') {
                const lstfamilyMemberNew = this.listOfFamilyname;
                let boolLabelDentalCardType = false;
                let boolLabelPharmacyCardType =false;
                for (let i = 0; i < lstfamilyMemberNew.length; i++) {
                    for (let k = 0; k < lstfamilyMemberNew[i].lstCheckBoxWrapper.length; k++) {
                        if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType === 'Dental'
                             && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisExisting){
                            boolLabelDentalCardType = true;
                        } else if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType ==='Pharmacy'
                                   && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisExisting) {
                           boolLabelPharmacyCardType = true;
                        } else {
                            //do nothing
                        }
                    }
                }
                for (let i = 0; i < lstfamilyMemberNew.length; i++) {
                    let strLabels = '';
                    for (let k = 0; k < lstfamilyMemberNew[i].lstCheckBoxWrapper.length; k++) {
                        if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType === 'Supplemental Medical'
                        || lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType === 'Supplemental Vision'
                        || lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType === 'Supplemental Pharmacy') { 
                            if (!lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardDisabled) {
                                if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisSupressed) {
                                    strLabels += lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType + ' (Suppressed); ';
                                }
                                if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisExisting) {
                                    strLabels += lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType + ' (Existing Request); ';
                                }
                            }
                        } else {
                            if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisSupressed) {
                                strLabels += lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType + ' (Suppressed); ';
                            }
                            if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisExisting &&
                                lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType !=='Dental' &&
                                lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType !=='Pharmacy') {
                                strLabels += lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType + ' (Existing Request); ';
                            }
                            if (boolLabelDentalCardType && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType ==='Dental') {
                                strLabels += 'Dental' + ' (Existing Request); ';
                            }
                            if (boolLabelPharmacyCardType && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType ==='Pharmacy') {
                                strLabels += 'Pharmacy' + ' (Existing Request); ';
                            }
                        }
                    }
                    if (strLabels !== '') {
                        strLabels = lstfamilyMemberNew[i].strMemberNameUI + ': ' + strLabels;
                        if (strLabels != null && strLabels.endsWith('; ')) {
                            strLabels = strLabels.substring(0, strLabels.length - 2);
                        }
                        supressedLables.push(strLabels);
                    }
                }
                if (supressedLables.length > 0) {

                    this.lstsupressedLables = supressedLables;
                    this.boolSupressedLables = true;
                } else {
                    this.boolSupressedLables = false;
                }

            } else {
                this.boolSupressedLables = false;
            }
        } catch (objexception) {
            /*Do Nothing*/
        }
    }
    /*Method To Get The Case Object Details */
    getCaseObject() {
        const objCase = {
            Type: 'Member Management',
            Sub_Type_ACE__c: 'ID Card Request',
            SubscriberID_ACE__c: this.objPlanData.strSubscriberID,
            GroupNumber_ACE__c: this.objPlanData.strGroupNumber,
            GroupName_ACE__c: this.objPlanData.strGroupName,
            SectionNumber_ACE__c: this.objPlanData.strSectionNumber,
            CorporationCode_ACE__c: this.objPlanData.strCorporationCode,
            CMID_ACE__c: this.objPlanData.strCMID,
            GroupCostCenter_ACE__c: this.objPlanData.strGroupCostCenter,
            Policy_ID_ACE__c: this.objPlanData.strPolicyId,
            Plan_Effective_Date_ACE__c: this.objPlanData.strEffectiveDate,
            Plan_Termination_Date_ACE__c: this.objPlanData.strTerminationDate,
            Account_Number_ACE__c: this.objPlanData.strAccountNumber,
            Multiplan_ACE__c: this.objPlanData.strMultiPlan,
            Product_Type_ACE__c: this.objPlanData.strProductType,
            AddonServices_ACE__c: this.objPlanData.strAddOnServices,
              CaseCreationSource_ACE__c:'PatentCard/IdCard',
            DeliveryMethod_ACE__c: this.deliveryMethodDefaultValue,
            SelfServiceRecipient_ACE__c: this.recipientDefaultValue,
            Status: this.statusDefaultValue,
            Sub_Status_ACE__c: this.SubstatusDefaultValue,
            Address_ACE__c: '',
            City_ACE__c: '',
            State_ACE__c: '',
            RecordTypeId: this.recordTypeId,
            ZipCode_ACE__c: '',
            AccountId: this.strAccountId,
            InquirerName_ACE__c: this.strInquirerName,
            //Fix fieldName
            InquirerRelationship_ACE__c: this.strInquirerRelationship,
            InCareOf_ACE__c: '',
            CardTypeValues_ACE__c: '',
            IdCardLevelIndicator_ACE__c: '',
            UniqueIdentifierIDCard_ACE__c: '',
            Origin: this.caseOriginDefaultValues,
            Interaction_Log_Id_ACE__c: this.strInteractionLogId
        };
        //CEAS-62221
        if(this.boolIsProvider === true){
            objCase.InquirerRelationship_ACE__c = 'Provider';
        }
        objCase.SecureGroupName_ACE__c =  this.strPlanSummaryData !== null && this.strPlanSummaryData !== undefined && this.strPlanSummaryData.securedGroupNecessaryRole && this.strPlanSummaryData.securedGroupNecessaryRole !== null && this.strPlanSummaryData.securedGroupNecessaryRole !== undefined ? this.strPlanSummaryData.securedGroupNecessaryRole : '';
        objCase.IsCbcApiCallAvailable_ACE__c =false;
        objCase.IsAccountsAPICallAvailable_ACE__c =false;
        if(this.objPlanData.boolIsAccountsAPICallAvailable && this.objPlanData.boolIsAccountsAPICallAvailable=== true) {
            objCase.IsAccountsAPICallAvailable_ACE__c = this.objPlanData.boolIsAccountsAPICallAvailable;
        }
        if(this.objPlanData.boolIsCbcApiCallAvailable && this.objPlanData.boolIsCbcApiCallAvailable=== true) {
            objCase.IsCbcApiCallAvailable_ACE__c = this.objPlanData.boolIsCbcApiCallAvailable;
        }
         if( this.objPlanData.strAceLineOfBusiness!==undefined && this.objPlanData.strAceLineOfBusiness !==null && this.objPlanData.strAceLineOfBusiness !=='') {
            objCase.LineOfBusiness_ACE__c = this.objPlanData.strAceLineOfBusiness.toUpperCase();
            if(this.objPlanData.strSourceSystemName!==undefined && this.objPlanData.strSourceSystemName !==null && this.objPlanData.strSourceSystemName !=='' && this.objPlanData.strAceLineOfBusiness.toUpperCase()==='RETAIL') {
                        objCase.Source_System_Name_ACE__c = this.objPlanData.strSourceSystemName;
                    }
        }
        if (this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Member') {
            objCase.Fax_ACE__c = this.strFaxNumber;
            objCase.CardTypeValues_ACE__c = this.strCardTypeDefaultValue;
            if (this.strFaxNumber !== undefined && this.strFaxNumber !== null && this.strFaxNumber !== '' && this.strFaxNumber.length === 10) {
                this.strFaxNumberFormatted = '(' + this.strFaxNumber.substr(0, 3) + ') ' + this.strFaxNumber.substr(3, 3) + '-' + this.strFaxNumber.substr(6, this.strFaxNumber.length);
            }
        }
        if (this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Provider') {
            objCase.ProviderName_ACE__c = this.strProvider;
            objCase.Fax_ACE__c = this.strFaxNumber;
            objCase.CardTypeValues_ACE__c = this.strCardTypeDefaultValue;
            if (this.strFaxNumber !== undefined && this.strFaxNumber !== null && this.strFaxNumber !== '' && this.strFaxNumber.length === 10) {
                this.strFaxNumberFormatted = '(' + this.strFaxNumber.substr(0, 3) + ') ' + this.strFaxNumber.substr(3, 3) + '-' + this.strFaxNumber.substr(6, this.strFaxNumber.length);
            }
        }
        if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Member') {
            objCase.Email_ACE__c = this.strEmail;
            objCase.CardTypeValues_ACE__c = this.strCardTypeDefaultValue;
        }
        if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Provider') {
            objCase.ProviderName_ACE__c = this.strProvider;
            objCase.Email_ACE__c = this.strEmail;
            objCase.CardTypeValues_ACE__c = this.strCardTypeDefaultValue;
        }
        if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
            objCase.Address_ACE__c = this.objPlanData.Address_ACE__c;
            objCase.City_ACE__c = this.objPlanData.City_ACE__c;
            objCase.State_ACE__c = this.objPlanData.State_ACE__c;
            objCase.ZipCode_ACE__c = this.objPlanData.ZipCode_ACE__c;
            objCase.IdCardLevelIndicator_ACE__c = this.strIdCardLevelIndicator;
            objCase.InCareOf_ACE__c = this.strInCareOf;
        }
        if (objCase.InquirerName_ACE__c === undefined || objCase.InquirerName_ACE__c === null || objCase.InquirerName_ACE__c === '') {
            objCase.InquirerName_ACE__c = this.strSubscriberName;
        }
        if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member' && this.boolAlteranteMailAddress) {
            objCase.Address_ACE__c = this.strADDRESS;
            objCase.City_ACE__c = this.strCity;
            objCase.State_ACE__c = this.strState;
            objCase.ZipCode_ACE__c = this.strZipCode;
            objCase.InCareOf_ACE__c = this.strInCareOf;
            objCase.IdCardLevelIndicator_ACE__c = this.strIdCardLevelIndicator;
        }
        if (objCase.Sub_Status_ACE__c === '--None--') {
            objCase.Sub_Status_ACE__c = '';
        }
        if((this.deliveryMethodDefaultValue === 'Fax' || this.deliveryMethodDefaultValue === 'Email') && this.boolFEPIndicator && (this.recipientDefaultValue === 'Member' || this.recipientDefaultValue === 'Provider') ){
           objCase.CardTypeValues_ACE__c ='Medical';
        }
        if(this.boolBoeingDrugOnlyPlan) {
            objCase.CardTypeValues_ACE__c = 'Pharmacy';
            if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
                this.recipientDefaultValue = this.recipientBoeingDefaultValue;
                this.SubstatusDefaultValue ='Pended to Others';
                this.statusDefaultValue = 'Pended';
                objCase.Status =this.statusDefaultValue;
                 objCase.SelfServiceRecipient_ACE__c= this.recipientDefaultValue;
                 objCase.Sub_Status_ACE__c=this.SubstatusDefaultValue;
            }
            if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Member') {
                this.statusDefaultValue = 'Pended';
                objCase.Status = this.statusDefaultValue;
                this.SubstatusDefaultValue ='Pended to self';
                this.recipientDefaultValue = this.recipientBoeingDefaultValue;
                objCase.SelfServiceRecipient_ACE__c= this.recipientDefaultValue;
                objCase.Sub_Status_ACE__c= this.SubstatusDefaultValue;
               //Case Owner - Advocate that created the case
            }
            if (this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Member') {
                this.statusDefaultValue = 'Pended';
                objCase.Status = this.statusDefaultValue;
                this.SubstatusDefaultValue ='Pended to self';
                this.recipientDefaultValue = this.recipientBoeingDefaultValue;
                objCase.SelfServiceRecipient_ACE__c=this.recipientDefaultValue;
                objCase.Sub_Status_ACE__c=this.SubstatusDefaultValue;
            }
            if (this.deliveryMethodDefaultValue === 'Directed to Self-Service' && this.recipientDefaultValue === 'Member') {
                this.statusDefaultValue = 'Closed';
                this.SubstatusDefaultValue = '';
                objCase.SelfServiceRecipient_ACE__c=this.recipientDefaultValue;
                objCase.Status =this.statusDefaultValue;
                objCase.Sub_Status_ACE__c= this.SubstatusDefaultValue;
            }
        }
        if (this.strInquirerRelationship !==undefined && this.strInquirerRelationship !== null &&
            (this.strInquirerRelationship === 'PROVIDER' || this.strInquirerRelationship === 'Provider') &&
            this.strProviderInfoIdCard !== undefined && this.strProviderInfoIdCard !== null) {
            objCase.TaxId_ACE__c = this.returnDataValue(this.strProviderInfoIdCard.strTaxID);
            objCase.ProviderNPI_ACE__c = this.returnDataValue(this.strProviderInfoIdCard.strNPI);
            objCase.ProviderStreet_ACE__c = this.returnDataValue(this.strProviderInfoIdCard.straddressLine1) +' '+this.returnDataValue(this.strProviderInfoIdCard.straddressLine2);
            objCase.ProviderCity_ACE__c = this.returnDataValue(this.strProviderInfoIdCard.strcity);
            objCase.ProviderName_ACE__c = this.returnDataValue(this.strProviderInfoIdCard.strFirstName) + ' ' + this.returnDataValue(this.strProviderInfoIdCard.strLastName);
            objCase.ProviderNumber_ACE__c = this.returnDataValue(this.strProviderInfoIdCard.strProviderNumber);
            objCase.ProviderState_ACE__c = this.returnDataValue(this.strProviderInfoIdCard.strstateCode);
            objCase.ProviderZipCode_ACE__c = this.returnDataValue(this.strProviderInfoIdCard.strpostalCode);
            objCase.ProviderInfoName_ACE__c = this.returnDataValue(this.strProviderInfoIdCard.strInstitutionalName);
            objCase.ProviderFaxNumber_ACE__c = this.returnDataValue(this.strProviderInfoIdCard.strFaxNumber);
            if ( !objCase.ProviderInfoName_ACE__c) {
                objCase.ProviderInfoName_ACE__c =objCase.ProviderName_ACE__c;
            }
        }
        return objCase;
    }
    returnDataValue(strData) {
        if (strData) {
            return strData;
        } else {
            //do nothing
        }    
        return '';
    }
    getFepMemberTotalCount(){
        let totalCount=0;
         for (let i = 0; i < this.listOfFamilyname.length; i++) {
            for (let k = 0; k < this.listOfFamilyname[i].lstCheckBoxWrapper.length; k++) {
                const isChecked = this.listOfFamilyname[i].lstCheckBoxWrapper[k].boolCardChecked;
                if(isChecked){
                    totalCount+=1;
                }
            }
          }
          return totalCount;
    }
    /* Method To get the Memeber LIst For Mail DeliveryMethod*/
    getLstMemberSubmitList() {
        this.boolStandAloneCards = false;
        const lstmembers = [];
        let countOfHealth = 0;
        let countOfDrug = 0;
        let countOfDental = 0;
        let countOfCombined = 0;
        let countOfStandAloneDentalForSubscriber = 0;
        let countOfStandAloneDrugForSubscriber = 0;
        let boolSubscriberChecked = false;
        if (this.strIdCardLevelIndicator === 'S') {
            for (let i = 0; i < this.listOfFamilyname.length; i++) {
                for (let k = 0; k < this.listOfFamilyname[i].lstCheckBoxWrapper.length; k++) {
                    const strCardType = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strCardType;
                    const isChecked = this.listOfFamilyname[i].lstCheckBoxWrapper[k].boolCardChecked;
                    if (strCardType === 'Medical' && isChecked) {
                        countOfHealth = countOfHealth + 1;
                    } else if (strCardType === 'Pharmacy' && isChecked) {
                        countOfDrug = countOfDrug + 1;
                    } else if (strCardType === 'Dental' && isChecked) {
                        countOfDental = countOfDental + 1;
                    } else {
                        if (isChecked) {
                            if (strCardType === 'Supplemental Medical' || strCardType === 'Supplemental Vision'
                                || strCardType === 'Supplemental Pharmacy') {
                                    //Do Nothing
                            } else {
                                countOfCombined = countOfCombined + 1;
                            }
                        }
                    }
                }
            }
            const member = {
                memNbr: '1',
                hlthCardCnt: countOfHealth.toString(),
                dentCardCnt: countOfDental.toString(),
                drugCardCnt: countOfDrug.toString(),
                combCardCnt: countOfCombined.toString()
            }
            lstmembers.push(member);
        } else {
            for (let i = 0; i < this.listOfFamilyname.length; i++) {
                countOfHealth = 0;
                countOfDrug = 0;
                countOfDental = 0;
                countOfCombined = 0;
                for (let k = 0; k < this.listOfFamilyname[i].lstCheckBoxWrapper.length; k++) {
                    const strCardType = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strCardType;
                    const isChecked = this.listOfFamilyname[i].lstCheckBoxWrapper[k].boolCardChecked;
                    if (strCardType === 'Medical' && isChecked) {
                        countOfHealth = countOfHealth + 1;
                    } else if (strCardType === 'Pharmacy' && isChecked) {
                        countOfDrug = countOfDrug + 1;
                    } else if (strCardType === 'Dental' && isChecked) {
                        countOfDental = countOfDental + 1;
                    } else {
                        if (isChecked) {
                            if (strCardType === 'Supplemental Medical' || strCardType === 'Supplemental Vision'
                                || strCardType === 'Supplemental Pharmacy') {
                                    //Do Nothing
                            } else {
                                countOfCombined = countOfCombined + 1;
                            }
                        }
                    }
                }
                if (countOfHealth !== 0 || countOfDental !== 0 || countOfDrug !== 0 || countOfCombined !== 0) {
                    let member;
                    let strMemNbr = '';
                    if(this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName] !== undefined && 
                        this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName] !== null) {
                            if (typeof this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName] !== 'string'){
                                strMemNbr = this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName].toString();
                            }
                    }
                    if (this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName] !== 1) {
                        if (countOfHealth !== 0 || countOfCombined !== 0) {
                            member = {
                                memNbr: strMemNbr,
                                hlthCardCnt: countOfHealth.toString(),
                                dentCardCnt: countOfDental.toString(),
                                drugCardCnt: countOfDrug.toString(),
                                combCardCnt: countOfCombined.toString()
                            };
                            lstmembers.push(member);
                        } else {
                            countOfStandAloneDentalForSubscriber += countOfDental;
                            countOfStandAloneDrugForSubscriber += countOfDrug;
                        }
                    } else {
                        boolSubscriberChecked = true;
                        member = {
                            memNbr: strMemNbr,
                            hlthCardCnt: countOfHealth.toString(),
                            dentCardCnt: countOfDental.toString(),
                            drugCardCnt: countOfDrug.toString(),
                            combCardCnt: countOfCombined.toString()
                        };
                        lstmembers.push(member);
                    }
                }
            }
        }
        if (this.strIdCardLevelIndicator === 'M') {
            if (lstmembers.length >= 1 && boolSubscriberChecked) {
                this.getCombinedCountForStandAloneCards(lstmembers, countOfStandAloneDentalForSubscriber, countOfStandAloneDrugForSubscriber);
            } else {
                if (countOfStandAloneDentalForSubscriber !== 0 || countOfStandAloneDrugForSubscriber !== 0) {
                    const subMember = {
                        memNbr: '1',
                        hlthCardCnt: '0',
                        dentCardCnt: countOfStandAloneDentalForSubscriber.toString(),
                        drugCardCnt: countOfStandAloneDrugForSubscriber.toString(),
                        combCardCnt: '0'
                    };
                    lstmembers.push(subMember);
                    this.boolStandAloneCards = true;
                }
            }
        }
        return lstmembers;
    }

    /* Method To get the Memeber LIst For Mail DeliveryMethod for Retail ID Card*/
    getLstMemberRetailSubmitList() {
        const lstmembers = [];
        if (this.boolHMO === true) {
            //Add selected members if hmo is true
            for (let i = 0; i < this.listOfFamilyname.length; i++) {
                for (let k = 0; k < this.listOfFamilyname[i].lstCheckBoxWrapper.length; k++) {
                    const strCardType = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strCardType;
                    const isChecked = this.listOfFamilyname[i].lstCheckBoxWrapper[k].boolCardChecked;
                    
                    if((strCardType === 'Medical' || strCardType === 'Dental') && isChecked) {
                        const member  = {
                            mid: this.listOfFamilyname[i].strMemberMID,
                            name: this.listOfFamilyname[i].strMemberName
                        }
                        lstmembers.push(member);
                    }
                }
            }
        } else if (this.boolHMO === false){
            //Add only subscriber if hmo is false
            for (let i = 0; i < this.strPlanSummaryData.lstFamilyWrapper.length; i++) {
                if(this.strPlanSummaryData.lstFamilyWrapper[i].strRelation === 'Subscriber') { 
                    const member  = {
                        mid: this.strPlanSummaryData.lstFamilyWrapper[i].strMemberId,
                        name: this.strPlanSummaryData.lstFamilyWrapper[i].strFirstName + ' ' + this.strPlanSummaryData.lstFamilyWrapper[i].strLastName
                    }
                    this.strMIDRetail = this.strPlanSummaryData.lstFamilyWrapper[i].strMemberId;
                    lstmembers.push(member);
                }
            }
        } else {
            //Do Nothing
        }
        return lstmembers;
    }

    /* Method To get the Supplemental Memeber List For Mail DeliveryMethod*/
    getLstSuppMemberSubmitList() {
        this.boolStandAloneCards = false;
        const lstSuppMembers = [];
        let countOfSuppHealth = 0;
        let countOfSuppDrug = 0;
        let countOfStandAloneHealthForSubscriber = 0;
        let countOfStandAloneDrugForSubscriber = 0;
        let boolSubscriberChecked = false;
        let strSpmtlIns = "";
        
        if (this.strIdCardLevelIndicator === 'S') {
            for (let i = 0; i < this.listOfFamilyname.length; i++) {
                for (let k = 0; k < this.listOfFamilyname[i].lstCheckBoxWrapper.length; k++) {
                    const strCardType = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strCardType;
                    const isChecked = this.listOfFamilyname[i].lstCheckBoxWrapper[k].boolCardChecked;
                    if (strCardType === 'Supplemental Medical' && isChecked) {
                        countOfSuppHealth = countOfSuppHealth + 1;
                        strSpmtlIns = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strSpmtlInsTypCd;
                    } else if (strCardType === 'Supplemental Vision' && isChecked) {
                        countOfSuppHealth = countOfSuppHealth + 1;
                        strSpmtlIns = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strSpmtlInsTypCd;
                    } else if (strCardType === 'Supplemental Pharmacy' && isChecked) {
                        countOfSuppDrug = countOfSuppDrug + 1;
                        strSpmtlIns = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strSpmtlInsTypCd;
                    } else {
                        //Do Nothing
                    }
                }
            }
             const member = {
                memNbr: '1',
                hlthCardCnt: countOfSuppHealth.toString(),
                drugCardCnt: countOfSuppDrug.toString(),
                spmtlInsTypCd: strSpmtlIns
            }
            lstSuppMembers.push(member);
        } else {
            for (let i = 0; i < this.listOfFamilyname.length; i++) {
                countOfSuppHealth = 0;
                countOfSuppDrug = 0;
                for (let k = 0; k < this.listOfFamilyname[i].lstCheckBoxWrapper.length; k++) {
                    const strCardType = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strCardType;
                    const isChecked = this.listOfFamilyname[i].lstCheckBoxWrapper[k].boolCardChecked;
                    if (strCardType === 'Supplemental Medical' && isChecked) {
                        countOfSuppHealth = countOfSuppHealth + 1;
                        strSpmtlIns = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strSpmtlInsTypCd;
                    } else if (strCardType === 'Supplemental Vision' && isChecked) {
                        countOfSuppHealth = countOfSuppHealth + 1;
                        strSpmtlIns = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strSpmtlInsTypCd;
                    } else if (strCardType === 'Supplemental Pharmacy' && isChecked) {
                        countOfSuppDrug = countOfSuppDrug + 1;
                        strSpmtlIns = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strSpmtlInsTypCd;
                    } else {
                        //Do Nothing
                    }
                }
                if (countOfSuppHealth !== 0 || countOfSuppDrug !== 0) {
                    let member;
                    //Changing the memNbr to string value
                    let strMemNbr = '';
                    if(this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName] !== undefined && 
                        this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName] !== null) {
                            if (typeof this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName] !== 'string'){
                                strMemNbr = this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName].toString();
                            }
                    }
                    if (this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName] !== 1) {
                        if (countOfSuppHealth !== 0) {
                            member = {
                                memNbr: strMemNbr,
                                hlthCardCnt: countOfSuppHealth.toString(),
                                drugCardCnt: countOfSuppDrug.toString(),
                                spmtlInsTypCd : strSpmtlIns
                            };
                            lstSuppMembers.push(member);
                        } else {
                            countOfStandAloneHealthForSubscriber += countOfSuppHealth;
                            countOfStandAloneDrugForSubscriber += countOfSuppDrug;
                        }
                    } else {
                        boolSubscriberChecked = true;
                        member = {
                            memNbr: strMemNbr,
                            hlthCardCnt: countOfSuppHealth.toString(),
                            drugCardCnt: countOfSuppDrug.toString(),
                            spmtlInsTypCd: strSpmtlIns
                        };
                        lstSuppMembers.push(member);
                    }
                }
            }
        }
        if (this.strIdCardLevelIndicator === 'M') {
            if (lstSuppMembers.length >= 1 && boolSubscriberChecked) {
                this.getCombinedCountForStandAloneCards(lstSuppMembers, countOfStandAloneHealthForSubscriber, countOfStandAloneDrugForSubscriber);
            } else {
                if (countOfStandAloneHealthForSubscriber !== 0 || countOfStandAloneDrugForSubscriber !== 0) {
                    const subMember = {
                        memNbr: '1',
                        hlthCardCnt: countOfStandAloneHealthForSubscriber.toString(),
                        drugCardCnt: countOfStandAloneDrugForSubscriber.toString(),
                        spmtlInsTypCd: strSpmtlIns
                    };
                    lstSuppMembers.push(subMember);
                    this.boolStandAloneCards = true;
                }
            }
        }
        return lstSuppMembers;
    }

    /*To get The Wrapper For Combined Count of StandAlone Cards*/
    getCombinedCountForStandAloneCards(lstmembers, countOfStandAloneDentalForSubscriber, countOfStandAloneDrugForSubscriber) {
        for (let i = 0; i < lstmembers.length; i++) {
            if (lstmembers[i].memNbr === 1 && countOfStandAloneDentalForSubscriber !== 0 || countOfStandAloneDrugForSubscriber !== 0) {
                lstmembers[i].dentCardCnt = (parseInt(lstmembers[i].dentCardCnt, 10) + countOfStandAloneDentalForSubscriber).toString();
                lstmembers[i].drugCardCnt = (parseInt(lstmembers[i].drugCardCnt, 10) + countOfStandAloneDrugForSubscriber).toString();
                this.boolStandAloneCards = true;
                break;
            }
        }
    }
    checkforFepMemberResults(result) {
        if (this.boolFEPIndicator) {
            if (result.lstPendedCases !== undefined && result.lstPendedCases !== null && result.lstPendedCases.length !== 0) {
                return false;
            }
        }
        return true;
    }
    getSubscriberId(){
        let strTrimmedSubscriberId='';
        if(this.objPlanData.strSubscriberID!==undefined && this.objPlanData.strSubscriberID!==null && this.objPlanData.strSubscriberID!==''){
            strTrimmedSubscriberId=this.objPlanData.strSubscriberID.replace(/^0+/, '');
        }
        return strTrimmedSubscriberId;
    }
    
    /* Method To Make a Server Call On Submit*/
    handleSubmitClick() {
        if(this.strPlanSummaryData.strAceLineOfBusiness === 'Retail' && this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
            this.handleRetailSubmit();
        } else {
            this.handleNonRetailSubmit();
        }
    }
    
    /* Method to handle non retail submit scenario*/
    handleNonRetailSubmit() {
        this.isLoaded = !this.isLoaded;
        let boolisMailMemberStatusClosed = false;
        let lstmembers = this.getLstMemberSubmitList();
        lstmembers = this.checklstmembers(lstmembers);
        let lstSuppMembers = this.getLstSuppMemberSubmitList();
        lstSuppMembers = this.checkspmtlmembers(lstSuppMembers);
        const objCase = this.getCaseObject();
        if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member' && this.statusDefaultValue === 'Closed' && this.strPlanSummaryData.strAceLineOfBusiness !== 'Retail') {
            boolisMailMemberStatusClosed = true;
        }
        const objaddressInfo = {
            strAddrLn1: objCase.Address_ACE__c,
            strAddrLn2: '',
            inCareOfLn: objCase.InCareOf_ACE__c,
            ctyNm: objCase.City_ACE__c,
            stCd: objCase.State_ACE__c,
            zipCd: objCase.ZipCode_ACE__c,
            cntryCd: 'US'
        };
        const submitReq = {
            corporateEntityCode: objCase.CorporationCode_ACE__c,
            bluestarAccountNumber: this.strPlanSummaryData.objViewEmployerGroupWrapper.strblueStarAccountNumber,
            subscriberSequenceNumber: this.objPlanData.subscriberSequenceNumber,
            subMemLvlCd: this.strIdCardLevelIndicator,
            members: lstmembers,
            spmtlmembers: lstSuppMembers,
            addressInfo: objaddressInfo
        };
        //CEAS-59345 If condition is added when lstSuppMembers or lstmembers length is 0 remove that attribute from request(GMS)
        if(!this.boolFEPIndicator && boolisMailMemberStatusClosed){
            if(lstSuppMembers.length === 0 && submitReq.spmtlmembers) {
                delete submitReq.spmtlmembers;
            }
            if(lstmembers.length === 0 && submitReq.members) {
                delete submitReq.members;
            }
        }
        const lstSubmitReq = [];
        lstSubmitReq.push(submitReq);
        const fepSubmitReq = {
        subscriberId :this.getSubscriberId(),
            idCardCount: this.getFepMemberTotalCount(),
            suppressionIndicator: "Y"
        };
        const inputzip = this.template.querySelector('.ZIPCODE');
        if (inputzip !== undefined && inputzip !== null) {
            inputzip.setCustomValidity('');
            inputzip.reportValidity();
        }
        const allValidPicklist = [...this.template.querySelectorAll('.slds-combobox__input')]
            .reduce((validSoFar, inputCmp) => {
                this.reportComboboxValidity(inputCmp);
                return validSoFar && this.checkComboboxValidity(inputCmp);
            }, true);
        const allValid = [...this.template.querySelectorAll('lightning-input')]
            .reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);
        if (allValid && allValidPicklist) {
            this.boolAlteranteMailAddress = false;
            this.isResultPendedSuccess = false;
            this.isResultPendedSuccessWithNoCases = false;
            const strCaseStatusBeforeCallout = objCase.Status;
            submitCaseFromIdCard({
                    strCaseData: JSON.stringify(objCase),
                    strFamilyDataChecboxes: JSON.stringify(this.listOfFamilyname),
                    boolBlueStarCallout: boolisMailMemberStatusClosed,
                    lstSubmitReq: lstSubmitReq,
                    fepSubmitReq: JSON.stringify(fepSubmitReq),
                    strMemberId: this.objPlanData.strMid,
                    mapOfFamilyMemberAndMemberNumber: this.mapOfFamilyMemberAndMemberNumber,
                    strIdCardLevelIndicator: this.strIdCardLevelIndicator,
                    boolcheckAvailblity: false,
                    strUniqueIdentifier: '',
                    mapOfDataforEmail: this.MapOfDataforEmail,
                    mapOfFamilyMemberNumberAndMid: this.MapOfFamilyMemberNumberAndMid,
                    mapOfFamilyMemberIdAndCMID: this.MapOfFamilyMemberIdAndCMID,
                    boolFEPIndicator: this.boolFEPIndicator,
                    boolStandAloneCards: this.boolStandAloneCards,
                    boolBoeingIndicator:this.boolBoeingDrugOnlyPlan
                }).then((result) => {
                    this.isLoaded = !this.isLoaded;
                    this.isSubmitResultSuccess = true;
                    const lstOfCasesFromServer = [];
                    const lstOfCasesFromServerPended = [];
                    this.removeAddressErrorsOnSuccess();
                    if (result !== undefined && result !== null && result.boolResponseStatus && result.lstSuccessCases.length > 0 && this.checkforFepMemberResults(result)) {
                        //Section for success response and success cases
                        for (let i = 0; i < result.lstSuccessCases.length; i++) {
                            this.boolEmailStatus = false;
                            this.statusEmailDefaultValue = 'Closed';
                            if (result.lstSuccessCases[i].Status === 'Open' && !result.boolEmailSuccess) {
                                this.boolEmailStatus = true;
                                this.statusEmailDefaultValue = 'Open';
                                this.strCaseIdEmail = result.lstSuccessCases[i].Id;
                                this.strCaseAccount = result.lstSuccessCases[i].AccountId;
                                this.strCaseURL = result.lstSuccessCases[i].CaseUrlIDCard_ACE__c;
                            }
                            const objCaseFromServer = {
                                CaseNumber: result.lstSuccessCases[i].CaseNumber,
                                Id: result.lstSuccessCases[i].Id,
                                caseUrl: result.lstSuccessCases[i].CaseUrlIDCard_ACE__c,
                                accountid: result.lstSuccessCases[i].AccountId
                            };
                            //Creating list of cases with casenumber, id, url to be shown on UI
                            lstOfCasesFromServer.push(objCaseFromServer)
                        }
                        this.caseNumbers = lstOfCasesFromServer;
                        this.isResultSuccess = true;
                        this.caseType = 'Member Management';
                        this.caseSubtype = 'ID Card Request';
                        //Setting case status based on closed 
                        if (strCaseStatusBeforeCallout === 'Closed' && !boolisMailMemberStatusClosed) {
                            this.isSubmitResultText = 'Case created and closed successfully.';
                        } else if (strCaseStatusBeforeCallout === 'Closed' && boolisMailMemberStatusClosed && result.boolResponseStatus) {
                            this.isSubmitResultText = 'Case created and closed successfully.';
                        } else if (strCaseStatusBeforeCallout !== 'Closed' && !boolisMailMemberStatusClosed) {
                            this.isSubmitResultText = 'Case created successfully.';
                        } else { this.isSubmitResultText = 'Case created successfully.'; }
                        if (this.boolFEPIndicator && this.deliveryMethodDefaultValue !== 'Mail') { this.isSubmitResultText = 'Case created and closed successfully.'; }
                        if (this.boolFEPIndicator && this.deliveryMethodDefaultValue === 'Mail') { this.isSubmitResultText = 'Case created successfully.'; }
                        if (this.strAlternateAddressOfMember === '') { this.strAlternateAddressOfMember = this.strAddressOfMember; }
                        if(this.deliveryMethodDefaultValue ==='Directed to Self-Service') { this.isdeliveryMethodDefault= true; }
                        this.isError = false;
                        this.boolSubstatus = false;
                        this.boolrefresh = false;
                    } else if (result !== undefined && result !== null && !result.boolResponseStatus && result.strZipCodeError !== null && result.strZipCodeError !== '') {
                        //Zipcode validation error 
                        this.validateZipCode();
                    } else if (result !== undefined && result !== null && !result.boolResponseStatus && result.lstSuccessCases && result.lstPendedCases.length === 0 && result.strZipCodeError === '') {
                        //Section to handle when boolResponseStatus=false but success cases are not zero but pended cases are 0 and no zipcode validation error
                        for (let i = 0; i < result.lstSuccessCases.length; i++) {
                            const objCaseFromServer = {
                                CaseNumber: result.lstSuccessCases[i].CaseNumber,
                                Id: result.lstSuccessCases[i].Id,
                                caseUrl: result.lstSuccessCases[i].CaseUrlIDCard_ACE__c,
                                accountid: result.lstSuccessCases[i].AccountId
                            };
                            lstOfCasesFromServer.push(objCaseFromServer)
                        }
                        this.caseNumbers = lstOfCasesFromServer;
                        this.caseType = 'Member Management';
                        this.caseSubtype = 'ID Card Request';
                        this.isSubmitResultText = 'Case created successfully.';
                        this.isError = false;
                        this.isResultSuccess = true;
                        this.boolSubstatus = false;
                        this.boolrefresh = false;
                        if (this.strAlternateAddressOfMember === '') { this.strAlternateAddressOfMember = this.strAddressOfMember; }
                        this.isResultPendedSuccess = false;
                        this.isResultPendedSuccessWithNoCases = false;
                    } else if (result !== undefined && result !== null && !result.boolResponseStatus && result.lstPendedCases && result.strZipCodeError === '') {
                        //Section to handle when boolResponseStatus=false and oended cases are not 0
                        for (let i = 0; i < result.lstSuccessCases.length; i++) {
                            const objCaseFromServer = {
                                CaseNumber: result.lstSuccessCases[i].CaseNumber,
                                Id: result.lstSuccessCases[i].Id,
                                caseUrl: result.lstSuccessCases[i].CaseUrlIDCard_ACE__c,
                                accountid: result.lstSuccessCases[i].AccountId
                            };
                            this.isResultPendedSuccessWithNoCases = true;
                            lstOfCasesFromServer.push(objCaseFromServer)
                        }
                        for (let i = 0; i < result.lstPendedCases.length; i++) {
                            const objCaseFromServer = {
                                CaseNumber: result.lstPendedCases[i].CaseNumber,
                                Id: result.lstPendedCases[i].Id,
                                caseUrl: result.lstPendedCases[i].CaseUrlIDCard_ACE__c,
                                accountid: result.lstPendedCases[i].AccountId
                            };
                            lstOfCasesFromServerPended.push(objCaseFromServer)
                        }
                        this.caseNumbersPended = lstOfCasesFromServerPended;
                        const lstCasesCombined = lstOfCasesFromServer.concat(lstOfCasesFromServerPended);
                        this.caseNumbers = lstCasesCombined;
                        this.boolSubstatus = false;
                        this.boolrefresh = false;
                        this.caseType = 'Member Management';
                        this.caseSubtype = 'ID Card Request';
                        this.isError = false;
                        this.isResultSuccess = false;
                        if (this.strAlternateAddressOfMember === '') {
                            this.strAlternateAddressOfMember = this.strAddressOfMember;
                        }
                        this.isResultPendedSuccess = true;
                    } else if (result !== undefined && result !== null && this.boolFEPIndicator && this.deliveryMethodDefaultValue ==='Mail' && this.recipientDefaultValue === 'Member' &&
                        (result.lstPendedCases || result.lstSuccessCases) && !result.boolFepOrderIdCardResponse) {
                        //FEP member handle
                            this.getSuccessCasesForFepMember(result)
                    } else {
                        this.handleErrorScenario();
                    }
                }).catch(() => {
                    this.handleError();
                });
        } else {
            this.isLoaded = !this.isLoaded;
        }
    }

    /* Method to handle error scenario*/
    handleErrorScenario() {
        //Error Scenario
        this.isSubmitResultSuccess = false;
        this.boolIsRecipientAndMail = false;
        this.boolAlteranteMailAddress = false;
        this.isError = true;
        if (this.isLoaded) {
            this.isLoaded = !this.isLoaded;
        }
    }
    
    /* Method to handle retail submit click*/
    handleRetailSubmit() {
        this.isLoaded = !this.isLoaded;
            const objCase = this.getCaseObject();
            let boolisMailRetailMemberStatusClosed = false;
            const lstmembers = this.getLstMemberRetailSubmitList();
            const objaddressInfo = {
                streetAddress: objCase.Address_ACE__c,
                city: objCase.City_ACE__c,
                state: objCase.State_ACE__c,
                zipCode: objCase.ZipCode_ACE__c
            };
            if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member' && this.statusDefaultValue === 'Closed'
                && this.strPlanSummaryData.strAceLineOfBusiness === 'Retail') {
                boolisMailRetailMemberStatusClosed = true;
            }
           
            const submitReq = {
                mid: this.strMIDRetail,
                policyId: this.strPlanSummaryData.strPolicyId,
                members: lstmembers,
                orderAddress: objaddressInfo
            };
            const lstRetailSubmitReq = [];
            lstRetailSubmitReq.push(submitReq);
            const strCaseStatusBeforeCallout = objCase.Status;
            submitRetailIDCard({
                strCaseData: JSON.stringify(objCase),
                strFamilyDataChecboxes: JSON.stringify(this.listOfFamilyname),
                boolRetailAPICallout: boolisMailRetailMemberStatusClosed,
                strMIDRetail : this.strMIDRetail,
                lstRetailSubmitReq: lstRetailSubmitReq,
                mapOfFamilyMemberAndMemberNumber: this.mapOfFamilyMemberAndMemberNumber,
                strIdCardLevelIndicator: this.strIdCardLevelIndicator,
                strUniqueIdentifier: '',
                mapOfFamilyMemberNumberAndMid: this.MapOfFamilyMemberNumberAndMid,
                mapOfFamilyMemberIdAndCMID: this.MapOfFamilyMemberIdAndCMID
            }).then(result => {
                this.isLoaded = !this.isLoaded;
                this.isSubmitResultSuccess = true;
                const lstOfCasesFromServer = [];
                const lstOfCasesFromServerPended = [];

                if (result !== undefined && result !== null && result.boolResponseStatus && result.lstSuccessCases.length > 0) {
                    //Section for success response and success cases
                    for (let i = 0; i < result.lstSuccessCases.length; i++) {
                        
                        const objCaseFromServer = {
                            CaseNumber: result.lstSuccessCases[i].CaseNumber,
                            Id: result.lstSuccessCases[i].Id,
                            caseUrl: result.lstSuccessCases[i].CaseUrlIDCard_ACE__c,
                            accountid: result.lstSuccessCases[i].AccountId
                        };
                        //Creating list of cases with casenumber, id, url to be shown on UI
                        lstOfCasesFromServer.push(objCaseFromServer);
                        this.caseNumbers = lstOfCasesFromServer;
                        this.isResultSuccess = true;
                        this.caseType = 'Member Management';
                        this.caseSubtype = 'ID Card Request';
                        //Setting case status based on closed 
                        if (strCaseStatusBeforeCallout === 'Closed' && !boolisMailRetailMemberStatusClosed) {
                            this.isSubmitResultText = 'Case created and closed successfully.';
                        } else if (strCaseStatusBeforeCallout === 'Closed' && boolisMailRetailMemberStatusClosed && result.boolResponseStatus) {
                            this.isSubmitResultText = 'Case created and closed successfully.';
                        } else if (strCaseStatusBeforeCallout !== 'Closed' && !boolisMailRetailMemberStatusClosed) {
                            this.isSubmitResultText = 'Case created successfully.';
                        } else {
                            this.isSubmitResultText = 'Case created successfully.';
                        }
                        if (this.strAlternateAddressOfMember === '') {
                            this.strAlternateAddressOfMember = this.strAddressOfMember;
                        }
                        if(this.deliveryMethodDefaultValue ==='Directed to Self-Service') {
                            this.isdeliveryMethodDefault= true;
                        }
                        this.isError = false;
                        this.boolSubstatus = false;
                        this.boolrefresh = false;
                    }
                } else if (result !== undefined && result !== null && !result.boolResponseStatus && result.lstPendedCases.length > 0) {
                    for (let i = 0; i < result.lstPendedCases.length; i++) {
                        const objCaseFromServer = {
                            CaseNumber: result.lstPendedCases[i].CaseNumber,
                            Id: result.lstPendedCases[i].Id,
                            caseUrl: result.lstPendedCases[i].CaseUrlIDCard_ACE__c,
                            accountid: result.lstPendedCases[i].AccountId
                        };
                        lstOfCasesFromServerPended.push(objCaseFromServer)
                    }
                    this.caseNumbersPended = lstOfCasesFromServerPended;
                    const lstCasesCombined = lstOfCasesFromServer.concat(lstOfCasesFromServerPended);
                    this.caseNumbers = lstCasesCombined;
                    this.boolSubstatus = false;
                    this.boolrefresh = false;
                    this.caseType = 'Member Management';
                    this.caseSubtype = 'ID Card Request';
                    this.isError = false;
                    this.isResultSuccess = false;
                    if (this.strAlternateAddressOfMember === '') {
                        this.strAlternateAddressOfMember = this.strAddressOfMember;
                    }
                    this.isResultPendedSuccess = true;
                
                } else {
                    //Do Nothing
                }
            })
            .catch(() => {
                this.handleError();
            });
    }
    
    /*Handle on error case*/
    handleError(){
        this.isError = true;
        if (this.isLoaded) {
            this.isLoaded = !this.isLoaded;
        }
    }

    getSuccessCasesForFepMember(result) {
        const lstOfCasesFromServer = [];
        const lstOfCasesFromServerPended = [];
        for (let i = 0; i < result.lstSuccessCases.length; i++) {
            const objCaseFromServer = {
                CaseNumber: result.lstSuccessCases[i].CaseNumber,
                Id: result.lstSuccessCases[i].Id,
                caseUrl: result.lstSuccessCases[i].CaseUrlIDCard_ACE__c,
                accountid: result.lstSuccessCases[i].AccountId
            };
            this.isResultPendedSuccessWithNoCases = true;
            lstOfCasesFromServer.push(objCaseFromServer)
        }
        for (let i = 0; i < result.lstPendedCases.length; i++) {
            const objCaseFromServer = {
                CaseNumber: result.lstPendedCases[i].CaseNumber,
                Id: result.lstPendedCases[i].Id,
                caseUrl: result.lstPendedCases[i].CaseUrlIDCard_ACE__c,
                accountid: result.lstPendedCases[i].AccountId
            };
            lstOfCasesFromServerPended.push(objCaseFromServer)
        }
        this.caseNumbersPended = lstOfCasesFromServerPended;
        const lstCasesCombined = lstOfCasesFromServer.concat(lstOfCasesFromServerPended);
        this.isResultPendedSuccess = true;
        this.caseNumbers = lstCasesCombined;
        this.boolSubstatus = false;
        this.boolrefresh = false;
        this.caseType = 'Member Management';
        this.caseSubtype = 'ID Card Request';
        this.isError = false;
        this.isResultSuccess = false;
    }
    /* Validate ZipCode and highlight all address fields. */
    validateZipCode() {
        this.isSubmitResultSuccess = false;
        this.boolIsRecipientAndMail = true;
        this.boolAlteranteMailAddress = true;
        this.boolzipError = true;
        setTimeout(function(){
            this.template.querySelector('button.AlternateAddress').classList.add('selected');
            this.template.querySelector('button.AlternateAddress').focus();
            const inp1 = this.template.querySelector('.ZIPCODE');
            const inp2 = this.template.querySelector('.CITY');
            const inp3 = this.template.querySelector('.ADDRESS');
            const inp4 = this.template.querySelector('.id-class-state-err');
            inp1.classList.add('slds-has-error');
            inp2.classList.add('slds-has-error');
            inp3.classList.add('slds-has-error');
            inp4.classList.add('slds-has-error');
        }.bind(this), 500);
    }

    /* Remove validation error messages on submit success. */
    removeAddressErrorsOnSuccess() {
        this.boolzipError = false;
        const strInputZipCode = this.template.querySelector('.ZIPCODE.slds-has-error');
        const strInputCity = this.template.querySelector('.CITY.slds-has-error');
        const strInputAddress = this.template.querySelector('.ADDRESS.slds-has-error');
        const strInputState = this.template.querySelector('.id-class-state-err.slds-has-error');
        if(strInputZipCode) {
          strInputZipCode.classList.remove('slds-has-error');
        }
        if(strInputCity) {
          strInputCity.classList.remove('slds-has-error');
        }
        if(strInputAddress) {
          strInputAddress.classList.remove('slds-has-error');
        }
        if(strInputZipCode) {
          strInputState.classList.remove('slds-has-error');
        }
    }
    /*To Handle on Select of Checkbox*/
    handleChange(objEvent) {
        const checkedVal = objEvent.target.checked;
        const attributeKey = objEvent.target.getAttribute('data-membercardtype');
        if (attributeKey.includes('-Medical') || attributeKey.includes('-Dental') || attributeKey.includes('-Pharmacy') ||
            attributeKey.includes('-Medical/Dental') || attributeKey.includes('-Medical/Pharmacy') || attributeKey.includes('-Medical/Pharmacy/Dental')
            || attributeKey.includes('-Supplemental Vision') || attributeKey.includes('-Supplemental Medical') || 
            attributeKey.includes('-Supplemental Pharmacy')) {
            let MemberName;
            if(this.boolIsRetail === true) {
                MemberName = attributeKey.split('_')[0];
            } else {
                MemberName = attributeKey.split('-')[0];
            }
            let lstfamilyMemberNew = [];
            lstfamilyMemberNew = this.listOfFamilyname;
            for (let i = 0; i < lstfamilyMemberNew.length; i++) {
                if (lstfamilyMemberNew[i].strMemberName === MemberName) {
                    for (let k = 0; k < lstfamilyMemberNew[i].lstCheckBoxWrapper.length; k++) {
                        if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardKey === attributeKey) {
                            lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked = checkedVal;
                        }
                    }
                    this.listOfFamilyname = lstfamilyMemberNew;
                }
            }
        }
        if(this.boolFEPIndicator){
            this.checkForFEPMemberIDCardMessage();
        }
        if(this.boolBoeingDrugOnlyPlan === false) {
            this.checkForCheckBoxSelected();
            this.setStatusForSuppressAndExisting();
        }
    }
    checkForFEPMemberIDCardMessage() {
        let lstfamilyMemberNew = [];
        lstfamilyMemberNew = this.listOfFamilyname;
        let count = 0;
        for (let i = 0; i < lstfamilyMemberNew.length; i++) {
            for (let k = 0; k < lstfamilyMemberNew[i].lstCheckBoxWrapper.length; k++) {
                if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked) {
                    count += 1;
                }
            }
        }
        this.boolFepMoreThan8Member = false;
        if (count >= 8) {
            this.boolFepMoreThan8Member = true;
        } else {
            this.boolFepMoreThan8Member = false;
        }
        lstfamilyMemberNew = this.listOfFamilyname;
        for (let i = 0; i < lstfamilyMemberNew.length; i++) {
            for (let k = 0; k < lstfamilyMemberNew[i].lstCheckBoxWrapper.length; k++) {
                if (!lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked) {
                    lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardDisabled = this.boolFepMoreThan8Member;
                }
            }
        }
        this.listOfFamilyname = lstfamilyMemberNew;
    }
    /* Method To Enable Submit Button*/
    checkForCheckBoxSelected() {
        let lstFamilyMemberNamelocal = [];
        lstFamilyMemberNamelocal = this.listOfFamilyname;
        let boolIsCheckBoxesSelected = false;
        for (let i = 0; i < lstFamilyMemberNamelocal.length; i++) {
            for (let k = 0; k < lstFamilyMemberNamelocal[i].lstCheckBoxWrapper.length; k++) {
                if (lstFamilyMemberNamelocal[i].lstCheckBoxWrapper[k].boolCardChecked) {
                    boolIsCheckBoxesSelected = true;
                    break;
                }
            }
        }
        if (boolIsCheckBoxesSelected) {
            this.isSubmitEnabled = false;
        } else {
            this.isSubmitEnabled = true;
        }
    }
    /* Method To Handle On Change of Status*/
    handleChangeStatus(objEvent) {
        this.statusDefaultValue = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
        if (this.statusDefaultValue === 'Pended') {
            this.SubstatusDefaultValue = 'Personal Pend';
            this.boolSubstatus = true;
        } else {
            this.SubstatusDefaultValue = this.lstSubStatus[0].label;
            this.boolSubstatus = false;
        }
    }
    /* Method To Handle On Change of SUB Status*/
    handleChangeSubStatus(objEvent) {
        this.SubstatusDefaultValue = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
    }
    /* Method To Handle On Change of Origin*/
    handleChangeOrigin(objEvent) {
        this.caseOriginDefaultValues = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
    }
    /* Method To Handle On Change of Recipient*/
    handleChangeRecipient(objEvent) {
        this.recipientDefaultValue = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
        this.isSubmitResultSuccess = false;
        const lstDeliveryMethodUI = [];
        const objTypeNull = {
            label: '--None--',
            value: ''
        };
        if (this.recipientDefaultValue === 'Provider') {
            this.boolIsRecipientAndMail = false;
            this.boolFaxIsRecipientAndMail = false;
            this.boolfaxCondition = false;
            this.boolEmailCondition = false;
            this.boolEmailIsRecipientAndMail = false;
            this.boolTempToast = false;
            this.boolFaxIsRecipientAndProv = false;
            this.boolEmailIsRecipientAndProv = false;
            lstDeliveryMethodUI.push(objTypeNull);
            lstDeliveryMethodUI.push({
                label: 'Email',
                value: 'Email'
            });
            lstDeliveryMethodUI.push({
                label: 'Fax',
                value: 'Fax'
            });
            this.lstDeliveryMethod = lstDeliveryMethodUI;
        } else {
            this.boolIsRecipientAndMail = false;
            this.boolFaxIsRecipientAndMail = false;
            this.boolfaxCondition = false;
            this.boolEmailCondition = false;
            this.boolEmailIsRecipientAndMail = false;
            this.boolTempToast = false;
            this.boolFaxIsRecipientAndProv = false;
            this.boolEmailIsRecipientAndProv = false;
            this.lstDeliveryMethod = this.lstDeliveryMethodBackup;
        }
        this.deliveryMethodDefaultValue = this.lstDeliveryMethod[0].label;
        this.showDisableSubmitButton();
        if(this.boolBoeingDrugOnlyPlan === false) {
            this.setStatusForSuppressAndExisting();
            this.setStatusForSuppressAndExistingLabels();
        }
    }
    /* Method To Show or Disable Submit Button */
    showDisableSubmitButton() {
        if (this.deliveryMethodDefaultValue === '--None--' || this.recipientDefaultValue === '--None--') {
            this.isSubmitEnabled = true;
        } else {
            this.isSubmitEnabled = false;
        }
    }
    /* Method To Handle On Change of Delivery Method*/
    handleChangeDeliveryMethod(objEvent) {
        this.deliveryMethodDefaultValue = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
        this.isSubmitResultSuccess = false;
        this.boolIsRecipientAndMail = false;
        this.boolFaxIsRecipientAndMail = false;
        this.boolfaxCondition = false;
        this.boolEmailCondition = false;
        this.boolEmailIsRecipientAndMail = false;
        this.boolTempToast = false;
        this.boolFaxIsRecipientAndProv = false;
        this.boolEmailIsRecipientAndProv = false;
        if (!this.isApiError) {
            this.boolApiError = false;
            this.strErrorSectionName = '';
            if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
                this.boolIsRecipientAndMail = true;
                //44374 Showing Warning Message if PCP/MG is not assigned or dummy value                
                if(this.objPCPDetailsSubtab.strPCPDummyPlaceholder === 'PCP NOT SELECTED' || this.objPCPDetailsSubtab.strMGDummyPlaceholder === 'NOT SELECTED' ) {
                    this.boolPCPMGNull = true; 
                    this.enableCaseOrigin();
                    this.boolIsRecipientAndMail = false;
                    this.strErrorSectionName = 'MAIL TO MEMBER';
                } else if((this.objPCPDetailsSubtab.strPCPDummyPlaceholder === null && this.objPCPDetailsSubtab.strPCPOrMG === 'PCP' 
                    && (this.objPCPDetailsSubtab.objProvidersWrapper === null || this.objPCPDetailsSubtab.objProvidersWrapper.pcpNumber === null)) 
                    ||(this.objPCPDetailsSubtab.strMGDummyPlaceholder === null && this.objPCPDetailsSubtab.strPCPOrMG === 'MG' 
                        && this.objPCPDetailsSubtab.objProvidersWrapper !== null
                        && this.objPCPDetailsSubtab.objProvidersWrapper.medicalGroup && this.objPCPDetailsSubtab.objProvidersWrapper.medicalGroup.siteNumber === null)) {
                        this.boolPCPMGNull = true;
                        this.enableCaseOrigin();
                        this.boolIsRecipientAndMail = false;
                        this.strErrorSectionName = 'MAIL TO MEMBER';
                } else {
                    //Do Nothing
                }
                if (this.boolAlteranteMailAddress && !this.boolFEPIndicator) {
                    setTimeout(function(){
                        if(this.template.querySelector('button.AlternateAddress')) {
                            this.template.querySelector('button.AlternateAddress').classList.add('selected');
                            this.template.querySelector('button.AlternateAddress').focus();
                        }
                    }.bind(this), 700);
                } else {
                    if (!this.boolFEPIndicator) {
                        setTimeout(function() {
                            if(this.template.querySelector('button.MailAddress')) {
                                this.template.querySelector('button.MailAddress').classList.add('selected');
                                this.template.querySelector('button.MailAddress').focus();
                            }
                        }.bind(this), 700);
                    }
                }
            } else if (this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Member') {
                this.boolFaxIsRecipientAndMail = true;
                this.boolfaxCondition = true;
                this.boolPCPMGNull = false;
            } else if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Member') {
                this.boolEmailIsRecipientAndMail = true;
                this.boolTempToast = true;
                this.boolEmailCondition = true;
                this.boolfaxCondition = true;
                this.boolPCPMGNull = false;
            } else if (this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Provider') {
                this.boolFaxIsRecipientAndProv = true;
                this.boolfaxCondition = true;
                this.boolPCPMGNull = false;
            } else if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Provider') {
                this.boolEmailIsRecipientAndProv = true;
                this.boolTempToast = true;
                this.boolEmailCondition = true;
                this.boolfaxCondition = true;
                this.strEmail = '';
                this.boolPCPMGNull = false;
            } else {
                this.boolPCPMGNull = false;
                //Nothing
            }
            this.showDisableSubmitButton();
            if(this.boolBoeingDrugOnlyPlan === false) {
                this.setStatusForSuppressAndExisting();
                this.setStatusForSuppressAndExistingLabels();
                //Set Default Values
                this.strCardTypeDefaultValue = this.lstCardType[0].label;
            }

        } else {
            this.strErrorSectionName = '';
            if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
                this.strErrorSectionName = 'MAIL TO MEMBER';
                this.boolApiError = true;
            } else if (this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Member') {
                this.strErrorSectionName = 'FAX TO MEMBER';
                this.boolApiError = true;
            } else if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Member') {
                this.strErrorSectionName = 'EMAIL TO MEMBER';
                this.boolApiError = true;
            } else if (this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Provider') {
                this.strErrorSectionName = 'FAX TO PROVIDER';
                this.boolApiError = true;
            } else if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Provider') {
                this.strErrorSectionName = 'EMAIL TO PROVIDER';
                this.boolApiError = true;
            } else {
                this.boolApiError = false;
                this.strErrorSectionName = '';
                this.showDisableSubmitButton();
                if(this.boolBoeingDrugOnlyPlan === false) {
                this.setStatusForSuppressAndExisting();
                this.setStatusForSuppressAndExistingLabels();
                }
            }
        }
    }
    /* Method To Handle On Change of Alterante*/
    handleChangeAlternatevalue(objEvent) {
        if (objEvent.currentTarget && objEvent.currentTarget.classList.contains('STATE')) {
            this.strState = objEvent.currentTarget.getAttribute('data-label');
            objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
        } else {
            const className = objEvent.target.className;
            if (className.includes('InCareOf')) {
                this.strInCareOf = objEvent.target.value;
            } else if (className.includes('ADDRESS')) {
                this.strADDRESS = objEvent.target.value;
            } else if (className.includes('CITY')) {
                this.strCity = objEvent.target.value;
            } else if (className.includes('ZIPCODE')) {
                this.strZipCode = objEvent.target.value;
            } else {
                /*Do Nothing*/
            }
        }
        this.strAlternateAddressOfMember = this.strInCareOf + ' ' + '</br>' +
            this.strADDRESS + ', ' + '</br>' +
            this.strCity + ', ' +
            this.strState + ', ' +
            this.strZipCode;
    }
    handleFaxChange(objEvent) {
        const className = objEvent.target.className;
        if (objEvent.currentTarget && objEvent.currentTarget.classList.contains('CardType')) {
            this.strCardTypeDefaultValue = objEvent.currentTarget.getAttribute('data-label');
            objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
        } else if (className.includes('FaxNumber')) {
            this.strFaxNumber = objEvent.target.value;
        } else if (className.includes('ToEmail')) {
            this.strEmail = objEvent.target.value;
        } else if (className.includes('Provider')) {
            this.strProvider = objEvent.target.value;
        } else {
            //Do nothing
        }
    }
    /* Method To Handle Change oF Main Address */
    handleMainAddress(objEvent) {
        const className = objEvent.currentTarget.className;
        if (this.template.querySelector('.address-button.selected')) {
            this.template.querySelector('.address-button.selected').classList.remove('selected');
        }
        if (className.includes('MailAddress')) {
            this.boolMailAddress = true;
            this.boolAlteranteMailAddress = false;
            setTimeout(function() {
                this.template.querySelector('button.MailAddress').classList.add('selected');
                this.template.querySelector('button.MailAddress').focus();
            }.bind(this), 500);

        } else if (className.includes('AlternateAddress')) {
            this.boolMailAddress = false;
            this.boolAlteranteMailAddress = true;
            setTimeout(function() {
                this.template.querySelector('button.AlternateAddress').classList.add('selected');
                this.template.querySelector('button.AlternateAddress').focus();
            }.bind(this), 500);
        } else {
            /*Do Nothing*/
        }
    }
    /*Launch a case on Select Sub Tab*/
    openCase(objEvent) {
        if (objEvent !== undefined && objEvent !== null && objEvent.target !== undefined && objEvent.target !== null &&
            objEvent.target.getAttribute('data-caseid') !== undefined && objEvent.target.getAttribute('data-caseid') !== null) {
            const caseId = objEvent.target.getAttribute('data-caseid');
            const caseIdURL = objEvent.target.getAttribute('data-caseurl');
            const strAccountIdOfCase = objEvent.target.getAttribute('data-caseaccid');
            let boolOpenSubtab = false;
            if (this.strAccountId === strAccountIdOfCase) {
                boolOpenSubtab = true;
                if(objEvent.currentTarget && objEvent.currentTarget.label === 'NEXT') {
                    this.showModal = false;
                }
            }
            const objDispatchEventData = {
                Id: caseId,
                TabId: this.currentTabId,
                CaseUrl: caseIdURL,
                AccountId: strAccountIdOfCase,
                boolOpenSubtab: boolOpenSubtab
            };
            const openSubTab = new CustomEvent('OpenSubTab', {
                detail: JSON.stringify(objDispatchEventData)
            });
            window.dispatchEvent(openSubTab);
        }
    }
    /*Get A value of Selcted Plans*/
    getValueFromPLan(strPLanValue, strSelectedValue, strElseValue) {
        let valueToBeReturned;
        if (strPLanValue !== undefined && strPLanValue !== null) {
            valueToBeReturned = strSelectedValue;
        } else {
            valueToBeReturned = strElseValue;
        }
        return valueToBeReturned;
    }
    /*Get Plan Summary Wrapper*/
    planSummaryValue() {
        if (this.strPlanSummaryData !== undefined && this.strPlanSummaryData !== null) {
            const MapOfDataforEmailLocal = {};
            const casePlanParam = {
                strSubscriberID: this.getValueFromPLan(this.strPlanSummaryData.strSubscriberId, this.strPlanSummaryData.strSubscriberId, ''),
                strGroupNumber: this.getValueFromPLan(this.strPlanSummaryData.strGroupNumber, this.strPlanSummaryData.strGroupNumber, ''),
                strGroupName: this.getValueFromPLan(this.strPlanSummaryData.strGroupName, this.strPlanSummaryData.strGroupName, ''),
                strSectionNumber: this.getValueFromPLan(this.strPlanSummaryData.objViewEmployerGroupWrapper.strGroupSectionNumber, this.strPlanSummaryData.objViewEmployerGroupWrapper.strGroupSectionNumber, ''),
                strCorporationCode: this.getValueFromPLan(this.strPlanSummaryData.strCorporationCode, this.strPlanSummaryData.strCorporationCode, ''),
                boolPgIndicator: this.getValueFromPLan(this.strPlanSummaryData.boolPgIndicator, this.strPlanSummaryData.boolPgIndicator, ''),
                strCMID: this.getValueFromPLan(this.strPlanSummaryData.strClientMemberId, this.strPlanSummaryData.strClientMemberId, ''),
                strMid: this.getValueFromPLan(this.strPlanSummaryData.strMemberId, this.strPlanSummaryData.strMemberId, ''),
                strGroupCostCenter: this.getValueFromPLan(this.strPlanSummaryData.strGroupCostCenterNumber, this.strPlanSummaryData.strGroupCostCenterNumber, ''),
                strPolicyId: this.getValueFromPLan(this.strPlanSummaryData.strPolicyId, this.strPlanSummaryData.strPolicyId, ''),
                strEffectiveDate: this.getValueFromPLan(this.strPlanSummaryData.strEffectiveDate, this.strPlanSummaryData.strEffectiveDate, ''),
                strTerminationDate: this.getValueFromPLan(this.strPlanSummaryData.strTerminationDate, this.strPlanSummaryData.strTerminationDate, ''),
                strAccountNumber: this.getValueFromPLan(this.strPlanSummaryData.strAccountNumber, this.strPlanSummaryData.strAccountNumber, ''),
                strMultiPlan: this.getValueFromPLan(this.strPlanSummaryData.strMultiPlan, this.strPlanSummaryData.strMultiPlan, ''),
                strProductType: this.getValueFromPLan(this.strPlanSummaryData.strNetwork, this.strPlanSummaryData.strNetwork, ''),
                strFundingType: this.getValueFromPLan(this.strPlanSummaryData.strFundingTypeCode, this.strPlanSummaryData.strFundingTypeCode, ''),
                addOnServices: this.strPlanSummaryData.lstCoverageCodes,
                strPolicyClientMemberId: this.getValueFromPLan(this.strPlanSummaryData.strPolicyClientMemberId, this.strPlanSummaryData.strPolicyClientMemberId, ''),
                strCorpCode: this.getValueFromPLan(this.strPlanSummaryData.strCorpCode, this.strPlanSummaryData.strCorpCode, ''),
                strAddOnServices: '',
                Address_ACE__c: '',
                City_ACE__c: '',
                State_ACE__c: '',
                ZipCode_ACE__c: '',
                Email_ACE__c: '',
                lstFamilyName: null,
                boolIsCbcApiCallAvailable: this.getValueFromPLan(this.strPlanSummaryData.boolIsCbcApiCallAvailable, this.strPlanSummaryData.boolIsCbcApiCallAvailable, ''),
                boolIsAccountsAPICallAvailable: this.getValueFromPLan(this.strPlanSummaryData.boolIsAccountsAPICallAvailable, this.strPlanSummaryData.boolIsAccountsAPICallAvailable, ''),
                strAceLineOfBusiness: this.getValueFromPLan(this.strPlanSummaryData.strAceLineOfBusiness, this.strPlanSummaryData.strAceLineOfBusiness, ''),
                                strSourceSystemName: this.getValueFromPLan(this.strPlanSummaryData.strSourceSystemName, this.strPlanSummaryData.strSourceSystemName, '')
            };
            const objreq = {
                "subscriberSequenceNumber": this.getValueFromPLan(this.strPlanSummaryData.strSubscriberSequenceNumber, this.strPlanSummaryData.strSubscriberSequenceNumber, ''),
                "corporateEntityCode": this.strPlanSummaryData.strCorporationCode,
                "bluestarAccountNumber": this.strPlanSummaryData.objViewEmployerGroupWrapper.strblueStarAccountNumber
            };
            const lstOfRequestWrapper = [];
            lstOfRequestWrapper.push(objreq);
            this.objRequestForCardType = lstOfRequestWrapper;
            casePlanParam['subscriberSequenceNumber'] = objreq.subscriberSequenceNumber;
            casePlanParam['memberNumber'] = objreq.memberNumber;
            casePlanParam['bluestarAccountNumber'] = objreq.bluestarAccountNumber;
            const strSenderAddress = this.strPlanSummaryData.strfirstName + ' ' + this.strPlanSummaryData.strlastname;
            if (this.objCommunicationPreferenceData !== null && this.objCommunicationPreferenceData !== undefined) {
                casePlanParam['Address_ACE__c'] = this.objCommunicationPreferenceData.streetAddress;
                casePlanParam['City_ACE__c'] = this.objCommunicationPreferenceData.city;
                casePlanParam['State_ACE__c'] = this.objCommunicationPreferenceData.state;
                casePlanParam['ZipCode_ACE__c'] = this.objCommunicationPreferenceData.zipCode;
                this.strAddressOfMember = strSenderAddress + ' ' + '</br>' + this.objCommunicationPreferenceData.streetAddress + ', </br>' +
                    this.objCommunicationPreferenceData.city +
                    ', ' + this.objCommunicationPreferenceData.state + ', ' + this.objCommunicationPreferenceData.zipCode;
                this.boolAddressNotAvailable = false;
                this.boolAlteranteMailAddress = false;
            }
            if (this.strAddressOfMember === undefined || this.strAddressOfMember === null || this.strAddressOfMember === '') {
                this.boolAddressNotAvailable = true;
                this.boolAlteranteMailAddress = true;
            }
            if (this.strEmail !== null && this.strEmail !== undefined) {
                casePlanParam['Email_ACE__c'] = this.strEmail;
                if(this.boolEmailDefault) {
                    this.strEmailDefault = this.strEmail;
                }
            } else {
                casePlanParam['Email_ACE__c'] = '';
            }
            this.boolEmailDefault = false;
            if (this.strLanguage !== null && this.strLanguage !== undefined) {
                casePlanParam['strLanguage'] = this.strLanguage;
            } else {
                casePlanParam['strLanguage'] = '';
            }
            if (this.strPlanSummaryData.lstFamilyWrapper !== undefined && this.strPlanSummaryData.lstFamilyWrapper !== null &&
                this.strPlanSummaryData.lstFamilyWrapper.length > 0) {
                const strCurrentPageMemberName = this.strPlanSummaryData.strfirstName + ' ' + this.strPlanSummaryData.strlastname;
                const strCurrentPageMemberNumber = parseInt(this.strPlanSummaryData.strMemberNumber, 10);
                const lstFamilyMemberName = [];
                const MapOfFamilyMemberAndMemberNumberLocal = {};
                const MapOfFamilyMemberNumberAndMidlocal = {};
                const MapOfFamilyMemberNameAndMemberIdLocal = {};
                const MapOfFamilyMemberIdAndCMIDlocal = {};
                for (let j = 0; j < this.strPlanSummaryData.lstFamilyWrapper.length; j++) {
                    const strFamilyName = this.strPlanSummaryData.lstFamilyWrapper[j].strFirstName + ' ' + this.strPlanSummaryData.lstFamilyWrapper[j].strLastName;
                    if (strCurrentPageMemberNumber !== this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber) {
                        lstFamilyMemberName.push(strFamilyName + '_' + this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber.toString());
                        MapOfFamilyMemberAndMemberNumberLocal[this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber] = strFamilyName + '_' + this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber.toString();
                        MapOfFamilyMemberNameAndMemberIdLocal[strFamilyName + '_' + this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber.toString()] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                        MapOfFamilyMemberNumberAndMidlocal[this.strPlanSummaryData.lstFamilyWrapper[j].strMemberId] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                        MapOfFamilyMemberIdAndCMIDlocal[this.strPlanSummaryData.lstFamilyWrapper[j].strClientMemberId] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                    } else {
                        MapOfFamilyMemberAndMemberNumberLocal[this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber] = strFamilyName + '_' + this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber.toString();
                        MapOfFamilyMemberNameAndMemberIdLocal[strFamilyName + '_' + this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber.toString()] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                        MapOfFamilyMemberNumberAndMidlocal[this.strPlanSummaryData.lstFamilyWrapper[j].strMemberId] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                        MapOfFamilyMemberIdAndCMIDlocal[this.strPlanSummaryData.lstFamilyWrapper[j].strClientMemberId] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                    }
                }
                lstFamilyMemberName.sort();
                lstFamilyMemberName.splice(0, 0, strCurrentPageMemberName + '_' + strCurrentPageMemberNumber.toString());
                casePlanParam['lstFamilyName'] = lstFamilyMemberName;
                this.strInCareOf = strCurrentPageMemberName;
                this.strSubscriberName = strCurrentPageMemberName;
                this.strCMIDUI = strCurrentPageMemberNumber.toString();
                this.lstFamilyMemberNameOfOrderCard = lstFamilyMemberName;
                this.mapOfFamilyMemberAndMemberNumber = MapOfFamilyMemberAndMemberNumberLocal;
                this.MapOfFamilyMemberNameAndMemberId = MapOfFamilyMemberNameAndMemberIdLocal;
                this.MapOfFamilyMemberNumberAndMid = MapOfFamilyMemberNumberAndMidlocal;
                this.MapOfFamilyMemberIdAndCMID = MapOfFamilyMemberIdAndCMIDlocal;
            }
            const lstAddOnServices = casePlanParam.addOnServices;
            let strAddOnServices = '';
            let strAddOnServicesEmail = '';
            if (lstAddOnServices) {
                for (let intCount = 0; intCount < lstAddOnServices.length; intCount++) {
                    if (lstAddOnServices[intCount].strCode !== null) {
                        strAddOnServicesEmail = strAddOnServicesEmail + lstAddOnServices[intCount].strCode;
                        casePlanParam['strAddOnServicesEmail'] = strAddOnServices;
                    }
                    if (lstAddOnServices[intCount].strEffectiveEndDate !== undefined && lstAddOnServices[intCount].strEffectiveEndDate !== null && lstAddOnServices[intCount].strEffectiveEndDate !== "") {
                        const codeDate = new Date(lstAddOnServices[intCount].strEffectiveEndDate);
                        const CurrentDate = new Date();
                        CurrentDate.setHours(0, 0, 0, 0);
                        if (lstAddOnServices[intCount].strCode !== null && codeDate >= CurrentDate) {
                            strAddOnServices = strAddOnServices +',' +lstAddOnServices[intCount].strCode;
                        }
                    }
                }
 if(strAddOnServices!==''){
                    strAddOnServices=strAddOnServices.substr(1);
                     casePlanParam['strAddOnServices'] = strAddOnServices;
                }
            }
            if (casePlanParam.strTerminationDate) {
                const TerminationDate = casePlanParam.strTerminationDate;
                let TerminationDateArray = [];
                TerminationDateArray = TerminationDate.split('/');
                casePlanParam.strTerminationDate = TerminationDateArray[2] + '-' + TerminationDateArray[0] + '-' + TerminationDateArray[1];
            }
            if (casePlanParam.strEffectiveDate) {
                const EffectiveDate = casePlanParam.strEffectiveDate;
                let EffectiveDateArray = [];
                EffectiveDateArray = EffectiveDate.split('/');
                casePlanParam.strEffectiveDate = EffectiveDateArray[2] + '-' + EffectiveDateArray[0] + '-' + EffectiveDateArray[1];
            }
            MapOfDataforEmailLocal['Group Number'] = casePlanParam.strGroupNumber;
            MapOfDataforEmailLocal['Account Name (Account/Group)'] = this.strSubscriberName;
            MapOfDataforEmailLocal['Corporation Code (Plan)'] = casePlanParam.strCorpCode;
            MapOfDataforEmailLocal['Policy Client Member Id'] = casePlanParam.strPolicyClientMemberId;
            MapOfDataforEmailLocal['Line Of Business'] = casePlanParam.strAceLineOfBusiness;
            this.MapOfDataforEmail = MapOfDataforEmailLocal;
            this.objPlanData = casePlanParam;
        }
    }
    @api
    idcardModal(objCommunicationAddress){
        if(typeof objCommunicationAddress === 'string' && objCommunicationAddress) {
            this.objCommunicationPreferenceData= JSON.parse(objCommunicationAddress);
        } else {
            this.objCommunicationPreferenceData=objCommunicationAddress;
        }
         this.planSummaryValue();
         if(!this.boolBoeingDrugOnlyPlan) {
         this.handleLoad();
         } else {
             this.isLoaded = !this.isLoaded;
         }
    }
    @api
    openModal() {
        this.showModal = true;
    }
    @api
    closeModal() {
        this.showModal = false;
    }
    /*Refresh Modal*/
    refreshModal() {
        this.isSubmitResultSuccess = false;
        this.isSubmitEnabled = false;
        this.isError = false;
        this.isLoaded = !this.isLoaded;
        this.isdeliveryMethodDefault = false;
        this.recipientDefaultValue = 'Member';
        this.isError = false;
        this.lstDeliveryMethod = this.lstDeliveryMethodBackup;
        this.deliveryMethodDefaultValue = 'Directed to Self-Service';
        this.statusDefaultValue = 'Closed';
        this.SubstatusDefaultValue = '';
        this.strADDRESS = '';
        this.strAlternateAddressOfMember = '';
        this.strCity = '';
        this.strEmail = this.strEmailDefault;
        this.strState = '';
        this.strZipCode = '';
        this.strInCareOf = '';
        this.strFaxNumber = '';
        this.strProvider = '';
        this.strCardTypeDefaultValue = '';
        this.strFaxNumberFormatted = '';
        this.boolMailAddress = false;
        this.boolAlteranteMailAddress = false;
        this.boolCaseOrigin = false;
        this.boolIsRecipientAndMail = false;
        this.boolFaxIsRecipientAndMail = false;
        this.boolEmailCondition = false;
        this.boolfaxCondition = false;
        this.boolEmailIsRecipientAndMail = false;
        this.boolTempToast = false;
        this.boolFaxIsRecipientAndProv = false;
        this.boolEmailIsRecipientAndProv = false;
        this.boolSubstatus = false;
        this.boolApiError = false;
        this.isApiError = false;
        this.boolShowMemberMessage=false;
        this.boolFepMoreThan8Member=false;
        this.caseOriginDefaultValues = this.caseOriginDefaultValuesBackup;
        this.strErrorSectionName = '';
        this.boolSupressedLables = false;
        // Fire the custom event
        const orderIdCardEvent = new CustomEvent('RefreshOrderIdCard', {detail: 'FetchDataFromCommunicationCard',bubbles : true});
         // Fire the custom event
         this.dispatchEvent(orderIdCardEvent);
    }
    handleFocusout(objEvent) {
        if (this.showModal) {
            let boolIsComboboxOpen = false;
            if (objEvent.target.closest('.slds-combobox')) {
                boolIsComboboxOpen = objEvent.target.closest('.slds-combobox').classList.contains('slds-is-open');
            }
            [...this.template.querySelectorAll('.slds-combobox')].forEach((el) => {
                el.classList.remove('slds-is-open');
            });
            if (boolIsComboboxOpen) {
                objEvent.target.closest('.slds-combobox').classList.add('slds-is-open')
            }
        }
    }
    toggleCombobox(objEvent) {
        const objCmbx = objEvent.target.closest('.slds-combobox');
        if (objCmbx.querySelector('.highlight') && objCmbx.querySelector('.highlight').classList) {
            objCmbx.querySelector('.highlight').classList.remove('highlight');
        }
        const objDimensions = objCmbx.getBoundingClientRect();
        const objDropdown = objCmbx.querySelector('.slds-dropdown');
        objDropdown.style.top = objDimensions.top + 34 + 'px';
        objDropdown.style.width = objDimensions.width + 'px';
        objDropdown.style.left = objDimensions.left -
            objCmbx.closest('.slds-modal__container').getBoundingClientRect().left + 'px';
        if (objCmbx && objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]') && objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]').classList) {
            objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]').classList.add('highlight');
        }
        objCmbx.classList.toggle('slds-is-open');
    }
    reportComboboxValidity(objComp) {
        let boolIsValid = false;
        if (objComp.hasAttribute('required')) {
            const strValue = objComp.value;
            [...objComp.closest('.slds-combobox').querySelectorAll('li[data-value]')]
            .forEach((el) => {
                boolIsValid = boolIsValid || (el.getAttribute('data-value') === strValue);
            });
        } else {
            boolIsValid = true;
        }
        if (boolIsValid) {
            objComp.closest('.slds-form-element').classList.remove('slds-has-error');
        } else {
            objComp.closest('.slds-form-element').classList.add('slds-has-error');
        }
        return boolIsValid;
    }
    checkComboboxValidity(objComp) {
        return !objComp.closest('.slds-form-element').classList.contains('slds-has-error');
    }
    //CEAS-59345 if lstSuppMembers list of object attribute count is 0 dont send it in callout request
    checkspmtlmembers(lstSuppMembers) {
        let newArraySuppMembers = [];
        if(lstSuppMembers.length > 0) {
            newArraySuppMembers = lstSuppMembers.filter(element => element.spmtlInsTypCd !== '' && ((element.drugCardCnt !== '0' && element.drugCardCnt !== '') || (element.hlthCardCnt !== '0' && element.hlthCardCnt !== ''))) 
        }
        return newArraySuppMembers;
    }
    //CEAS-59345 if lstmembers list of object attribute count is 0 dont send it in callout request
    checklstmembers(lstmembers) {
        let newArrayLstMembers = [];
        if(lstmembers.length > 0 ) {
            newArrayLstMembers = lstmembers.filter(element => (element.dentCardCnt !== '0' && element.dentCardCnt !== '') || (element.combCardCnt !== '0' && element.combCardCnt !== '') || (element.drugCardCnt !== '0' && element.drugCardCnt !== '') || (element.hlthCardCnt !== '0' && element.hlthCardCnt !== ''))
        }
        return newArrayLstMembers;
    }
}
