import { LightningElement,api,track,wire } from 'lwc';

import getIdenticalCaseAndCaseRelatedDetails from '@salesforce/apex/CreateChildCaseController_ACE.getIdenticalCaseAndCaseRelatedDetails';

import { EnclosingTabId, getTabInfo, openSubtab } from 'lightning/platformWorkspaceApi';
import BaseLWC from 'c/baseLWCFunctions_CF';

import ClaimDentalRecordType_ACE from '@salesforce/label/c.ClaimDentalRecordType_ACE';
import ViewClaimsSummary_Medical_ACE from '@salesforce/label/c.ClaimMedicalRecordType_ACE';
import ClaimMedicalRecordType_ACE from '@salesforce/label/c.ClaimMedicalRecordType_ACE';
import ViewClaimsSummary_Pharmacy_ACE from '@salesforce/label/c.ClaimPharmacyRecordType_ACE';
import ClaimPharmacyRecordType_ACE from '@salesforce/label/c.ClaimPharmacyRecordType_ACE';
import IDRDisputeRecordType from '@salesforce/label/c.IDRDisputeRecordType';
import AppealsRecordType_ACE from '@salesforce/label/c.AppealsRecordType_ACE';
import CorrespondenceCase_Type_ACE from '@salesforce/label/c.CorrespondenceCase_Type_ACE';
import WrittenCorrespondenceCase_SubType_ACE from '@salesforce/label/c.WrittenCorrespondenceCase_SubType_ACE';
import CreateCasePage_Provider_ACE from '@salesforce/label/c.CreateCasePage_Provider_ACE';
import ManualCaseCreation_UrlParam_ACE from '@salesforce/label/c.ManualCaseCreation_UrlParam_ACE';

export default class LwcCreateIdenticalChildCaseModalWindowComponentAce extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    label = {  
        ClaimDentalRecordType_ACE,
        ViewClaimsSummary_Medical_ACE,
        ClaimMedicalRecordType_ACE,
        ViewClaimsSummary_Pharmacy_ACE,
        ClaimPharmacyRecordType_ACE,
        IDRDisputeRecordType,
        AppealsRecordType_ACE,
        CorrespondenceCase_Type_ACE,
        WrittenCorrespondenceCase_SubType_ACE,
        CreateCasePage_Provider_ACE,
        ManualCaseCreation_UrlParam_ACE
    }
        lstCaseRelatedDetail  = [];
        boolPersonAccount = false; 
        lstCaseandCaseRelatedDet;            
        idAccount ; 
        strCaseNumber;
        strCurrentTabUrl;
        boolProspectMember ;
        parenttabId;
        //Stores the List of case values 
        lstCase; 

        @track strIframeId;

        @api strAceLineOfBusiness;
        @api boolNoSubscriber;
        @api recordId;
        @api isOpenIdenticalChildCase;
    
    connectedCallback() {
        this.fetchTabData();
        if(this.isOpenIdenticalChildCase) {
        this.callbackMethod();
        }      
    }
    //Fetches the TabId from Workspace API 
    fetchTabData = () => {
        this.boolAddToCase = false;
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
                this.objTabData = objTabData;
                this.parenttabId = this.objTabData.parentTabId;
                this.strCurrentTabUrl = this.objTabData.url;
            })
            .catch(() => {
                this.handleErrors();
            });
        }
    }
    //Makes Apex Call and get the data processed
    callbackMethod() {
        const objParameters = {
            "idCaseRecord": this.recordId,
            "strLineOfBusiness": this.strAceLineOfBusiness
        };     
        getIdenticalCaseAndCaseRelatedDetails(objParameters)    
        .then((objResult) => {
            try {
                this.lstCaseandCaseRelatedDet = objResult;
                const lstcaserel = this.lstCaseandCaseRelatedDet.lstofCaseRelatedDetails;
                if(this.lstCaseandCaseRelatedDet.lstCase !== null && this.lstCaseandCaseRelatedDet.lstCase !== undefined && this.lstCaseandCaseRelatedDet.lstCase.length > 0) {
                    this.lstCase = this.lstCaseandCaseRelatedDet.lstCase[0];
                }
                
                this.setValues();
                if(this.lstCase.Account.RecordType.DeveloperName &&
                   this.lstCase.Account.RecordType.DeveloperName === 'PersonAccount') {
                    this.boolPersonAccount = true;
                }
                if (BaseLWC.isNotUndefinedOrNull(lstcaserel) && lstcaserel.length > 0) {
                    for (let i = 0; i < lstcaserel.length; i++) {
                        const objDateTime = lstcaserel[i].Date_ACE__c;
                        let datDateToShow = [];
                        let newDate;
                        let strStatus;
                        let completionDate;

                        if (objDateTime !== undefined && objDateTime !== "") {
                            datDateToShow = objDateTime.split('-');
                        }
                        //Attaching the Hover Over code to the data before passing the result set to datatable.
                        if (objDateTime !== undefined && objDateTime !== "") {
                            newDate = (datDateToShow[1] + "/" + datDateToShow[2] + "/" + datDateToShow[0]);
                        } else {
                            newDate = null;
                        }
                        if (lstcaserel[i].Status_ACE__c === "" || lstcaserel[i].Status_ACE__c === undefined) {
                            strStatus = "";
                        } else {
                            strStatus = lstcaserel[i].Status_ACE__c;
                        }
                        if (lstcaserel[i].Completion_Date_ACE__c) {
                            const lstDateTimeOpened = lstcaserel[i].Completion_Date_ACE__c.split("-");
                            completionDate = lstDateTimeOpened[1] + '/' + lstDateTimeOpened[2] + '/' + lstDateTimeOpened[0];
                        }
                        const pattern = {
                            "CAS_Indicator_ACE__c": true,
                            "Claim_Number_ACE__c": lstcaserel[i].Claim_Number_ACE__c,
                            "Date_ACE__c": newDate,
                            "Status_ACE__c": strStatus,
                            "SCCF_Number_ACE__c": lstcaserel[i].SCCF_Number_ACE__c,
                            "Total_Billed_ACE__c": lstcaserel[i].Total_Billed_ACE__c,
                            "Billing_Provider_Name_Medical_Claim_ACE__c": lstcaserel[i].Billing_Provider_Name_Medical_Claim_ACE__c,
                            "Billing_Provider_Name_Dental_Claim_ACE__c": lstcaserel[i].Billing_Provider_Name_Dental_Claim_ACE__c,
                            "Adjustment_Number_ACE__c": lstcaserel[i].Adjustment_Number_ACE__c,
                            "Claim_Id_ACE__c": lstcaserel[i].Claim_Id_ACE__c,
                            //CEAS-52445 Added for Dispute Identical Case
                            "Idr_Claim_Number_ACE__c" : lstcaserel[i].Idr_Claim_Number_ACE__c,
                            "Patient_Name_ACE__c": lstcaserel[i].Patient_Name_ACE__c,
                            "Requestor_Name_ACE__c" : lstcaserel[i].Requestor_Name_ACE__c,
                            "GC_Appeal_ACE__c": lstcaserel[i].GC_Appeal_ACE__c,
                            "Status_Reason_ACE__c": lstcaserel[i].Status_Reason_ACE__c,
                            "ComplaintClass_ACE__c": lstcaserel[i].ComplaintClass_ACE__c,
                            "Completion_Date_ACE__c": completionDate
                        };
                        const hoverDetailsPattern = {
                            "SCCF_Number": lstcaserel[i].SCCF_Number_ACE__c,
                            "Total_Billed": lstcaserel[i].Total_Billed_ACE__c,
                            "Provider_Name": lstcaserel[i].Billing_Provider_Name_Medical_Claim_ACE__c
                        };
                        const hoverDetailsPatternphar = {
                            "Product_Name": lstcaserel[i].Product_Name_ACE__c,
                            "Pharmacy_Name": lstcaserel[i].Pharmacy_Name_ACE__c
                        };
                        const hoverDetailsPatternAppeal = {
                            "Patient_Name_ACE__c": lstcaserel[i].Patient_Name_ACE__c,
                            "Completion_Date_ACE__c": lstcaserel[i].Completion_Date_ACE__c,
                            "Status_Reason_ACE__c": lstcaserel[i].Status_Reason_ACE__c,
                            "Sub_Category_ACE__c": lstcaserel[i].Sub_Category_ACE__c
                        };
                        const hoverDetailsPatternPriorAuth = {
                            "Facility_ACE__c": lstcaserel[i].Facility_ACE__c,
                            "Requested_Date_Range_ACE__c": lstcaserel[i].Requested_Date_Range_ACE__c,
                            "Patient_Name_ACE__c": lstcaserel[i].Patient_Name_ACE__c,
                            "BirthDate_ACE__c": lstcaserel[i].BirthDate_ACE__c
                        };
                        //CEAS-52875
                        const hoverDetailsPatternDental = {
                            "Total_Billed": lstcaserel[i].Total_Billed_ACE__c,
                            "Provider_Name": lstcaserel[i].Billing_Provider_Name_Dental_Claim_ACE__c
                        };
                         //CEAS-52445 Added for IDR Dispute Identical Case
                        const hoverDetailsPatternDispute = {
                            "Requestor_Name": lstcaserel[i].Requestor_Name_ACE__c,
                            "Patient_Name": lstcaserel[i].Patient_Name_ACE__c,
                            "Claim_Id": lstcaserel[i].Idr_Claim_Number_ACE__c    
                        };
                        if (lstcaserel[i].RecordType.Name ===this.label.ClaimDentalRecordType_ACE) {
                            pattern.RecordType = this.label.ClaimDentalRecordType_ACE;
                            pattern.Hover_Related_Field_Dental_ACE__c = hoverDetailsPatternDental;
                        } else if (lstcaserel[i].RecordType.Name === this.label.ViewClaimsSummary_Medical_ACE) {
                            pattern.RecordType = this.label.ClaimMedicalRecordType_ACE;
                            pattern.Hover_Related_Field_Medical_ACE__c = hoverDetailsPattern;
                        } else if (lstcaserel[i].RecordType.Name === this.label.ViewClaimsSummary_Pharmacy_ACE) {
                            pattern.RecordType = this.label.ClaimPharmacyRecordType_ACE;
                            pattern.Hover_Related_Field_Pharmacy_ACE__c = hoverDetailsPatternphar;
                        } else if(lstcaserel[i].RecordType.Name === this.label.IDRDisputeRecordType) {
                            pattern.RecordType = this.label.IDRDisputeRecordType;
                            pattern.Hover_Related_Field_Dispute_ACE__c = hoverDetailsPatternDispute;
                        } else if (lstcaserel[i].RecordType.Name === this.label.AppealsRecordType_ACE) {
                            pattern.RecordType =this.label.AppealsRecordType_ACE;
                            pattern.Hover_Related_Field_Appeals_ACE__c = hoverDetailsPatternAppeal;
                        } else {
                            //Added as part of CEAS-32556
                            pattern.RecordType = lstcaserel[i].RecordType.Name;
                            pattern.Hover_Related_Auth_ACE = hoverDetailsPatternPriorAuth;
                            pattern.Approved_Date_Range_ACE__c = lstcaserel[i].Approved_Date_Range_ACE__c;
                        }
                        this.lstCaseRelatedDetail .push(pattern);
                    }
                }
                let strInquirerName;
                let strInquirerRelationship;
                let strCallBackNumber;
                const strParentCaseType = this.lstCase.Type;
                const strParentCaseSubType = this.lstCase.Sub_Type_ACE__c;
                if (strParentCaseType === this.label.CorrespondenceCase_Type_ACE &&
                    strParentCaseSubType === this.label.WrittenCorrespondenceCase_SubType_ACE &&
                    this.lstCase.InquirerRelationship_ACE__c === this.label.CreateCasePage_Provider_ACE) {
                    strInquirerName = this.lstCase.InquirerName_ACE__c;
                    strInquirerRelationship = this.lstCase.InquirerRelationship_ACE__c;
                    strCallBackNumber = this.lstCase.CaseCallbackNumber_ACE__c;
                } else {
                    strInquirerName = null;
                    strInquirerRelationship = null;
                    strCallBackNumber = null;
                }
                let strSendById = '';
                let strSendByName = '';
                if(this.lstCase.SentBy_ACE__c !== undefined && this.lstCase.SentBy_ACE__c !== '' && this.lstCase.SentBy_ACE__c !== null) {
                    strSendById = this.lstCase.SentBy_ACE__c;
                    strSendByName = this.lstCase.SentBy_ACE__r.Name;
                }
                const idCaseRuleId = this.lstCaseandCaseRelatedDet.idCaseRule;
                const objCasedetails = this.setobjCasedetails(); 
               if (this.strCurrentTabUrl != null) {
               const objUrl = new URL(this.strCurrentTabUrl);
                if (typeof objUrl.searchParams !== "undefined" && objUrl.searchParams !== null && objUrl.searchParams.get('c__BaseURLParam') !== null) {
                    const objDecodedURLUrl = new URL(BaseLWC.helperBaseDecodeUrl(objUrl.href));
                    const prospectUrl = JSON.stringify(objDecodedURLUrl);
                   const urlProspect =  BaseLWC.helperBaseGetUrlParameters('boolProspectMember',prospectUrl);
                   if(urlProspect !== null && urlProspect !== undefined) {
                        this.boolProspectMember  = urlProspect;
                    }
                    //When URL have c__BaseURLParam
                    let strFlexipageNameUrl = this.label.ManualCaseCreation_UrlParam_ACE;
                    if (this.boolProspectMember  === "true") {
                        if (this.boolNoSubscriber === true) {
                            strFlexipageNameUrl = '/lightning/n/ManualCaseCreate_ProspectMemberNoSub_ACE'
                        } else {
                            strFlexipageNameUrl = '/lightning/n/ManualCaseCreate_ProspectMember_ACE'
                        }
                    }
                     //CEAS-57152 Added new url param boolLoadAfterPlanEvent
                    const strFlexiPageUrl = strFlexipageNameUrl+ BaseLWC.helperBaseEncodeUrl('?' + decodeURIComponent(escape(window.atob(objUrl.searchParams.get('c__BaseURLParam')))) + '&caseId=' + this.strCaseNumber + '&boolLoadAfterPlanEvent=' + this.boolPersonAccount +'&Dynamic=true&timeInMillis=' + Date.now());
                    openSubtab(this.parenttabId, {url: strFlexiPageUrl, focus: true});
                    this.sendToFoundationCreateCasePage( objCasedetails,this.lstCaseRelatedDetail, idCaseRuleId,this.strIframeId);
                } else {
                    //When URL does not have c__BaseURLParam
                    const strFlexipageNameUrl = this.label.ManualCaseCreation_UrlParam_ACE;
                    const strUrl = '?caseId=' +this.strCaseNumber + '&boolLoadAfterPlanEvent=' +this.boolPersonAccount +'&Dynamic=true&timeInMillis=' + Date.now();
                    const strFlexiPageUrl = strFlexipageNameUrl +  BaseLWC.helperBaseEncodeUrl(strUrl);
                    openSubtab(this.parenttabId, {url: strFlexiPageUrl, focus: true});
                    this.sendToFoundationCreateCasePage(objCasedetails,this.lstCaseRelatedDetail , idCaseRuleId,this.strIframeId);
                }
            } 
            } catch (exception) {
                this.handleErrors();
            }
            })
            .catch(() => {
                this.handleErrors();
            });
    }
    //Handle the error occurances
    handleErrors() {
        //Do nothing
    }
    //Posts a message to the iframe to capture the parent case details which needs to be handled in Manualcasecreation.js
    sendToFoundationCreateCasePage(objCasedetails,lstCaseRelatedDetail , caseRuleId,strIframeId) {
        
      try {
            let intCasePageInterval = 0;
            const objErrorData = {};
            objErrorData.strComponentName = 'lwcCreateIdenticalChildCaseModalWindowComponentAce';
            objErrorData.strMessage = 'SetIntervals';
            objErrorData.strFunctionName = 'sendToFoundationCreateCasePage';
            objErrorData.strStackTrace = 'MaxIntervalReached;\nClearedInterval;\n';
            objErrorData.strError = 'IframeId Not Found: ' +this.strIframeId;
            
            const postMessageFunction = setInterval(() => { 
                
            try {
               
                intCasePageInterval++;
                const idIframe = strIframeId;
                const strDynamicCasePage = document.getElementById(idIframe);
                if (strDynamicCasePage !== undefined && strDynamicCasePage !== null && strDynamicCasePage.dataIsLoaded === 1) {
                    clearInterval(postMessageFunction);
                    this.postDataToCasePage(objCasedetails,lstCaseRelatedDetail , caseRuleId,strIframeId);
                }
                BaseLWC.clearLoopedIntervalsInBase(this, intCasePageInterval, 1, postMessageFunction, objErrorData);
            } catch (objException) {
                clearInterval(postMessageFunction);
            }
            }, 1000);
            
    
        } catch (exception) {
            return;
        }
    }

    postDataToCasePage(objCasedetails,lstCaseRelatedDetail , caseRuleId,strIframeId) {
        const objClaimSummaryFrame = document.getElementById(strIframeId).contentWindow;
        const objResponse = {
            strIdDestination: 'Manual_Case_Creation_Case_Related_Details',
            objParameters: {
                caseObject: objCasedetails,
                lstCaseRelatedDetail : lstCaseRelatedDetail ,
                caseRuleId : caseRuleId
            }
        };
        // Posting message
        
        objClaimSummaryFrame.postMessage(JSON.stringify(objResponse), '*');
        
    }

    setValues() {
    this.idAccount =  this.lstCase.AccountId;
    this.strCaseNumber = this.lstCase.CaseNumber;
                    const strFrameURL = "idCreateNewCaseLightningComponent";
                    if (this.lstCase.Account.MID_Surrogate_ACE__c || (this.lstCase.Account.RecordType.DeveloperName &&
                       (this.lstCase.Account.RecordType.DeveloperName === 'ProspectMember_ACE' || this.lstCase.Account.RecordType.DeveloperName === 'Out_of_State_FEP_Member'))) {
                        this.strIframeId = strFrameURL + '_' + this.lstCase.AccountId;
                    } else {
                        this.strIframeId = strFrameURL;
                    }
    }
    //sets the values to the params
    setobjCasedetails() {
        return {
            "boolChildCase": true,
            "AccountId": this.idAccount,
            "CaseNumber": this.strCaseNumber,
            "RecordTypeId":this.lstCase.RecordTypeId,
            "Type": this.lstCase.Type,
            "Sub_Type_ACE__c": this.lstCase.Sub_Type_ACE__c,
            "CAS_Indicator_ACE__c":false,
            "Identical_Indicator_ACE__c": true,
            "IsCbcApiCallAvailable_ACE__c":false,
            "Level_of_Review_ACE__c":this.lstCase.Level_of_Review_ACE__c,
            "InquirerName_ACE__c": this.lstCase.InquirerName_ACE__c,
            "strInquirerName": this.lstCase.InquirerName_ACE__c,
            "InquirerRelationship_ACE__c": this.lstCase.InquirerRelationship_ACE__c,
            "strInquirerRelationship": this.lstCase.InquirerRelationship_ACE__c,
            "strCallBackNumber": this.lstCase.CaseCallbackNumber_ACE__c,
            "CaseCallbackNumber_ACE__c": this.lstCase.CaseCallbackNumber_ACE__c,
            "Member_Name_ACE__c":this.lstCase.Member_Name_ACE__c,
            "Appeal_Requested_DateTime_ACE__c":this.lstCase.Appeal_Requested_DateTime_ACE__c,
            "Origin":this.lstCase.Origin,
            "SpecialHandling_ACE__c":this.lstCase.SpecialHandling_ACE__c,
            "AppealRecordType_ACE__c":this.lstCase.AppealRecordType_ACE__c,
            "RequestorType_ACE__c": this.lstCase.RequestorType_ACE__c,
            "Sub_Category_ACE__c":this.lstCase.Sub_Category_ACE__c,
            "RequestReceived_ACE__c":this.lstCase.RequestReceived_ACE__c,
            "Source_ACE__c":this.lstCase.Source_ACE__c,
            "Category_ACE__c":this.lstCase.Category_ACE__c,
            "AppealType_ACE__c":this.lstCase.AppealType_ACE__c,
            "PriorityOfReview_ACE__c":this.lstCase.PriorityOfReview_ACE__c,
            "DOINumber_ACE__c":this.lstCase.DOINumber_ACE__c,
            "Interaction_Log_Id_ACE__c" : this.lstCase.Interaction_Log_Id_ACE__c,
            "EarliestInteractionLog_ACE__c" : this.lstCase.EarliestInteractionLog_ACE__c,
            "eCheckInCaseNumber_ACE__c" : this.lstCase.eCheckInCaseNumber_ACE__c
        };   
    }
}