import { LightningElement ,api,track} from 'lwc';

export default class LwcCodeCheckSelection_ACE extends LightningElement {
    @api
    values = [];
    @track valuesLocal = [];
    @track
    selectedvalues = [];
    selectedLabels = [];
    boolCheckbox = true;
    @track strSelectedmessage = "--None--"

    @api
    picklistlabel = '';
    @api
    customClass = '';
    boolSelectAll;

    showdropdown;
    boolShowLabel=true;
    boolRenderPicklistMenu = true;
    showPill=false;
    handleleave() {
        
        let sddcheck= this.showdropdown;

        if(sddcheck){
            this.showdropdown = false;
            this.fetchSelectedValues();
        }
    }

    handleBlur(event) {
        this.showdropdown = false;
    }
    @api resetValue() {
        this.selectedLabels = [];
        this.selectedvalues = [];
        this.strSelectedmessage =  "--None--";
        this.valuesLocal.forEach((objElement) => {
            objElement.value = false;
            objElement.selected = false;
        });
    }

    connectedCallback(){
        this.values=this.values;
        this.valuesLocal = this.values;
        this.picklistlabel=this.picklistlabel;
        this.boolShowLabel=(this.picklistlabel && this.picklistlabe !== '');

        if(this.valuesLocal){
            JSON.parse(JSON.stringify(this.valuesLocal)).forEach((element) =>  {
                if(element.selected) {
                    this.selectedvalues.push(element.value);
                } else {
                    //do nothing
                }
            });
        }

        if(this.selectedvalues.length === 0) {
            this.strSelectedmessage =  "--None--";
        } else {
            this.strSelectedmessage =  this.selectedvalues.length + ' selected';
        }
    }
    handleSelectAll(objEvent) {
            const isChecked = objEvent.target.checked;
            this.boolSelectAll = isChecked;      
            this.selectedLabels = [];
            this.selectedvalues = [];       
            if(isChecked) {
                this.valuesLocal.forEach((objElement) => {
                    this.selectedLabels.push(objElement.label);
                    this.selectedvalues.push(objElement.value);
                });         
            } else {
                //Do Nothing
            }
            if(this.selectedLabels.length === 0) {
                this.strSelectedmessage =  "--None--";
            } else {
                this.strSelectedmessage =  this.selectedLabels.length + ' selected'; 
            }
            this.refreshOrginalList();
            const selectedEvent = new CustomEvent("changecheckbox", {
                detail : JSON.stringify(this.valuesLocal)
                
            });
            this.dispatchEvent(selectedEvent);

    }

    fetchSelectedValues() {

        this.selectedvalues = [];

        //get all the selected values
        if(this.boolCheckbox){
            [...this.template.querySelectorAll('.selectbox-with-checkbox li .multiSelectCheckBox')].forEach(
                element => {
                    if(element.checked){
                        this.selectedvalues.push(element.getAttribute('data-value'));
                    }
                }
            );
        }

        //refresh original list
        this.refreshOrginalList();
    }

    disableOtherCheckBoxes(selectedCheckbox) {
        //this.selectedvalues = [];
        //get all the selected values
        if(this.boolCheckbox){
            [...this.template.querySelectorAll('.selectbox-with-checkbox li .multiSelectCheckBox')].forEach(
                element => {
                    if(element.checked && element.getAttribute('data-value') !== selectedCheckbox) {
                        element.removeAttribute('checked');
                    }
                }
            );
        }
    }


    refreshOrginalList() {
        //update the original value array to shown after close
        if(!this.valuesLocal){
            return;
        }
        const picklistvalues = JSON.parse(JSON.stringify(this.valuesLocal));
        picklistvalues.forEach((element, index) => {
            if(this.selectedvalues.includes(element.value)){
                picklistvalues[index].selected = true;
            }else{
                picklistvalues[index].selected = false;
            }

            if(this.selectedLabels.includes(element.label)){
                picklistvalues[index].selected = true;
            }else{
                picklistvalues[index].selected = false;
            }
        });
        this.valuesLocal = picklistvalues;
    }

    handleShowdropdown(){
        const drop = this.showdropdown;
        if(drop){
            this.showdropdown = false;
            this.fetchSelectedValues();
        }else{
            this.showdropdown = true;
        }
    }

    //Boolean Checkbox true

        //holds only selected checkbox items that is being displayed based on search
        @track selectedItems = []; 

        //since values on checkbox deselection is difficult to track, so workaround to store previous values.
        //clicking on Done button, first previousSelectedItems items to be deleted and then selectedItems to be added into globalSelectedItems
        @track previousSelectedItems = [];
        //this holds checkbox values (Ids) which will be shown as selected
        @track value = []; 
        //captures the text to be searched from user input
        searchInput ='';    

        //Cancel button click hides the dialog
        handleCancelClick(){
            this.initializeValues();
        }

        //this method initializes values after performing operations
        initializeValues(){
            this.searchInput = '';
        }

        handleSelectChange(event) {
            const checkedVal = event.target.getAttribute("data-value");
            const checkedLabel = event.target.label;
            const isChecked = event.target.checked;              
            if(isChecked) {
                this.selectedLabels.push(checkedLabel);
                this.selectedvalues.push(checkedVal);   
                if(this.selectedLabels && this.selectedLabels.length === this.valuesLocal.length) {
                    this.boolSelectAll = true;
                }
            } else {
                this.selectedLabels.splice(this.selectedLabels.indexOf(checkedLabel),1);
                this.selectedvalues.splice(this.selectedvalues.indexOf(checkedVal),1);
                if(this.boolSelectAll) {
                    this.boolSelectAll = false;
                }
            }
            if(this.selectedLabels.length === 0) {
                this.strSelectedmessage =  "--None--";
            } else {
                this.strSelectedmessage =  this.selectedLabels.length + ' selected'; 
            }
            this.refreshOrginalList();
            const selectedEvent = new CustomEvent("changecheckbox", {
                    detail : JSON.stringify(this.valuesLocal)
            });
            this.dispatchEvent(selectedEvent);
            
        }
}