/*
 *
 * Created by Kundan Kumar Das on 2/19/2021.
 */

import { LightningElement, api, track } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
import Message_warning_ACE from "@salesforce/label/c.MessageLightningComponent_Warning_ACE";
import Message_error_ACE from "@salesforce/label/c.Message_error_ACE";
import MESSAGEAPIERROR from '@salesforce/label/c.ArchivedRecordsAPIError_ACE';
import MESSAGEWARNING from '@salesforce/label/c.ViewCaseSummary_NoCasesError_ACE';
export default class LwcCustomizedDatatable extends LightningElement {

    @track tableInitData = [];
    @track tableSettings = {};
    label = {

        Message_warning_ACE,
        Message_error_ACE,
        MESSAGEAPIERROR,
        MESSAGEWARNING
    };
    @api
    get tableData() {
        return this.tableInitData;
    }

    set tableData(value) {
        if (value) {
            this.tableInitData = [...value];
            this.loadData();
        }
    }

    @api
    get settings() {
        return this.tableSettings;
    }

    set settings(value) {
        this.tableSettings = { ...value };
        this.loadData();
    }

    tooltipValue = '';
    buttonTitle = 'Export';
    strExportFileName='';
    @track boolExportButtonDisabled = true;
    @api renderingTableData;
    columnsortedTableData;
    @track enableViewMore = false;
    @track showPagination = false;
    @track pages = [1];
    @track intActivePage = 1;
    @track searchMarginParams = "";
    @track tableContainerClass = "slds-box slds-theme_default table-container";
    filterdata;
    columns;
    restrictedpageSize;
    pageSize;
    strLabelExpandCollapseRows = "Expand All Rows";
    @track boolSecondaryTable = false;
    @track boolDataChange = false;
    //For Page Length Menu
    boolPaginationwithSize = false;
    boolShowSearch = true;
    boolShowFilter = false;
    @track boolShowExport =  false;
    //CEAS-52825
    boolShowCheckbox = false;
    boolPrevDisabled = true;
    boolNextDisabled = false;
    boolCreateRowTemplate = false;
    nestedColSpan;
    strNoMatchColspan;
    boolShowNoMatchFound = false;
    boolEmptyTable =false;
    @api lstFilteredData;
    @api sortedData = [];
    //For Filter Rendering
    mapFilterConfig = new Map();
    lstTableFilterData = [];
    lstSelectedRowId = [];
    searchMatrix = ['', []];
    mapPicklistColumnUniqueData = new Map();
    lstTrackEvents = ['click'];
    rowSelectCount = 0;
    boolShowHeader = false;
    boolShowSearchLabel = true;
    searchPlaceholder = '';
    intConnectedCount = 0;
    numOfRecords;
    //Header btn
    @track showTableCustomButtonsSetting = {};
    //Header btn
    boolShowCustomButtonColumn = false;
    //Header btn
    boolShowHeaderCustomButton = false;
    //Header btn
    boolDisableHeaderCustomButton = false;
    //Booleans for showing warning/erorr banners for no data/api errors.
    @api boolShowNoRecordsFound;
    @api boolShowApiError = false;
    boolShowNoRecordsFoundLV;
    showRecordCount = false;
    //CEAS-77153
    boolShowIcon = false;
    iconNameToShow = '';
    //CEAS-77005
    boolCheckboxHeader = false;

    boolHeaderNoCapital = false;
        cloneObject = (origObj) => {
        return JSON.parse(JSON.stringify(origObj));
    }
    deepCloneMap = (obj) => {
        let Val;
        if (typeof obj == 'number' || typeof obj == 'string' || typeof obj == 'undefined') {
            Val = obj;
        } else if (obj instanceof Map) {
            Val = new Map();
            for (const [key, value] of obj.entries()) {
                Val.set(key, this.deepCloneMap(value));
            }
        } else if (Array.isArray(obj)) {
            Val = obj.map(el => {
                return this.deepCloneMap(el);
            });
        } else {
            Val = JSON.parse(JSON.stringify(obj));
        }
        return Val;
    }
    //Header btn
    handleHeaderCustomButtonClick = () => {
        const objParams = {};
        BaseLWC.fireNativeCustomEvent('headercustombuttonclick', objParams, this);
    }
    //Header btn
    handleRowCustomButtonClick = (event) => {
        if (event.target.getAttribute('data-disabled')) {
            return;
        }
        let clickedButtonRow;
        const intIndex = event.target.closest('tr').getAttribute('data-key');
        this.lstFilteredData.forEach(el => {
            if (el.get('id').toString() === intIndex.toString()) {
                clickedButtonRow = el.get("rowData");
            } else {
                //do nothing
            }
        });
        const objParams = { ...clickedButtonRow };
        BaseLWC.fireNativeCustomEvent('rowcustombuttonclick', objParams, this);
    }
    //Header btn
    checkDisableHeaderCustomButtonCondition = () => {
        this.boolDisableHeaderCustomButton = BaseLWC.isNotUndefinedOrNull(this.tableSettings.showTableCustomButtonsSetting) &&
            (this.tableSettings.showTableCustomButtonsSetting.boolDisableOnNoSelection && this.rowSelectCount === 0
                || false);
    }
    handleCheckBoxSelection = (event) => {
        const selectedRowsList = [];
        let selectedAction;
        let selectedTarget; // CEAS-80187
        if (event.target.classList.contains('rowCheckBox')) {
            selectedTarget = 'rowCheckBox'; // CEAS-80187
            const intIndex = event.target.closest('tr').getAttribute('data-key');
            if (event.target.checked) {
                selectedAction = 'ADD';
                this.lstFilteredData.forEach(el => {
                    if (el.get('id').toString() === intIndex.toString()) {
                        el.set('boolRowChecked', true);
                        selectedRowsList.push(el.get("rowData"));
                        this.lstSelectedRowId.push(el.get('id').toString());
                    } else {
                        //do nothing
                    }
                })
                this.rowSelectCount++;
                // CEAS-80187
                if(this.lstFilteredData.length == this.rowSelectCount){
                    this.template.querySelector('.selectAllCheckBox').checked = true;
                }

            } else if (!event.target.checked) {
                selectedAction = 'REMOVE';
                this.lstFilteredData.forEach(el => {
                    if (el.get('id').toString() === intIndex.toString()) {
                        el.set('boolRowChecked', false);
                        selectedRowsList.push(el.get("rowData"));
                        this.lstSelectedRowId = this.lstSelectedRowId.filter(elem => elem.toString() !== el.get('id').toString());
                    } else {
                        //do nothing
                    }
                })
                this.rowSelectCount--;
                if(this.template.querySelector('.selectAllCheckBox')) {
                    this.template.querySelector('.selectAllCheckBox').checked = false;
                }
                
            } else {
                //do nothing
            }
        } else if (event.target.classList.contains('selectAllCheckBox')) {
            const checkedValue = event.target.checked;
            selectedTarget = 'selectAllCheckBox'; // CEAS-80187
            if (checkedValue) {
                selectedAction = 'ADD';
                this.lstFilteredData.forEach(el => {
                    el.set('boolRowChecked', true);
                    selectedRowsList.push(el.get("rowData"));
                    if (!this.lstSelectedRowId.includes(el.get('id').toString())) {
                        this.lstSelectedRowId.push(el.get('id').toString());
                    }
                });
                this.rowSelectCount = this.lstFilteredData.length;
            } else {
                selectedAction = 'REMOVE';
                this.lstFilteredData.forEach(el => {
                    el.set('boolRowChecked', false);
                    selectedRowsList.push(el.get("rowData"));
                })
                this.lstSelectedRowId = [];
                this.rowSelectCount = 0;
            }
        } else {
            //do nothing
        }
        //Header Btn
        this.checkDisableHeaderCustomButtonCondition();
        const sliceStart = (this.intActivePage - 1) * this.pageSize;
        this.numOfRecords = this.lstFilteredData.length;
        this.renderingTableData = this.convertRenderingData(this.lstFilteredData.slice(sliceStart, sliceStart + this.pageSize));
        if (selectedRowsList.length > 0) {
            const objParams = {
                rowInfo: selectedRowsList,
                action: selectedAction,
                target: selectedTarget  // CEAS-80187
            }
            BaseLWC.fireNativeCustomEvent("selectrowaction", objParams, this);

            const selectrowactionEvent = new CustomEvent("selectrowactionforaura", {
                detail: objParams
            });
            this.dispatchEvent(selectrowactionEvent);
        }
    }
    @api
    refreshData(param) {
        if (param.source === 'maintainAssignedAdocate' && param.action === 'UPDATE') {
            this.performDataRefreshUpdate(param.newData);
        } else if (param.source === 'maintainAssignedAdocate' && param.action === 'DELETE') {
            this.performDataRefreshDelete(param.newData);
        } else {
            //do nothing
        }
    }
    performDataRefreshUpdate(latestDataMap) {
        this.renderingTableData.forEach(el => {
            if (latestDataMap.has(el.list[6].value)) {
                el.list = latestDataMap.get(el.list[6].value);
                el.strList = JSON.stringify(latestDataMap.get(el.list[6].value));
            } else {
                //do nothing
            }
        })
        this.lstFilteredData.forEach(el => {
            if (latestDataMap.has(el.get('rowData')[6].value)) {
                el.set('rowData', latestDataMap.get(el.get('rowData')[6].value));
            } else {
                //do nothing
            }
        })
        this.sortedData.forEach(elem => {
            if (latestDataMap.has(elem.get('rowData')[6].value)) {
                elem.set('rowData', latestDataMap.get(elem.get('rowData')[6].value));
            } else {
                //do nothing
            }
        })
    }
    performDataRefreshDelete(latestDataMap) {
        for (let i = this.renderingTableData.length - 1; i >= 0; --i) {
            if (latestDataMap.has(this.renderingTableData[i].list[6].value)) {
                this.renderingTableData.splice(i, 1);
            } else {
                //do nothing
            }
        }
        for (let i = this.lstFilteredData.length - 1; i >= 0; --i) {
            if (latestDataMap.has(this.lstFilteredData[i].get('rowData')[6].value)) {
                this.lstFilteredData.splice(i, 1);
            } else {
                //do nothing
            }
        }
        for (let i = this.sortedData.length - 1; i >= 0; --i) {
            if (latestDataMap.has(this.sortedData[i].get('rowData')[6].value)) {
                this.sortedData.splice(i, 1);
            }
        }
        this.numOfRecords = this.lstFilteredData.length;
        this.boolShowNoMatchFound = this.numOfRecords === 0;
    }
    loadData() {
        if (this.template.querySelector('.selectAllCheckBox')) {
            this.template.querySelector('.selectAllCheckBox').checked = false;
        }
        this.boolSecondaryTable = this.tableSettings.boolSecondaryTable || false;
        this.columns = this.tableSettings.columnsData;
        //Page Lenth Menu
        this.boolPaginationwithSize = this.tableSettings.boolPaginationwithSize;
                this.boolShowSearch = true;
        if (this.tableSettings.boolShowSearch !== undefined && this.tableSettings.boolShowSearch !== null) {
            this.boolShowSearch = this.tableSettings.boolShowSearch;
        } else {
            //do nothing
        }
        this.boolShowIcon = this.tableSettings.boolShowIcon || false;
        this.boolHeaderNoCapital = this.tableSettings.boolHeaderNoCapital || false;
        if (this.tableSettings.iconNameToShow) {
            this.iconNameToShow = this.tableSettings.iconNameToShow;
        }

        if (this.tableSettings.boolHasSearchandFilterCustomMargins &&
            BaseLWC.isNotUndefinedOrNull(this.tableSettings.objSearchandFilterCustomMargins)) {
            this.searchMarginParams = "";
            if (BaseLWC.isNotUndefinedOrNull(this.tableSettings.objSearchandFilterCustomMargins.left)) {
                this.searchMarginParams += "margin-left:" + this.tableSettings.objSearchandFilterCustomMargins.left + ";";
            }
            if (BaseLWC.isNotUndefinedOrNull(this.tableSettings.objSearchandFilterCustomMargins.top)) {
                this.searchMarginParams += "margin-top:" + this.tableSettings.objSearchandFilterCustomMargins.top + ";";
            }
            if (BaseLWC.isNotUndefinedOrNull(this.tableSettings.objSearchandFilterCustomMargins.right)) {
                this.searchMarginParams += "margin-right:" + this.tableSettings.objSearchandFilterCustomMargins.right + ";";
            }
            if (BaseLWC.isNotUndefinedOrNull(this.tableSettings.objSearchandFilterCustomMargins.bottom)) {
                this.searchMarginParams += "margin-bottom:" + this.tableSettings.objSearchandFilterCustomMargins.bottom + ";";
            }
        }

        this.nestedColSpan = this.columns.length + 1;
        this.strNoMatchColspan = this.columns.length;
        if (this.boolSecondaryTable) {
            this.strNoMatchColspan = this.nestedColSpan;
        } else {
            //do nothing
        }
        this.boolShowFilter = this.tableSettings.boolShowFilter || false;
        this.boolShowHeader = this.tableSettings.boolShowHeader || false;
        this.searchPlaceholder = this.tableSettings.searchPlaceholder;
        this.boolShowSearchLabel = this.tableSettings.boolShowSearchLabel || false;
        this.showRecordCount = this.tableSettings.boolShowRecordCount || false;
        this.boolShowExport = this.tableSettings.boolShowExport || false;
        this.filterdata = this.tableSettings.filterData;
        this.strExportFileName = this.tableSettings.strExportFileName;
        if (!this.boolShowFilter) {
            this.filterdata = [];
        } else {
            //do nothing
        }

        this.filterdata.forEach(el => {
            const obj = { type: el.strType, intCol: el.intCol };
            this.mapFilterConfig.set(el.strFilterName, obj);
        });
        //Check for default Filter
        if (this.tableSettings.lstDefaultFilter && this.tableSettings.lstDefaultFilter.length) {
            this.tableSettings.lstDefaultFilter.forEach(el => {
                if (el.strFilterName && this.mapFilterConfig.get(el.strFilterName)) {
                    const obj = { ...this.mapFilterConfig.get(el.strFilterName) };
                    obj.defaultValues = el.lstValues
                    this.mapFilterConfig.set(el.strFilterName, obj);
                }
            })
        }
        this.boolShowCheckbox = this.tableSettings.boolShowCheckbox || false;
        //CEAS-77005 Adding condition as to remove check box from the header
        if (this.tableSettings.boolShowCheckbox) {
            this.boolCheckboxHeader = true;
            if(this.tableSettings.boolHideHeaderCheckbox) {
                this.boolCheckboxHeader = false;
            }
        } else {
            this.boolCheckboxHeader = false;
        }
        this.boolShowCustomButtonColumn = BaseLWC.isNotUndefinedOrNull(this.tableSettings.showTableCustomButtonsSetting) &&
            (this.tableSettings.showTableCustomButtonsSetting.boolShowHeaderCustomButton
                || this.tableSettings.showTableCustomButtonsSetting.boolShowRowCustomButton
                || false);
        //Header btn
        this.boolShowHeaderCustomButton = BaseLWC.isNotUndefinedOrNull(this.tableSettings.showTableCustomButtonsSetting) &&
            (this.tableSettings.showTableCustomButtonsSetting.boolShowHeaderCustomButton
                || false);
        //Header btn
        this.checkDisableHeaderCustomButtonCondition();
        //Setting Page Menu
        this.pageSizeOptions = this.tableSettings.pageMenu;

        this.pageSize = this.tableSettings.pageSize;
        this.restrictedpageSize = this.tableSettings.restrictedPageSize;
        this.columnsortedTableData = this.sortTableDataColWise();
        let initialSortIndex = null;
        if (this.columns.findIndex(el => Object.keys(el).includes('boolInitSort')) > -1) {
            initialSortIndex = this.columns.findIndex(el => Object.keys(el).includes('boolInitSort'));
        } else {
            //do nothing
        }
        if (initialSortIndex !== null) {
            const boolInitialSortDirectionAsc = (this.columns[initialSortIndex].boolAsc) || false;
            this.sortedData = this.sortTable(this.columnsortedTableData, initialSortIndex, boolInitialSortDirectionAsc);
        } else {
            this.sortedData = this.columnsortedTableData;
        }

        this.lstFilteredData = this.deepCloneMap(this.sortedData);
        if (this.restrictedpageSize) {

            this.enableViewMore = true;
            this.showPagination = false;
            //CEAS-65290
            if (BaseLWC.isNotUndefinedOrNull(this.lstFilteredData)) {
                this.enableViewMore = (this.lstFilteredData.length > this.restrictedpageSize);
                this.renderingTableData = this.convertRenderingData(this.lstFilteredData.slice(0, 0 + this.restrictedpageSize));
            }
        } else {
            //CEAS-65290
            if (BaseLWC.isNotUndefinedOrNull(this.lstFilteredData)) {
                this.renderingTableData = this.convertRenderingData(this.lstFilteredData.slice(0, 0 + this.pageSize));

                if (this.lstFilteredData.length > this.pageSize) {
                    this.showPagination = true;
                    const totalpagesize = Math.ceil(this.lstFilteredData.length / this.pageSize);
                    this.pages = [...this.getPages(totalpagesize)];
                } else {
                    //do nothing
                }
            }
        }
    }
    handlePageSizeChange(event) {
        const selectedPageOption = event.target.value;
        this.pageSize = Number(selectedPageOption);
        this.renderingTableData = this.convertRenderingData(this.lstFilteredData.slice(0, 0 + this.pageSize));
        if (this.lstFilteredData.length > this.pageSize) {
            this.showPagination = true;
            const totalpagesize = Math.ceil(this.lstFilteredData.length / this.pageSize);
            this.pages = [...this.getPages(totalpagesize)];
        } else {
            //do nothing
            this.showPagination = false;
        }
    }


    sortTableDataColWise = () => {

        const clonedData = JSON.parse(JSON.stringify(this.tableInitData));
        this.records = clonedData;
        this.numOfRecords = clonedData.length;
        const clonedColumns = JSON.parse(JSON.stringify(this.columns));
        const picklistCols = [];
        const picklistFields = [];
        this.filterdata.forEach(el => {
            if (el.strType === 'picklist') {
                picklistCols.push(Number(el.intCol) - 1);
                picklistFields.push(el.strFilterName);
            }
        })
        let mapSortedData = [];
        const mapPicklist = new Map();
        if (this.numOfRecords > 0) {
            mapSortedData = clonedData.map((row, index) => {
                const rowData = [];
                for (let i = 0; i < clonedColumns.length; i++) {
                    const objTd = {};
                    objTd['key'] = clonedColumns[i].fieldName;
                    if (clonedColumns[i].type === "date") {
                        const rowFieldData = row[clonedColumns[i].fieldName];
                        if (rowFieldData) {
                            if (typeof rowFieldData === 'string') {
                                if (rowFieldData.includes('/') || new Date(rowFieldData).toString() === 'Invalid Date') {
                                    objTd['value'] = rowFieldData;
                                } else {
                                    objTd['value'] = BaseLWC.dateFormatterHelper(rowFieldData);
                                }
                            } else if (typeof rowFieldData === 'object') {
                                if (rowFieldData.value) {
                                    objTd['value'] = BaseLWC.dtDateTimeISOtoLocal(rowFieldData.value);
                                }
                            } else {
                                objTd['value'] = BaseLWC.dtDateTimeISOtoLocal(rowFieldData);
                            }
                        } else {
                            objTd['value'] = rowFieldData;
                        }
                    } else {
                        objTd['value'] = '';
                        /* CEAS-66674  -  Adding tooltip JS code*/
                        if (row[clonedColumns[i].fieldName] && clonedColumns[i].boolIsTooltip) {
                            if (typeof row[clonedColumns[i].fieldName].value === 'string') {
                                objTd['value'] = row[clonedColumns[i].fieldName].value
                            } else if (row[clonedColumns[i].fieldName].strCellValue) {
                                objTd['value'] = row[clonedColumns[i].fieldName].strCellValue
                            } else {
                                objTd['value'] = ''
                            }

                        } else if (row[clonedColumns[i].fieldName]) {
                            objTd['value'] = row[clonedColumns[i].fieldName];
                        } else {
                            objTd['value'] = '';
                        }
                        /* CEAS-66674  -  End of Adding tooltip JS code*/

                    }
                    objTd['boolWrapper'] = false;
                    if (row[clonedColumns[i].fieldName] && row[clonedColumns[i].fieldName].wrapper) {
                        objTd['boolWrapper'] = true;
                        // CEAS-80660 Added if condition to avoide true label with icon
                        if(row[clonedColumns[i].fieldName].value != undefined && row[clonedColumns[i].fieldName].value != null && row[clonedColumns[i].fieldName].value != ''){
                            objTd['wrapperHtml'] = row[clonedColumns[i].fieldName].wrapper;
                        }
                    } else {
                        //do nothing
                    }
                    objTd['boolActionBtn'] = false;
                    if (clonedColumns[i].fieldName === 'actionBtn') {
                        objTd['boolActionBtn'] = true;
                        this.tableContainerClass = "slds-box slds-theme_default table-container table-extraPadding";
                        objTd['btnSize'] = "medium";
                        if (BaseLWC.isNotUndefinedOrNull(clonedColumns[i].btnSize)) {
                            objTd['btnSize'] = clonedColumns[i].btnSize;
                        }
                    }
                    if (clonedColumns[i].fieldName === 'customBtn') {
                        objTd['boolShowRowCustomButton'] = true;
                        if (BaseLWC.isNotUndefinedOrNull(row[clonedColumns[i].fieldName].strRowCustomButtonLabel)) {
                            objTd["strRowCustomButtonLabel"] = row[clonedColumns[i].fieldName].strRowCustomButtonLabel;
                        } else {
                            objTd["strRowCustomButtonLabel"] = "";
                        }
                        if (BaseLWC.isNotUndefinedOrNull(row[clonedColumns[i].fieldName].strButtonVariant)) {
                            objTd["strBtnClass"] = "slds-m-left_x-small slds-button slds-button_" + row[clonedColumns[i].fieldName].strButtonVariant;
                        } else {
                            objTd["strBtnClass"] = "slds-m-left_x-small slds-button slds-button_neutral";
                        }
                        if (row[clonedColumns[i].fieldName].boolIsTooltip) {
                            objTd["boolIsTooltip"] = true;
                            objTd["boolIsInfoIconTooltip"] = false;
                            objTd["boolWrapper"] = false;
                            if (BaseLWC.isNotUndefinedOrNull(row[clonedColumns[i].fieldName].strTextTooltipContent)) {
                                objTd['strTextTooltipContent'] = row[clonedColumns[i].fieldName].strTextTooltipContent;
                            } else {
                                objTd['strTextTooltipContent'] = '';
                            }
                        } else {
                            objTd["boolIsTooltip"] = false;
                        }
                        if (row[clonedColumns[i].fieldName].boolIsBtnDisabled) {
                            objTd["strBtnClass"] += " btn-disabled";
                            objTd["boolIsBtnDisabled"] = true;
                        } else {
                            //do nothing
                        }
                    } else {
                        objTd['boolHidden'] = clonedColumns[i].boolHidden || false;
                        /* CEAS-66674  -  Adding tooltip JS code*/
                        objTd['boolIsTooltip'] = clonedColumns[i].boolIsTooltip || false;
                        objTd['boolIsInfoIconTooltip'] = clonedColumns[i].boolIsInfoIconTooltip || false;
                        if (objTd['boolIsTooltip']) {
                            objTd['strTextTooltipContent'] = row[clonedColumns[i].fieldName].strTextTooltipContent || '';
                            objTd['strTooltipNubbinAlignment'] = row[clonedColumns[i].fieldName].strTooltipNubbinAlignment || 'right';
                        }
                        /* CEAS-66674  - End of Adding tooltip JS code*/
                    }

                    //Set picklist Options
                    if (picklistCols.includes(i)) {
                        const ix = picklistCols.indexOf(i);
                        if (mapPicklist.get(picklistFields[ix])) {
                            const lst = mapPicklist.get(picklistFields[ix]);
                            if (!lst.includes(row[clonedColumns[i].fieldName])) {
                                lst.push(row[clonedColumns[i].fieldName]);
                                mapPicklist.set(picklistFields[ix], lst);
                            } else {
                                //do nothing
                            }
                        } else {
                            mapPicklist.set(picklistFields[ix], [row[clonedColumns[i].fieldName]]);
                        }

                    } else {
                        //do nothing
                    }
                    rowData.push(objTd);
                }

                const rowMap = new Map();
                rowMap.set('id', index);
                rowMap.set('rowData', rowData);
                rowMap.set('boolSecTable', row.boolSecTable || false);
                rowMap.set('boolRowChecked', row.boolRowChecked || false);
                //Added for rendering a nested table
                rowMap.set('boolNestedTable', row.boolNestedTable || false);
                //Added for disabling check box
                rowMap.set('boolCheckBoxDisable', row.boolCheckBoxDisable || false);
                if (row.boolSecTable) {
                    rowMap.set('strSecTable', row.strSecTable);
                    if (row.objSecTableStatus) {
                        rowMap.set('objSecTableStatus', row.objSecTableStatus);
                    } else {
                        //do nothing
                    }
                } else if (row.boolNestedTable) {
                    //Setting Nested table settings and data
                    rowMap.set('objSecondaryTableSetting', row.objSecondaryTableSetting);
                    rowMap.set('objSecondaryTableData', row.objSecondaryTableData);
                    if (row.objSecTableStatus) {
                        rowMap.set('objSecTableStatus', row.objSecTableStatus);
                    }
                } else {
                    //do nothing
                }
                return rowMap;
            });
            //Sort for Picklist
            //Map for picklist component
            for (const [key, value] of mapPicklist) {
                const lst = [];
                value.forEach(el => {
                    if (typeof el === 'string' && el.trim() !== '') {
                        lst.push({ key: el, value: el, selected: false })
                    }
                });
                this.mapPicklistColumnUniqueData.set(key, lst);
            }
            return mapSortedData;
        }
    }

    getPages = (totalPageSize) => {
        const lstPages = Array.from({ length: totalPageSize + 1 }, (v, i) => i).map(el => {
            const obj = {};
            obj.pagenum = el;
            obj.boolPageActive = (el === this.intActivePage);
            //CEAS-64928, CEAS-65583
            obj.boolPreviousActive = (parseInt(el, 10) === (parseInt(this.intActivePage, 10) - 1));
            obj.boolshowpreviousellipsis = this.intActivePage !== 1 && (parseInt(this.intActivePage, 10) - (parseInt(el, 10)) === 2) && (parseInt(el, 10) > 1);
            obj.boolshownextellipsis = this.intActivePage !== this.pages.length && ((parseInt(this.pages.length, 10) - parseInt(this.intActivePage, 10)) >= 3) && ((parseInt(this.pages.length, 10) - 2) === parseInt(el, 10));
            return obj;
        });
        lstPages.shift();
        return lstPages;
    }
    convertRenderingData = (lstObj) => {
        const lstObjNew = lstObj.map(el => {
            let strSecTable = '';
            let strExpandedClass = 'innerTable collapsed';
            let boolDisabled = false;
            let boolHidden = false;

            //Nest Table variable
            let boolNestedTable = false;
            let boolNestedSpinner = false;
            let objSecondaryTableSetting = {};
            let objSecondaryTableData = {};
            if (el.get('boolSecTable')) {
                strSecTable = el.get('strSecTable');
            } else {
                //do nothing
            }
            let rowData = el.get('rowData');
            let isIconDisabled = false;
            if(rowData && this.boolShowIcon) {
                rowData.forEach(objData => {
                    if(objData.key === 'isIconDisabled') {
                        if(objData.value) {
                            isIconDisabled = true;
                        }
                    }
                });
            }
            if (el.get('objSecTableStatus')) {
                if (el.get('objSecTableStatus').boolDisabled) {
                    boolDisabled = true;
                } else {
                    //do nothing
                }
                if (el.get('objSecTableStatus').boolExpanded) {
                    strExpandedClass = 'innerTable expanded';
                } else {
                    //do nothing
                }
                if (el.get('objSecTableStatus').boolHidden) {
                    boolHidden = true;
                } else {
                    //do nothing
                }
            } else {
                //do nothing
            }

            //wire--- adding attributes for nested tableobjItr.set('boolNestedSpinner',false);
            if (el.get('boolNestedTable')) {
                boolNestedTable = true;
                if (el.get('boolNestedSpinner') === true) {
                    boolNestedSpinner = true;
                } else {
                    boolNestedSpinner = false;
                }
            } else {
                //do nothing
            }
            if (el.get('objSecondaryTableSetting') !== undefined && el.get('objSecondaryTableSetting') !== null) {
                objSecondaryTableSetting = el.get('objSecondaryTableSetting');
            } else {
                //do nothing
            }
            if (el.get('objSecondaryTableData') !== undefined && el.get('objSecondaryTableData') !== null) {
                objSecondaryTableData = el.get('objSecondaryTableData');
            } else {
                //do nothing
            }
            //ceas-52825
            return {
                list: el.get('rowData'),
                strList: JSON.stringify(el.get('rowData')),
                other: {
                    id: el.get('id'),
                    boolSecTable: el.get('boolSecTable'),
                    strSecTable: strSecTable,
                    expanded: strExpandedClass,
                    boolDisabled: boolDisabled,
                    boolHidden: boolHidden,
                    boolNestedSpinner: boolNestedSpinner,
                    boolNestedTable: boolNestedTable,
                    objSecondaryTableSetting: objSecondaryTableSetting,
                    objSecondaryTableData: objSecondaryTableData,
                    boolShowCheckbox: this.boolShowCheckbox,
                    boolShowRowCustomButton: BaseLWC.isNotUndefinedOrNull(this.tableSettings.showTableCustomButtonsSetting) &&
                        (this.tableSettings.showTableCustomButtonsSetting.boolShowRowCustomButton || false),
                    boolChecked: el.get('boolRowChecked'),
                    nestedId: `nestedRow_${el.get('id')}`,
                    boolCheckBoxVal: el.get('boolCheckBoxVal'),
                    boolCheckBoxDisable: el.get('boolCheckBoxDisable'),
                    isIconDisabled: isIconDisabled

                }

            }
        });

        this.boolShowNoMatchFound = (!lstObjNew.length);
        return lstObjNew;
    }
    handleShowNested(ev) {
        const isDisabled = ev.currentTarget.getAttribute('data-disabled');

        if (isDisabled === 'true') {
            return;
        } else {
            //do nothing
        }
        let boolExpanded;
        if (ev.currentTarget.classList.contains('expanded')) {
            boolExpanded = false;
            ev.currentTarget.closest('tr').nextElementSibling.setAttribute('data-expanded', 'innerTable collapsed');
            ev.currentTarget.closest('tr').nextElementSibling.classList.remove('expanded');
        } else {
            boolExpanded = true;
            ev.currentTarget.closest('tr').nextElementSibling.setAttribute('data-expanded', 'innerTable expanded');
            ev.currentTarget.closest('tr').nextElementSibling.classList.add('expanded');
        }
        ev.currentTarget.classList.toggle('expanded');
        try {
            const isRowNested = ev.currentTarget.closest('tr').classList.contains('nestedTable');
            let renderedRowData;
            if (isRowNested) {
                renderedRowData = ev.currentTarget.closest('tr').previousElementSibling.getAttribute('data-rowdata');
            } else {
                renderedRowData = ev.currentTarget.closest('tr').getAttribute('data-rowdata');
            }

            const objParams = {
                renderedRowData: renderedRowData,
                activeColumnName: null,
                activeColFieldName: null,
                activeColumnData: null,
                isRowNested: true,
                isExpanded: boolExpanded
                    };
            this.boolDataChange = true;
            BaseLWC.fireNativeCustomEvent('rowaction', objParams, this);
        } catch (error) {
            //Do Nothing
        }
    }

    @api
    refreshNestedTableData() {
        this.boolDataChange = false;
    }

    sortTable = (lstData, intCol, boolAsc) => {
        const cloneData = this.deepCloneMap(lstData);
        if (BaseLWC.isNotUndefinedOrNull(cloneData)) {
            if (this.columns[intCol].type === "date") {
                cloneData.sort((a, b) => {
                    const rowA = a.get('rowData');
                    const rowB = b.get('rowData');
                    let da = new Date(rowA[intCol].value);
                    let db = new Date(rowB[intCol].value);
                    if (rowA[intCol].boolWrapper) {
                        if (rowA[intCol].value.value) {
                            da = new Date(rowA[intCol].value.value)
                        }
                    } else {
                        //do nothing
                    }
                    if (rowB[intCol].boolWrapper) {
                        if (rowB[intCol].value.value) {
                            db = new Date(rowB[intCol].value.value)
                        }

                    } else {
                        //do nothing
                    }
                    if (!boolAsc) {
                        if (da > db) {
                            return -1
                        }
                        return 1;
                    } else {
                        //do nothing
                    }

                    if (db > da) {
                        return -1;
                    }
                    return 1;
                });
            } else {
                cloneData.sort((a, b) => {
                    const rowA = a.get('rowData');
                    const rowB = b.get('rowData');
                    let fa = rowA[intCol].value,
                        fb = rowB[intCol].value;
                    if (rowA[intCol].boolWrapper && typeof rowA[intCol].value !== 'string') {
                        fa = rowA[intCol].value.value;
                    } else {
                        //do nothing
                    }
                    if (rowB[intCol].boolWrapper && typeof rowA[intCol].value !== 'string') {
                        fb = rowB[intCol].value.value;
                    } else {
                        //do nothing
                    }

                    if (!isNaN(fa) && !isNaN(fb)) {
                        if (!boolAsc) {
                            return (Number(fb) - Number(fa));
                        } else {
                            //do nothing
                        }
                        return (Number(fa) - Number(fb));
                    }
                    if (BaseLWC.isNotUndefinedOrNull(fa) && BaseLWC.isNotUndefinedOrNull(fb)) {
                        if (typeof (fa) === 'string') {
                            fa = fa.toLowerCase();
                        } else {
                            //do nothing
                        }
                        if (typeof (fb) === 'string') {
                            fb = fb.toLowerCase();
                        } else {
                            //do nothing
                        }
                    }

                    if (fa < fb) {
                        if (boolAsc) {
                            return -1;
                        } else {
                            //do nothing
                        }
                        return 1;
                    }
                    if (fa > fb) {
                        if (boolAsc) {
                            return 1;
                        }
                        return -1;
                    }
                    return 0;
                });
            }
            return cloneData;
        }
    }

    searchTable = () => {
        const clonedData = this.deepCloneMap(this.sortedData);
        if (!(this.lstSelectedRowId && clonedData)) {
            return
        }
        for (let increment = 0; increment < this.lstSelectedRowId.length; increment++) {
            clonedData.forEach(el => {
                if (el.get("id").toString() === this.lstSelectedRowId[increment]) {
                    el.set("boolRowChecked", true);
                }
            });
        }
        let filteredData;
        if (this.searchMatrix[0] === '' && !this.searchMatrix[1].length) {
            filteredData = clonedData;
        } else {
            filteredData = clonedData.filter((row) => {
                const rowData = row.get('rowData');
                let boolFound = false;
                const lstTd = rowData.map((a) => {
                    if (a.boolWrapper && a.value.value) {
                        return a.value.value;
                    } else {
                        //do nothing
                    }
                    return a.value;
                });
                if (this.searchMatrix[0] !== '') {
                    for (let i = 0; i < lstTd.length; i++) {
                        if (typeof lstTd[i] === 'string' && lstTd[i].toLowerCase().includes(this.searchMatrix[0].toLowerCase())) {
                            boolFound = true;
                            break;
                        } else {
                            //do nothing
                        }
                    }
                } else {
                    boolFound = true;
                }

                const lstFound = [];
                this.searchMatrix[1].forEach(el => {
                    if (el.searchTerm.split('|').length >= 1) {
                        let lst = el.searchTerm.split('|');
                        if (lst.length === 2) {
                            if ((new Date(lst[0]).toString() !== "Invalid Date" && new Date(lst[1]).toString() !== "Invalid Date")) {
                                //get All in between dates
                                const arr = [], dt = new Date(lst[0]);
                                try{
                                    while (dt <= new Date(lst[1])) {
                                        arr.push(BaseLWC.dateFormatterHelper(dt.toLocaleDateString()));
                                        dt.setDate(dt.getDate() + 1)
                                    }
                                } catch (_e){

                                }
                                
                                lst = [...arr];
                            } else if ((new Date(lst[0]).toString() !== "Invalid Date" || new Date(lst[1]).toString() !== "Invalid Date")) {
                                return;
                            } else {
                                //Do Nothing
                            }
                        } else {
                            //do nothing
                        }
                        for (let int = 0; int < lst.length; int++) {
                            if (typeof lstTd[el.colIndx] === 'string' && typeof lst[int] === 'string' && lstTd[el.colIndx].toLowerCase().includes(lst[int].toLowerCase())) {
                                lstFound.push(true);
                                break;
                            }
                        }
                    } else {
                        if (typeof lstTd[el.colIndx] === 'string' && typeof el.searchTerm === 'string' && lstTd[el.colIndx].toLowerCase().includes(el.searchTerm.toLowerCase())) {
                            lstFound.push(true);
                        } else {
                            //do nothing
                        }
                    }

                });
                if (this.searchMatrix[1].length) {
                    return boolFound && (lstFound.length === this.searchMatrix[1].length)
                } else {
                    //do nothing
                }
                return boolFound;
            });
        }


        this.lstFilteredData = filteredData;
        this.numOfRecords = filteredData.length;
        this.renderingTableData = this.convertRenderingData(filteredData.slice(0, 0 + this.pageSize));
        const isViewMore = this.enableViewMore && !this.template.querySelector('.viewMore').classList.contains('slds-hide');

        if (isViewMore) {
            this.showPagination = false;
            this.renderingTableData = this.convertRenderingData(filteredData.slice(0, 0 + this.restrictedpageSize));
            if (filteredData.length <= this.restrictedpageSize && this.enableViewMore) {
                this.template.querySelector('.viewMore').classList.add('disabled-link');
            } else {
                this.template.querySelector('.viewMore').classList.remove('disabled-link');
            }
        } else {
            this.showPagination = false;
            if (filteredData.length > this.pageSize) {
                const totalpagesize = Math.ceil(filteredData.length / this.pageSize);
                this.pages = [...this.getPages(totalpagesize)];
            } else {
                this.pages = [...this.getPages(1)];
            }
            if (this.pages.length > 1) {
                this.showPagination = true;
            }
            if (this.enableViewMore) {
                if (filteredData.length <= this.restrictedpageSize) {
                    this.template.querySelector('.viewLess').classList.add('disabled-link');
                } else {
                    this.template.querySelector('.viewLess').classList.remove('disabled-link');
                }
            } else {
                //do nothing
            }

        }
    }

    async connectedCallback() {
        this.boolShowNoRecordsFoundLV = this.boolShowNoRecordsFound || false;
        this.boolEmptyTable = this.boolShowNoRecordsFound || this.boolShowApiError || !(Array.isArray(this.tableInitData) && this.tableInitData.length);
        this.intConnectedCount += 1;
        this.loadData();
        if (!(this.renderingTableData && this.renderingTableData.length)) {
            this.enableViewMore = false;
        }

        setTimeout(function () {
            if (this.intConnectedCount === 1) {
                this.updateDefaultFilters();
            }
        }.bind(this), 2000);
    }

    renderedCallback() {
        //Add custom margins
        if (this.template.querySelector('.search-filter-subctr')) {
            this.template.querySelector('.search-filter-subctr').setAttribute('style', this.searchMarginParams);
        } else {
            //Do nothing
        }
        this.boolEmptyTable = this.boolShowNoRecordsFound || this.boolShowApiError || !(Array.isArray(this.tableInitData) && this.tableInitData.length);
        this.manageTableComponentHeight();
    }

    handleViewMoreLess(ev) {
        ev.target.classList.toggle('slds-hide');
        const sliceStart = (this.intActivePage - 1) * this.pageSize;
        if (ev.target.classList.contains('viewMore')) {
            ev.target.nextElementSibling.classList.remove('slds-hide');
            this.renderingTableData = this.convertRenderingData(this.lstFilteredData.slice(sliceStart, sliceStart + this.pageSize));
            if (this.lstFilteredData.length > this.pageSize) {
                this.showPagination = true;
                const totalpagesize = Math.ceil(this.lstFilteredData.length / this.pageSize);
                this.pages = [...this.getPages(totalpagesize)];
            } else {
                //do nothing
            }
        } else {
            this.showPagination = false;
            ev.target.previousElementSibling.classList.remove('slds-hide');
            this.renderingTableData = this.convertRenderingData(this.lstFilteredData.slice(sliceStart, sliceStart + this.restrictedpageSize));
        }
    }

    handleSort(ev) {
        const boolPaginationData = JSON.parse(JSON.stringify(this.tableSettings)).boolPagination;
        this.lstFilteredData = this.deepCloneMap(this.sortedData);
        const objTarget = ev.currentTarget;
        let intCol = [...objTarget.parentElement.children].indexOf(objTarget);
        if (this.boolSecondaryTable || this.boolShowCheckbox) {
            intCol = intCol - 1;
        } else {
            //do nothing
        }

        let isAsc = objTarget.querySelector(".upArrow").getAttribute('data-isascending');
        //Make the boolean opposite of previous self to activate click
        if (isAsc === '' || isAsc === 'true') {
            isAsc = 'false';
        } else {
            isAsc = 'true';
        }

        //Remove Search
        this.searchMatrix = ['', []];
        if(this.template.querySelector('.search')){
            this.template.querySelector('.search').value = '';
        }

        this.lstTableFilterData = [];
        if (this.template.querySelector('.filter-container')) {
            this.template.querySelector('.filter-container').classList.add('slds-hide');
        } else {
            //do nothing
        }

        [...objTarget.parentElement.querySelectorAll('.sortIcon')].forEach((el) => {
            el.setAttribute('data-isascending', '');
        });
        if (isAsc === "false") {
            objTarget.querySelector(".downArrow").setAttribute('data-isascending', 'false');
            objTarget.querySelector(".upArrow").setAttribute('data-isascending', 'false');
            this.sortedData = this.sortTable(this.columnsortedTableData, intCol, false);
        } else {
            objTarget.querySelector(".downArrow").setAttribute('data-isascending', 'true');
            objTarget.querySelector(".upArrow").setAttribute('data-isascending', 'true');
            this.sortedData = this.sortTable(this.columnsortedTableData, intCol, true);
        }
        if (this.enableViewMore) {
            const isViewMore = !this.template.querySelector('.viewMore').classList.contains('slds-hide');
            this.intActivePage = 1;
            const sliceStart = (this.intActivePage - 1) * this.pageSize;
            if (isViewMore) {
                this.showPagination = false;
                this.renderingTableData = this.convertRenderingData(this.sortedData.slice(sliceStart, sliceStart + this.restrictedpageSize));
            } else {
                if (boolPaginationData || this.tableSettings.pageSize) {

                    this.showPagination = false;
                    this.renderingTableData = this.convertRenderingData(this.sortedData.slice(sliceStart, sliceStart + this.pageSize));
                    this.pages = [...this.getPages(Math.ceil(this.sortedData.length / this.pageSize))]

                    if (this.pages.length > 1) {
                        this.showPagination = true;
                    }

                } else {
                    this.renderingTableData = this.convertRenderingData(this.sortedData.slice(sliceStart, sliceStart + this.pageSize));
                }

            }

            if (this.renderingTableData.length < this.restrictedpageSize) {
                this.template.querySelector(".viewMore").classList.add("disabled-link")
                this.template.querySelector(".viewLess").classList.add("disabled-link")
            } else {
                this.template.querySelector(".viewMore").classList.remove("disabled-link")
                this.template.querySelector(".viewLess").classList.remove("disabled-link")
            }

        } else {

            if (boolPaginationData || this.tableSettings.pageSize) {
                this.intActivePage = 1;
                const sliceStart = (this.intActivePage - 1) * this.pageSize;
                this.showPagination = false;

                this.renderingTableData = this.convertRenderingData(this.sortedData.slice(sliceStart, sliceStart + this.pageSize));
                this.pages = [...this.getPages(Math.ceil(this.sortedData.length / this.pageSize))]

                if (this.pages.length > 1) {
                    this.showPagination = true;
                }
            } else {
                this.renderingTableData = this.convertRenderingData(this.sortedData);
            }


        }
        this.lstFilteredData = this.sortedData;
    }

    handlePrevNext(e) {
        const isPrev = e.target.classList.contains('prev');
        if (isPrev) {
            e.target.parentElement.querySelector('.pageNumber[data-pgn="' + (this.intActivePage - 1) + '"]').click();
        } else {
            e.target.parentElement.querySelector('.pageNumber[data-pgn="' + (this.intActivePage + 1) + '"]').click();
        }
        this.strLabelExpandCollapseRows = "Expand All Rows";
    }


    get firstEntryNumber() {
        const countRec = ((this.intActivePage - 1) * this.pageSize) + 1;
        if (countRec > this.totalEntries) {
            return this.totalEntries;
        } else {
            return countRec;
        }
    }

    get lastEntryNumber() {
        let _pagesize = this.restrictedpageSize;
        if (this.enableViewMore) {
            if (this.showPagination) {
                _pagesize = this.pageSize;
            } else {
                _pagesize = this.renderedEntries;
            }
        }
        
        let lastEntry = (this.firstEntryNumber + _pagesize - 1) > this.totalEntries ? this.totalEntries : (this.firstEntryNumber + _pagesize - 1);
        lastEntry = lastEntry < 0 ? 0 : lastEntry;
        return lastEntry;
    }

    get totalEntries() {
        if (BaseLWC.arrayIsNotEmpty(this.lstFilteredData)) {
            return this.lstFilteredData.length;
        } else {
            return 0;
        }
        
    }
    get boolExportDisable() {
            return this.totalEntries > 0 ? false :  true;

    }
    get exportButtonCss() {
        if (this.tableSettings && this.tableSettings.exportButtonCss) {
            return this.tableSettings.exportButtonCss;
        }
    }
    get exportRowData() {
        let headData = [];
        for (let key in this.columns) {
            if(this.columns[key].boolExport) {
                headData.push(this.columns[key].fieldName);
            } 
        }
        let rowData = [];
            let selectedRowsList = [];
            if(this.lstFilteredData && this.lstFilteredData.length > 0) {
                this.lstFilteredData.forEach(el => {
                    selectedRowsList.push(el.get("rowData"));
                })
                for (let outerKey in selectedRowsList) {
                    let mapOfRows = new Map();
                    for (let inner in selectedRowsList[outerKey]) {
                        if(headData.includes(selectedRowsList[outerKey][inner].key)) {
                            if(typeof selectedRowsList[outerKey][inner].value === 'object') {
                                mapOfRows.set(selectedRowsList[outerKey][inner].key , selectedRowsList[outerKey][inner].value.value);
                            } else {
                                mapOfRows.set(selectedRowsList[outerKey][inner].key , selectedRowsList[outerKey][inner].value);
                            }
                            
                        }
                    }
                    rowData.push(mapOfRows);
                }
            }
            return rowData;
    }

    get renderedEntries() {
        if (BaseLWC.arrayIsNotEmpty(this.renderingTableData)) {
            return this.renderingTableData.length;
        } else {
            return 0;
        }
        
    }

    get filterNumbers() {
        if (this.searchMatrix.length && (this.searchMatrix[0] || (this.searchMatrix[1] && this.searchMatrix[1].length))) {
            return `(filtered from ${this.sortedData.length} total entries)`;
        } else {
            return '';
        }
    }

    changePage(ev) {
        const target = ev.target;
        const prevActivePage = ev.target.parentElement.querySelector('.pageNumber.active');
        prevActivePage.classList.remove('active', 'slds-button_brand');
        prevActivePage.classList.add('slds-button_neutral');
        target.classList.remove('slds-button_neutral');
        target.classList.add('active', 'slds-button_brand');
        this.intActivePage = Number(target.textContent);
        this.boolPrevDisabled = (this.intActivePage === 1);
        this.boolNextDisabled = (this.intActivePage === this.pages.length);
        const sliceStart = (this.intActivePage - 1) * this.pageSize;
        //CEAS-64928, CEAS-65583
        const totalpagesize = Math.ceil(this.lstFilteredData.length / this.pageSize);
        this.pages = [...this.getPages(totalpagesize)];
        this.renderingTableData = this.convertRenderingData(this.lstFilteredData.slice(sliceStart, sliceStart + this.pageSize));
        this.strLabelExpandCollapseRows = "Expand All Rows";
    }
    handleSearch(ev) {
        ev.preventDefault();
        const searchVal = ev.currentTarget.value;
        this.searchMatrix[0] = searchVal;
        this.searchTable();
    }

    openFilter(ev) {
        if (!this.boolShowHeader) {
            const postionLeft = ev.currentTarget.parentElement.querySelector('input.search').offsetWidth;
            this.template.querySelector('.filter-container')
                .setAttribute('style', 'position:absolute;left:' + postionLeft + 'px;');
        } else {
            const postionLeft = ev.currentTarget.parentElement.querySelector('h1.searchHeader').offsetWidth;
            this.template.querySelector('.filter-container')
                .setAttribute('style', 'position:absolute;left:' + postionLeft + 'px;');
        }
        this.template.querySelector('.filter-container').classList.remove('slds-hide');
    }

    manageTableComponentHeight = () => {
        const objTableCmp = this.template.querySelector('.table-container')
        if (objTableCmp.scrollHeight > objTableCmp.clientHeight) {
            this.template.querySelector('.table-container').setAttribute('style', `min-height:${objTableCmp.scrollHeight + 20}px`);
        } else {
            this.template.querySelector('.table-container').removeAttribute('style');
        }
    }
    closeFilter() {
        this.template.querySelector('.filter-container').classList.add('slds-hide');
    }
    addFilterItems(ev) {
        this.createFilterRow();
        ev.currentTarget.nextElementSibling.classList.remove('disabled-link');
    }
    removeAllFilterItems(ev) {
        ev.currentTarget.classList.add('disabled-link');
        ev.currentTarget.previousElementSibling.classList.remove('disabled-link');
        this.lstTableFilterData = [];
        this.searchMatrix[1] = [];
        this.searchTable();
    }
    createFilterRow = () => {
        this.generateUpdateFilterData('ADD', false, {});
        this.template.querySelector('.add-filter').classList.add('disabled-link');
    }
    handleCloseFilterRow(ev) {
        const objTarget = ev.currentTarget;
        const intRowIndex = [...objTarget.closest('.filter-body').children].indexOf(objTarget.closest('.filter-row'));
        const colName = this.lstTableFilterData[intRowIndex].value;
        this.generateUpdateFilterData('REMOVE', false, { rowIndex: intRowIndex, value: colName });
        this.searchTable();
        if (this.lstTableFilterData.length) {
            this.template.querySelector('.remove-all-filter').classList.remove('disabled-link');
            if (this.mapFilterConfig.size!==this.lstTableFilterData.length) {
                this.template.querySelector('.add-filter').classList.remove('disabled-link');
            }
        } else {
            this.template.querySelector('.add-filter').classList.remove('disabled-link');
            this.template.querySelector('.remove-all-filter').classList.add('disabled-link');
        }
    }
    generateUpdateFilterData = (strAction, boolColumnUpdate, objUpdateData) => {

        const lstFilterNames = this.filterdata.map(el => el.strFilterName);
        const lstColumns = lstFilterNames.map(el => {
            let label = el;
            if (this.mapFilterConfig.get(el).intCol !== -1) {
                label = el.toUpperCase();
            } else {
                //do nothing
            }
            return {
                value: el,
                label: label
            };
        });
        let lstClonedTableFilterData = this.cloneObject(this.lstTableFilterData);
        if (strAction === 'UPDATE') {
            if (boolColumnUpdate) {
                //Remove column Picklist duplication
                lstClonedTableFilterData = lstClonedTableFilterData.map((el, index) => {
                    if (index === objUpdateData.rowIndex) {
                        el.value = objUpdateData.value;
                        el.fvalue.textType = this.mapFilterConfig.get(objUpdateData.value).type === 'text';
                        el.fvalue.pickListType = this.mapFilterConfig.get(objUpdateData.value).type === 'picklist';
                        el.fvalue.placeholderType = this.mapFilterConfig.get(objUpdateData.value).intCol === -1;
                        el.fvalue.dateType = this.mapFilterConfig.get(objUpdateData.value).type === 'date';
                        el.fvalue.dateRangeMFType = this.mapFilterConfig.get(objUpdateData.value).type === 'dateRangeMF';
                        el.fvalue.value = '';
                        el.fvalue.pickListOptions = [];
                        el.coloptions.forEach(elm => {
                            if (objUpdateData.value === elm.value) {
                                elm.selected = true;
                            }
                        })
                        if (this.mapFilterConfig.get(objUpdateData.value).type === 'picklist') {
                            el.fvalue.pickListOptions = this.mapPicklistColumnUniqueData.get(objUpdateData.value);
                        } else {
                            //do nothing
                        }
                    } else {
                        el.coloptions = el.coloptions.filter(elm => {
                            return !((this.mapFilterConfig.get(elm.value).intCol === -1) || (elm.value === objUpdateData.value));
                        });
                    }
                    return el;
                });

            } else {
                if (lstClonedTableFilterData[objUpdateData.rowIndex].fvalue.dateRangeMFType) {
                    if (objUpdateData.dateType && objUpdateData.dateType === 'todate') {
                        lstClonedTableFilterData[objUpdateData.rowIndex].fvalue.value =
                            lstClonedTableFilterData[objUpdateData.rowIndex].fvalue.value.split('|')[0] + '|' +
                            objUpdateData.value;
                    } else if (objUpdateData.dateType && objUpdateData.dateType === 'fromdate') {
                        lstClonedTableFilterData[objUpdateData.rowIndex].fvalue.value = objUpdateData.value + '|' +
                            lstClonedTableFilterData[objUpdateData.rowIndex].fvalue.value.split('|')[1];
                    } else {
                        //Do Nothing
                    }

                } else {
                    lstClonedTableFilterData[objUpdateData.rowIndex].fvalue.value = objUpdateData.value;
                }

                if (lstClonedTableFilterData[objUpdateData.rowIndex].fvalue.pickListType) {
                    const values = objUpdateData.value.split('|');
                    lstClonedTableFilterData[objUpdateData.rowIndex].fvalue.pickListOptions.forEach(el => {
                        el.selected = values.includes(el.value);
                    })
                } else {
                    //do nothing
                }
                if ((this.mapFilterConfig.size - lstClonedTableFilterData.length) < 2) {
                    //removed second or condition   ||this.mapFilterConfig.get(lstClonedTableFilterData[lstClonedTableFilterData.length - 1].coloptions[1].value).intCol === -1
                    const boolPreventAddLink = this.mapFilterConfig.get(lstClonedTableFilterData[lstClonedTableFilterData.length - 1].coloptions[0].value).intCol === -1;

                    if (!boolPreventAddLink && this.mapFilterConfig.size!==lstClonedTableFilterData.length) {
                        this.template.querySelector('.add-filter').classList.remove('disabled-link');
                    } else {
                        //do nothing
                    }
                } else {
                    this.template.querySelector('.add-filter').classList.remove('disabled-link');
                }
            }

        } else if (strAction === 'ADD') {
            let currentFilterNames = [];
            if (lstClonedTableFilterData.length) {
                currentFilterNames = lstClonedTableFilterData.map(el => el.value);
            } else {
                //do nothing
            }
            const pendingFilterNames = lstFilterNames.filter(el => !currentFilterNames.includes(el));
            const pendinglstColumns = lstColumns.filter((el, index) => pendingFilterNames.includes(lstFilterNames[index]));

            const objFilterRow = {};
            let pickListOptions = [];
            if (this.mapFilterConfig.get(pendingFilterNames[0]).type === 'picklist') {
                pickListOptions = this.mapPicklistColumnUniqueData.get(pendingFilterNames[0]);
            } else {
                //do nothing
            }
            objFilterRow.coloptions = pendinglstColumns;
            objFilterRow.value = pendingFilterNames[0];
            objFilterRow.fvalue = {
                textType: this.mapFilterConfig.get(pendingFilterNames[0]).type === 'text',
                pickListType: this.mapFilterConfig.get(pendingFilterNames[0]).type === 'picklist',
                placeholderType: this.mapFilterConfig.get(pendingFilterNames[0]).intCol === -1,
                dateType: this.mapFilterConfig.get(pendingFilterNames[0]).type === 'date',
                dateRangeMFType: this.mapFilterConfig.get(pendingFilterNames[0]).type === 'dateRangeMF',
                value: '',
                pickListOptions: pickListOptions

            };
            objFilterRow.id = 'filterRow_' + lstClonedTableFilterData.length;
            lstClonedTableFilterData.push(objFilterRow);

        } else {
            lstClonedTableFilterData.splice(objUpdateData.rowIndex, 1);
            lstClonedTableFilterData.forEach(el => {
                const opt = lstColumns.filter((elm) => {
                    const lstOpt = el.coloptions.map(elem => elem.value);
                    return (lstOpt.includes(elm.value)) || (elm.value === objUpdateData.value);
                });
                el.coloptions = opt;
            });
        }
        // Update search Matrix
        const lstFilterVal = [];
        lstClonedTableFilterData.forEach(el => {
            if (this.mapFilterConfig.get(el.value).intCol !== -1 && el.fvalue.value && el.fvalue.value !== '') {
                lstFilterVal.push({ colIndx: this.mapFilterConfig.get(el.value).intCol - 1, searchTerm: el.fvalue.value });
            } else {
                //do nothing
            }
        });
        this.searchMatrix[1] = lstFilterVal;
        this.lstTableFilterData = lstClonedTableFilterData;
    }

    handleColumnChange(ev) {
        let value = '';
        let intRowIndex = '';

        if (ev.currentTarget) {
            const objTarget = ev.currentTarget;
            value = ev.currentTarget.value;
            intRowIndex = [...objTarget.closest('.filter-body').children].indexOf(objTarget.closest('.filter-row'));
        } else {
            value = ev.value;
            intRowIndex = ev.intRowIndex;
        }
        this.generateUpdateFilterData('UPDATE', true, { rowIndex: intRowIndex, value: value });
        this.manageTableComponentHeight();
    }

    handlefValChange(ev) {
        try {
            const objTarget = ev.currentTarget;
            let value, dateType, intRowIndex;
            if (objTarget) {
                if (ev.type === 'calendardataupdate') {
                    value = ev.detail;
                    dateType = objTarget && objTarget.strUniqueId;
                } else if (ev.type === 'changecheckbox') {
                    value = ev.detail.join('|');
                } else {
                    value = objTarget.value;
                }
                intRowIndex = [...objTarget.closest('.filter-body').children].indexOf(objTarget.closest('.filter-row'));
            } else if (ev.value) {
                value = ev.value;
                dateType = false;
                intRowIndex = ev.intRowIndex;
            } else {
                return;
            }

            this.generateUpdateFilterData('UPDATE', false, { rowIndex: intRowIndex, value: value, dateType: dateType });
            this.searchTable();
            this.manageTableComponentHeight();
        } catch (e) {
            //Do nothing
        }
    }

    handleRowAction(ev) {
        try {
            if (this.tableSettings.boolExpandOnRowClick) {
                this.handleShowNested(ev);
            }
            const isRowNested = ev.currentTarget.closest('tr').classList.contains('nestedTable');
            let intColIndex = [...ev.currentTarget.closest('tr').children].indexOf(ev.currentTarget);
            if (this.boolSecondaryTable || this.boolShowCheckbox) {
                intColIndex = intColIndex - 1;
            } else {
                //do nothing
            }

            //check for hidden columns
            let intNewColIndex = intColIndex;
            let intCount = 0;
            let intBreakCount = 0;
            while (intBreakCount <= intColIndex) {
                if (this.columns[intCount] && this.columns[intCount].boolHidden) {
                    intNewColIndex++;
                } else {
                    intBreakCount++;
                }
                intCount++
            }
            intColIndex = intNewColIndex;
            let columnName = '';
            let columnFieldName = '';
            if (BaseLWC.isNotUndefinedOrNull(intColIndex) && intColIndex > -1 && this.columns[intColIndex]) {
                columnName = this.columns[intColIndex].label;
                columnFieldName = this.columns[intColIndex].fieldName;
            }

            let renderedRowData = ev.currentTarget.closest('tr').getAttribute('data-rowdata');
            if (isRowNested) {
                columnName = '';
                columnFieldName = '';
                renderedRowData = ev.currentTarget.closest('tr').previousElementSibling.getAttribute('data-rowdata');
            } else {
                //do nothing
            }

            let strActionKey = '';
            if (ev.currentTarget.classList.contains("option")) {
                strActionKey = ev.currentTarget.getAttribute("data-key");
                columnName = "ACTION";
                columnFieldName = "actionBtn";
            } else {
                strActionKey = '';
            }

            let activeColumnData = '';
            JSON.parse(renderedRowData).forEach(objData => {

                if (objData.key === columnFieldName) {
                    activeColumnData = objData;
                    return;
                } else {
                    //do nothing
                }
            });

            const objParams = {
                renderedRowData: renderedRowData,
                activeColumnName: columnName,
                activeColFieldName: columnFieldName,
                activeColumnData: activeColumnData,
                isRowNested: isRowNested,
                strActionKey: strActionKey,
                isChecked: ev.target.checked //added this parem to notify if checkbox is checked or unchecked.     
            };
            BaseLWC.fireNativeCustomEvent('rowaction', objParams, this);
        } catch (error) {
            //Do Nothing
        }

    }

    richTextEventHandler = (ev) => {

        let renderedRowDataObj = null;
        if (this.boolSecondaryTable){
            renderedRowDataObj = ev.currentTarget.closest('tr').previousElementSibling.getAttribute('data-rowdata');
        } 
        const objParams = {
            renderedRowData: null,
            activeColumnName: null,
            activeColFieldName: null,
            activeColumnData: null,
            isRowNested: true,
            isExpanded: true,
            objSecTableEvent: ev.detail,
            objSecTableParentRowData: renderedRowDataObj
        };

        BaseLWC.fireNativeCustomEvent('rowaction', objParams, this);
    }

    showTooltip(ev) {
        this.tooltipValue = ev.currentTarget.getAttribute('data-tooltip');
        const strKeyData = ev.currentTarget.getAttribute('data-keydata');
        const element = '[data-keypop="' + strKeyData + '"]';
        this.template.querySelector(element).style.display = 'block';
    }

    hideTooltip() {
        //Do nothing
    }

    /**
     * method to hide certifications hover
     */
    hideHoverDetails(event) {
        event.target.closest("div").querySelector(".slds-popover_tooltip").classList.add("slds-hide");
    }

    /**
     * method to show certifications hover
     */
    displayHoverDetails(event) {
        //Table container
        const tableCtr=event.target.closest('.table-container').getBoundingClientRect();
        const targetPos = event.target.getBoundingClientRect();
        const clientPopover = event.target.closest("div").querySelector(".slds-popover_tooltip");
        const strNubbinAlign = clientPopover.getAttribute('data-nubbin-align');
        clientPopover.classList.remove("slds-hide");
        clientPopover.classList.add("slds-is-fixed");
        if(strNubbinAlign==='left-top'){
            clientPopover.style.left = targetPos.left - tableCtr.left + 20+'px';
            clientPopover.style.top = targetPos.top- tableCtr.top + (0.5*targetPos.height)-8+'px';
        }else{
            clientPopover.style.left = targetPos.left -tableCtr.left-clientPopover.clientWidth+20+'px';
            let PopoverTop = targetPos.top- tableCtr.top - clientPopover.clientHeight-targetPos.height;
            if(PopoverTop<0){
                clientPopover.style.top = 0;
            } else{
                clientPopover.style.top = PopoverTop+'px';
            }
        }
       
        clientPopover.style.right = 'unset';
        clientPopover.style.bottom = 'unset';
    }
    /**
     * method to show certifications hover
     */
    displayHeaderHoverDetails(event) {
        event.target.closest("th").querySelector(".slds-popover_tooltip").classList.remove("slds-hide");
    }
    hideHeaderHoverDetails(event) {
        event.target.closest("th").querySelector(".slds-popover_tooltip").classList.add("slds-hide");
    }

    openOrCloseBtnMenu(objEvent) {
        if (objEvent.currentTarget.closest("div").querySelectorAll(".slds-dropdown")[0].classList.contains("slds-hide")) {
            objEvent.currentTarget.closest("tbody").querySelectorAll(".slds-dropdown").forEach((objElement) => {
                if (!objElement.classList.contains("slds-hide")) {
                    objElement.classList.add("slds-hide");
                }
            });
            objEvent.currentTarget.closest("div").querySelectorAll(".slds-dropdown")[0].classList.remove("slds-hide");
        } else {
            objEvent.currentTarget.closest("div").querySelectorAll(".slds-dropdown")[0].classList.add("slds-hide")
        }
    }

    handleExpandCollpaseRows = () => {

        const tabelRows = this.template.querySelectorAll('.clsLwcCustomizedDatatableTable tbody tr.nestedTable');
        const tabelRowsParentAccord = this.template.querySelectorAll('.clsLwcCustomizedDatatableTable tbody tr td.innerTable')


        tabelRows.forEach((rowItem) => {
            if (this.strLabelExpandCollapseRows === "Expand All Rows") {
                rowItem.classList.add('expanded');
                rowItem.setAttribute('data-expanded', 'innerTable expanded');
            } else {
                rowItem.classList.remove('expanded');
                rowItem.setAttribute('data-expanded', 'innerTable collapsed');
            }

        });

        tabelRowsParentAccord.forEach((parentRowItem) => {
            if (this.strLabelExpandCollapseRows === "Expand All Rows") {
                parentRowItem.classList.add('expanded');

            } else {
                parentRowItem.classList.remove('expanded');

            }


        });

        if (this.strLabelExpandCollapseRows === "Expand All Rows") {
            this.strLabelExpandCollapseRows = "Collapse All Rows"

        } else {
            this.strLabelExpandCollapseRows = "Expand All Rows"

        }

    }

    updateDefaultFilters = () => {
        //Check for default Filter
        if (this.tableSettings.lstDefaultFilter && this.tableSettings.lstDefaultFilter.length) {
            this.tableSettings.lstDefaultFilter.forEach(() => {
                let boolDisplay = false;
                const lstDef = [];
                for (let [key, value] of this.mapFilterConfig) {
                    if (value.defaultValues) {
                        lstDef.push({ 'key': key, 'value': value })
                        boolDisplay = true;
                    }
                }
                if (boolDisplay && !this.lstTableFilterData.length) {
                    lstDef.forEach((elm, index) => {
                        this.generateUpdateFilterData('ADD', false, {});
                        //column Selector
                        this.handleColumnChange({ value: elm.key, intRowIndex: index });

                        //value selector
                        this.handlefValChange({ value: elm.value.defaultValues.join('|'), intRowIndex: index, dateType: false })

                    });
                    this.template.querySelector('.remove-all-filter').classList.remove('disabled-link');
                }
            })
        }
    }
    adjustTableClass = (objEvent) => {
        const objDataTable = this.template.querySelector(".clsLwcCustomizedDatatableTable");
        if (objDataTable) {
            if (objEvent.detail.boolIsCalendarOpen) {
                objDataTable.classList.add("extraMargin");
            } else {
                objDataTable.classList.remove("extraMargin");
            }
        }
    }
}