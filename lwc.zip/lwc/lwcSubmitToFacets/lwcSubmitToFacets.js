import { LightningElement, api } from 'lwc';

//Toast Message Helper
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
//refresh the Lightning Data Service cache, to see the changes in the record instantly.
import { getRecordNotifyChange } from 'lightning/uiRecordApi';

//Callout method to submit facets.
import submitCaseToFacets from "@salesforce/apexContinuation/CreateChildCaseController_ACE.submitCaseToFacets";
//CEAS-69294
import facetsUpdateTempAddress from "@salesforce/apexContinuation/CreateChildCaseController_ACE.facetsUpdateTempAddress";
import submitToFacets_COCC from "@salesforce/apexContinuation/CreateChildCaseController_ACE.submitToFacetsCOCC";
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';

export default class LwcSubmitToFacets extends LightningElement {

    //Attributes from childcaselightningcomponent.
    @api strType;
    @api strSubType;
    @api objCaseData;
    @api recordId;
    @api boolNmccCheck;
    @api boolIsGovtMedicare;
    @api strcorpcode;

    //Global default variables
    objCardError = {};
    caseParam;
    facetsMap;

    //Boolean Variables
    boolAPIError = false;
    boolShowSpinner = false;
    boolInquiryId = false;
    boolNotesBlank = false;
    boolshowFacetsCard = false;
    boolMetaDataBlank = false;
    //CEAS-69294 TO CHECK WHETHER LOB IS NMCC
    boolNmcc = false;
    routeToQueueLOB = '';
    caseId;
    facetNotes;

    //Toast message helper variables
    successToast = { title: 'Request successfully submitted', message: '', variant: 'success' }
    failureToast = { title: 'The following fields are required to submit to Facets: Facets Additional Notes. Please update the case and resubmit to Facets', message: '', variant: 'error' }
    apiFailureToast = { title: 'There was an error completing your request. Please attempt to resubmit to Facets. if unsuccessful, please submit a help desk ticket.', message: '', variant: 'error' }
    //CEAS-69102
    boolIsNmcc_COCC = false;
    //Initial method
    connectedCallback() {
        try {
            this.boolshowFacetsCard = true;
            this.initializeFacetsData();
        } catch (error) {
            this.handleErrors(error);
        }
    }

    get boolSubmitDisabled() {
        return this.boolNmccCheck && this.boolNotesBlank;
    }

    get boolShowFacetNotes() {
        return this.boolNmccCheck && ((this.strType === 'Enrollment / Eligibility' && this.strSubType === 'Update Membership Information') || 
        (this.strType === 'Member Management' && this.strSubType === 'Coordination of Benefits') || (this.strType === 'Benefits' && this.strSubType === 'Vendor Inquiry') ||
        (this.strType === 'Member Management' && this.strSubType === 'Address Change') || (this.strType === 'Provider / PCP / Specialist' && this.strSubType === 'PCP Update') ||
        (this.strType === 'Correspondence' && this.strSubType === 'Provider Correspondence') || (this.strType === 'Claims' && this.strSubType === 'Claim Inquiry') ||
        (this.strType === 'Provider' && this.strSubType === 'Provider Data') || (this.strType === 'Member Management' && this.strSubType === 'ID Card Request'));
    }

    /**
     * CEAS-60565
     * Data handler for Facets .
     * Creating a map(body for callout) in JS for good performance.
     */
    initializeFacetsData = () => {
        //CEAS-69294
        //Preparing the map Params to be passed to facets API and fetching the case id to send as state for update
        if(this.strType  === 'Member Management' && this.strSubType === 'Address Change' && this.strcorpcode === 'NM1') {
        this.boolNmcc = true;
        const labelsNmcc = ["groupContrivedKey","subscriberContrivedKey","subscriberAddressLine1", "subscriberAddressLine2","city", "zipCode","state","memberContrivedKey","effectiveDate","terminationDate"];
        if (this.objCaseData) {
            this.caseParam = JSON.parse(this.objCaseData, (elem, value) => value == null ? '' : value);
            this.caseId = this.caseParam.pop();
            this.facetsMap = Object.fromEntries(labelsNmcc.map((_, i) => [labelsNmcc[i], this.caseParam[i]]));
            this.facetsMap = JSON.stringify(this.facetsMap);
         }
        } else if(this.strType  === 'Correspondence' && this.strSubType === 'Member Correspondence' && this.strcorpcode === 'NM1') {
            const labelsNmcc = ["userId","description","entityId", "entityType","policyStatus", "firstName","lastName","middleName","address1","address2","city","state","zipCode","subscriberId","policyEffectiveDate","ownerId","policyTerminationDate","caseId"];
            if (this.objCaseData) {
                this.boolNmcc = true;
                this.boolIsNmcc_COCC = true;
                this.caseParam = JSON.parse(this.objCaseData, (elem, value) => value == null ? '' : value);
                this.caseId = this.caseParam.pop();
                this.facetsMap = Object.fromEntries(labelsNmcc.map((_, i) => [labelsNmcc[i], this.caseParam[i]]));
                //CEAS-73279
                if(this.facetsMap && this.facetsMap.policyTerminationDate === "") {
                    this.facetsMap.policyTerminationDate = null;
                }
                this.facetsMap = JSON.stringify(this.facetsMap);

            }
        } else {
        //CEAS-65909 added facetsSubgroupContrivedKey
        //Labels and caseParam array's are keys and values of the map respectively.
        const labels = ["contactLastName", "contactFirstName", "accountId", "caseId",
            "facetsAdditionalInformation", "customerId", "subscriberId", "groupId", "userDefinedCodeCategory", "subjectClassification", "pageType",
            "facetsSubgroupContrivedKey", "callerType", "inquiryMethod", "statusClassification", "productCategory", "customerType", "configurationType"];

        //Hardcoded values for callout.
        const staticValues = ["CAL1", "1", "OP", "M", "M", "T"];

        if (this.objCaseData) {

            this.caseParam = JSON.parse(this.objCaseData, (elem, value) => value == null ? '' : value);
            this.caseParam.push(...staticValues);
            this.facetNotes = this.caseParam[4];
            //Create the final body map.
            this.facetsMap = Object.fromEntries(labels.map((_, i) => [labels[i], this.caseParam[i]]));

            //Checking whether the custom metadata record is available for this type subtype.
            if (!(this.facetsMap.userDefinedCodeCategory && this.facetsMap.subjectClassification)) {
                this.boolMetaDataBlank = true;
            }
            //The facetsAdditionalInformation cannot be blank, if it is blank/null/undefined we skip the callout and show toast message.
            if (this.facetsMap.facetsAdditionalInformation) {
                this.facetsMap.facetsAdditionalInformation = 'ACE-' + this.facetsMap.facetsAdditionalInformation;
                this.facetsMap = JSON.stringify(this.facetsMap);
            } else {
                this.boolNotesBlank = true;
            }
        }
    }
    
    if (this.facetNotes === undefined || this.facetNotes === null || this.facetNotes === '') {
        this.boolNotesBlank = true;
    }

    if (this.boolNmccCheck && this.strType && this.strSubType && this.strcorpcode === 'NM1' &&
        ((this.strType  === 'Member Management' && this.strSubType === 'Coordination of Benefits') ||
        (this.strType  === 'Benefits' && this.strSubType === 'Vendor Inquiry') ||
        (this.strType  === 'Provider' && this.strSubType === 'Provider Data') ||
        (this.strType  === 'Enrollment / Eligibility' && this.strSubType === 'Update Membership Information'))) {
            this.routeToQueueLOB = 'NM_Medicaid_Pend_FAC';
     } else if(this.strcorpcode === 'TX1' && this.boolNmccCheck) {
        this.routeToQueueLOB = 'TX_Medicaid_Pend_to_Facets';
     } else {
         //do nothing
     }
     if (this.boolIsGovtMedicare && this.strType && this.strSubType &&
        (this.strType  === 'Claims' && this.strSubType === 'Claim Inquiry') ||
        (this.strType  === 'Enrollment / Eligibility' && this.strSubType === 'Cancellation Request')) {
            this.routeToQueueLOB = 'MAPDPNDF';
    } else {
        //do nothing
    }
}

    handleFacetNotes = (event) => {
        this.facetNotes = event.detail.value;
        if (BaseLWC.stringIsNotBlank(this.facetNotes)) {
            this.boolNotesBlank = false;
        } else {
            this.boolNotesBlank = true;
        }
    }

    /**
     * CEAS-60565
     * Method called to submit the Case to facets.
     * @returns Inquiry Id / Task Id which will confirm that Case submitted successfuly.
     */

    async fetchFacetsData() {
        try {
            const facetsElement = this.template.querySelector(".facetNotes");
            if (facetsElement) {
                if (!facetsElement.checkValidity()) {
                    facetsElement.reportValidity();
                    this.boolNotesBlank = true;
                    return;
                }
                facetsElement.setCustomValidity('');
                this.boolNotesBlank = false;
                let facetsObj = this.facetsMap;
                if (typeof this.facetsMap === 'string') {
                    facetsObj = JSON.parse(this.facetsMap);
                }
                if ('facetsAdditionalInformation' in facetsObj) {
                    facetsObj.facetsAdditionalInformation = 'ACE-' + this.facetNotes;
                    this.facetsMap = JSON.stringify(facetsObj);
                }
            }
            //If "facetsAdditionalInformation" is blank or
            //type-subtype doesn't have metadata recordcallout will not happen
            if (!this.boolNotesBlank && !this.boolMetaDataBlank) {

                this.boolShowSpinner = true;
                this.boolInquiryId = await submitCaseToFacets({ facetsMap: this.facetsMap, routeToQueueLOB: this.routeToQueueLOB, facetNotes: this.facetNotes});

                //If the callout is success we show a Toast Message and perform further steps.
                if (this.boolInquiryId === true) {

                    this.boolShowSpinner = false;
                    this.showNotification(this.successToast);

                    //This imported method will trigger a refresh on the case record to show the changes instantly.
                    getRecordNotifyChange([{ recordId: this.recordId }]);
                    this.boolshowFacetsCard = false;
                    this.successEvent();
                    this.closeModal();
                } else {
                    this.showNotification(this.apiFailureToast);
                    this.boolshowFacetsCard = false;
                    this.closeModal();
                }
            } else {
                if (this.boolNotesBlank) {
                    this.showNotification(this.failureToast);
                } else if (this.boolMetaDataBlank) {
                    this.showNotification(this.apiFailureToast);
                } else {
                    //do nothing
                }
                this.boolshowFacetsCard = false;
                this.closeModal();
            }
        } catch (error) {
            this.handleErrors(error);
        }
    }
    /**
     * CEAS-69294
     * Method called to submit the NMCC Case to facets.
     */

    async fetchFacetsNmccData() {
        let objErrorToast = { title: 'There was an error completing your request. Please attempt to resubmit to Facets. If unsuccessful, please submit a help desk ticket.', message: '', variant: 'error' }
        try {
            if(this.boolIsNmcc_COCC) {
                this.boolShowSpinner = true;
                this.boolInquiryId = await submitToFacets_COCC({ facetsMap: this.facetsMap ,strCaseID:this.caseId});
                if (this.boolInquiryId === true) {
                    this.boolShowSpinner = false;
                    this.showNotification(this.successToast);
                    getRecordNotifyChange([{ recordId: this.recordId }]);
                    this.boolshowFacetsCard = false;
                    this.successEvent();
                    this.closeModal();
                } else {
                    this.showNotification(objErrorToast);
                    this.boolshowFacetsCard = false;
                    this.closeModal();
                }
            } else {
            this.boolShowSpinner = true;
            this.boolInquiryId = await facetsUpdateTempAddress({strRecordId:this.caseId, facetsMap: this.facetsMap ,  boolOrderIdCard:false,  strCaseData:'',  strFamilyDataChecboxes:'' });
            if (this.boolInquiryId === true) {
                this.boolShowSpinner = false;
                this.showNotification(this.successToast);
                getRecordNotifyChange([{ recordId: this.recordId }]);
                this.boolshowFacetsCard = false;
                this.successEvent();
                this.closeModal();
            } else {
                this.showNotification(this.apiFailureToast);
                this.boolshowFacetsCard = false;
                this.closeModal();
            }
        }
        } catch (error) {
            this.handleErrors(error);
        }
    }

    /**
     * CEAS- 60595
     * @param {* toast object} objToast
     */
    showNotification(objToast) {
        const evt = new ShowToastEvent({
            title: objToast.title,
            message: objToast.message,
            variant: objToast.variant,
        });
        this.dispatchEvent(evt);
    }

    /**
     * CEAS- 60595
     * Firing Event back to aura to close the modal.
     */
    closeModal() {
        const FacetscloseModal = new CustomEvent('facetsclosemodal', {
            detail: { modalClose: false }
        });
        // Fire the custom event
        this.dispatchEvent(FacetscloseModal);
    }

    /**
     * CEAS- 60595
     * Firing Event back to aura to show the success of callout.
     */
    successEvent() {
        const FacetSuccessInfo = new CustomEvent('facetsuccess', {
            detail: { facetStatus: true }
        });
        // Fire the custom event
        this.dispatchEvent(FacetSuccessInfo);
    }

    /**
     * To handle Errors.
     * Helps to show case errors.
     * All components should have this code.
     */
    handleErrors = (error) => {
        //show Account API Error
        this.objCardError = error;
        this.boolAPIError = true;
        this.boolShowSpinner = false;
    };
}
