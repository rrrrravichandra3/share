import { LightningElement ,api,track} from 'lwc';

export default class LwcMultiselectPicklist extends LightningElement {
    @api
    values = [];
    @track valuesLocal = [];
    @track
    selectedvalues = [];
    selectedLabels = [];
    boolCheckbox = true;
    @track strSelectedmessage = "Select a Value"

    @api
    picklistlabel = '';
    @api
    customClass = '';
    @api
    defaultSelected = [];

    showdropdown;
    boolShowLabel=true;
    showPill=false;
    handleleave() {
        
        let sddcheck= this.showdropdown;

        if(sddcheck){
            this.showdropdown = false;
            this.fetchSelectedValues();
        }
    }

    connectedCallback(){
        this.values=this.values;
        this.valuesLocal = this.values;
         this.picklistlabel=this.picklistlabel;
        this.boolShowLabel=(this.picklistlabel && this.picklistlabel !== '');
        let disableAll = false;
        if (this.defaultSelected && (this.defaultSelected.includes('ASKU') || this.defaultSelected.includes('UNK'))) {
            disableAll = true;
        }
        if(this.values){
            this.valuesLocal = this.values.map((element) =>  {
                const currElement = {...element};
                if(currElement.selected || this.defaultSelected.includes(currElement.value)) {
                    currElement.selected = true;
                    this.selectedvalues.push(currElement.value);
                    this.selectedLabels.push(currElement.label);
                } else {
                    //do nothing
                }
                if (disableAll) {
                    if (currElement.value === 'AKSU' || currElement.value === 'UNK') {
                        currElement.selected = true;
                    } else {
                        currElement.selected = false;
                        currElement.isDisabled = true;
                    }
                }
                
                return currElement;
            });
        }

        if(this.selectedLabels.length === 0) {
            this.strSelectedmessage =  "Select a Value";
        } else if(this.selectedLabels.length === 1) {
            this.strSelectedmessage =  this.selectedLabels[0];
        } else if(this.selectedLabels.length === 2){
            this.strSelectedmessage =  this.selectedLabels.join("; ");
        } else {
            this.strSelectedmessage =  this.selectedLabels.length + ' selected';
        }
    }

    fetchSelectedValues() {

        this.selectedvalues = [];

        //get all the selected values
        if(this.boolCheckbox){
            [...this.template.querySelectorAll('.selectbox-with-checkbox li .multiSelectCheckBox')].forEach(
                element => {
                    if(element.checked){
                        this.selectedvalues.push(element.getAttribute('data-value'));
                    }
                }
            );
        }

        //refresh original list
        this.refreshOrginalList();
    }

    refreshOrginalList() {
        //update the original value array to shown after close
        if(!this.valuesLocal){
            return;
        }
        const picklistvalues = JSON.parse(JSON.stringify(this.valuesLocal));
        picklistvalues.forEach((element, index) => {
            if(this.selectedvalues.includes(element.value)){
                picklistvalues[index].selected = true;
            }else{
                picklistvalues[index].selected = false;
            }

            if(this.selectedLabels.includes(element.label)){
                picklistvalues[index].selected = true;
            }else{
                picklistvalues[index].selected = false;
            }
        });
        this.valuesLocal = picklistvalues;
    }

    handleShowdropdown(){
        const drop = this.showdropdown;
        if(drop){
            this.showdropdown = false;
            this.fetchSelectedValues();
        }else{
            this.showdropdown = true;
        }
    }

    //Boolean Checkbox true

        //holds only selected checkbox items that is being displayed based on search
        @track selectedItems = []; 

        //since values on checkbox deselection is difficult to track, so workaround to store previous values.
        //clicking on Done button, first previousSelectedItems items to be deleted and then selectedItems to be added into globalSelectedItems
        @track previousSelectedItems = [];
        //this holds checkbox values (Ids) which will be shown as selected
        @track value = []; 
        //captures the text to be searched from user input
        searchInput ='';    

        //Cancel button click hides the dialog
        handleCancelClick(){
            this.initializeValues();
        }

        //this method initializes values after performing operations
        initializeValues(){
            this.searchInput = '';
        }

        handleSelectChange(event){
            const checkedVal = event.target.getAttribute("data-value");
            const checkedLabel = event.target.label;
            const isChecked = event.target.checked;

            if(isChecked && checkedVal && (checkedVal === 'ASKU' || checkedVal === 'UNK')) {
                this.selectedLabels.splice(0, this.selectedLabels.length);
                this.selectedvalues.splice(0, this.selectedvalues.length);
                this.valuesLocal = JSON.parse(JSON.stringify(this.valuesLocal)).map(el=> {
                    if(el.label !== checkedLabel) {
                        el.selected = false;
                        el.isDisabled = true;
                    } else {
                        el.selected = true;
                    } 
                    return el;               
                });            
            } else if(checkedVal && (checkedVal === 'ASKU' || checkedVal === 'UNK') && !isChecked && this.valuesLocal.length) {
                this.valuesLocal = this.values;
            }               
            if(isChecked) {
                this.selectedLabels.push(checkedLabel);
                this.selectedvalues.push(checkedVal);            
             } else {
                this.selectedLabels.splice(this.selectedLabels.indexOf(checkedLabel),1);
                this.selectedvalues.splice(this.selectedvalues.indexOf(checkedVal),1);
            }

            if(this.selectedLabels.length === 0) {
                this.strSelectedmessage =  "Select a Value";
            } else if(this.selectedLabels.length === 1) {
                this.strSelectedmessage =  this.selectedLabels[0];
            } else if(this.selectedLabels.length === 2){
                this.strSelectedmessage =  this.selectedLabels.join("; ");
            } else {
                this.strSelectedmessage =  this.selectedLabels.length + ' selected';
            }

            const selectedEvent = new CustomEvent("changecheckbox", {
                    detail : this.selectedvalues
            });
            this.dispatchEvent(selectedEvent);
            this.refreshOrginalList();
        }

        closePill(event){
            let selection = event.target.dataset.value;
            let selectedpills = this.selectedvalues;
            let selectedlabelpills = this.selectedvalues;
            let pillIndex = selectedpills.indexOf(selection);
            let pilllabelIndex = selectedlabelpills.indexOf(selection);
            this.selectedvalues.splice(pillIndex, 1);
            this.selectedLabels.splice(pilllabelIndex, 1);
            this.refreshOrginalList();
            if(this.selectedvalues.length === 0) {
                this.strSelectedmessage =  "Select a Value";
            } else if(this.selectedvalues.length === 1) {
                this.strSelectedmessage =  this.selectedvalues[0];
            } else if(this.selectedvalues.length === 2){
                this.strSelectedmessage =  this.selectedvalues.join("; ");
            } else {
                this.strSelectedmessage =  this.selectedvalues.length + ' selected';
            }
        }
}