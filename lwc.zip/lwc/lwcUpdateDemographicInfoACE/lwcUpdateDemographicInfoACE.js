import { LightningElement ,api, wire, track} from 'lwc'; 
import fetchDemographicValues from '@salesforce/apex/DemographicInfoController.fetchDemographicValues';
import updateDemographicInfo from '@salesforce/apexContinuation/DemographicInfoController.updateDemographicInfo';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class LwcUpdateDemographicInfoACE extends LightningElement {
    @api boolopenmodal;
    @api recordId;
    @api strMID;
    _selectedRace = [];
    @api
    get selectedRace() {
        return this._selectedRace;
    }
    set selectedRace(value) {
        if (value) {
            this._selectedRace = value;
        }
    }
    @api
    get selectedEthnicity() {
        return this._selectedEthnicity;
    }
    set selectedEthnicity(value) {
        if (value) {
            this._selectedEthnicity = value;
        }
    }
    @api
    get selectedLanguage() {
        if (this._selectedLanguage) {
            return this._selectedLanguage;
        }
        return '';
    }
    set selectedLanguage(value) {
        if (value) {
            this._selectedLanguage = value;
        }
    }
    @api
    get selectedSex() {
        return this._selectedSex;
    }
    set selectedSex(value) {
        if (value) {
            this._selectedSex = value;
        }
    }
    @api
    get selectedGender() {
        return this._selectedGender;
    }
    set selectedGender(value) {
        if (value) {
            this._selectedGender = value;
        }
    }
    @api
    get selectedOrientation() {
        return this._selectedOrientation;
    }
    set selectedOrientation(value) {
        if (value) {
            this._selectedOrientation = value;
        }
    }
    @api
    get selectedPronouns() {
        return this._selectedPronouns;
    }
    set selectedPronouns(value) {
        if (value) {
            this._selectedPronouns = value;
        }
    }
    _selectedEthnicity;
    _selectedLanguage;
    _selectedSex;
    _selectedGender;
    _selectedOrientation;
    _selectedPronouns;
    @track languageOptions;
    boolApiError=false;
    resultData;
    objError;

    handleErrors(error) {
        this.objError = error;
    }

    @wire(fetchDemographicValues, {})
    fetchDemographicValuesExec({ error, data }) {       
        if (data) {
            ({'language' : this.languageOptions,'RACE' : this.raceOptions,'GENDER IDENTITY' : this.genderOptions,'SEX ASSIGNED AT BIRTH' : this.sexOptions,'ETHNICITY' : this.ethnicityOptions, 'SEXUAL ORIENTATION' : this.orientationOptions, 'PRONOUNS' : this.pronousOptions} = data);
        } else if (error) {
            this.handleErrors(error);
        }
    }
    
    @track raceOptions;
    @track ethnicityOptions = [];
    @track sexOptions = [];
    @track genderOptions = [];
    @track orientationOptions = [];
    @track pronousOptions = [];

    handleChangeRace(event) {
        this.selectedRace = event.detail;
    }
    handleChangeEthnicity(event) {
        this.selectedEthnicity = event.target.value;
    }
    handleChangeLanguage(event) {
        this.selectedLanguage = event.detail;
    }
    handleChangeSex(event) {
        this.selectedSex = event.target.value;
    }
    handleChangeGender(event) {
        this.selectedGender = event.target.value;
    }
    handleChangeOrientation(event) {
        this.selectedOrientation = event.target.value;
    }
    handleChangePronous(event) {
        this.selectedPronouns = event.target.value;
    }

    closeModalEvent(event) {
        this.boolopenmodal= false;
        const closeModal = new CustomEvent('cancelorclosemodal', {
            detail: { boolopenmodal: false }
        });
        // Fire the custom event
        this.dispatchEvent(closeModal); 
    }

    stringifiedArr(data) {
        if (data) {
            return JSON.stringify([data]);
        }
        return JSON.stringify([]);
    }

    saveDemographicUpdates(){
     try {        
        updateDemographicInfo({ mid : this.strMID, strRace: JSON.stringify(this.selectedRace),strEthnicity:this.stringifiedArr(this.selectedEthnicity) ,strLanguage:this.stringifiedArr(this.selectedLanguage) ,strOrientation:this.stringifiedArr(this.selectedOrientation) ,strGender:this.stringifiedArr(this.selectedGender) ,strSex: this.stringifiedArr(this.selectedSex),strPronouse:this.stringifiedArr(this.selectedPronouns)  })
            .then(result => {
                if (result) {
                    this.resultData = JSON.parse(result);
                        if(this.resultData && (this.resultData.toString() === '200' || this.resultData.toString() === '201')){
                            this.boolApiError = false;
                        const event = new ShowToastEvent({
                            title:'',
                            message: 'Members demographic data has been submitted.  It may take up to 24 hours to update the members account information',
                            variant: 'success',
                            mode: 'sticky'
                        });
                        this.dispatchEvent(event);
                        this.closeModalEvent(event);
                    } else {
                        this.boolApiError = true;
                    }
                }
                else {
                    this.boolApiError = true;
                }
                }).catch((e) => {
                    this.handleErrors(e);
                });
        } catch(exp){
            this.handleErrors(exp);
        }
    }
}