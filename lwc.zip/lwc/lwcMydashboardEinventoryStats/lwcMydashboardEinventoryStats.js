import {
	LightningElement,
	track
} from 'lwc';

import getCaseStatus from '@salesforce/apex/MydashboardEinventoryStatsController.getCaseStatus';

export default class LwcMydashboardEinventoryStats extends LightningElement {
	@track objCaseData = {
		totalcases: 0,
		opencases: 0,
		pendedcases: 0,
		closedcases: 0
	};
	boolShowSpinner = false;
	fetchCaseData() {
		this.boolShowSpinner = true;
		getCaseStatus().then(lstCaseData => {
			if (lstCaseData) {
                this.objCaseData['totalcases'] = 0;
                lstCaseData.forEach((objCase) => {
                    if(objCase.Status === "Open") {
                        this.objCaseData['opencases'] = objCase.expr0;
                    } else if(objCase.Status === "Pended") {
                        this.objCaseData['pendedcases'] = objCase.expr0;
                    } else if(objCase.Status === "Closed") {
                        this.objCaseData['closedcases'] = objCase.expr0;
                    } else {
						//Do Nothing
					}
                    this.objCaseData['totalcases'] += objCase.expr0; 
                })
				this.boolShowSpinner = false;
			}
		}).catch(error => {
			this.boolSpinner = false;
		});
	}
	connectedCallback() {
		try {
			this.fetchCaseData();
		} catch (error) {
            //Do Nothing
		}

	}
	refreshData() {
		
		this.objCaseData['totalcases'] = 0;
		this.objCaseData['opencases'] = 0;
		this.objCaseData['pendedcases'] = 0;
		this.objCaseData['closedcases'] = 0;

		this.fetchCaseData();
	}
}