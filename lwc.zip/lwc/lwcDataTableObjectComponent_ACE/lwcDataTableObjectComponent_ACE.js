import { LightningElement,api,wire } from 'lwc';
//CEAS-82979 Platform Workspace API
import { refreshTab,setTabLabel,setTabIcon,getFocusedTabInfo,openSubtab,getTabInfo,EnclosingTabId} from 'lightning/platformWorkspaceApi';
export default class LwcDataTableObjectComponentACE extends LightningElement {

    boolIsHyperLink=false;
    boolIsHighlighted=false;
    //CEAS-70215 Added the variable in order to disable the claim number in the table
    boolIsDisabled = false; 
    localstrFlexiPageName='';
    objTabData;
    localstrIconName='';
    localstrFieldValue='';
    boolError;
    strParentTabId;
    strMedicalClaimFlexipage = 'ViewMedicalClaimDetailsFlexiPage_ACE';
    
    @api objFieldValues;
    @api objFieldDetails;
    @api strURL;
    @api strURLParamToPick;
    @api boolFEPMember;
    @api strMid;
    @api strClaimsFEPDirectURL;
    @api
    get strFlexiPageName() {
        return this.localstrFlexiPageName;
    }
    set strFlexiPageName(value) {
        if(value) {
            this.localstrFlexiPageName=value;
        }
    }

    @api
    get strIconName() {
        return this.localstrIconName;
    }
    set strIconName(value) {
        if(value) {
            this.localstrIconName=value;
        }
    }

    @api
    get strFieldValue() {
        return this.localstrFieldValue;
    }
    set strFieldValue(value) {
        if(value) {
            this.localstrFieldValue=value;
        }
    }
    @wire(EnclosingTabId) enclosingTabId;

    connectedCallback() {
        this.initialDoInit();
    }

    checkForTextHover(event) {
        event.preventDefault();
        event.stopImmediatePropagation();
        event.stopPropagation();

        const textElements = event.target;
        if(textElements.querySelectorAll(".cls-hovertext").length > 0 && textElements.querySelectorAll("slds-popover").length > 0){
            textElements.querySelectorAll("slds-popover")[0].classList.remove("slds-hide");
        }
    }

    hideHoverText(event) {
        event.preventDefault();
        event.stopImmediatePropagation();
        event.stopPropagation();

        const textElements = event.target;
        if(textElements.querySelectorAll(".cls-hovertext").length > 0 && textElements.querySelectorAll("slds-popover").length > 0){
            textElements.querySelectorAll("slds-popover")[0].classList.add("slds-hide");
        }
    }

    initialDoInit() {
        let objFieldData = '';
        const strFieldData = JSON.stringify(this.objFieldValues);
        const strField = JSON.stringify(this.objFieldDetails);
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(response => {
                this.objTabData = JSON.parse(JSON.stringify(response));
                if (this.objTabData.isSubtab) {
                    this.strParentTabId = this.objTabData.parentTabId;
                } else {
                    this.strParentTabId = this.objTabData.tabId;
                } 
            }).catch(function() {
                //Do Nothing
            });
        }
        if(strFieldData !== undefined) {
             objFieldData = JSON.parse(strFieldData);
        }
        const objField = JSON.parse(strField);
        
        if(objField && objField.Key && objFieldData !== ''){
            this.strFieldValue = objFieldData[objField.Key];
        } else {
            this.strFieldValue='';
        }

        if(objField.isHyperLink){
            this.boolIsHyperLink=true;
        } else {
            this.boolIsHyperLink=false;
        }
        if (objFieldData['IS HIGHLIGHTED'] !== undefined && objFieldData['IS HIGHLIGHTED'] !== null && objFieldData['IS HIGHLIGHTED'] && objFieldData['IS HIGHLIGHTED'] === true ) {
            if(objFieldData['COLUMN NAME'] !== undefined && objFieldData['COLUMN NAME'] !== null && objFieldData['COLUMN NAME'] && objFieldData['COLUMN NAME'].includes(objField.Key)) {
                this.boolIsHighlighted=true;
            } else {
                this.boolIsHighlighted=false;
            }
        }
        else {
            this.boolIsHighlighted=false;
        }
        //CEAS-70215
        if (objFieldData['IS DISABLED'] !== undefined && objFieldData['IS DISABLED'] !== null && objFieldData['IS DISABLED'] && objFieldData['IS DISABLED'] === true ) {
            if(objFieldData['COLUMN NAME'] !== undefined && objFieldData['COLUMN NAME'] !== null && objFieldData['COLUMN NAME'] && objFieldData['COLUMN NAME'].includes(objField.Key)) {
                this.boolIsDisabled=true;
            } else {
                this.boolIsDisabled=false;
            }
        } else {
            this.boolIsDisabled=false;
        }
    }

    openSubTabClaims(event) {
        const strFieldData = JSON.stringify(this.objFieldValues);
        const objFieldData = JSON.parse(strFieldData);
        
        if(this.boolFEPMember && objFieldData["DCN"] !== "" && objFieldData["DCN"] !== undefined) {
                     const UniqueId = "FEPDirect"+ this.strMid;
                     const URL = this.strClaimsFEPDirectURL+"?senderApp=HCSC&action=invenClmRoster&claimNumber="+objFieldData["DCN"];
                     window.open(URL,UniqueId);
                     return ;
         }
        let Recordtype;
        let filedLabel;
        if (objFieldData.hasOwnProperty("RECORD TYPE")) {
        Recordtype = objFieldData["RECORD TYPE"];
        }
        filedLabel = objFieldData[this.strURLParamToPick];
        if(objFieldData["FLEXIPAGE"] !== "" && objFieldData["FLEXIPAGE"] !== undefined) {
         this.strFlexiPageName=objFieldData["FLEXIPAGE"];
        }
        if(objFieldData["SUBTABICON"] !== "" && objFieldData["SUBTABICON"] !== undefined) {
                 this.strIconName=objFieldData["SUBTABICON"];
        }
        let objPageReference;
        if ( event.target.text==='Adjust Claim (Streamline GUI)') {
            const URL=objFieldData['URLPARAMSGUI'];
            
            window.open(URL);
        } else {
            if(this.strFlexiPageName === 'Claims_History_FlexiPage_ACE') {
                //Navigate to Subtab
                const objPageReference2 = {
                    "type": "standard__navItemPage",
                    "attributes": {
                        "apiName": this.strFlexiPageName
                    },
                    "state": {
                        "c__BaseURLParam": objFieldData['URLPARAMS']
                    }
                };
                const callBackForRefreshSubTab =()=> {
                    getFocusedTabInfo().then(refereshresponse => {
                            localStorage.strBypassCustomRefreshLogic = "true";
                            refreshTab(refereshresponse.tabId);
                            setTabLabel(refereshresponse.tabId, labelname);
                    }).catch(error => {
                        this.handleErrors(error);
                    });
                }

            
                openSubtab(this.strParentTabId,{pageReference:objPageReference2,focus:true}).then(callBackForRefreshSubTab).catch(function() {
                    // Do Nothing
                }).catch(function() {
                    this.handleErrors(error);
                });
            
            } else if(this.strFlexiPageName === 'PriorAuthReferralDetailsFlexiPage_ACE' || this.strFlexiPageName === 'PredeterminationDetailsFlexiPage_ACE' ||
                this.strFlexiPageName === 'ReferralDetailFlexiPage_ACE') {
                objPageReference = {
                    "type": "standard__navItemPage",
                    "attributes": {
                        "apiName": this.strFlexiPageName,
                        "uid": objFieldData['URLPARAMS']
                    },
                    "state": {
                        "c__strAuthAndTabDetails": objFieldData['URLPARAMS']
                    }
                };
            } else if (this.strFlexiPageName === 'ViewPreserviceDetailsFlexiPage_ACE' && Recordtype === 'Pre-Service Document - Image/ECM'){
                filedLabel = 'Preservice / Folder Notes';
                objPageReference = {
                            "type": "standard__navItemPage",
                            "attributes": {
                                "apiName": this.strFlexiPageName
                            },
                            "state": {
                                "c__BaseURLParam": objFieldData['URLPARAMS']
                            }
                        };
            } else {
                //CEAS-86140
                if(objFieldData['DISPUTE ID'] && objFieldData['DCN/CLAIM NUMBER'] === event.target.text) {
                    filedLabel = objFieldData['DCN/CLAIM NUMBER'];
                    objPageReference = {
                        "type": "standard__navItemPage",
                        "attributes": {
                            "apiName": this.strMedicalClaimFlexipage,
                            "uid": objFieldData[this.strURLParamToPick]
                        },
                        "state": {
                            "c__BaseURLParam": objFieldData['URLPARAMS']
                        }
                    };
                } else {
                objPageReference = {
                    "type": "standard__navItemPage",
                    "attributes": {
                        "apiName": this.strFlexiPageName,
                        "uid": objFieldData[this.strURLParamToPick]
                    },
                    "state": {
                        "c__BaseURLParam": objFieldData['URLPARAMS']
                    }
                };
            }
            
            
            }
        }
        //open subtab
        const callBackForRefreshSubTab =()=> {
            getFocusedTabInfo().then(refereshresponse => {
                    localStorage.strBypassCustomRefreshLogic = "true";
                    const focusedSubTabId = refereshresponse.tabId;
                    setTabIcon(focusedSubTabId,this.strIconName,this.strFlexiPageName);
                    refreshTab(focusedSubTabId);
                    setTabLabel(focusedSubTabId, filedLabel);
                    
            }).catch(error => {
                this.handleErrors(error);
            });
        }
       
       
        openSubtab(this.strParentTabId, {pageReference : objPageReference, focus:true}).then(callBackForRefreshSubTab).catch(function() {
            // Do Nothing
        }).catch(function(error) {
            this.handleErrors(error);
        });
    }
    // method to catch error
    handleErrors(error) {
        this.boolError = error;
    }
}
