import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';

//import platformWorkspaceApi
import {openSubtab} from 'lightning/platformWorkspaceApi';

import getSecureMessageDetails from '@salesforce/apexContinuation/SecureMessageController_ACE.getSecureMessageDetailsViaContinuation'
import getSecureMessageDetailsForProvider from '@salesforce/apexContinuation/SecureMessageController_ACE.getSecureMessageProviderDetailsViaContinuation'
import getAttachmentDetails from '@salesforce/apex/SecureMessageController_ACE.getAttachmentDetails'
import getAttachment from '@salesforce/apex/SecureMessageController_ACE.getAttachment'


//import labels
import SecureMessageMSGStatus_ACE from '@salesforce/label/c.SecureMessageMSGStatus_ACE';
import SecureMessageDateOpened_ACE from '@salesforce/label/c.ViewCaseSummary_DateTimeOpened_ACE';
import SecureMessageSubject_ACE from '@salesforce/label/c.ViewCaseSummary_Subject_ACE';
import SecureMessageCreatedBy_ACE from '@salesforce/label/c.SMSTextMessage_TableHeader_CreatedBy_ACE';
import SecureMessageCaseSubType_ACE from '@salesforce/label/c.SecureMessageCaseSubType_ACE';
import SecureMessageCaseStatus_ACE from '@salesforce/label/c.SecureMessageCaseStatus_ACE';
import SecureMessageCaseNumber_ACE from '@salesforce/label/c.ViewCaseSummary_CaseNumber_ACE';
import SecureMessageInquirer_ACE from '@salesforce/label/c.SecureMessageInquirer_ACE';
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import InteractionHistoryPage_NoRecordFound_ACE from '@salesforce/label/c.InteractionHistoryPage_NoRecordFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import SecureMessageSource_ACE from '@salesforce/label/c.SecureMessageSource_ACE';

export default class LwcSecureMessageTabComponent extends LightningElement {

    label = {
        SecureMessageMSGStatus_ACE,
        SecureMessageDateOpened_ACE,
        SecureMessageSubject_ACE,
        SecureMessageCreatedBy_ACE,
        SecureMessageCaseSubType_ACE,
        SecureMessageCaseStatus_ACE,
        SecureMessageCaseNumber_ACE,
        SecureMessageInquirer_ACE,
        SafeMode_ToastMessage_ACE,
        InteractionHistoryPage_NoRecordFound_ACE,
        IntegrationFailMessage_ACE,
        SecureMessageSource_ACE
   }

    @api tabData;
    @api globalData;
    @api boolSafeMode;



    attachmentId;
    attachmentBody;
    strFileName;
    strFileType;

    boolDisplayData = false;
    boolSpinner = false;
    boolShowNoRecorsFound = false;
    boolAPIError = false;
    boolDisplayLimitMessage = false;
    intLimitCount = 100;
    intMessageCount = 0;
    strLimitMessage = '';
    strTabURL = '';
    handleError;
    boolSMProcessed = false;
    boolPSMProcessed = false;
    boolSMError = false;
    boolPSMError = false;
    boolFromHDB = true;
    boolFromCDV = false;
    lstData = [];
    lstTableData = [];

    columns = [
        { label: this.label.SecureMessageMSGStatus_ACE, fieldName: 'InOutDetails', sortable: true, type: '' },
        { label: this.label.SecureMessageDateOpened_ACE, fieldName: 'DateOpened', sortable: true, type: 'date', boolInitSort: true, boolAsc: false },
        { label: this.label.SecureMessageSubject_ACE, fieldName: 'Subject', sortable: true, type: '' },
        { label: this.label.SecureMessageCreatedBy_ACE, fieldName: 'CreatedBy', sortable: true, type: '' },
        { label: this.label.SecureMessageCaseSubType_ACE, fieldName: 'CaseTypeSubType', sortable: true, type: '' },
        { label: this.label.SecureMessageCaseStatus_ACE, fieldName: 'CaseStatus', sortable: true, type: '' },
        { label: this.label.SecureMessageCaseNumber_ACE, fieldName: 'CaseNumber', sortable: true, type: '' },
        { label: this.label.SecureMessageInquirer_ACE, fieldName: 'Inquirer', sortable: true, type: '' },
        { label: '', fieldName: 'DeletedSMTooltip', boolIsTooltip: true, boolIsInfoIconTooltip: true, sortable: true, type: '' },
        { label: '', fieldName: 'ExpandableDetails', sortable: false, type: '', boolHidden: true }
    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: true,
        boolShowSearch: true,
        boolShowSearchLabel: true,
        filterData: [
            { strType: 'Select a value', intCol: -1, strFilterName: 'Select a value' },
            { strType: 'picklist', intCol: 1, strFilterName: 'Inbound/Outbound' },
            { strType: 'dateRangeMF', intCol: 2, strFilterName: 'Date/Time Opened' },
            { strType: 'picklist', intCol: 5, strFilterName: 'Case Type/Sub Type"' },
            { strType: 'picklist', intCol: 6, strFilterName: 'Case Status' },
            { strType: 'text', intCol: 7, strFilterName: 'Case Number' },
            { strType: 'picklist', intCol: 8, strFilterName: 'Inquirer' }
        ]
    };

    connectedCallback() {
        if (this.tabData) {
            const objParsedTabData = JSON.parse(JSON.stringify(this.tabData)); 
            if (objParsedTabData.url) {
                this.strTabURL = objParsedTabData.url;
                this.fetchData();
            }
    }
}

    getAttchmentsFromRecords = (recId) => {
        this.recId = recId;
        getAttachment({
            recId: recId
        }).then(result => {

            if (result) {
                this.attachmentBody = result;
    
                if (this.strFileName && this.strFileType) {
                    this.previewAndDownloadDocument(this.strFileName, this.strFileType, this.attachmentBody);
                }
    
    
            }  else {
                //Do nothing
            }
        }).catch((error) => {
            this.handleErrors(error);
        });
    }

    fetchData = () => {
        //Fetch Data from Controller  
        this.boolAPIError = false;
        this.boolDisplayData = false;
        this.boolShowNoRecorsFound = false;
        this.boolSpinner = true;
        this.boolSMProcessed = false;
        this.boolPSMProcessed = false;
        this.boolSMError = false;
        this.boolPSMError = false;
        this.lstData = [];
        this.intMessageCount = 0;

        const objBody = this.getSecureMessageDetailsFn();
        if (!this.globalData.boolBlueCardOOS && !this.globalData.boolFEPOOS &&
            !this.globalData.boolIsLineOfBusinessFEP && !this.globalData.boolShowMinor) {
            let strSecReqBody = '';
            if (objBody.strRequestBody) {
                strSecReqBody = objBody.strRequestBody;
            }
            getSecureMessageDetails({
                strRequestBody: strSecReqBody,
                boolFromHDB: this.boolFromHDB,
                boolFromCDV: this.boolFromCDV
            }).then(result => {

                this.boolSMProcessed = true;
                let objTableDataSM;
                if (result && result && result.statusCode === '200') {
                    objTableDataSM = result.strResponseBody;
                    if (result.messageCount > 100) {
                        this.intMessageCount += result.messageCount;
                    }
                } else {
                    this.boolSMError = true;
                    this.boolAPIError = true;
                }
                if (objTableDataSM && Array.isArray(objTableDataSM) && objTableDataSM.length) {
                    this.lstData = [...objTableDataSM];
                }
                this.checkIfRequestFromHCD();

            }).catch(() => {
                this.boolSpinner = false;
                this.boolAPIError = true;
                this.boolSMError = true;
            });
        } else {
            this.boolSMProcessed = true;
        }
        let strReqBody = '';
        if (objBody.strRequestBodyForProvider) {
            strReqBody = objBody.strRequestBodyForProvider
        }
        getSecureMessageDetailsForProvider({
            strRequestBody: strReqBody,
            boolFromHDB: this.boolFromHDB,
            boolFromCDV: this.boolFromCDV
        }).then(result => {

            this.boolPSMProcessed = true;
            let objTableDataPSM;
            if (result && result.statusCode === '200') {
                objTableDataPSM = result.strResponseBody;
                if (result.messageCount > 100) {
                    this.intMessageCount += result.messageCount;
                }
            } else {
                this.boolAPIError = true;
                this.boolPSMError = true;
            }
            if (objTableDataPSM && Array.isArray(objTableDataPSM) && objTableDataPSM.length) {
                //CEAS-84986
                this.lstData = [...this.lstData,...objTableDataPSM];
            }
            this.checkIfRequestFromHCD();
        }).catch(() => {
            this.boolSpinner = false;
            this.boolAPIError = true;
            this.boolPSMError = true;
        });
    }

    parseHTMLFn = (str) => {
        let newStr = str;
        if (newStr) {
            const parser = new DOMParser();
            if (parser.parseFromString(str, "text/html").body.firstChild && parser.parseFromString(str, "text/html").body.firstChild != null) {
                newStr = parser.parseFromString(str, "text/html").body.firstChild.textContent;
            }
        }
        return newStr;
    }

    checkIfRequestFromHCD = () => {
        if (this.boolFromHDB) {
            if (this.boolSMProcessed && this.boolPSMProcessed) {
                this.processTableData();
            }
        } else {
            this.processTableData();
        }
    }

    processTableData = () => {
        this.boolAPIError = false;
        if (this.boolPSMError && this.boolSMError) {
            this.boolAPIError = true;
        } else {
            if (Array.isArray(this.lstData) && !this.lstData.length) {
                this.boolShowNoRecorsFound = true;
            }
        }

        const lstDataLocal = [];
        for (let i = 0; i < this.lstData.length; i++) {
            const obj = { ...this.lstData[i] };
            //for inbound/outbound column
            if (obj["IN/OUTBOUND"] === "OUT") {
                obj["InOutDetails"] = "Outbound";
            } else if (obj["IN/OUTBOUND"] === "IN") {
                obj["InOutDetails"] = "Inbound";
            } else {
                obj["InOutDetails"] = "";
            }

            let dtTimeOpened = '';
            if (obj["DATE/TIME OPENED"] && new Date(obj["DATE/TIME OPENED"]).toString() !== 'Invalid Date') {
                dtTimeOpened = BaseLWC.dtDateTimeISOtoLocal(obj["DATE/TIME OPENED"]);
            }
            obj['DateOpened'] = {
                value: obj["DATE/TIME OPENED"],
                wrapper: `<span>${dtTimeOpened}</span>`
            }

            obj.CreatedBy = '';
            if (obj['CREATED BY']) {
                obj.CreatedBy = obj['CREATED BY'];
            }
            obj.CaseTypeSubType = '';
            if (obj['CASE TYPE/SUBTYPE']) {
                obj.CaseTypeSubType = this.convertAPIToLabelForTypeAndSubtype(obj['CASE TYPE/SUBTYPE']);
            }
            obj.CaseStatus = '';
            if (obj['CASE STATUS']) {
                obj.CaseStatus = obj['CASE STATUS'];
            }
            obj['CaseNumber'] = {
                value: obj['CASE NUMBER'],
                strCaseId: obj['CASE ID'],
                wrapper: `<a>${obj['CASE NUMBER']}</a>`
            };

            obj.Inquirer = '';
            if (obj['INQUIRER']) {
                obj.Inquirer = obj['INQUIRER'];
            }

            let strSub = '';
            if (obj["MESSAGE BODY"] !== null && obj["MESSAGE BODY"] !== undefined && obj["MESSAGE BODY"] !== "undefined") {
                strSub = "<span>" + this.parseHTMLFn(obj["SUBJECT"]) + "</span>"
            }
            obj['Subject'] = {
                value: strSub,
                wrapper: strSub
            }


            obj['boolSecTable'] = true;
            let msgBody = '';
            if (obj["MESSAGE BODY"] !== null && obj["MESSAGE BODY"] !== undefined && obj["MESSAGE BODY"] !== "undefined") {
                msgBody = "<span>" + this.parseHTMLFn(obj["MESSAGE BODY"]) + "</span>";
            }

            if (obj["ATTACHMENTS"] === undefined || obj["ATTACHMENTS"] === null || (obj["ATTACHMENTS"] && obj["ATTACHMENTS"].length === 0)) {
                obj["Attachments"] = "";
            } else {
                obj["ATTACHMENTS"].sort(function (a, b) {
                    const x = a['fileName'].toLowerCase();
                    const y = b['fileName'].toLowerCase();
                    if (x < y) {
                        return -1
                    } else {
                        if (x > y) {
                            return 1
                        } else {
                            return 0
                        }
                    }
                });
                obj["Attachments"] = "<p class = 'attachmentsContainer'>";
                [...obj["ATTACHMENTS"]].forEach(el => {
                    obj["Attachments"] += `<span data-id="${el.fileName}">`;
                    obj["Attachments"] += `<a data-msgid="${obj["MESSAGE ID"]}" data-docid="${el.docId}">${el.fileName}</a>`;
                    obj["Attachments"] += `</span>`;
                })
                obj["Attachments"] += `</p>`;

            }

            const objAttachment = obj["Attachments"];
            obj["Attachments"] = {
                value: '',
                wrapper: objAttachment
            }
            let strDeletedTooltip = '';
            if (obj["DELETEFLAG"] === "Y") {
                strDeletedTooltip = '<div>This message has been deleted by the member</div>'
            }
            obj['DeletedSMTooltip'] = {
                value: '',
                wrapper: true,
                strCellValue: strDeletedTooltip,
                strTextTooltipContent: strDeletedTooltip
            }

            const msgBodyFn = `<p><strong>Message Details:</strong>${msgBody}<br/> ${objAttachment}</p>`
            obj['boolSecTable'] = true;
            obj['strSecTable'] = msgBodyFn;
            lstDataLocal.push(obj);
            if (i === (this.intLimitCount - 1)) {
                this.boolDisplayLimitMessage = true;
                break;
            }
        }

        if (this.intMessageCount > 100) {
            this.boolDisplayLimitMessage = true;
            this.strLimitMessage = `Displaying 100/${this.intMessageCount} secure messages.`;
        }
        this.boolSpinner = false;
        this.boolDisplayData = true;

        this.lstTableData = lstDataLocal;

    }

    getSecureMessageDetailsFn = () => {

        const strRequestBody = {
            "sourceSystem": this.label.SecureMessageSource_ACE,
            "corpEntityCode": this.globalData.strCorpCode,
            "subscriberNbr": this.globalData.strSubscriberId,
            "groupNbr": this.globalData.strGroupName,
            "clientMemberId": this.globalData.strCmid,
            "pageSize": 100,
            "deleted": true
        };

        //CEAS-60598        
        let strRequestBodyForProvider = {};
        const objAcc = this.globalData.objAccRecords;
        const strRecordType = objAcc.RecordType.value.fields.DeveloperName.value;
        if (strRecordType === 'BlueCard_Member_ACE' || strRecordType === 'Out_of_State_FEP_Member' || strRecordType === 'ProspectMember_ACE') {//CEAS-63718
            strRequestBodyForProvider = {
                "sourceSystem": "Salesforce",
                "patientFirstName": this.globalData.strPatientFirstName,
                "patientLastName": this.globalData.strPatientLastName,
                "patientDateOfBirth": this.globalData.strPatientDOB,
                "alphaPrefix": this.globalData.strPrefix,
                "groupNbr": this.globalData.strGroupName,
                "subscriberNbr": this.globalData.strSubscriberId,
                "pageNumber": "",
                "pageSize": ""
            };
        } else {
            const strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.strTabURL);
            if (!BaseLWC.isValidUrl(strDecodedURL)) {
                return
            }
            const objUrl = new URL(strDecodedURL);
            let strGroupNumber = '';
            if (objUrl.searchParams.has('groupNumber') === true && objUrl.searchParams.get('groupNumber') !== undefined && objUrl.searchParams.get('groupNumber') !== null && objUrl.searchParams.get('groupNumber') !== '') {
                strGroupNumber = objUrl.searchParams.get('groupNumber');
            }

            let objProviderData = null;
            const strProviderData = window.localStorage.getItem('lstProviderData_ACE');
            if (strProviderData && typeof strProviderData === 'string') {
                const strMid = this.globalData.strCmid;
                const lstProviderData = JSON.parse(strProviderData);
                lstProviderData.forEach(element => {
                    if (element.mid === strMid) {
                        objProviderData = element;
                    }
                });
            }
            let strNpid = '';
            if (objProviderData !== undefined && objProviderData !== null && objProviderData.strNpid !== undefined && objProviderData.strNpid !== '') {
                strNpid = objProviderData.strNpid;
            }
            strRequestBodyForProvider = {
                "sourceSystem": "Salesforce",
                "mid": this.globalData.strUrlMemberId,
                "memberId": this.globalData.strCmid,
                "groupNbr": this.globalData.strGroupName,
                "providerNPI": strNpid,
                "pageNumber": "",
                "pageSize": ""
            }
        }

        return {
            strRequestBody: JSON.stringify(strRequestBody),
            strRequestBodyForProvider: JSON.stringify(strRequestBodyForProvider)
        };


    }
    handleErrors = (error) => {
        this.handleError = error;
    }
    handleRowAction(event) {
        const rowData = JSON.parse(event.detail);
        if (rowData.activeColumnName === this.label.SecureMessageCaseNumber_ACE) {
            this.openCaseDetails(rowData.activeColumnData.value.strCaseId, rowData.activeColumnData.value.value)
        } else if (rowData.objSecTableEvent) {
            if (rowData.objSecTableEvent.eventType === 'click') {
                const strTarget = rowData.objSecTableEvent.eventTarget;
                const parser = new DOMParser();
                const objDOM = parser.parseFromString(strTarget, 'text/html').body.firstChild;
                if (objDOM) {
                    const strDocId = objDOM.getAttribute("data-docid");
                    const strMsgId = objDOM.getAttribute("data-msgid");
                    const strName = objDOM.textContent;
                    this.openAttachment(strDocId, strMsgId, strName);
                }
            }

        } else {
            //Do nothing
        }
    }

    openAttachment = (strDocId, strMsgId, strName) => {

        getAttachmentDetails({
            strMessageId: strMsgId,
            strDocId: strDocId
        })
            .then(response => {

                this.strFileName = strName;
                this.strFileType = null;
                if (response && response.strResponseCode && (response.strResponseCode === '200' || response.strResponseCode === '201')) {
                    this.strFileName = strName;
                    this.strFileType = response.strResponseBody.type;
                    this.getAttchmentsFromRecords(response.strResponseBody.data);
                } else if (response && response.strResponseCode && response.strResponseCode === '406') {
                    window.open(response.strResponseBody.data);
                } else {
                    const evt = new ShowToastEvent({
                        title: '',
                        message: 'No Data Found For the Document ',
                        variant: 'error'
                    });
                    this.dispatchEvent(evt);
                }
            }).catch((error) => {
                this.handleErrors(error);
            })
    }

    previewAndDownloadDocument = (strDocumentName, strDocumentType, strBase64Response) => {
        //File Types which can be Previewed
        const lstDocumentType = ['image/png', 'text/plain', 'application/pdf', 'image/jpeg', 'text/xml', 'image/bmp', 'image/x-bmp', 'image/gif', 'image/pjpeg'];
        // Check for document type
        let lstDocType = [];
        if(strDocumentType) {
            lstDocType = lstDocumentType.filter(el=>strDocumentType.includes(el))
            strDocumentType=lstDocType[0];
        }
        const strURI = 'data:'+lstDocType[0]+';base64,'+strBase64Response;
           
            const downloadContainer = this.template.querySelector('.download-container');
            const link = document.createElement('a');
            link.href = strURI;
            if (lstDocumentType.includes(strDocumentType)) {
                // Code to preview as well as download the document
                try{
                    const newWindow = window.open(link, '_blank');
                    newWindow.addEventListener("load", function () {
                        newWindow.document.title = strDocumentName;
                    });
                }catch(e){
                    this.handleErrors(e);
                }
                
                const downloadLink = document.createElement('a');
                downloadLink.href = strURI;
                downloadLink.download = strDocumentName;
                if (downloadContainer) {
                    downloadContainer.appendChild(downloadLink);
                }
                downloadLink.click();
                downloadContainer.removeChild(downloadLink);
            } else {
                //Code to only Download the document
                link.download = strDocumentName;
                if (downloadContainer) {
                    downloadContainer.appendChild(link);
                }
                link.click();
                downloadContainer.removeChild(link);
            }
    }
    openCaseDetails = (strCaseId, strCaseNumber) => {
        if (this.tabData) {
            const objParsedTabData = JSON.parse(JSON.stringify(this.tabData)); 
            if (objParsedTabData.url) {
                const strDecodedURL = BaseLWC.helperBaseDecodeUrl(objParsedTabData.url);
                if (!BaseLWC.isValidUrl(strDecodedURL)) {
                    return
                }
                const objUrl = new URL(strDecodedURL);

                const strProducerId = objUrl.searchParams.get("producerId");
                let strParams = '?mid=' + this.globalData.strUrlMemberId + '&caseNumber=' + strCaseNumber;
                if (this.globalData.boolProspectMember) {
                    strParams += '&boolProspectMember=true&boolProducer=false&boolURLFormed=true';
                } else {
                    if (this.globalData.objAccRecords.RecordType.value.fields.DeveloperName.value === 'Producer_ACE') {
                        strParams += '&boolProducer=true&producerId=' + strProducerId
                    } else {
                        strParams += '&boolProducer=false'
                    }
                }

                const strUrl = '/lightning/r/Case/' + strCaseId + '/view' + BaseLWC.helperBaseEncodeUrl(strParams);

                openSubtab(this.tabData.tabId, { url: strUrl, focus: true}) 
                    .then(() => {
                        //Do nothing
                    }).catch(() => {
                        //Do nothing
                    })
            }
    }
    }

    closeLimitMessage = () => {
        this.boolDisplayLimitMessage = false;
    }

    refreshData = () => {
        this.fetchData();
    }

    convertAPIToLabelForTypeAndSubtype(strTypeSubtype) {
        let strNewTypeSubtype = strTypeSubtype;

        const strGMC = 'Grievance / Complaint';
        if (strNewTypeSubtype.includes(strGMC)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strGMC, 'Grievance / Member Complaint');
        }
        const strMemberPortal = 'Member Portal (BAM)';
        if (strNewTypeSubtype.includes(strMemberPortal)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMemberPortal, 'Member Portal');
        }
        const strMGPCP = 'PCP Update';
        if (strNewTypeSubtype.includes(strMGPCP)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMGPCP, 'MG / PCP Update');
        }
        const strPreAuth = 'Prior Authorization';
        if (strNewTypeSubtype.includes(strPreAuth)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strPreAuth, 'Preauth');
        }
        const strProspectiveMember = 'Prospective Member';
        if (strNewTypeSubtype.includes(strProspectiveMember)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strProspectiveMember, 'Temporary Member');
        }
        return strNewTypeSubtype;
    }
}
