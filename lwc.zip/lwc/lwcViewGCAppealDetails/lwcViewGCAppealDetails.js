import BaseLWC from 'c/baseLWCFunctions_CF';
import { LightningElement, track, api, wire } from 'lwc';
//CEAS-82941 Changes
import { EnclosingTabId, getTabInfo, setTabIcon, setTabLabel } from 'lightning/platformWorkspaceApi';
import fetchGCAppealDetailsRecord from '@salesforce/apexContinuation/GCAppealDetailsController_ACE.fetchGCAppealDetailsRecord';
import fetchGCAppealDocumentRecords from '@salesforce/apexContinuation/GCAppealDetailsController_ACE.fetchGCAppealDocumentRecords';
import ArchivedRecordsAPIError_ACE from '@salesforce/label/c.ArchivedRecordsAPIError_ACE';
//CEAS-77949
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import { CurrentPageReference } from 'lightning/navigation';
//CEAS-84459 AutoDoc Appeals
import NotepadTransmissionChannel_ACE from '@salesforce/messageChannel/NotepadTransmissionChannel__c';
import {
    MessageContext,
    publish,
} from 'lightning/messageService';

export default class LwcViewGCAppealDetails extends LightningElement {
    //CEAS-84459 AutoDoc Appeals
    NotepadTransmissionChannel = NotepadTransmissionChannel_ACE;
    @wire(MessageContext)
    messageContext;
    //CEAS-82941 Changes
    @wire(EnclosingTabId) enclosingTabId;
    label = {
        ArchivedRecordsAPIError_ACE,
        EnableVPSTabSpecificEvents_ACE
    };
    @api tabId;
    @api lstTXMAppealDocRecords = [];
    @api strSubscriberId='';
    @api strAppealId='';
    selectedTabId = 'details';
    showInfoBanner = false;
    //CEAS-77949
    strPlanSummaryEvent = 'PlanSummaryEvent';
    strPatientName = '';
    boolPlanSummaryData;
    PlanSummaryData;
    boolVPSTabSpecificEvents;
    strCorpCode = '';
    strLob = '';
    parenttabId;
    @track objAppealDetails = {
        strAppealCreationDate:'',
	    strComplaintClass:'',
	    strResolutionCategory:'',
	    strComplianceDueDate:'',
	    strComplaintSubcategory:'',
	    strResolutionSubcategory:'',
	    strAppealStatus:'',
	    strWhoInitiatedComplaint:'',
	    strEffectuationDateTime:'',
	    strAppealCloseDate:'',
	    strStatusReason:'',
	    strAppealCoordinatorName:'',
	    strResolutionDetailNote:'',
        strAppealId:''
    };

    
     objAppealDetailsAddToCase = {
       Claim_Number_ACE__c: '',
       Date_ACE__c: '',
       Status_ACE__c: '',
       Completion_Date_ACE__c: '',
       Status_Reason_ACE__c: '',
       Sub_Category_ACE__c: '',
       Patient_Name_ACE__c: ''
    }; 

    @track lstBoolExpandedSections = {
        'boolExpandAppealInfo':true,
        'boolExpandAppealNotes':true,
        'boolExpandDocuments':true,
    };

    @track objSectionExpansionIcons = {
        'strAppealInfoExpansion':'utility:chevrondown',
        'strExpandAppealNotesExpansion':'utility:chevrondown',
        'strExpandDocumentsExpansion':'utility:chevrondown',
    };

    @track boolNoRecs = false;
    @track boolDocAPIError = false;
    @track boolAppealAPIError = false;
    @track boolShowSpinner = false;
    objTMGReqParams=null;
    boolShowResultsTable = true;
    boolShowData = true;
    @api boolShowAppealsModal = false;
    boolTXMAppealsAddToCase = false;
    strPrevAppealId=null;
    strSubId=null;
    strboolFromCaseDetails=false;
    //CEAS-84459 AutoDoc Appeals
    strInteractionLogId;
    strAccountId;
    strNotePadNotes;
    boolAutoDocDisable = true;
    strFrameURL='/apex/ReadLocalStorageVFPage_ACE';

    @track planSummaryListened = false;
    
    objTXMAppealDocInitSetting = {
        pageSize: 20,
        boolShowSearch: false,
        columnsData: [
            { label: 'Document ID', fieldName: 'strIdentifier', sortable: false, type: '' },
            { label: 'Document Name', fieldName: 'strDocumentName', sortable: false, type: ''}
        ]
    }
    
    @wire(CurrentPageReference)
    getPageReferenceParameters(currentPageReference) {
        const strURL = currentPageReference.state.c__BaseURLParam;
        this.strboolFromCaseDetails = BaseLWC.helperBaseGetUrlParameters('boolFromCaseDetails',strURL);
        this.strAppealId = BaseLWC.helperBaseGetUrlParameters('appealId',strURL); 
        if (currentPageReference && (this.strPrevAppealId != null) && (this.strAppealId != this.strPrevAppealId) && this.strboolFromCaseDetails) {
           this.strPrevAppealId = this.strAppealId;
           this.strSubscriberId = this.strSubId;
           this.executeSubTabCheck();
           this.fetchAppealData();
            if (this.boolAppealAPIError == false) {
                this.fetchDocData();
            }
        }
     } 

    connectedCallback() {
        try {
            this.fetchTabData();
        } catch (error) {
            this.handleErrors(error);
        }
    }

    get relatedCasesClass() {
        if (this.selectedTabId === 'relatedCases') {
            return 'slds-show';
        }
        return 'slds-hide';
    }

    handleShowInfoBanner(event) {
        const showBanner = event.detail.showBanner;
        this.showInfoBanner = showBanner;
    }

    handleActive(event) {
        this.selectedTabId = event.target.value;
        if (this.selectedTabId === 'relatedCases') {
            this.showInfoBanner = false;
        }
        
    }
    showRelatedCases(event) {
        this.selectedTabId = 'relatedCases';
        this.showInfoBanner = false;
    }

    fetchTabData() {
       //CEAS-82941 Changes 
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((tabInfo) => {
                this.objTabData = tabInfo;
                this.parenttabId = this.objTabData.parentTabId;
                const strURL = this.objTabData.url;
                let strAppIdURL = new URL(strURL).searchParams.getAll('c__BaseURLParam');
                if(strAppIdURL.length > 0) {
                    this.strAppealId = BaseLWC.helperBaseGetUrlParameters('appealId', strAppIdURL[0].split('=')[0]);
                } 
                if (this.strAppealId == undefined || this.strAppealId == null || this.strAppealId == '') {
                    this.strAppealId = BaseLWC.helperBaseGetUrlParameters('appealId',strURL); 
                }
                //CEAS-84459 AutoDoc Appeals
                if (!this.strAccountId) {
                    this.strAccountId = BaseLWC.helperBaseGetUrlParameters('accountId',strURL); 
                }
                this.strPrevAppealId = this.strAppealId;
                this.strSubscriberId = BaseLWC.helperBaseGetUrlParameters('subscriberId', strURL);
                this.strSubId = this.strSubscriberId;
                //CEAS-77949
                if (BaseLWC.stringIsNotBlank(this.label.EnableVPSTabSpecificEvents_ACE) && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                    this.boolVPSTabSpecificEvents = true;
                }
                //CEAS-84459 AutoDoc Appeals
                this.addMessageListner();
                this.planSummaryListener();
                this.executeSubTabCheck();
                this.fetchAppealData();
                //CEAS-84459 AutoDoc Appeals
                this.callIframeOnLoad();
                this.setInteractionLogDetails();
                if (this.boolAppealAPIError == false) {
                    this.fetchDocData();
                }
            }).catch((error) => {
                this.handleErrors();
            });
        }
    }

     //CEAS-77949 start
     planSummaryListener() {
        if(this.boolVPSTabSpecificEvents)  {
            window.addEventListener('PlanSummaryEvent_' + this.parenttabId, this.capturePlanSummaryListener, false);
        } else {
            window.addEventListener('PlanSummaryEvent', this.capturePlanSummaryListener);
        }
    
       if (!this.planSummaryListened) {
            if (this.label.EnableVPSTabSpecificEvents_ACE && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === "true") {
                BaseLWC.helperBasePostTabIdMessageCustomEvents('TriggerPlanSummaryData_' + this.parenttabId, null, null, 'PlanCardDetails_ACE', this.parenttabId).catch(() => {});
            } else {
                BaseLWC.helperBasePostTabIdMessageCustomEvents('TriggerPlanSummaryData', null, null, 'PlanCardDetails_ACE', this.parenttabId).catch(() => {});
            }
        }
    }

    capturePlanSummaryListener = (planSummaryDataEvent) => {
        try{
            if (BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail) ) {
            
                this.planSummaryListened = true;
                this.PlanSummaryData = JSON.parse(planSummaryDataEvent.detail);
                if (typeof this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strfirstName !== "undefined" && this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strfirstName !== null) {
                    this.strPatientName = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strfirstName;
                }
                if (typeof this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strlastname !== "undefined" && this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strlastname !== null) {
                    this.strPatientName = this.strPatientName + ' ' + this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strlastname;
                }  
                this.objAppealDetailsAddToCase.Patient_Name_ACE__c= this.strPatientName;
                if (typeof this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strCorporationCode !== "undefined" && this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strCorporationCode !== null) {
                    this.strCorpCode = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strCorporationCode;
                }
                if (typeof this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strAceLineOfBusiness !== "undefined" && this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strAceLineOfBusiness !== null) {
                    this.strLob = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strAceLineOfBusiness.toUpperCase();
                }
                if (this.boolVPSTabSpecificEvents) {
                    window.removeEventListener("PlanSummaryEvent_" + this.parenttabId,this.capturePlanSummaryListener, false);
                } else {
                    window.removeEventListener("PlanSummaryEvent",this.capturePlanSummaryListener);
                }
            }
        } catch (e) {
            this.handleErrors(e);
        }
    };
     //CEAS-77949 end

    executeSubTabCheck() {
        if (this.objTabData.isSubtab === true) {
            const subTabId = this.objTabData.tabId;
            const strFlexiPageName = 'ViewGCAppealDetails_FlexiPage_ACE';
            const strIconName = 'standard:work_plan';
           //CEAS-82941 changes
           setTabIcon(subTabId,strIconName,strFlexiPageName);
           setTabLabel(subTabId, this.strAppealId);
        }
    }

    handleErrors(error) {
        this.boolError = error;
    }

    fetchAppealData() {
        if (!this.strSubscriberId) {
            return;
        }
        const strSubscriberId = this.strSubscriberId;
        const strAppealId = this.strAppealId;
        
        this.boolShowSpinner = true;
        
        let    jasonreqbody = '{"subscriberId": "'+strSubscriberId.substring(3) + '", "appealId": "'+strAppealId + '"}';
        fetchGCAppealDetailsRecord({
            strDataJSON: jasonreqbody
        }).then(objResult => {
                if(objResult !== undefined && objResult !== null && objResult !== '') {
                    this.boolShowSpinner = false;
                    this.boolAppealAPIError = false;
                    const objResponse=JSON.parse(objResult);
                    
                    this.objAppealDetails.strAppealCreationDate=this.validateDateDate(objResponse.strAppealCreationDate);
                    this.objAppealDetails.strComplaintClass=this.validateData(objResponse.strComplaintClass);
                    this.objAppealDetails.strResolutionCategory=this.validateData(objResponse.strResolutionCategory);
                    this.objAppealDetails.strComplianceDueDate=this.validateDateDate(objResponse.strComplianceDueDate);
                    this.objAppealDetails.strComplaintSubcategory=this.validateData(objResponse.strComplaintSubcategory);
                    this.objAppealDetails.strResolutionSubcategory=this.validateData(objResponse.strResolutionSubcategory);
                    this.objAppealDetails.strAppealStatus=this.validateData(objResponse.strAppealStatus);
                    this.objAppealDetails.strWhoInitiatedComplaint=this.validateData(objResponse.strWhoInitiatedComplaint);
                    this.objAppealDetails.strEffectuationDateTime=this.validateDateDate(objResponse.strEffectuationDateTime);
                    this.objAppealDetails.strAppealCloseDate=this.validateDateDate(objResponse.strAppealCloseDate);
                    this.objAppealDetails.strStatusReason=this.validateData(objResponse.strStatusReason);
                    this.objAppealDetails.strAppealCoordinatorName=this.validateData(objResponse.strAppealCoordinatorName);
                    this.objAppealDetails.strResolutionDetailNote=this.validateData(objResponse.strResolutionDetailNote);
                    this.objAppealDetails.strAppealId=this.strAppealId; 

                    this.objAppealDetailsAddToCase.Claim_Number_ACE__c=this.strAppealId; 
                    this.objAppealDetailsAddToCase.Date_ACE__c=objResponse.strAppealCreationDate ? this.validateDateDate(objResponse.strAppealCreationDate) : null;
                    this.objAppealDetailsAddToCase.Status_ACE__c=this.validateData(objResponse.strAppealStatus);
                    this.objAppealDetailsAddToCase.Completion_Date_ACE__c=objResponse.strAppealCloseDate ? this.validateDateDate(objResponse.strAppealCloseDate) : null;
                    this.objAppealDetailsAddToCase.Status_Reason_ACE__c=this.validateData(objResponse.strStatusReason);
                    this.objAppealDetailsAddToCase.Sub_Category_ACE__c=this.validateData(objResponse.strComplaintSubcategory);
                    this.objAppealDetailsAddToCase.ComplaintClass_ACE__c=this.validateData(objResponse.strComplaintClass);
                    this.objAppealDetailsAddToCase.Patient_Name_ACE__c= this.strPatientName;
                    this.objAppealDetailsAddToCase.CorpCode_ACE__c=this.strCorpCode;
                } else {
                    this.boolShowSpinner = false;
                    this.boolAppealAPIError = true;       
                }
                            }).catch(error => {
                this.boolShowSpinner = false;
                this.boolAppealAPIError = true;
            });
 
    }

    validateData(objData) {
        var finalData = ((objData !== null) && (objData !== undefined && (objData !== ''))) ? objData : '-';
        return finalData;
    }

    validateDateDate(objDateData) {
        var finalDateData = ((objDateData !== null) && (objDateData !== undefined && (objDateData !== ''))) ? this.convertDateFormat(objDateData) : '-';
        return finalDateData;
    }

    fetchDocData() {
        if (!this.strSubscriberId) {
            return;
        }
        const strSubscriberId = this.strSubscriberId;
        const strAppealId = this.strAppealId;
        this.boolShowResultsTable = false;
        this.boolShowSpinner = true;
        
        let    jasonreqbody = '{"subscriberId": "'+strSubscriberId.substring(3) + '", "appealId": "'+strAppealId + '"}';
        
        fetchGCAppealDocumentRecords({
            strDataJSON: jasonreqbody
        }).then(objResult => {
            if(objResult !== undefined && objResult !== null && objResult !== '') {
                this.boolShowResultsTable = true;
                this.boolShowSpinner = false;
                this.boolDocAPIError = false;
                this.boolNoRecs = true; 
                var lstDocRec = [];
                const docData = JSON.parse(objResult);
               
                if (BaseLWC.isNotUndefinedOrNull(docData) &&
                    BaseLWC.isNotUndefinedOrNull(docData.lstDocDetails) &&
                    docData.lstDocDetails.length > 0) {
                    this.boolNoRecs = false;
                    const lstData=docData.lstDocDetails;
                    for(let i=0;i<lstData.length;i++) {
                        const obj={...lstData[i]};
                        lstDocRec.push(obj);
                    }
                    this.lstTXMAppealDocRecords = lstDocRec;
                
                    if (!this.lstTXMAppealDocRecords.length)
                    {
                        this.boolNoRecs = true;
                    } 
                }
            } else {
                this.boolShowSpinner = false;
                this.boolShowResultsTable = true;
                this.boolDocAPIError = true;       
            }
        }).catch(error => {
            this.boolShowSpinner = false;
            this.boolShowResultsTable = true;
            this.boolDocAPIError = true;
        }); 
            }

    convertDateFormat(dateObj) {
        const dateTimeArray = dateObj.split("T");
        var strDate = dateTimeArray[0].toString();
        var strDateSplit =strDate.split("-");
        var finalDate = strDateSplit[1]+"/"+strDateSplit[2]+"/"+strDateSplit[0];
        return finalDate;
    }

    refreshRecords() {
        this.boolShowSpinner = true;
        try {
            this.fetchAppealData();
            if (this.boolNoRecs == false && this.boolAppealAPIError == false) {
                this.fetchDocData();
            }
            if (this.template.querySelector('c-claim-related-cases-table_-a-c-e')) {
                this.template.querySelector('c-claim-related-cases-table_-a-c-e').refreshData();
            }

            if (this.template.querySelector('c-medical-record-status-viewer-button-l-w-c-a-c-e')) {
                this.template.querySelector('c-medical-record-status-viewer-button-l-w-c-a-c-e').fetchCaseData();
            }
        } catch (error) {
            this.handleErrors(error);
        }
    }

    toggleCollapse(event) {
        if(this.objSectionExpansionIcons[event.currentTarget.dataset.id] == 'utility:chevrondown') {
            this.objSectionExpansionIcons[event.currentTarget.dataset.id] = 'utility:chevronup';
        } else {
            this.objSectionExpansionIcons[event.currentTarget.dataset.id] = 'utility:chevrondown';
        }
    }
    openAddToCase() {
            this.boolShowAppealsModal = true;
            this.boolTXMAppealsAddToCase = true;
    }

    handleExpand(event) {
        this.lstBoolExpandedSections[event.currentTarget.dataset.id] = !this.lstBoolExpandedSections[event.currentTarget.dataset.id];
    }
    //CEAS-84459 AutoDoc Appeals
    handleAutoDoc(objEvent) {
        //Get Section from which autodoc was triggered
        const strAutoDocSrc = objEvent.currentTarget.dataset.id;
        this.setAutoDocDetails(strAutoDocSrc);
    }
    setAutoDocDetails(strAutoDocSrc) {
        let strNotes = '';
        let sectionId = 'id'+strAutoDocSrc.replace(/ /g,"_").toUpperCase() +'-' + this.strAppealId;
        //CEAS-83660 | Removing Logic for disabling autodoc & Interaction Check

        let TotalPattern = [];
        let pattern = {
            strInteractionLogId: this.strInteractionLogId
        };
        let lstValuesData = [];
        let lstTitles = [];
        let lstTitleValues = [];
        let objCardDetails;
        let strSection = '';
        let lstAppealsData = [];
        let strAppeal;
        if(strAutoDocSrc === 'appealInformationAutoDoc') {
            objCardDetails = this.objAppealDetails;
            strSection = 'APPEAL INFORMATION';
            lstTitles = ['APPEAL CREATION DATE','COMPLAINT CLASS','RESOLUTION CATEGORY','COMPLIANCE DUE DATE',
                                        'COMPLAINT SUBCATEGORY','RESOLUTION SUBCATEGORY','APPEAL STATUS','WHO INITIATED COMPLAINT',
                                        'EFFECTUATION DATE','APPEAL CLOSE DATE','STATUS REASON','APPEAL COORDINATOR NAME','APPEAL ID'];
            lstTitleValues = [this.objAppealDetails.strAppealCreationDate, this.objAppealDetails.strComplaintClass, this.objAppealDetails.strResolutionCategory,
                                this.objAppealDetails.strComplianceDueDate, this.objAppealDetails.strComplaintSubcategory, this.objAppealDetails.strResolutionSubcategory,
                                this.objAppealDetails.strAppealStatus, this.objAppealDetails.strWhoInitiatedComplaint, this.objAppealDetails.strEffectuationDateTime,
                                this.objAppealDetails.strAppealCloseDate, this.objAppealDetails.strStatusReason , this.objAppealDetails.strAppealCoordinatorName,
                                this.objAppealDetails.strAppealId];
        } else if(strAutoDocSrc === 'appealNotes') {
            objCardDetails === this.objAppealDetails.strResolutionDetailNote;
            strSection = 'APPEAL NOTES';
            lstTitles = ['RESOLUTION DETAIL NOTE'];
            lstTitleValues = [this.objAppealDetails.strResolutionDetailNote];
        }
        strAppeal = ' Appeal ID - ' + ' ' + this.strAppealId;
        lstAppealsData = ["APPEALS", strAppeal, strSection];

        const lstAppealSectionsData = [];

        for (let i = 0; i < lstAppealsData.length; i++) {
            const subPatternForLstSections = {
                "strLabel": lstAppealsData[i].toUpperCase()
            };
            strNotes += lstAppealsData[i].toUpperCase().trim() + '\n\n';
            if (i === 0) {
                subPatternForLstSections.strIcon = 'add_contact';
                subPatternForLstSections.strIconFamily = 'action';
                subPatternForLstSections.strIconColor = '#5876a3';
            } else {
                subPatternForLstSections.strIcon = '';
                subPatternForLstSections.strIconFamily = '';
                subPatternForLstSections.strIconColor = '';
            }
            lstAppealSectionsData.push(subPatternForLstSections);
        }
        pattern.lstSections = lstAppealSectionsData;
        for (let i = 0; i < lstTitles.length; i++) {
            const objFieldData = {};
            objFieldData.strFieldLabel = lstTitles[i].toUpperCase();
                if(!lstTitleValues[i]) {
                    objFieldData.strFieldValue = ''; 
                } else {
                    objFieldData.strFieldValue = lstTitleValues[i];
                }
            strNotes += objFieldData.strFieldLabel + '\t\t' + objFieldData.strFieldValue + '\n';
            lstValuesData.push(objFieldData);
        }
        pattern.lstValues = lstValuesData;
        TotalPattern.push(pattern);

        const strAutoDocStorageKey = sectionId + '-' + this.strInteractionLogId + '-' + this.strMemeberId + '-' + this.strAppealNumber;
        this.strNotePadNotes = strNotes;
        this.publishToNotepad();
        this.sendAutoDocData( TotalPattern, strAutoDocStorageKey);
    }
    //CEAS-83660
    publishToNotepad() {
        const message = {
            method: 'POST',
            reqSource: "lwcNotepadAce",
            boolIsFromAutdoc : true,
            notes : this.strNotePadNotes
        };
        publish(this.messageContext, this.NotepadTransmissionChannel, message);
    }
    sendAutoDocData( TotalPattern, strAutoDocStorageKey) {
        if (this.strInteractionLogId && !this.boolAutoDocDisable) {
        const objIframe = document.createElement("iframe");
        objIframe.src = "/apex/ClaimsSetlocalstoragePage_ACE";
        objIframe.style.display = "none";
        document.body.appendChild(objIframe);
        objIframe.onload = function() {
            objIframe.contentWindow.postMessage({
                key: 'strAutodoc',
                value: JSON.stringify(TotalPattern),
                boolIsClaimsAutoDoc: true
            }, '*');
            
                    objIframe.contentWindow.postMessage({
                        key: 'strAutoDocIconInfo_ACE',
                        value: strAutoDocStorageKey,
                        boolIsClaimsAutoDoc: false
                    }, '*');
                objIframe.contentWindow.postMessage({
                    key: 'strKeepAutodocActive',
                    value: 'true',
                    boolIsClaimsAutoDoc: true
                }, '*');
            }
        }
    }
    getCurrentOpenCases = () => {
        checkIfAnyCasesAreOpen({
            mid: this.strMemeberId,
            type: 'Claims',
            subType: 'Claim Status_Claim Adjustment',
            strGroupNumber: this.groupNumber,
            strCmId: this.strCMID,
            strInteractionLogId: this.strInteractionLogId
        })
        .then(result => {
            try {
                if (!result) {
                    if (this,this.strinteractionlogid !== '') {
                        this.dispatchEvent(new CustomEvent('openmanualcase', {
                            detail: {
                                message: 'openmanualcase'
                            }
                        }));
                    }
                }
            } catch (exception) {
            }
        }
    ).catch(function() {
    });
    }
    setInteractionLogDetails () {
        //Getting Interaction Id.
        const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + this.strAccountId;
        const strInteractionLogId = BaseLWC.helperBaseGetItem(localStorageKey);
        this.strInteractionLogId = strInteractionLogId;
    }
    //CEAS-84459 AutoDoc Appeals
    addMessageListner() {
        
        window.addEventListener('message', this.objAppealMessageListner);
    }

    objAppealMessageListner = (objEventData) => {
        try {
        const strAccountId = this.strAccountId;
        const strAppealId = this.strAppealId;
                if (objEventData && objEventData.data) {
                    let objControllerResult = null;
                        try {
                            objControllerResult = JSON.parse(objEventData.data);
                        } catch (e) {
                            //Do Nothing
                        }
                        if (objControllerResult && objControllerResult.action && objControllerResult.action === 'ReadLocalStorage_ACE'){
                            if(objControllerResult.id &&
                                objControllerResult.id.includes(strAppealId) && objControllerResult.accountId &&
                                objControllerResult.accountId.includes(strAccountId)) {
                            if(objControllerResult.objParameters && objControllerResult.objParameters.boolIsCTIStarted) {
                                this.boolAutoDocDisable = false;
                                this.setInteractionLogDetails();
                            } else if(objControllerResult.objParameters && objControllerResult.objParameters.boolIsCTIStarted === false) {
                                this.boolAutoDocDisable = true;
                            }
                        } } else {
                            return;
                        }
                } else {
                    return;
                }
            } catch (objException) {
                //Do Nothing
            }
    }
    callIframeOnLoad() {
        const strAppealId = this.strAppealId;
        const AccountId = this.strAccountId;
        const objIframe = document.createElement("iframe");
        objIframe.src = "/apex/ReadLocalStorageVFPage_ACE";
        objIframe.style.display = "none";
        document.body.appendChild(objIframe);
        objIframe.onload = function() {
            objIframe.contentWindow.postMessage(JSON.stringify({
                "Id": strAppealId,
                "AccountId": AccountId
            }), '*');
        }
    }
}