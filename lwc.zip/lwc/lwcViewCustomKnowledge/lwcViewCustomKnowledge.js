import { LightningElement, track, api, wire } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
//import platformWorkspaceApi
import { EnclosingTabId, getTabInfo, openSubtab} from 'lightning/platformWorkspaceApi';
import fetchKnowledgeArticle from '@salesforce/apex/SearchProviderLightningController_ACE.fetchKnowledgeArticle';

export default class LwcViewCustomKnowledge extends LightningElement {

    //wire
    @wire(EnclosingTabId) enclosingTabId;

    @api boolModal = false;
    @api boolReadCN = false;
    @api boolLink = false;
    @api boolDisableLink = false;
    @api labelName = "Search for Provider";
    @api boolPatientCardFullyLoaded = false;
    @api boolSmartUMLinkmodal = false;
    @api boolmedicalselect = false;
    @api boolbehavioralHealthSelect = false;
    @api strErrorMessageForModal;
    @api smartPreAuthValueChange;
    @api strCorpCode;
    objTabData = {};
    objCardError = {};
    strParentTabId = null;
    showSpinner = false;

    @track strErrorNameSearchforProvider = " unavailable. Please log in to BAM to access Search for Provider.";

    connectedCallback() {
        try {
            this.fetchTabData();
        } catch (error) {
            this.handleErrors(error);
        }
    }

    fetchTabData() {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
            this.objTabData = objTabData;
            if (this.objTabData.isSubtab) {
                this.strParentTabId = this.objTabData.parentTabId;
            } else {
                this.strParentTabId = this.objTabData.tabId;
            }
        }).catch((error) => {
            this.handleErrors(error);
        });
    }
}

    handleErrors(error) {
        this.objCardError = error;
    }

    // Method to external system
    gotoLink() {
        if(this.boolLink) {
            this.boolLink = false;
        } else {
            this.boolLink = true;
        }
        this.navigateToKnowledgeArticle();
    }

    // Method to view Custom Network
    gotoCN() {
        if(this.boolReadCN) {
            this.boolReadCN = false;
        } else {
            this.boolReadCN = true;
        }
        const objValueChangeEvent = new CustomEvent('sflboolreadcn', {
            detail: { boolReadCN: this.boolReadCN }
        });
        this.dispatchEvent(objValueChangeEvent);
        this.boolModal = false;
    }

    // Method to close modal
    closeModal() {
        this.boolModal = false;
        this.closeModalEvent();
    }

    goMedical(event) {
        event.target.disabled = true;
        this.showSpinner = true;
        this.smartPreAuthValueChange.onMedUpdate();
    }

    goBehavioralHealth(event) {
        event.target.disabled = true;
        this.showSpinner = true;
        this.smartPreAuthValueChange.onBehaviorUpdate();
    }

    @api
    hideSpinner() {
        this.showSpinner = false;
    }

    closeUMModal() {
        this.boolSmartUMLinkmodal = false;
        this.closeModalEvent();
    }

    closeModalEvent() {
        const closemodalEvt = new CustomEvent('evtclosemodal', {
            detail: {}
        });

        this.dispatchEvent(closemodalEvt);
    }

    navigateToKnowledgeArticle() {
        fetchKnowledgeArticle({
            strCode: this.strCorpCode
        }).then((objResult)=>{
            const strArticleId = objResult;
            if (!BaseLWC.isUndefinedOrNullOrBlank(strArticleId) && !BaseLWC.isUndefinedOrNullOrBlank(this.strParentTabId)) {
                openSubtab(this.strParentTabId, { recordId: strArticleId, focus: true });
            }
            if (this.boolModal) {
                this.closeModal();
            } else if (this.boolSmartUMLinkmodal) {
                this.closeUMModal();
            } else {
                //do nothing
            }
        }).catch((error) => {
            this.handleErrors(error);
        })
    }
}