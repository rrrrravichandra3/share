import { LightningElement,api } from 'lwc';

export default class LwcChildOrderIdCardPendedSuccess extends LightningElement {

    @api label;
    @api caseSubtype;
    @api caseType;
    @api caseNumbers;
    @api caseNumbersPended;

    openCaseHelper(objEvent) {
        objEvent.preventDefault();
        const openSubTab = new CustomEvent('opencasechild', {
            detail: objEvent
        });
        this.dispatchEvent(openSubTab);
    }
}