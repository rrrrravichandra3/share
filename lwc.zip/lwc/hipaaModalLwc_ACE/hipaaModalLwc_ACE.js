import { LightningElement,api,track,wire } from 'lwc';
import LightningModal from 'lightning/modal';
import BaseLWC from "c/baseLWCFunctions_CF";

import UpdateHIPAARestrictions_ModalHeaderName_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_ModalHeaderName_ACE';
import ViewPlanSummary_Select_ACE from '@salesforce/label/c.ViewPlanSummary_Select_ACE';
import fetchPickListValues from '@salesforce/apex/HIPAA_CCRF_RRF_DetailController_ACE.fetchPickListValues';
import createInteractionAndCaseForAutoDocHelper from '@salesforce/apex/HIPAA_CCRF_RRF_DetailController_ACE.createInteractionAndCaseForAutoDocHelper';
import submitToFacetsHIPAARestriction from '@salesforce/apexContinuation/HIPAA_CCRF_RRF_DetailController_ACE.submitToFacetsHIPAARestriction';
import upsertHIPAARestrictionsData from '@salesforce/apex/HIPAA_CCRF_RRF_DetailController_ACE.upsertHIPAARestrictionsData';
import UpdateHIPPARestrictions_PersonRestricted_ACE from "@salesforce/label/c.UpdateHIPPARestrictions_PersonRestricted_ACE";
import MemberSearch_ResetButton_ACE from "@salesforce/label/c.MemberSearch_ResetButton_ACE";
import UpdateHIPAARestrictions_RRFHeaderName_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_RRFHeaderName_ACE";
import UpdateHIPAARestrictions_CCRFHeaderName_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_CCRFHeaderName_ACE";
import ViewAuthorization_MemberNameLabel_ACE from "@salesforce/label/c.ViewAuthorization_MemberNameLabel_ACE";
import ViewAuthorizedParty_EffectiveDate_ACE from "@salesforce/label/c.ViewAuthorizedParty_EffectiveDate_ACE";
import UpdateHIPPARestrictions_IMGReferenceNumber_ACE from "@salesforce/label/c.UpdateHIPPARestrictions_IMGReferenceNumber_ACE";
import UpdateHIPAARestrictions_SubscriberLevel_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_SubscriberLevel_ACE";
import UpdateHIPAARestrictions_Memberlevel_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_Memberlevel_ACE";
import UpdateHIPPARestrictions_SaveUnsuccessfull_ACE from "@salesforce/label/c.UpdateHIPPARestrictions_SaveUnsuccessfull_ACE";
import IDCardCity_ACE from "@salesforce/label/c.IDCardCity_ACE";
import UpdateHIPPARestrictions_Address2_ACE from "@salesforce/label/c.UpdateHIPPARestrictions_Address2_ACE";
import UpdateHIPPARestrictions_ZipCode_ACE from "@salesforce/label/c.UpdateHIPPARestrictions_ZipCode_ACE";
import IDCardState_ACE from "@salesforce/label/c.IDCardState_ACE";
import PHONENUMBER_ACE from "@salesforce/label/c.PHONENUMBER_ACE";
import ViewCaseSummary_Notes_ACE from "@salesforce/label/c.ViewCaseSummary_Notes_ACE";
import UpdateHIPAARestrictions_IsMinor_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_IsMinor_ACE";
import UpdateHIPAARestrictions_Email_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_Email_ACE";
import UpdateHIPAARestrictions_RevokedBAMAccess_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_RevokedBAMAccess_ACE";
import UpdateHIPPARestrictions_Address1_ACE from "@salesforce/label/c.UpdateHIPPARestrictions_Address1_ACE";
import UpdateHIPAARestrictions_ErrorMessage_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_ErrorMessage_ACE";
import HIPAAAuthParty_OldValue_ACE from "@salesforce/label/c.HIPAAAuthParty_OldValue_ACE";
import HIPAAAuthParty_NewValue_ACE from "@salesforce/label/c.HIPAAAuthParty_NewValue_ACE";
import HIPAAAuthParty_AutoDocHeader_ACE from "@salesforce/label/c.HIPAAAuthParty_AutoDocHeader_ACE";
import ViewStandardAuthorization_Header_ACE from "@salesforce/label/c.ViewStandardAuthorization_Header_ACE";
import HIPAAAuthParty_Active_ACE from "@salesforce/label/c.HIPAAAuthParty_Active_ACE";
import HIPAAAuthParty_Deactivated_ACE from "@salesforce/label/c.HIPAAAuthParty_Deactivated_ACE";
import ViewAuthorization_SaveButtonNMCCLabel_ACE from "@salesforce/label/c.ViewAuthorization_SaveButtonNMCCLabel_ACE";
import EO_SaveLabel_ACE from "@salesforce/label/c.EO_SaveLabel_ACE";
import HIPAAAuthParty_AuthorizedPartyHeader_ACE from "@salesforce/label/c.HIPAAAuthParty_AuthorizedPartyHeader_ACE";


export default class HipaaModalLwc_ACE extends LightningElement {
    label = {
        UpdateHIPPARestrictions_Address1_ACE,
        ViewAuthorization_SaveButtonNMCCLabel_ACE,
        EO_SaveLabel_ACE,
        IDCardCity_ACE,
        UpdateHIPPARestrictions_ZipCode_ACE,
        PHONENUMBER_ACE,
        IDCardState_ACE,
        ViewCaseSummary_Notes_ACE,
        ViewAuthorizedParty_EffectiveDate_ACE,
        UpdateHIPAARestrictions_IsMinor_ACE,
        UpdateHIPAARestrictions_Email_ACE,
        UpdateHIPAARestrictions_RevokedBAMAccess_ACE,
        UpdateHIPPARestrictions_Address2_ACE,
        UpdateHIPPARestrictions_PersonRestricted_ACE,
        UpdateHIPPARestrictions_IMGReferenceNumber_ACE,
        UpdateHIPAARestrictions_ModalHeaderName_ACE,
        UpdateHIPAARestrictions_RRFHeaderName_ACE,
        UpdateHIPAARestrictions_CCRFHeaderName_ACE,
        MemberSearch_ResetButton_ACE,
        ViewAuthorization_MemberNameLabel_ACE,
        ViewAuthorizedParty_EffectiveDate_ACE,
        UpdateHIPAARestrictions_SubscriberLevel_ACE,
        UpdateHIPAARestrictions_Memberlevel_ACE,
        UpdateHIPPARestrictions_SaveUnsuccessfull_ACE,
        UpdateHIPAARestrictions_ErrorMessage_ACE,
        HIPAAAuthParty_OldValue_ACE,
        HIPAAAuthParty_NewValue_ACE,
        HIPAAAuthParty_AutoDocHeader_ACE,
        ViewStandardAuthorization_Header_ACE,
        HIPAAAuthParty_Active_ACE,
        HIPAAAuthParty_Deactivated_ACE,
        HIPAAAuthParty_AuthorizedPartyHeader_ACE
    }
    @api content;
    @api boolIsOpen;
    @api objHIPPARestriction;
    @api objHIPPARestrictionCopy;
    @api idMemberPlan;
    @api boolIsEdit;
    @api boolDMLStatus;
    @api strMemberName;
    @api strPlanDetails;
    @api strAccountId;
    @api strClientMemberId;
    @api strInteractionLogId;
    @api facetsCalloutRestrictionSuccess;
    @api boolIsNMCC;
    @api boolIsEditCCRF;
    @api boolIsEditRRF;
    @api mapStates;
    @api strCreatedRecordId;
    @api facetsHIPAAResReq;
    @api strRecordId;
    @api strCreatedInteractionHolder;
    @api strAuthorizedPartyCopy;
    @api objAuthorizedPartyCopy;

    @track boolErrorOnSave;
    @track strErrorMessage;
    @track boolDisableRestrictionType;
    @track errorMessage = "Please enter a valid date in MM/DD/YYYY format";
    @track strFacetsGroupId;
    @track strSubscriberId;
    @track minorChecked=false;
    @track boolDateValid=true;
    @track datePickerElem;
    @track stateElementValid=true;

    objType = "{sobjectType :'HIPAA_Restrictions_ACE__c'}";
    strFieldAPIName2 = 'State_ACE__c';
    boolIsValid;
    boolSpinner = false;
    strObjectAPIName = 'HIPAA_Restrictions_ACE__c';
    strIntialNotes ='';

    connectedCallback(){
        const states = this.mapStates;
        // initialize component
        const strPlanData = this.strPlanDetails;
        if(strPlanData && this.isJson(strPlanData)){
            const objGetPlanData = JSON.parse(strPlanData);
            const strAceLineBusiness = objGetPlanData.strAceLineOfBusiness;
            const strCorpCode = objGetPlanData.strCorporationCode;
          
            if (strAceLineBusiness && strAceLineBusiness.toUpperCase() === 'GOVERNMENT-MEDICAID') {
                if (objGetPlanData.objFacetPolicy) {
                    this.strFacetsGroupId = objGetPlanData.objFacetPolicy.facetsGroupId;
                }              
            } 
            if (objGetPlanData.strSubscriberId) {
                this.strSubscriberId = objGetPlanData.strSubscriberId;
            }
        }
     
       const boolIsEdit = this.boolIsEdit;
      if (boolIsEdit && boolIsEdit === true) {
         this.processingStepsOnHIPAAUpdate();
      } else{
        this.processingStepsOnHIPAACreation();
      }
    }

    renderedCallback() {
        const boolIsEdit = this.boolIsEdit;
        if (boolIsEdit && boolIsEdit === true) {
            this.template.querySelector('.setwidthState').value=this.objHIPPARestriction.State_ACE__c;
         }
    }

    /**
     * Method to execute on opening edit modal.
     *
     * @param objComponent to hold the instance of component and access the attributes.
     */
    processingStepsOnHIPAAUpdate(){
         //Disable the Restriction type radio buttons.
         this.boolDisableRestrictionType= true;
         this.strRecordId = this.objHIPPARestriction.Id;
 
         //Stamp the Restriction type.
         const objHIPPARestriction = this.objHIPPARestriction;
        setTimeout(() => {
            this.objHIPPARestriction =objHIPPARestriction ;
          }, 50);
 
         //Stamp Member Minor status.
         if (this.objHIPPARestriction.IsMinor_ACE__c) {
             this.minorChecked = true;
         }
    }

    processingStepsOnHIPAACreation(){
        this.objHIPPARestriction = {};
    }

    isJson(str) {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    }
    

    handleOkay() {
       const states = this.mapStates;
       const isValidInputs = this.checkValidations();
       if(isValidInputs){
            this.boolShowSpinner = true;
            this.saveHIPAARestriction(isValidInputs);
       }
    }

    clearUserInputs(){
        console.info('inside clearUserInputs');
        const objUserInputs = this.template.querySelectorAll('.idHIPAARestriction');
     
        this.boolErrorOnSave = false;
        objUserInputs.forEach(function(objElement) {
            objElement.value = '';
        });
        this.template.querySelector('.datepickercls').clearDate();
        this.template.querySelector('.datepickercls').selectedDate = null;
        this.template.querySelector('.setwidthState').value='--None--';
        const stdErrmsgs = this.template.querySelectorAll('.slds-form-element__help');
        stdErrmsgs.forEach(function(errMsg){
            errMsg.classList.add('slds-hide');
        });
        
        //clear radio inputs.
        this.template.querySelector('.idRRFRadio').checked = false;
        this.template.querySelector('.idCCRFRadio').checked = false;
        this.template.querySelector('.idSubscriberLevel').checked = false;
        this.template.querySelector('.idMemberLevel').checked = false;
        this.template.querySelector('.isminor').checked = false;
        this.template.querySelector('.isminor').value = '';
        this.minorChecked = false;

    }

     /* Method To Handle On Change of Alterante*/
     handleChange(objEvent) {

        let  objHIPPARestriction = JSON.parse(JSON.stringify(this.objHIPPARestriction));
        

        const className = objEvent.target.className;
        if (className.includes('datepickercls')) {
            objHIPPARestriction.Date_Signed_ACE__c = objEvent.target.value;
        } else if (className.includes('address1')) {
            objHIPPARestriction.Address1_ACE__c = objEvent.target.value;
        } else if (className.includes('city')) {
            objHIPPARestriction.City_ACE__c = objEvent.target.value;
        } else if (className.includes('zipcode')) {
            objHIPPARestriction.ZipCode_ACE__c = objEvent.target.value;
        } else if (className.includes('personrestricted')) {
            objHIPPARestriction.Person_Restricted_ACE__c = objEvent.target.value;
        } else if (className.includes('address2')) {
            objHIPPARestriction.Address2_ACE__c = objEvent.target.value;
        } else if (className.includes('state')) {
            objHIPPARestriction.State_ACE__c = objEvent.target.value;
        } else if (className.includes('phonenum')) {
            objHIPPARestriction.Phone_Number_ACE__c = objEvent.target.value;
        } else if (className.includes('imageref')) {
            objHIPPARestriction.Image_Ref_Number_ACE__c = objEvent.target.value;
        } else if (className.includes('emailaddr')) {
            objHIPPARestriction.EmailAddress_ACE__c = objEvent.target.value;
        } else if (className.includes('isminor')) {
            objHIPPARestriction.IsMinor_ACE__c = objEvent.target.value;
        } else if (className.includes('notestext')) {
            objHIPPARestriction.Notes_ACE__c = objEvent.target.value;
        } else if (className.includes('idRRFRadio')) {
            this.boolIsEditRRF = true;
            this.boolIsEditCCRF = false;
        } else if (className.includes('idCCRFRadio')) {
            this.boolIsEditCCRF = true;
            this.boolIsEditRRF = false;
        }else {
            /*Do Nothing*/
        }

        this.objHIPPARestriction = objHIPPARestriction;
     }

    saveHIPAARestriction(isValidInputs){
            let strRestrictionType;

            //Show spinner.
            this.boolSpinner = true;

            //Clear validation error message.
            this.boolErrorOnSave = false;
            const boolRRFRadio = this.template.querySelector('.idRRFRadio').checked;
            const boolCCRFRadio = this.template.querySelector('.idCCRFRadio').checked
            this.datePickerElem = this.template.querySelector('.datepickercls');
            const selectedDateVal = this.template.querySelector('.datepickercls').selectedDate;
            //CEAS-82934 - moved object creation and assignment
            let  objHIPPARestriction = JSON.parse(JSON.stringify(this.objHIPPARestriction));  

            if(selectedDateVal){
                let splittedDate = selectedDateVal.split('/');
                const finalDate = splittedDate[2]+'-'+splittedDate[0]+'-'+splittedDate[1];
                if(this.template.querySelector('.datepickercls').selectedDate){
                    //this.objHIPPARestriction.Date_Signed_ACE__c = finalDate;
                    objHIPPARestriction.Date_Signed_ACE__c  = finalDate;
                }
            }
            
            this.objHIPPARestriction = objHIPPARestriction;
            //Identify the record type.
            if (boolRRFRadio && boolRRFRadio === true) {
                strRestrictionType = this.label.UpdateHIPAARestrictions_RRFHeaderName_ACE;
            } else if(boolCCRFRadio && boolCCRFRadio === true){
                strRestrictionType = this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE;
            }

            //Identify Member plan.
            if(this.idMemberPlan){
                this.objHIPPARestriction.Member_Plan_ACE__c = this.idMemberPlan;
            }

            const boolSubscriberLevel = this.template.querySelector('.idSubscriberLevel').checked;
            const boolMemberLevel = this.template.querySelector('.idMemberLevel').checked;
            const boolIsMinor = this.template.querySelector('.isminor').checked;

            //Stamp Member Minor status.
            this.objHIPPARestriction.IsMinor_ACE__c = boolIsMinor;

            //Stamp BAM Access level.
            if (boolSubscriberLevel) {
                this.objHIPPARestriction.RevokedBAMAccess_ACE__c = this.label.UpdateHIPAARestrictions_SubscriberLevel_ACE;
            }
            if (boolMemberLevel) {
                this.objHIPPARestriction.RevokedBAMAccess_ACE__c = this.label.UpdateHIPAARestrictions_Memberlevel_ACE;
            }

            //Execute save.
            this.saveHIPAARecord(strRestrictionType);
    }

    /**
     * Method used to save the HIPAA Restrictions.
     * @param strRestrictionType to hold Restriction type.
     *
     */
    saveHIPAARecord(strRestrictionType) {
        const boolIsNMCCconst = this.boolIsNMCC;
        this.strRestrictionType = strRestrictionType;

        upsertHIPAARestrictionsData({ 
            strHIPAARestriction: JSON.stringify(this.objHIPPARestriction),
            strRestrictionType: JSON.stringify(strRestrictionType)
        }).then(result => {
            if(result){
                this.strCreatedRecordId = result;
                this.boolDMLStatus = true;
            }
            try {
                const lstFieldsToCompare = ['Person_Restricted_ACE__c', 'Address1_ACE__c', 'Address2_ACE__c', 'City_ACE__c', 'State_ACE__c', 'ZipCode_ACE__c',
                    'Phone_Number_ACE__c', 'EmailAddress_ACE__c', 'Date_Signed_ACE__c',
                    'Image_Ref_Number_ACE__c', 'RevokedBAMAccess_ACE__c', 'IsMinor_ACE__c'
                ];

                //Construct field labels for respective fields.
                const mapGetFieldLabel = {
                    Address1_ACE__c: this.label.UpdateHIPPARestrictions_Address1_ACE,
                    Address2_ACE__c: this.label.UpdateHIPPARestrictions_Address2_ACE,
                    City_ACE__c: this.label.IDCardCity_ACE,
                    ZipCode_ACE__c: this.label.UpdateHIPPARestrictions_ZipCode_ACE,
                    Person_Restricted_ACE__c: this.label.UpdateHIPPARestrictions_PersonRestricted_ACE,
                    State_ACE__c: this.label.IDCardState_ACE,
                    Phone_Number_ACE__c: this.label.PHONENUMBER_ACE,
                    IsMinor_ACE__c: this.label.UpdateHIPAARestrictions_IsMinor_ACE,
                    Date_Signed_ACE__c: this.label.ViewAuthorizedParty_EffectiveDate_ACE,
                    Image_Ref_Number_ACE__c: this.label.UpdateHIPPARestrictions_IMGReferenceNumber_ACE,
                    EmailAddress_ACE__c: this.label.UpdateHIPAARestrictions_Email_ACE,
                    RevokedBAMAccess_ACE__c: this.label.UpdateHIPAARestrictions_RevokedBAMAccess_ACE
                }
                const boolIsEdit = this.boolIsEdit;
                const boolRRFRadio = this.template.querySelector('.idRRFRadio').checked;
                
                let strFunctionality;
                let strFuncCode;
                if (this.strRestrictionType == this.label.UpdateHIPAARestrictions_RRFHeaderName_ACE) {
                    strFunctionality = this.label.UpdateHIPAARestrictions_RRFHeaderName_ACE;
                    strFuncCode = 'RRF';
                } else if(this.strRestrictionType == this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE){
                    strFunctionality = this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE;
                    strFuncCode = 'CCRF';
                }
                const objDeactiveAndRecordStatus = {
                    boolDeactivationIdentifier: null,
                    strSelectRecordStatus: null
                };
                if (this.boolIsNMCC && this.boolIsNMCC === true) {
                    const removedUndefinedAndNull = function(filterData) {
                        if (filterData) {
                            return filterData;   
                        } else {
                            return '';
                        }
                    }
                    const objHIPPARestriction = this.objHIPPARestriction;
                    let strEffectiveDate = removedUndefinedAndNull(this.objHIPPARestriction.Date_Signed_ACE__c);
                    if (strEffectiveDate) {
                         //change format
                           let splittedDate = strEffectiveDate.split('-');
                           strEffectiveDate = splittedDate[1]+'/'+splittedDate[2]+'/'+splittedDate[0];
                           let dt = new Date(strEffectiveDate);
                            const dtf = new Intl.DateTimeFormat('en', {
                                year: 'numeric',
                                month: '2-digit',
                                day: '2-digit'
                            })
                            let formatDateVal = dtf.format(dt); 
                            strEffectiveDate = formatDateVal;
                    }

                    const facetsHIPAAResReq = {
                        "groupId": removedUndefinedAndNull(this.strFacetsGroupId),
                        "subscriberId": removedUndefinedAndNull(this.strSubscriberId).replace(/^0+/, ''),
                        "addressLine1": removedUndefinedAndNull(this.objHIPPARestriction.Address1_ACE__c),
                        "city": removedUndefinedAndNull(this.objHIPPARestriction.City_ACE__c),
                        "state": removedUndefinedAndNull(this.objHIPPARestriction.State_ACE__c),
                        "zipCode": removedUndefinedAndNull(this.objHIPPARestriction.ZipCode_ACE__c),
                        "effectiveDate": strEffectiveDate,
                        "requestReasonCode": removedUndefinedAndNull(strFuncCode),
                        "addressLine2": removedUndefinedAndNull(this.objHIPPARestriction.Address2_ACE__c),
                        "notes": removedUndefinedAndNull(this.objHIPPARestriction.Notes_ACE__c),
                        "originalEndDate": "12/31/9999"
                    }
                    this.facetsHIPAAResReq = facetsHIPAAResReq;
                }
               this.updateInteractionAndCaseForAutoDocHelper(lstFieldsToCompare,mapGetFieldLabel, boolIsEdit, strFunctionality, objDeactiveAndRecordStatus);
            } catch (objException) {
                this.strErrorMessage = this.label.UpdateHIPPARestrictions_SaveUnsuccessfull_ACE;
            }
         
        })
        .catch(error => {
            this.strErrorMessage = this.label.UpdateHIPPARestrictions_SaveUnsuccessfull_ACE;
            this.boolErrorOnSave = true;
        });
    }

   
     /**
     * Method to fire validation (if any) on user inputs.
     */
    checkValidations() {
        let isValid = true;
        this.stateElementValid = true;
        const boolRRFRadio = this.template.querySelector('.idRRFRadio').checked;
        const boolCCRFRadio = this.template.querySelector('.idCCRFRadio').checked;
        let radioValid = true;
        this.boolErrorOnSave = false;
          //Check id user selected Restriction type.
        if((!boolRRFRadio || boolRRFRadio === false) && (!boolCCRFRadio  || boolCCRFRadio === false)) {
            this.strErrorMessage = this.label.UpdateHIPAARestrictions_ErrorMessage_ACE;
            this.boolErrorOnSave = true;
            radioValid = false;
        }
        //check for user input validity. 
        const allValid = [...this.template.querySelectorAll('lightning-input')]
            .reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);

        const dateError = this.template.querySelector('.datepickercls').getBoolErrorMessage();
        let effectveDateValid = true;
        if(this.boolIsNMCC && this.boolIsNMCC === true){
            const selectEffectiveDate = this.template.querySelector('.datepickercls').selectedDate;
            if(!selectEffectiveDate){
                effectveDateValid = false;
                this.template.querySelector('.datepickercls').setDateErrorMessage('Please select a Date');
            }
        }
        let validState = true;
        if(this.boolIsNMCC && this.boolIsNMCC === true){
           if(!this.template.querySelector('.setwidthState').value || this.template.querySelector('.setwidthState').value === '--None--'){
            validState = false;
           }
        }
        let validElements = false;
        validElements = (radioValid && allValid && !dateError && effectveDateValid && validState);
        this.stateElementValid = validState;
        return validElements;
    
    }

    /**
     * Method to create Interaction log and case.
     *
     * @param lstFetchFieldsToCompare Hold's list of fields to compare.
     * @param mapFetchFieldLabel Hold's FIelds labels for respective Field API name.
     * @param boolIsEdit Boolean to confirm edit action.
     * @param strFunctionality Hold's functionality name.
     * @param boolDeactivationIdentifier boolean to identify deactivation.
     * @param strSelectRecordStatus Hold's the record active status.
     */
    updateInteractionAndCaseForAutoDocHelper(lstFetchFieldsToCompare, mapFetchFieldLabel, boolIsEdit,strFunctionality, objDeactiveAndRecordStatus) {

        try {
            let strRecordId;
            if (boolIsEdit && boolIsEdit===true) {
                if (strFunctionality.includes('&&')) {
                    const strFunctionalityName = strFunctionality.split('&&')[0];
                    if (strFunctionalityName === 'STANDARD AUTHORIZATION' || strFunctionalityName === 'AUTHORIZED PARTIES') {
                        const listOfAuth = [];
                        listOfAuth.push(this.strRecordId);
                        strRecordId = JSON.stringify(listOfAuth);
                    }
                } else {
                    strRecordId = this.strRecordId;
                }
            } else {
                strRecordId = this.strCreatedRecordId;
            }
            let strInteractionLogIdForAutoDoc = this.strInteractionLogId;
            if (strInteractionLogIdForAutoDoc === null || strInteractionLogIdForAutoDoc === 'null' || strInteractionLogIdForAutoDoc === '') {
                strInteractionLogIdForAutoDoc = '';
            }
            const boolDeactivationIdentifier = objDeactiveAndRecordStatus['boolDeactivationIdentifier'];
            const strSelectRecordStatus = objDeactiveAndRecordStatus['strSelectRecordStatus'];
            let boolIsNMCC = false;
            let facetsHIPAAResReq = '';
            if(this.boolIsNMCC) {
                boolIsNMCC = this.boolIsNMCC;
            }
            if (this.facetsHIPAAResReq) {
                facetsHIPAAResReq = this.facetsHIPAAResReq;
            }
           if(boolIsNMCC && boolIsNMCC === true){
                submitToFacetsHIPAARestriction({ 
                    strRequestBody: JSON.stringify(facetsHIPAAResReq)
                }).then(result => {
                    if (!result && result === true) {
                        this.facetsCalloutRestrictionSuccess = true;
                    }
                    if (!result && result === false) {
                        this.facetsCalloutRestrictionSuccess = false;
                    }
                }).catch(error => {
                    this.strErrorMessage = error;
                });
            }
            let formatted_date = BaseLWC.currentDateFormat();
            this.strIntialNotes = 'Created on '+formatted_date+'\n\n'+'PHI AUTHORIZATION/RESTRICTION'+'\n\n';
            let strFunctionalitycheck;
            if (strFunctionality.includes('&&')) {
                strFunctionalitycheck = strFunctionality.split('&&')[0];
            } else {
                strFunctionalitycheck = strFunctionality;
            }
            let boolisNotChanged = true;
            const lstFieldsChangesInfo = this.compareFieldsValueChangesHelper(lstFetchFieldsToCompare, mapFetchFieldLabel, boolIsEdit,strFunctionalitycheck, boolDeactivationIdentifier, strSelectRecordStatus,true);
            if (lstFieldsChangesInfo) {
                lstFieldsChangesInfo.forEach((objValue, strKey) => {
                    //Set old and new values to be displayed.
                    if((strKey.toUpperCase() === 'AUTHORIZED PERSON/ENTITY' || strKey.toUpperCase() === 'RELATIONSHIP' || strKey.toUpperCase() === 'REPRESENTATIVE') && objValue.oldValue===objValue.newValue ) {
                        this.strIntialNotes = this.strIntialNotes +'\t\t'+ strKey.toUpperCase()+': \t\t'+objValue.newValue+'\n\n';
                    } else{
                        boolisNotChanged =false;
                        this.strIntialNotes = this.strIntialNotes +'\t\t'+ strKey.toUpperCase()+'\n'+'\t\t\t'+'OLD VALUE : '+objValue.oldValue+'\n'+'\t\t\t'+'NEW VALUE : '+objValue.newValue+'\n\n';
                    }
                });
            }
            if(boolisNotChanged){
                this.strIntialNotes ='';
            }
            const objParameters = {
                "strRecordId": strRecordId,
                "strInteractionId": strInteractionLogIdForAutoDoc,
                "strPlanDetails": this.strPlanDetails,
                "strAccountId": this.strAccountId,
                "strFunctionality": strFunctionality,
                "strIntialNotes": this.strIntialNotes
            };
            createInteractionAndCaseForAutoDocHelper(objParameters)
            .then(result => {
                const strResultOfAutodocInteraction = result;
                let strInteractionLogId = this.strInteractionLogId;
                    if (strResultOfAutodocInteraction && strResultOfAutodocInteraction.includes('_')) {
                        const strCheckRecordType = strResultOfAutodocInteraction.split('_');
                        this.strCreatedInteractionHolder = strCheckRecordType[0];
                        if (strCheckRecordType[1].toUpperCase() === 'LETTER') {
                            strInteractionLogId = null;
                        } 
                    }
                    this.strInteractionLogId = strInteractionLogId;
                    let strFunctionalityfinal;
                    if (strFunctionality.includes('&&')) {
                        strFunctionalityfinal = strFunctionality.split('&&')[0];
                    } else {
                        strFunctionalityfinal = strFunctionality;
                    }
                    const oldValue = 'OLD VALUE';
                    const newValue = 'NEW VALUE';
                    this.createJSONForAutoDocHelper(lstFetchFieldsToCompare, mapFetchFieldLabel, boolIsEdit, strFunctionalityfinal,boolDeactivationIdentifier, strSelectRecordStatus,oldValue,newValue,this.strCreatedInteractionHolder);

             }).catch(error => {
                this.strErrorMessage = error;
            });
        } catch (objException) {
            this.strErrorMessage = this.label.UpdateHIPPARestrictions_SaveUnsuccessfull_ACE;
        }
    }

    /**
     * Function to create JSON to show field value changes on Auto Doc card.
     *
     * @param lstFetchFieldsToCompare Hold's list of fields to compare.
     * @param mapFetchFieldLabel Hold's FIelds labels for respective Field API name.
     * @param boolIsEdit Boolean to confirm edit action.
     * @param strFunctionality Hold's functionality name.
     * @param boolDeactivationIdentifier boolean to identify deactivation.
     * @param strSelectRecordStatus Hold's the record active status.
     */
    
    createJSONForAutoDocHelper(lstFetchFieldsToCompare, mapFetchFieldLabel, boolIsEdit,
        strFunctionality, boolDeactivationIdentifier, strSelectRecordStatus,oldValueStr,newValueStr,strCreatedInteractionHolder) {

        //Get field value changes
       
        const lstFieldsChangesInfo = this.compareFieldsValueChangesHelper(lstFetchFieldsToCompare, mapFetchFieldLabel, boolIsEdit,strFunctionality, boolDeactivationIdentifier, strSelectRecordStatus,false);

        //Build JSON to stamp in Local storage.
        let lstAutoDocJson = [];
        let objAutoDocJson;
       
        if (lstFieldsChangesInfo) {
            lstFieldsChangesInfo.forEach(function(objValue, strKey) {
                const lstSections = [];
                const lstValues = [];
                  //Set old and new values to be displayed.
                lstValues.push({
                    strFieldLabel:  oldValueStr,
                    strFieldValue: objValue.oldValue
                });
                lstValues.push({
                    strFieldLabel:  newValueStr,
                    strFieldValue: objValue.newValue
                });

                let strIconName;
                let strIconFamilyType;
                if (strFunctionality ===  "Restrictions" || strFunctionality ===  "Confidential Communication Requests") {
                    strIconName = "error";
                    strIconFamilyType = "utility";
                } else {
                    strIconName = "custom91";
                    strIconFamilyType = "custom";
                }
                //Set Auto Doc Header.
                lstSections.push({
                    strLabel:  "PHI AUTHORIZATION/RESTRICTION",
                    strIcon: strIconName,
                    strIconFamily: strIconFamilyType,
                    strIconColor: "#fff;background-color: rgba(27, 82, 151, 1);width: 20px;height: 20px;"
                });

                //Set Section Header.
                lstSections.push({
                    strLabel: strKey.toUpperCase(),
                    strIcon: "",
                    strIconFamily: "",
                    strIconColor: ""
                });
                //Construct JSON.
                objAutoDocJson = {
                    strInteractionLogId: strCreatedInteractionHolder,
                    lstValues: lstValues,
                    lstSections: lstSections
                }
                lstAutoDocJson = [...lstAutoDocJson, objAutoDocJson];
            });

            //Send DML acknowledgement and close modal.
            this.triggerAcknowledgementsAndCloseHelper(lstAutoDocJson, strFunctionality, boolDeactivationIdentifier);
        }
    }
    
    /**
     * Method to create JSON to show field value changes on Auto Doc card.
     *
     * @param lstFetchFieldsToCompare Hold's list of fields to compare.
     * @param mapFetchFieldLabel Hold's FIelds labels for respective Field API name.
     * @param boolIsEdit Boolean to confirm edit action.
     * @param strFunctionality Hold's functionality name.
     * @param boolDeactivationIdentifier boolean to identify deactivation.
     * @param strSelectRecordStatus Hold's the record active status.
     */
    compareFieldsValueChangesHelper(lstFetchFieldsToCompare, mapFetchFieldLabel,boolIsEdit, strFunctionality, boolDeactivationIdentifier, strSelectRecordStatus,boolNotes) {
        const lstFieldsChangesInfo = new Map();
        let strStoredDataCopy;
        let objStoredDataCopy;
        let objModifiedData;

        //Fields To compare.
        const lstFieldsToCompare = lstFetchFieldsToCompare;

        //Construct field labels for respective fields.
        const mapGetFieldLabel = mapFetchFieldLabel;

        //Get Modified and Unmodified data.
        if (BaseLWC.isUndefinedOrNullOrBlank(boolDeactivationIdentifier) && !boolDeactivationIdentifier) {
            if (strFunctionality === this.label.UpdateHIPAARestrictions_RRFHeaderName_ACE || strFunctionality === this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE) {
                strStoredDataCopy = this.objHIPPARestrictionCopy;
                objModifiedData = this.objHIPPARestriction;
            } else {
                if (strFunctionality === this.label.ViewStandardAuthorization_Header_ACE) {
                    if (!BaseLWC.isUndefinedOrNullOrBlank(this.strAuthorizedPartyCopy) && !BaseLWC.isUndefinedOrNullOrBlank(this.strAuthorizedPartyCopy)) {
                        objComponent.set(this.objAuthorizedPartyCopy, JSON.parse(this.strAuthorizedPartyCopy));
                        this.processDatesFormat(this.objAuthorizedPartyCopy);
                        strStoredDataCopy = JSON.stringify(this.objAuthorizedPartyCopy);
                    }
                    this.processDatesFormat(objAuthorizedParty);
                } else {
                    strStoredDataCopy = this.objAuthorizedPartyCopy;
                }

                objModifiedData = JSON.parse(JSON.stringify(this.objAuthorizedParty));
            }
        } else {

            //Check for Deactivation action.
            const objOldNewValues = {};
            if (!BaseLWC.isUndefinedOrNullOrBlank(strSelectRecordStatus) && !BaseLWC.isUndefinedOrNullOrBlank(strSelectRecordStatus)) {
                objOldNewValues.oldValue = strSelectRecordStatus;
            } else {
                objOldNewValues.oldValue = this.label.HIPAAAuthParty_Active_ACE;
            }
            objOldNewValues.newValue = this.label.HIPAAAuthParty_Deactivated_ACE;
            lstFieldsChangesInfo.set('Status', objOldNewValues);
            return lstFieldsChangesInfo;
        }

        if (BaseLWC.isUndefinedOrNullOrBlank(strStoredDataCopy) || BaseLWC.isUndefinedOrNullOrBlank(strStoredDataCopy)) {
            objStoredDataCopy = {};
        } else {
            objStoredDataCopy = JSON.parse(strStoredDataCopy);
        }

        if (!boolIsEdit) {
            const objOldNewValues = {
                oldValue: '-'
            }
            if (strFunctionality === this.label.UpdateHIPAARestrictions_RRFHeaderName_ACE) {
                objOldNewValues.newValue = this.label.UpdateHIPAARestrictions_RRFHeaderName_ACE;
                lstFieldsChangesInfo.set('Type', objOldNewValues);
            } else if (strFunctionality === this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE) {
                objOldNewValues.newValue = this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE;
                lstFieldsChangesInfo.set('Type', objOldNewValues);
            } else if (strFunctionality === this.label.ViewStandardAuthorization_Header_ACE) {
                objOldNewValues.newValue = this.label.ViewStandardAuthorization_Header_ACE;
                lstFieldsChangesInfo.set('Type', objOldNewValues);
            } else if (strFunctionality === this.label.HIPAAAuthParty_AuthorizedPartyHeader_ACE) {
                objOldNewValues.newValue = this.label.HIPAAAuthParty_AuthorizedPartyHeader_ACE;
                lstFieldsChangesInfo.set('Type', objOldNewValues);
            } else {
                //No handling needed.
            }
        }

        //Check for changes in field values.
        for (const strKey in lstFieldsToCompare) {
            if (boolIsEdit) {
                const boolAdditionalCheck = (BaseLWC.isUndefinedOrNullOrBlank(objStoredDataCopy[lstFieldsToCompare[strKey]]) &&
                        BaseLWC.isUndefinedOrNullOrBlank(objModifiedData[lstFieldsToCompare[strKey]])) ||
                    (BaseLWC.isUndefinedOrNullOrBlank(objModifiedData[lstFieldsToCompare[strKey]]) &&
                        BaseLWC.isUndefinedOrNullOrBlank(objStoredDataCopy[lstFieldsToCompare[strKey]]))

                    if (!boolAdditionalCheck && ((!boolNotes && objStoredDataCopy[lstFieldsToCompare[strKey]] !== objModifiedData[lstFieldsToCompare[strKey]]) || (boolNotes && (objStoredDataCopy[lstFieldsToCompare[strKey]] !== objModifiedData[lstFieldsToCompare[strKey]] || lstFieldsToCompare[strKey].toUpperCase() ==='AUTHORIZED_PERSON_ACE__C' || lstFieldsToCompare[strKey].toUpperCase() ==='RELATIONSHIP_ACE__C' || lstFieldsToCompare[strKey].toUpperCase() ==='PERSON_RESTRICTED_ACE__C')))) {
                        const objOldNewValues = {
                        oldValue: '-'
                    };
                    if (lstFieldsToCompare[strKey].toLowerCase().includes('date')) {
                        if (!BaseLWC.isUndefinedOrNullOrBlank(objStoredDataCopy[lstFieldsToCompare[strKey]])) {
                            objOldNewValues.oldValue = this.formatDateValues(objStoredDataCopy[lstFieldsToCompare[strKey]]);//$A.localizationService.formatDate(objStoredDataCopy[lstFieldsToCompare[strKey]], "MM/DD/YYYY");
                        }
                        objOldNewValues.newValue = this.formatDateValues(objModifiedData[lstFieldsToCompare[strKey]]);//$A.localizationService.formatDate(objModifiedData[lstFieldsToCompare[strKey]], "MM/DD/YYYY");
                    } else {
                        if (!BaseLWC.isUndefinedOrNullOrBlank(objStoredDataCopy[lstFieldsToCompare[strKey]])) {
                            objOldNewValues.oldValue = objStoredDataCopy[lstFieldsToCompare[strKey]];
                        }
                        objOldNewValues.newValue = objModifiedData[lstFieldsToCompare[strKey]];
                    }
                    lstFieldsChangesInfo.set(mapGetFieldLabel[lstFieldsToCompare[strKey]], objOldNewValues);
                }
            } else {
                if (!BaseLWC.isUndefinedOrNullOrBlank(objModifiedData[lstFieldsToCompare[strKey]]) && !BaseLWC.isUndefinedOrNullOrBlank(objModifiedData[lstFieldsToCompare[strKey]])) {
                    const objOldNewValues = {
                        oldValue: '-'
                    }

                    if (lstFieldsToCompare[strKey].toLowerCase().includes('date')) {
                        objOldNewValues.newValue = this.formatDateValues(objModifiedData[lstFieldsToCompare[strKey]]);//$A.localizationService.formatDate(objModifiedData[lstFieldsToCompare[strKey]], "MM/DD/YYYY");
                    } else {
                        objOldNewValues.newValue = objModifiedData[lstFieldsToCompare[strKey]];
                    }

                    lstFieldsChangesInfo.set(mapGetFieldLabel[lstFieldsToCompare[strKey]], objOldNewValues);
                }
            }
        }

        return lstFieldsChangesInfo;
    }

    processDatesFormat(objAuthParty) {
        if (objAuthParty.Health_Plan_From_ACE__c) {
            objAuthParty.Health_Plan_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Health_Plan_From_ACE__c));
        }

        if (objAuthParty.Health_Plan_To_ACE__c) {
            objAuthParty.Health_Plan_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Health_Plan_To_ACE__c));
        }

        if (objAuthParty.Effective_Date_ACE__c) {
            objAuthParty.Effective_Date_ACE__c = this.formatDateValues(new Date(objAuthParty.Effective_Date_ACE__c));
        }

        if (objAuthParty.Other_Disclosure_To_ACE__c) {
            objAuthParty.Other_Disclosure_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Other_Disclosure_To_ACE__c));
        }

        if (objAuthParty.Other_Disclosure_From_ACE__c) {
            objAuthParty.Other_Disclosure_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Other_Disclosure_From_ACE__c));
        }

        if (objAuthParty.Premium_To_ACE__c) {
            objAuthParty.Premium_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Premium_To_ACE__c));
        }

        if (objAuthParty.Premium_From_ACE__c) {
            objAuthParty.Premium_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Premium_From_ACE__c));
        }

        if (objAuthParty.Service_Info_From_ACE__c) {
            objAuthParty.Service_Info_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Service_Info_From_ACE__c));
        }

        if (objAuthParty.Service_Info_To_ACE__c) {
            objAuthParty.Service_Info_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Service_Info_To_ACE__c));
        }

        if (objAuthParty.Provider_Supplier_To_ACE__c) {
            objAuthParty.Provider_Supplier_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Provider_Supplier_To_ACE__c));
        }

        if (objAuthParty.Provider_Supplier_From_ACE__c) {
            objAuthParty.Provider_Supplier_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Provider_Supplier_From_ACE__c));
        }

        if (objAuthParty.Claims_From_ACE__c) {
            objAuthParty.Claims_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Claims_From_ACE__c));
        }

        if (objAuthParty.Claims_To_ACE__c) {
            objAuthParty.Claims_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Claims_To_ACE__c));
        }
    }
    

    formatDateValues(dateToFormat){
        const dtf = new Intl.DateTimeFormat('en', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        })
        let formattedDate = dtf.format(new Date(dateToFormat.replace(/-/g, '\/'))); 
        return formattedDate;
    }
     /**
     * Method to access VF page to refresh and fire Application event to patient card.
     *
     * @param objComponent to hold the instance of component and access the attributes.
     * @param lstAutoDocJson Hold's Auto doc JSON.
     * @param strFunctionality Hold's functionality name.
     * @param boolDeactivationIdentifier boolean to identify deactivation.
     */
    
     triggerAcknowledgementsAndCloseHelper(lstAutoDocJson, strFunctionality, boolDeactivationIdentifier) {
        try {
            const hipaaSuccessEvent = new CustomEvent('hipaaauthpartysuccess', {
                detail: {
                    strClientMemberId: this.strClientMemberId,
                    objAutodoc: lstAutoDocJson, 
                    boolRefresh: true,
                    boolDMLStatus: this.boolDMLStatus,
                    facetsCalloutRestrictionSuccess : this.facetsCalloutRestrictionSuccess,
                    boolDeactivationIdentifier: boolDeactivationIdentifier
                }
            });
            //dispatching the custom event
            this.dispatchEvent(hipaaSuccessEvent);
            this.dispatchEvent(new CustomEvent("closelwcmodalpopupevent"));
            this.boolShowSpinner = false;
            return true;
        }  
         catch (objException) {
            return false;
        }
    }
}