import { LightningElement, track, api } from 'lwc';
import peerGroupSearchResults from '@salesforce/apex/MyCaseListDashboardController_ACE.fetchMatchingCases';

import TypeAndSubType from '@salesforce/label/c.ViewCaseSummary_TypeAndSubType_ACE';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import { openTab } from 'lightning/platformWorkspaceApi';

export default class LWCCaseSearchDashboard extends LightningElement {
    boolSpinner = false;
    boolShowNotesModal = false;
    boolShowTasksModal = false;
    tasksModal = {};
    @track
    notesModal = {};
    @track caseOwner = '';
    @track disabled = true;
    @track queueName = [];
    @track lstNewSearchList = [];
    @track showError = false;
    @track lstOwnerList = [];
    label = {
        TypeAndSubType
    };
    strProfileName;
    @track
    caseData;
    maxQueueSelection = 20;
    objError;
    get remQueues() {
        return this.maxQueueSelection - this.uidInputs;
    }
    get boolShowNoRecordsFound() {
        return !BaseLWC.arrayIsNotEmpty(this.caseData);
    }

    get disableReset() {
        return !BaseLWC.arrayIsNotEmpty(this.queueInputs);
    }

    get disableSearch() {
        return !BaseLWC.arrayIsNotEmpty(this.queueInputs) || this.queueInputs.length > this.maxQueueSelection;
    }

    lstColumns = [
        { label: 'Case #', fieldName: 'CaseNumber', sortable: true, type: '', boolExport: true },
        { label: 'Case Pend Age', fieldName: 'Case_Pend_Age_ACE__c', sortable: true, type: 'text', boolExport: true, boolInitSort: true, boolAsc: false },
        { label: 'Subscriber ID', fieldName: 'SubscriberID_ACE__c', sortable: true, type: 'text', boolExport: true },
        { label: 'Group #', fieldName: 'GroupNumber_ACE__c', sortable: true, type: 'text', boolExport: true },
        { label: this.label.TypeAndSubType, fieldName: 'TypeAndSubType_ACE__c', sortable: true, type: '', boolExport: true },
        { label: 'Status', fieldName: 'Status', sortable: true, type: '', boolHidden: true, boolExport: true },
        { label: 'Account #', fieldName: 'Account_Number_ACE__c', sortable: true, type: 'text', boolExport: true },
        { label: 'Corp code', fieldName: 'CorporationCode_ACE__c', sortable: true, type: 'text', boolExport: true },
        { label: 'Appeal ID', fieldName: 'AppealId', sortable: true, type: '', boolExport: true },
        { label: 'Case Owner', fieldName: 'OwnerName', sortable: true, type: '', boolExport: true },
        { label: 'Follow-Up Date', fieldName: 'FollowUpDate', sortable: true, type: 'date', boolExport: true },
        { label: 'Sub Type', fieldName: 'Sub_Type_ACE__c', sortable: true, type: 'text', boolHidden: true },
        { label: 'Facets Task Id', fieldName: 'Facets_Task_ID_ACE__c', sortable: true, type: 'text', boolHidden: true },
        { label: 'Type', fieldName: 'Type', sortable: true, type: 'text', boolHidden: true },
        { label: 'LineOfBusiness_ACE__c', fieldName: 'LineOfBusiness_ACE__c', sortable: true, type: 'text', boolHidden: true },
        {
            label: 'ACTION',
            fieldName: 'actionBtn',
            sortable: false,
            type: 'actionBtn',
            rowActions: [
                { key: 'viewNotes', label: 'View Notes' },
                { key: 'viewTasks', label: 'View Tasks' }
            ]
        }
    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 7,
        boolViewMore: true,
        columnsData: this.lstColumns,
        boolShowFilter: true,
        boolSecondaryTable: false,
        boolShowSearch: true,
        boolShowSearchLabel: true,
        boolShowRecordCount: true,
        boolShowExport: true,
        strExportFileName:'Cases.csv',
        exportButtonCss: 'position: absolute;right: 53px;',
        filterData: [
            { strType: 'picklist', intCol: 4, strFilterName: 'Group #' },
            { strType: 'picklist', intCol: 5, strFilterName: this.label.TypeAndSubType },
            { strType: 'picklist', intCol: 6, strFilterName: 'Status' },
            { strType: 'picklist', intCol: 8, strFilterName: 'Corp Code' },
            { strType: 'picklist', intCol: 11, strFilterName: 'Follow-Up Date' }
        ]
    };
    showCaseTable = false;
    @track _queueData;
    @api
    set queueData(val) {
        if (val) {
            this._queueData = val;
        }
    }
    get queueData() {
        return this._queueData;
    }
    get searchSectionClass() {
        if (this.showCaseTable) {
            return 'slds-p-left_medium slds-hide';
        }
        return 'slds-p-left_medium slds-show';
    }
    hideTableSection() {
        this.showCaseTable = false;
    }
    convertAPIToLabelForSubtype(strSubType) {
        let strNewSubtype = strSubType;
        if (strNewSubtype === 'Grievance / Complaint') {
            strNewSubtype = 'Grievance / Member Complaint';
        } else if (strNewSubtype === 'Member Portal (BAM)') {
            strNewSubtype = 'Member Portal';
        } else if (strNewSubtype === 'PCP Update') {
            strNewSubtype = 'MG / PCP Update';
        } else if (strNewSubtype === 'Prior Authorization') {
            strNewSubtype = 'Preauth';
        } else if (strNewSubtype === 'Prospective Member') {
            strNewSubtype = 'Temporary Member';
        } else {
            //Do nothing
        }
        return strNewSubtype;
    }

    convertAPIToLabelForTypeAndSubtype(strTypeSubtype) {
        let strNewTypeSubtype = strTypeSubtype;

        const strGMC = 'Grievance / Complaint';
        if (strNewTypeSubtype.includes(strGMC)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strGMC, 'Grievance / Member Complaint');
        }
        const strMemberPortal = 'Member Portal (BAM)';
        if (strNewTypeSubtype.includes(strMemberPortal)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMemberPortal, 'Member Portal');
        }
        const strMGPCP = 'PCP Update';
        if (strNewTypeSubtype.includes(strMGPCP)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMGPCP, 'MG / PCP Update');
        }
        const strPreAuth = 'Prior Authorization';
        if (strNewTypeSubtype.includes(strPreAuth)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strPreAuth, 'Preauth');
        }
        const strProspectiveMember = 'Prospective Member';
        if (strNewTypeSubtype.includes(strProspectiveMember)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strProspectiveMember, 'Temporary Member');
        }
        return strNewTypeSubtype;
    }
    handleRowAction(event) {
        try {
            const column = JSON.parse(event.detail).activeColFieldName;
            const rowData = JSON.parse(event.detail);
            if (column === 'actionBtn' && rowData.strActionKey === 'viewNotes') {
                this.notesModal.strCaseNumber = rowData.activeColumnData.value.objNotesData.value;
                this.notesModal.strCaseId = rowData.activeColumnData.value.objNotesData.strCaseId;
                this.notesModal.strCaseType = rowData.activeColumnData.value.objNotesData.strType;
                this.notesModal.strCaseSubType = rowData.activeColumnData.value.objNotesData.strSubType;
                this.notesModal.strFacetsTaskId = rowData.activeColumnData.value.objNotesData.strFacetsTaskId;
                this.boolShowNotesModal = true;
            } else if (column === 'actionBtn' && rowData.strActionKey === 'viewTasks') {
                this.tasksModal.strCaseId = rowData.activeColumnData.value.objTasksData.strCaseId;
                this.tasksModal.strAccountId = rowData.activeColumnData.value.objTasksData.strAccountId;
                this.tasksModal.strCaseNumber = rowData.activeColumnData.value.objTasksData.strCaseNumber;
                this.tasksModal.strCaseType = rowData.activeColumnData.value.objTasksData.strType;
                this.tasksModal.strCaseSubType = rowData.activeColumnData.value.objTasksData.strSubType;
                this.boolShowTasksModal = true;
            } else if (column === 'CaseNumber') {
                this.openCaseInSubTab(rowData.activeColumnData.value.strCaseId);
            } else {
                //do nothing
            }
        } catch (error) {
            //Handle Error
            this.handleErrors(error);
        }
    }

    handleErrors(error) {
        this.objError = error;
    }
    openCaseInSubTab = (strCaseId) => {
        openTab({recordId: strCaseId, focus: true})
            .then(() => {})
            .catch((_error) => {
                this.handleErrors(_error);
            });
    };
    closeModal() {
        this.boolShowNotesModal = false;
    }
    closeTaskModal() {
        this.boolShowTasksModal = false;
    }

    get uidInputs() {
        let ownerList = [];
        if (this.caseOwner.trim() !== '') {
            ownerList = this.caseOwner.split(',').map(function (item) {
                if (item.trim() !== '') {
                    return item.trim();
                }
            });
        }
        return ownerList.length;
    }
    get queueInputs() {
        let array = [];
        let ownerList = [];
        if (this.caseOwner.trim() !== '') {
            ownerList = this.caseOwner.split(',').map(function (item) {
                if (item.trim() !== '') {
                    return item.trim();
                }
            });
        }
        array = [...ownerList, ...this.lstNewSearchList];
        return array;
    }

    handleUIDChange(event) {
        this.caseOwner = event.target.value;
        if (this.caseOwner) {
            this.disabled = false;
        } else {
            this.disabled = true;
        }
        if (this.queueInputs.length > this.maxQueueSelection) {
            this.showError = true;
            this.template.querySelector('.uidInput').classList.add('slds-has-error');
        } else {
            this.showError = false;
            this.template.querySelector('.uidInput').classList.remove('slds-has-error');
        }
    }

    selectionHandler(event) {
        const selected = event.detail.globalSelectedItems;
        const maxSelected = event.detail.maxSelected;
        if (maxSelected || this.queueInputs.length > this.maxQueueSelection) {
            this.showError = true;
            this.template.querySelector('.uidInput').classList.add('slds-has-error');
            return;
        } else {
            this.showError = false;
            this.template.querySelector('.uidInput').classList.remove('slds-has-error');
            this.lstNewSearchList = [];
            for (var i = 0; i < selected.length; i++) {
                const name = selected[i].label;
                if (!this.lstNewSearchList.includes(name)) {
                    this.lstNewSearchList.push(name);
                }
            }
        }

        if (this.queueInputs.length > this.maxQueueSelection) {
            this.showError = true;
            this.template.querySelector('.uidInput').classList.add('slds-has-error');
        } else {
            this.showError = false;
            this.template.querySelector('.uidInput').classList.remove('slds-has-error');
        }
    }

    resetFields() {
        this.caseOwner = '';
        this.lstNewSearchList = [];
        this.template.querySelector('c-lwc-lookup-search').resetList();
        this.showError = false;
        this.template.querySelector('.uidInput').classList.remove('slds-has-error');
    }
    fetchUIDCases() {
        this.boolSpinner = true;
        peerGroupSearchResults({ queueNames: this.queueInputs })
            .then((data) => {
                if (data) {
                    this.caseData = [];
                    this.caseData = data.map((el) => {
                        const obj = {};
                        obj.Case_Pend_Age_ACE__c = this.validateData(el.Case_Pend_Age_ACE__c);
                        obj.SubscriberID_ACE__c = this.validateData(el.SubscriberID_ACE__c);
                        obj.GroupNumber_ACE__c = this.validateData(el.GroupNumber_ACE__c);
                        obj.Account_Number_ACE__c = this.validateData(el.Account_Number_ACE__c);
                        obj.CorporationCode_ACE__c = this.validateData(el.CorporationCode_ACE__c);
                        obj.AppealID_ACE__c = this.validateData(el.AppealID_ACE__c);
                        obj.OwnerName = this.validateData(el.Owner.Name);
                        obj['CaseNumber'] = {
                            value: el['CaseNumber'],
                            strCaseId: el['Id'],
                            wrapper: `<a data-casenumber="${el.CaseNumber}">${el.CaseNumber}</a>`
                        };
                        if (BaseLWC.stringIsNotBlank(el.AppealID_ACE__c) && BaseLWC.stringIsNotBlank(el.Appeal_ID_ACE__c)) {
                            obj['AppealId'] = {
                                value: el['Source_System_Identifier_ACE__c'],
                                appealId: el['Source_System_Identifier_ACE__c'],
                                wrapper: el.Appeal_ID_ACE__c.replace("_self", "_blank")
                            };
                        } else {
                            obj['AppealId'] = '-';
                        }
                        obj['Sub_Type_ACE__c'] = this.validateData(this.convertAPIToLabelForSubtype(el['Sub_Type_ACE__c']));
                        obj['TypeAndSubType_ACE__c'] = this.validateData(this.convertAPIToLabelForTypeAndSubtype(el['TypeAndSubType_ACE__c']));
                        let datDateToShow = '';
                        if (BaseLWC.stringIsNotBlank(el.Follow_Up_Date_ACE__c)) {
                            datDateToShow = BaseLWC.dateFormatterHelper(el.Follow_Up_Date_ACE__c);
                        }
                        obj['FollowUpDate'] = this.validateData(datDateToShow);
                        obj.Status = this.validateData(el.Status);
                        obj.Facets_Task_ID_ACE__c = el.Facets_Task_ID_ACE__c;
                        obj.Type = this.validateData(el.Type);
                        obj.LineOfBusiness_ACE__c = el.LineOfBusiness_ACE__c;
                        obj.actionBtn = {
                            rowActions: [
                                { key: 'viewNotes', label: 'View Notes', disabled: false },
                                { key: 'viewTasks', label: 'View Tasks', disabled: false }
                            ],
                            objNotesData: {
                                value: el['CaseNumber'],
                                strCaseId: el['Id'],
                                strType: el['Type'],
                                strSubType: el['Sub_Type_ACE__c'],
                                strFacetsTaskId: el['Facets_Task_ID_ACE__c']
                            },
                            objTasksData: {
                                strCaseId: el['Id'],
                                strAccountId: el['AccountId'],
                                strCaseNumber: el['CaseNumber'],
                                strType: el['Type'],
                                strSubType: el['Sub_Type_ACE__c']
                            }
                        };

                        return obj;
                    });
                }
                this.showCaseTable = false;
                this.boolSpinner = false;
                this.showCaseTable = true;
            })
            .catch((error) => {
                this.handleErrors(error);
            });
    }
    validateData(data) {
        if (data !== null && data !== undefined && typeof data === 'number') {
            return data.toString();
        }
        if (data) {
            return data;
        }
        return '-';
    }
}
