import { LightningElement, api, wire, track } from "lwc";

import fetchACData from '@salesforce/apexContinuation/EOControllerLWC_ACE.fetchEOAssignedClinicians';
import EO_ViewCliniciansLabel_ACE from "@salesforce/label/c.EO_ViewCliniciansLabel_ACE";
import MessageLightningComponent_Error_ACE from "@salesforce/label/c.MessageLightningComponent_Error_ACE";
import ClinicianUnAssigned_ACE from "@salesforce/label/c.ClinicianUnAssigned_ACE";
import EO_IntegrationFailMessage_ACE from '@salesforce/label/c.EO_IntegrationFailMessage_ACE';
import checkReadOnly from '@salesforce/apex/EOControllerLWC_ACE.checkReadOnly';
import ViewPlanSummary_CardHeader_Refresh_ACE from '@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE'
import EO_CardTitle_ACE from '@salesforce/label/c.EO_CardTitle_ACE'

//Import Shared JS files.
//Base LWC functions.
import BaseLWC from "c/baseLWCFunctions_CF";
//CEAS-82979 Platform Workspace API
import { EnclosingTabId, getTabInfo, openSubtab} from 'lightning/platformWorkspaceApi';
import createGuidingCase from '@salesforce/apex/EOControllerLWC_ACE.createCaseRecord';
import careManagementCaseRuleRecord from '@salesforce/apex/EOControllerLWC_ACE.careManagementCaseRuleRecord';
import CreateGuidingCareProgramLabel_ACE from '@salesforce/label/c.CreateGuidingCareProgramLabel_ACE';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import PatientCardEOCreateAerialManagementProgram_ACE from '@salesforce/label/c.PatientCardEOCreateAerialManagementProgram_ACE';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import {getRecord, getFieldValue} from 'lightning/uiRecordApi';
import USER_ID from '@salesforce/user/Id';
import PROFILE_NAME_FIELD from '@salesforce/schema/User.Profile.Name';
export default class LwcEOCardParentAce extends LightningElement {
    showSuccessToast = false;
    boolShowGuidingNotesModal = false;
    strGuidingCareNotes;
    strActionTaken;
    strCaseorigin;
    boolDisabledRefresh = true;
    @api recordId;
    objTabData;
    objCardError = {};
    objPlanSummaryData;
    childParams;
    strTotalprograms;
    boolIsError = true;
    boolPrograms = true;
    boolIsMedicare = false;
    boolIsClinicalApiAvailable = true;
    objProgramDetails = [];
    strErrorMessage = 'error'
    assignedCliniciansButtonIcon = "utility:chevronright";
    assignedCliniciansSectionLabel = EO_ViewCliniciansLabel_ACE;
    showSpinner = false;
    strMemberId;
    cliniciansDataAvailable = false;
    boolApiError = false;
    isAccordionExpanded = false;
    dataSize = 0;
    boolReadOnlyProfile;
    guidingProgramCase;
    strUniqueToken;
    boolSpinner = false;
    boolVPSTabSpecificEvents = false;
    strMedicare = false; 
    objSafeModeUtilitySummaryGenericListener;
    activeAddonService;
    //CEAS-77478
    boolDisableGuidingCare = false;
    boolDisableArial = false;
    boolIsClinicalIntroduction = false;
    activityButtonTooltip = 'A Guiding Care Activity will be automatically created when a Clinical Introduction is accepted and the Guiding Care notes are submitted.';
    @track boolIsEoUser = true;
    strAerialTitle = 'An Aerial Program will be automatically created when a Clinical Introduction is accepted and program notes are submitted.';
    strModalLabel = '';
    modalInputMaxlength = '';
    //CEAS-82997
    strAPIErrorMessageACE = 'An error has occurred, please refresh the card. If the error persists, please contact your system administrator.';
    get strMedicaidLOB() {
        return this.objPlanSummaryData && this.objPlanSummaryData.strAceLineOfBusiness === 'Government-Medicaid';
    }
    get strGMSFEPRetailLOB() {
        return this.objPlanSummaryData && (this.objPlanSummaryData.strAceLineOfBusiness === 'GMS' || this.objPlanSummaryData.strAceLineOfBusiness === 'FEP' || this.objPlanSummaryData.strAceLineOfBusiness === 'Retail');
    }
    @wire(EnclosingTabId) enclosingTabId;
    callingFrom = '';
    boolIsActivity = false;
    boolIsAerialProgram = false;
    EOUSER_PROFILE = 'EO User';

    label = {
        EO_ViewCliniciansLabel_ACE,
        MessageLightningComponent_Error_ACE,
        ClinicianUnAssigned_ACE,
        EO_IntegrationFailMessage_ACE,
        CreateGuidingCareProgramLabel_ACE,
        ViewPlanSummary_CardHeader_Refresh_ACE,
        EO_CardTitle_ACE,
        EnableVPSTabSpecificEvents_ACE,
        SafeMode_ToastMessage_ACE,
        PatientCardEOCreateAerialManagementProgram_ACE
    };
    @wire(checkReadOnly)
    getReadOnly({ data, error }) {
        if (BaseLWC.isNotUndefinedOrNull(data)) {
            this.boolReadOnlyProfile = data;
        } else if (error) {
            //Do nothing
        } else {
            //Do nothing
        }
    }

    @wire(getRecord, {
        recordId: USER_ID,
        fields: [PROFILE_NAME_FIELD]
    }) wireUserData({error, data}) {
        if (data) {
            const strProfileName = data.fields.Profile.value.fields.Name.value;
            this.boolIsEoUser = strProfileName === this.EOUSER_PROFILE || strProfileName === this.SYSTEM_ADMIN_PROFILE;
            
        } else if (error) {

        }
    }

    connectedCallback() {
        try {
            this.fetchTabData();
            this.boolSpinner = true;
        } catch (error) {
            this.handleErrors(error);
        }
    }
    get showCreateGuidingCare() {
        return this.boolReadOnlyProfile === false && this.objPlanSummaryData !== undefined && this.objPlanSummaryData !== null;
    }

    get boolProgramsDetailsAvl() {
        return this.objProgramDetails && this.objProgramDetails.length > 0;
    }

    viewAssignedClinicians() {
        let resultData;
        if (this.assignedCliniciansButtonIcon === "utility:chevronright") {
            this.assignedCliniciansButtonIcon = "utility:chevrondown";
            if (BaseLWC.isNotUndefinedOrNull(this.strMemberId)) {
                if (this.dataSize === 0) {
                    this.showSpinner = true;
                    fetchACData({ strMemberIdParam: this.strMemberId,boolIsEoUser:this.boolIsEoUser })
                        .then(result => {
                            if (BaseLWC.isNotUndefinedOrNull(result)) {
                                resultData = JSON.parse(result);
                                if (resultData.statusList[0].status === '200' || resultData.statusList[0].status === 200) {
                                    this.objProgramDetails = this.formatPhoneNumber(resultData.members[0].programs);
                                    this.cliniciansDataAvailable = true;
                                    if (this.objProgramDetails) {
                                        this.dataSize = this.objProgramDetails.length;
                                    }
                                    if (!this.assignedCliniciansSectionLabel.includes("(")) {
                                        this.dataSize = this.dataSize < 10 ? `0${this.dataSize}` : this.dataSize;
                                        this.assignedCliniciansSectionLabel += " (" + this.dataSize + ")";
                                    }
                                } else {
                                    this.cliniciansDataAvailable = false;
                                    this.boolApiError = true;
                                }
                                this.showSpinner = false;
                            } else {
                                this.cliniciansDataAvailable = false;
                                this.boolApiError = true;
                                this.showSpinner = false;
                            }
                        }).catch(() => {
                            // do nothing
                        });

                }
            } else {
                this.cliniciansDataAvailable = false;
                this.boolApiError = true;
                this.spinner = false;
            }
            this.isAccordionExpanded = true;
        } else {
            this.assignedCliniciansButtonIcon = "utility:chevronright";
            this.isAccordionExpanded = false;
        }
    }

    formatPhoneNumber(objData) {
        objData.forEach(objElement => {
            if (objElement.clinicianPhoneNumber && objElement.clinicianPhoneNumber.includes("-")) {
                const num = objElement.clinicianPhoneNumber;
                objElement.clinicianPhoneNumber = num.replace(/-/g, '');
            }
            if (objElement.enrollmentStatus && objElement.enrollmentStatus.toUpperCase() === 'O') {
                objElement.enrollOpenACE = 'CARE MGMT STATUS:Open';
            } else if (objElement.enrollmentStatus && objElement.enrollmentStatus.toUpperCase() === 'E') {
                objElement.enrolledACE = 'CARE MGMT STATUS:Enrolled';
            }
            if (!objElement.clinicianID) {
                objElement.clinicianID = 'Clinician not yet assigned';
            }
        });
        return objData;
    }
    //CEAS-77478
    disableGuidingCare() {
        this.boolIsClinicalIntroduction = true;
        this.boolDisableGuidingCare = true;
        this.boolDisableArial = true;
    }
    submitClinicalAccepted(event) {
        const eventData = event.detail;
        const objEventData = JSON.parse(eventData)
        if(objEventData && objEventData.apiStatus ==='"200"') {
            this.boolShowGuidingNotesModal = false;
            openSubtab(this.objTabData.tabId, { recordId: objEventData.strCaseId,focus: true})
            .then(() => {
                    const event = new ShowToastEvent({
                        title:'',
                        message: 'Case Created & Closed Successfully',
                        variant: 'success'
                    });
                    this.dispatchEvent(event);
            }).catch(() => {
                //Do nothing
            });
        } else {
            if (this.template.querySelector('c-lwc-guiding-case-add-notes-modal')) {
                this.template.querySelector('c-lwc-guiding-case-add-notes-modal').showError('Request could not be completed, please try resubmitting. If unsuccessful, follow your designated process then submit a help desk ticket.');
            }
        }
    }

    /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     * All components should have this code.
     */
    fetchTabData = () => {
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => { 
                this.objTabData = objTabData;
                if (BaseLWC.stringIsNotBlank(this.label.EnableVPSTabSpecificEvents_ACE) && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                    this.boolVPSTabSpecificEvents = true;
                }
                this.planSummaryListener();
                this.safeModeUtilityGenericComponentListenerForCommCard();
                this.listenerforHidingViewAll();
            }).catch(function(error) {
                            this.handleErrors(error);
                        });
                }
    };
    boolSafeModeOfUser = false;

    /**
     * Method to listen to Safe Mode Listener
     *
     */
    safeModeUtilityGenericComponentListenerForCommCard() {
        try {
            const strSafeModeModalGenericEventName = 'SafeModeModalHCDEvent_ACE';
            const strSafeModeModalEventGenericDestinationId = 'SafeModeModalHCDEventId_ACE';
            if (BaseLWC.isUndefinedOrNullOrBlank(this.objSafeModeUtilitySummaryGenericListener)) {
                const objSafeModeSummaryGenericListener = (objEventData) => {
                    if (objEventData !== null && objEventData.detail !== null && typeof objEventData.detail === 'string') {
                        if (this.objSafeModeUtilitySummaryGenericListener === undefined) {
                            window.removeEventListener(strSafeModeModalGenericEventName, objSafeModeSummaryGenericListener, false);
                        }
                        const strParsedData = JSON.parse(objEventData.detail);
                        if (strParsedData.strIdDestination && strParsedData.strIdDestination === strSafeModeModalEventGenericDestinationId) {
                            this.boolSafeModeOfUser = strParsedData.objMessage;
                        }
                    }
                };
                this.objSafeModeUtilitySummaryGenericListener = objSafeModeSummaryGenericListener;
                window.addEventListener(strSafeModeModalGenericEventName, objSafeModeSummaryGenericListener, false);
            }
        } catch (objException) {
            //Do Nothing.
        }
    }
    get safeModeHide() {
        return this.boolSafeModeOfUser && !(this.boolProvider || this.boolIsEOCard);
    }
    boolProvider = false;
    planSummaryInteractionListener;
    boolIsEOCard = false;
    listenerforHidingViewAll = () => {
        const strPlanSummaryInteractionEvent = 'PlanSummaryInteractionEvent' + '_' + this.objTabData.tabId;
        const strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.objTabData.url);
        const objUrl = new URL(strDecodedURL);
        const strProviderSearch = objUrl.searchParams.get('ProviderSearch');
        const strPlanSummaryInteractionDestinationId = 'PlanSummaryInteractionEvent_' + this.objTabData.tabId;
        if (BaseLWC.isNotUndefinedOrNull(strProviderSearch) && (strProviderSearch === 'true' || strProviderSearch === true)) {
            this.boolProvider = true;
            this.template.querySelector("[data-id=idEnagementOpp]").classList.add('slds-hide');
        } else {
            this.boolProvider = false;
        }
        if (BaseLWC.isUndefinedOrNullOrBlank(this.planSummaryInteractionListener)) {
            const planSummaryInteractionListener = (objListenerEvent) => {
                if (BaseLWC.isUndefinedOrNullOrBlank(this.planSummaryInteractionListener)) {
                    window.removeEventListener(strPlanSummaryInteractionEvent, planSummaryInteractionListener, false);
                }
                let objLocalStorageData;
                if (BaseLWC.isNotUndefinedOrNull(objListenerEvent) && typeof objListenerEvent.detail === 'string') {
                    try {
                        objLocalStorageData = JSON.parse(objListenerEvent.detail);
                    } catch (objException) {
                        // Do nothing
                    }
                    if (objLocalStorageData.strIdDestination !== strPlanSummaryInteractionDestinationId) {
                        return;
                    }
                    if (
                        BaseLWC.isNotUndefinedOrNull(objLocalStorageData) &&
                        BaseLWC.isNotUndefinedOrNull(objLocalStorageData.objParameters) &&
                        BaseLWC.isNotUndefinedOrNull(objLocalStorageData.objParameters.objMessage)
                    ) {
                        const boolIsProvider = objLocalStorageData.objParameters.objMessage.boolIsProvider;
                        this.boolIsEOCard = objLocalStorageData.objParameters.objMessage.boolIsEOCard;
                        if ((BaseLWC.isNotUndefinedOrNull(boolIsProvider) && (boolIsProvider === 'true' || boolIsProvider === true)) || this.boolProvider || (!this.boolIsEoUser && this.boolIsEOCard)) {
                            this.boolProvider = true;
                            if(!this.boolIsEoUser && this.template.querySelector("[data-id=idEnagementOpp]")) {
                                this.template.querySelector("[data-id=idEnagementOpp]").classList.add('slds-hide');
                            }
                            
                        } else if (BaseLWC.isNotUndefinedOrNull(boolIsProvider) && (boolIsProvider === 'false' || boolIsProvider === false || (!this.boolIsEoUser && !this.boolIsEOCard))) {
                            this.boolProvider = false;
                            if(!this.boolIsEoUser && this.template.querySelector("[data-id=idEnagementOpp]")) {
                                this.template.querySelector("[data-id=idEnagementOpp]").classList.remove('slds-hide');
                            }
                        } else {
                            /* Do Nothing*/
                        }
                    }
                }
            };
            this.planSummaryInteractionListener = planSummaryInteractionListener;
            window.addEventListener(strPlanSummaryInteractionEvent, planSummaryInteractionListener, false);
        }
    };

    /*
     * Capture plan summary data.
     */

    planSummaryListener() {
        if (this.objTabData.tabId) {
            if (this.boolVPSTabSpecificEvents) {
                window.addEventListener(
                    'PlanSummaryEvent_' + this.objTabData.tabId,
                    this.capturePlanSummaryListener
                );
            } else {
                window.addEventListener(
                    'PlanSummaryEvent',
                    this.capturePlanSummaryListener
                );
            }
        }
    }

    /**
     * To handle Errors.
     * Helps to show case errors.
     * All components should have this code.
     */
    handleErrors = (error) => {
        this.objCardError = error;
    };

    openNotesModal = (event) => {
        this.boolIsEoUser = event.detail.boolIsEoUser;
        if(!this.boolIsEoUser) {
            if(this.strGMSFEPRetailLOB) {
            this.strModalLabel = 'Program Creation Details';
            this.modalInputMaxlength = 4000;
        } else {
                this.boolIsActivity = true;
                this.strModalLabel = 'Guiding Care Notes';
                this.modalInputMaxlength = 2000;
            }
        } else {
            this.strModalLabel = 'Guiding Care Notes';
            this.modalInputMaxlength = 2000;
        }
        this.boolShowGuidingNotesModal = true;
    }

    /**
         * Capture plan summary Information from Event.
         */
    capturePlanSummaryListener = (planSummaryDataEvent) => {

        try {

            if (
                BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail) &&
                typeof planSummaryDataEvent.detail === "string"
            ) {
                const PlanSummaryData = JSON.parse(planSummaryDataEvent.detail);
                if (this.objTabData && this.objTabData.tabId && PlanSummaryData.objParameters.strParentTabId !== this.objTabData.tabId) {
                    return;
                }
                this.objPlanSummaryData = PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails;
                if (BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData)) {
                    if (this.boolVPSTabSpecificEvents) {
                        window.removeEventListener(
                            'PlanSummaryEvent_' + this.objTabData.tabId,
                            this.capturePlanSummaryListener
                        );
                    } else {
                        window.removeEventListener(
                            'PlanSummaryEvent',
                            this.capturePlanSummaryListener
                        );
                    }
                }

                //using local variable for check
                if (this.objPlanSummaryData) {
                    const objPlanSummaryCardData = this.objPlanSummaryData;
                    const strCaseParameters = new Object();

                    if (this.recordId) {
                        strCaseParameters.id = this.recordId;
                    } else {
                        strCaseParameters.id = '';
                    }
                    if (this.objTabData) {
                        strCaseParameters.objTabData = this.objTabData;
                    }
                    if (objPlanSummaryCardData) {
                        strCaseParameters.objPlanSummary = objPlanSummaryCardData;
                    }
                    if (typeof objPlanSummaryCardData.strMemberId !== "undefined" && objPlanSummaryCardData.strMemberId !== null) {
                        this.strMemberId = objPlanSummaryCardData.strMemberId;
                        strCaseParameters.mid = objPlanSummaryCardData.strMemberId;
                    }
                    if (typeof objPlanSummaryCardData.strSubscriberId !== "undefined" && objPlanSummaryCardData.strSubscriberId !== null) {
                        strCaseParameters.subscriberId = objPlanSummaryCardData.strSubscriberId;
                    }
                    if (typeof objPlanSummaryCardData.strCorpCode !== "undefined" && objPlanSummaryCardData.strCorpCode !== null) {
                        strCaseParameters.corpCode = objPlanSummaryCardData.strCorpCode;
                    }
                    if (typeof objPlanSummaryCardData.strClientMemberId !== "undefined" && objPlanSummaryCardData.strClientMemberId !== null) {
                        strCaseParameters.cmid = objPlanSummaryCardData.strClientMemberId;
                    }
                    if (typeof objPlanSummaryCardData.strPolicyId !== "undefined" && objPlanSummaryCardData.strPolicyId !== null) {
                        strCaseParameters.policyId = objPlanSummaryCardData.strPolicyId;
                    }
                    if (typeof objPlanSummaryCardData.strEffectiveDate !== "undefined" && objPlanSummaryCardData.strEffectiveDate !== null) {
                        strCaseParameters.planEffDt = objPlanSummaryCardData.strEffectiveDate;
                    }
                    if (typeof objPlanSummaryCardData.strTerminationDate !== "undefined" && objPlanSummaryCardData.strTerminationDate !== null) {
                        strCaseParameters.planTermDt = objPlanSummaryCardData.strTerminationDate;
                    }
                    if (typeof objPlanSummaryCardData.strGroupName !== "undefined" && objPlanSummaryCardData.strGroupName !== null) {
                        strCaseParameters.groupName = objPlanSummaryCardData.strGroupName;
                    }
                    if (typeof objPlanSummaryCardData.strMultiPlan !== "undefined" && objPlanSummaryCardData.strMultiPlan !== null) {
                        strCaseParameters.multiPlan = objPlanSummaryCardData.strMultiPlan;
                    }
                    //Now, we set the parameters we don't usually get from the Primary URL.
                    if (typeof objPlanSummaryCardData.strAccountNumber !== "undefined" && objPlanSummaryCardData.strAccountNumber !== null) {
                        strCaseParameters.accountNumber = objPlanSummaryCardData.strAccountNumber;
                    }
                    if (typeof objPlanSummaryCardData.strNetwork !== "undefined" && objPlanSummaryCardData.strNetwork !== null) {
                        strCaseParameters.productType = objPlanSummaryCardData.strNetwork;
                    }
                    if (typeof objPlanSummaryCardData.strGroupNumber !== "undefined" && objPlanSummaryCardData.strGroupNumber !== null) {
                        strCaseParameters.groupNumber = objPlanSummaryCardData.strGroupNumber;
                    }
                    if (typeof objPlanSummaryCardData.objViewEmployerGroupWrapper !== "undefined" && objPlanSummaryCardData.objViewEmployerGroupWrapper !== null &&
                        typeof objPlanSummaryCardData.objViewEmployerGroupWrapper.strGroupSectionNumber !== "undefined" &&
                        objPlanSummaryCardData.objViewEmployerGroupWrapper.strGroupSectionNumber) {
                        strCaseParameters.sectionNumber = objPlanSummaryCardData.objViewEmployerGroupWrapper.strGroupSectionNumber;
                    }
                    if (typeof objPlanSummaryCardData.boolPgIndicator !== "undefined" && objPlanSummaryCardData.boolPgIndicator !== null) {
                        strCaseParameters.pgIndicator = String(objPlanSummaryCardData.boolPgIndicator);
                    }
                    if (typeof objPlanSummaryCardData.strGroupCostCenterNumber !== "undefined" && objPlanSummaryCardData.strGroupCostCenterNumber !== null) {
                        strCaseParameters.grpCostCenter = objPlanSummaryCardData.strGroupCostCenterNumber;
                    }
                    if (typeof objPlanSummaryCardData.strAceLineOfBusiness !== "undefined" && objPlanSummaryCardData.strAceLineOfBusiness !== null) {
                        strCaseParameters.lineOfBusiness = objPlanSummaryCardData.strAceLineOfBusiness;
                        if (typeof objPlanSummaryCardData.strSourceSystemName !== "undefined" && objPlanSummaryCardData.strSourceSystemName !== null && typeof objPlanSummaryCardData.strAceLineOfBusiness === 'Retail') {
                            strCaseParameters.sourceSystem = objPlanSummaryCardData.strSourceSystemName;
                        }
                    }
                    if(typeof objPlanSummaryCardData.strAceLineOfBusiness !== "undefined" && objPlanSummaryCardData.lstCoverageCodes !== null) {
                        const lstAddOnServices = objPlanSummaryCardData.lstCoverageCodes;
                        let strAddOnServices = '';
                        if (lstAddOnServices) {
                            for (let intCount = 0; intCount < lstAddOnServices.length; intCount++) {
                                if (lstAddOnServices[intCount].strEffectiveEndDate && lstAddOnServices[intCount].strEffectiveStartDate) {
                                    const codeDate = new Date(lstAddOnServices[intCount].strEffectiveEndDate);
                                    const codeStartDate = new Date(lstAddOnServices[intCount].strEffectiveStartDate);
                                    const CurrentDate = new Date();
                                    CurrentDate.setHours(0, 0, 0, 0);
                                    if (lstAddOnServices[intCount].strCode && codeStartDate <= CurrentDate && codeDate >= CurrentDate) {
                                        strAddOnServices = strAddOnServices +',' +lstAddOnServices[intCount].strCode;
                                    }
                                }

                            }
                            if(strAddOnServices!==''){
                                strAddOnServices=strAddOnServices.substr(1);
                                this.activeAddonService= strAddOnServices;
                            }
                        }
                    }
                    //CEAS-84244
                    const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + this.recordId;
                    let strInteractionLogId = BaseLWC.helperBaseGetItem(localStorageKey);
                    if(!strInteractionLogId || this.boolIsEoUser) {
                        strInteractionLogId = '';
                    }
                    strCaseParameters.strInteractionId = strInteractionLogId;
                    if (!this.boolEO && (this.boolNMCC || this.boolTXM)) {
                        this.assignedCliniciansSectionLabel = 'View Assigned Care Coordinator';
                    } else {
                        this.assignedCliniciansSectionLabel = this.label.EO_ViewCliniciansLabel_ACE;
                    }
                    this.childParams = strCaseParameters;
                }
            }
        } catch (e) {
            this.handleErrors(e);
        }

    };


    // when event comes from child
    spinnerLogic(evt) {
        if (evt) {
            this.boolSpinner = evt.detail.spinner;
            this.boolDisabledRefresh = evt.detail.boolRefreshDisable;
        }
    }


    refreshChildPage() {
        this.boolSpinner = true;
        this.template.querySelector('c-lwc-engagement-opportunity-ace').refreshPage();
    }

    handleCancelNotesModal = () => {
        this.guidingProgramCase = null;
        this.boolShowGuidingNotesModal = false;
    };
    handleSubmitNotesModal = (event) => {
        const eventData = event.detail;
        if (BaseLWC.isNotUndefinedOrNull(eventData)) {
            const objAerialAceDetails = JSON.parse(eventData);
            if(objAerialAceDetails) {
                this.strGuidingCareNotes = objAerialAceDetails.guidingCareNotes;
                this.strActionTaken = objAerialAceDetails.actionTaken;
                this.strModalLabel = objAerialAceDetails.inputLabel;
                this.strCaseorigin = objAerialAceDetails.caseOrigin;
            }
            if(this.boolIsClinicalIntroduction) {
                this.template.querySelector("c-lwc-engagement-opportunity-ace").createClincalIntroductionCase(this.strGuidingCareNotes);
            } else {
            this.createCareManagementCase();
        }
        }
    };
    handleCreateCareManagementCase = () => {
        this.boolShowGuidingNotesModal = true;
        this.strModalLabel = 'Guiding Care Notes';
        this.modalInputMaxlength = 2000;
        this.boolIsActivity = true;
        if (this.boolIsEoUser) {
            this.callingFrom = 'EO';
        } else {
            this.callingFrom = 'ACE';
        }
    };
    handleCreateAerialCase = () => {
        this.boolShowGuidingNotesModal = true;
        this.strModalLabel = 'Program Creation Details';
        this.modalInputMaxlength = 4000;
        this.boolIsAerialProgram = true;
        this.callingFrom = 'ACE';
    };
    get boolNMCC() {
        return this.objPlanSummaryData && this.objPlanSummaryData.strAceLineOfBusiness === 'Government-Medicaid' && this.objPlanSummaryData.strCorporationCode === 'NM1';
    }
    //RL: CEAS-81636
    get boolTXM() {
        return this.objPlanSummaryData && this.objPlanSummaryData.strAceLineOfBusiness === 'Government-Medicaid' && this.objPlanSummaryData.strCorporationCode === 'TX1';
    }
    get boolEOMAPD() {
        return this.boolIsEoUser === true && this.objPlanSummaryData && this.objPlanSummaryData.strAceLineOfBusiness === 'Government-Medicare';
    }
    get boolMAPD() {
        return this.objPlanSummaryData && this.objPlanSummaryData.strAceLineOfBusiness === 'Government-Medicare';
    }
    get boolNMCCMAPD() {
        return this.objPlanSummaryData && ((this.objPlanSummaryData.strAceLineOfBusiness === 'Government-Medicaid' && this.objPlanSummaryData.strCorporationCode === 'NM1') || this.objPlanSummaryData.strAceLineOfBusiness === 'Government-Medicare'); 
    }
    get showAerialButton(){
        let lob = '';
        let corpCode = '';
        if(this.objPlanSummaryData){
            lob = this.objPlanSummaryData.strAceLineOfBusiness;
            corpCode = this.objPlanSummaryData.strCorporationCode;
        }
        return (!this.boolIsEoUser && lob != '' && this.boolReadOnlyProfile === false && (!(lob === 'Government' || lob === 'Government-Medicare' || lob === 'Government-Medicare Supplemental') && !(lob === 'Government-Medicaid' &&  (corpCode === 'NM1' || corpCode === 'TX1'))));
    }

    get showGuidingActivityBtn() {
        //CEAS-81531 removed corp code restrictions for govt-medicaid 
        return (this.strMedicaidLOB && this.boolReadOnlyProfile === false) || this.boolEOMAPD;
    }

    get showGuidingCareCaseBtn(){
        return this.boolMAPD && !this.boolIsEoUser && this.boolReadOnlyProfile === false;
    }

    async createCareManagementCase() {
        try {
            if (this.objTabData) {
                const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + this.recordId;
                let strInteractionLogId = BaseLWC.helperBaseGetItem(localStorageKey);
                const strEOId = window.localStorage.getItem('strSelectedEO');
                const boolProvider = BaseLWC.helperBaseGetUrlParameters('ProviderSearch', this.objTabData.url);
                const objCaseDefaults = {};
                if(!this.boolIsEoUser) {
                    if(this.boolIsActivity) {
                        objCaseDefaults.ActionTaken_ACE__c = this.strActionTaken;
                    } else {
                        objCaseDefaults.ActionTaken_ACE__c = '';
                    }  
                
                } else {
                    if (this.objPlanSummaryData.strAceLineOfBusiness === 'Government-Medicare') {
                        objCaseDefaults.ActionTaken_ACE__c = 'Care Coordination General Referral';
                        this.strMedicare = true;
                    } else {
                        objCaseDefaults.ActionTaken_ACE__c = 'Care Management General Referral';
                    }
                }
               if(this.boolIsAerialProgram) {
                objCaseDefaults.ProgramCreationDetails_ACE__c = this.strGuidingCareNotes;
                objCaseDefaults.Guiding_Care_Notes_ACE__c = '';
               } else {
                objCaseDefaults.Guiding_Care_Notes_ACE__c = this.strGuidingCareNotes;
                objCaseDefaults.ProgramCreationDetails_ACE__c = '';
               }
                
                if (BaseLWC.isNotUndefinedOrNull(this.guidingProgramCase)) {
                    objCaseDefaults.Id = this.guidingProgramCase.Id;
                    strInteractionLogId = this.guidingProgramCase.EarliestInteractionLog_ACE__c;
                }
                if(this.activeAddonService) {
                    objCaseDefaults.AddonServices_ACE__c=this.activeAddonService;
                }
                const objResult = await createGuidingCase({
                    'caseDetails': JSON.stringify({
                        mid: this.objPlanSummaryData.strMemberId,
                        strGroupNum: this.objPlanSummaryData.strGroupNumber,
                        strPolicyId: this.objPlanSummaryData.strPolicyId,
                        strSubscriberId: this.objPlanSummaryData.strSubscriberId,
                        strCorpCode: this.objPlanSummaryData.strCorporationCode,
                        strAccountNumber: this.objPlanSummaryData.strAccountNumber,
                        strInteractionId: strInteractionLogId,
                        strSectionNumber: this.objPlanSummaryData.strGroupSectionNumber,
                        strGroupCostCenter: this.objPlanSummaryData.strGroupCostCenterNumber,
                        strGroupName: this.objPlanSummaryData.strGroupNumber,
                        strCMID: this.objPlanSummaryData.strClientMemberId,
                        strProductType: this.objPlanSummaryData.strNetwork,
                        strMultiPlan: this.objPlanSummaryData.strMultiPlan,
                        pgIndicator: this.objPlanSummaryData.boolPgIndicator,
                        strEffectiveDate: this.objPlanSummaryData.strEffectiveDate,
                        strTerminationDate: this.objPlanSummaryData.strTerminationDate,
                        boolAccountsAPICallAvailable: this.objPlanSummaryData.boolIsAccountsAPICallAvailable,
                        boolCbcApiCallAvailable: this.objPlanSummaryData.boolIsCbcApiCallAvailable,
                        strLineOfBusiness: this.objPlanSummaryData.strAceLineOfBusiness,
                        //CEAS-62221
                        boolIsProvider: boolProvider,
                        objCaseDefaults: JSON.stringify(objCaseDefaults),
                        strEOIdCase: strEOId,
                        boolIsEoUser: this.boolIsEoUser,
                        strCaseOrigin : this.strCaseorigin,
                        boolIsAerialProgram: this.boolIsAerialProgram,
                        boolIsActivity: this.boolIsActivity
                    })
                });
                if (objResult.caseCreated) {
                    const objCase = JSON.parse(objResult.strCase);
                    this.guidingProgramCase = objCase;
                    if (objResult.EOAPISuccess) {
                        if (BaseLWC.stringIsNotBlank(objResult.strCase)) {
                            this.boolShowGuidingNotesModal = false;
                            this.showSuccessToast = true;
                            if(!this.boolIsEoUser) {
                                openSubtab(this.objTabData.tabId, { recordId: this.guidingProgramCase.Id,focus: true})
                                .then(() => {
                                    const event = new ShowToastEvent({
                                        title:'',
                                        message: 'Case Created & Closed Successfully',
                                        variant: 'success'
                                    });
                                    this.dispatchEvent(event);
                                }).catch(() => {
                                    //Do nothing
                                });
                            }
                            
                            setTimeout(function () {
                                this.closeToast();
                            }.bind(this), 3000);
                        }
                    } else if (!objResult.EOAPISuccess) {
                        this.showExceptionOnModal();
                    } else {
                        /** do nothing **/
                    }
                } else {
                    this.showExceptionOnModal();
                }
            }
        } catch (objException) {
            this.showExceptionOnModal();
        }
    }

    async handleGuidingCareCase (){

        let strEoId = window.localStorage.getItem('strSelectedEO');

        if (typeof strEoId === "undefined" || strEoId === "undefined" || strEoId === null) {
            strEoId = "null";
        }
        window.localStorage.setItem('strSelectedEO', strEoId);
        const objPlanDetails = this.objPlanSummaryData;
        const objMidPlanId = {
            strPlanId: objPlanDetails.strPolicyId,
            strMid: objPlanDetails.strMemberId
        };

        let strAerialCaseRule = '';

        let objResult = await careManagementCaseRuleRecord();
        

        if(objResult !== null && objResult !== '') {
            strAerialCaseRule = objResult;
            strAerialCaseRule = objResult.replace(/&quot;/g, '"');
            this.postMessageToDynamicCasePage(objMidPlanId, strAerialCaseRule,null,'CaseDefaultsOnDynamicCaseCreation');
        }

    };

    postMessageToDynamicCasePage(objMidPlanId, strCaseDefaultsJSON, objParametersToBeSent, strDestinationId) {
        const encodedURLParams = BaseLWC.helperBaseEncodeUrl('?Dynamic=true' + '&timeInMillis=' + Date.now());
        const strURL = '/lightning/n/Manual_Case_Create_ACE' + encodedURLParams;
        const strMemberId = objMidPlanId.strMid;
        openSubtab(this.objTabData.tabId, { url: strURL,focus: true})
            .then((subTabId) => {
                getTabInfo(subTabId)
                    .then(function (objEnclosedTabInfo) {
                        if (objEnclosedTabInfo !== undefined && objEnclosedTabInfo !== null && objEnclosedTabInfo !== false) {

                            const strWsUrl = BaseLWC.helperBaseGetUrlParameters('ws', objEnclosedTabInfo.url);
                            let strAccountId = null;
                            if (strWsUrl !== undefined && strWsUrl !== null) {
                                try {
                                    strAccountId = strWsUrl.split('/')[4];
                                } catch (objError) {
                                    // Do Nothing
                                }
                            }
                            if (strAccountId === undefined || strAccountId === null || strAccountId === '') {
                                try {
                                    const checkURL = new URL(decodeURIComponent(objEnclosedTabInfo.url));
                                    strAccountId = checkURL.searchParams.get('ws').split('/')[4];
                                } catch (e) {}
                            }

                            // Account id if the tab is not focused.
                            if (strAccountId === undefined || strAccountId === null || strAccountId === '') {
                                try {
                                    const checkURLAgain = new URL(decodeURIComponent(objEnclosedTabInfo.url));
                                    strAccountId = checkURLAgain.href.split('/')[6];
                                } catch (e) {}
                            }
                            let intCaseIntervalCounter = 0;
                            const objErrorData = {};
                            objErrorData.strComponentName = 'BaseLightningComponent_ACE';
                            objErrorData.strMessage = 'SetIntervals';
                            objErrorData.strFunctionName = 'helperBasePostMessage';
                            objErrorData.strStackTrace = 'MaxIntervalReached;\nClearedInterval;\n';
                            objErrorData.strError = 'IframeId Not Found: ' + 'idCreateNewCaseLightningComponent_' + strAccountId;
                            //Check DOM's dataIsLoaded attribute in Interval of 1 second
                            const postMessageFunction = setInterval(function () {
                                try {
                                    intCaseIntervalCounter++;
                                    const strDynamicCasePage = document.getElementById('idCreateNewCaseLightningComponent_' + strAccountId);
                                    if (strDynamicCasePage !== undefined && strDynamicCasePage !== null && strDynamicCasePage.dataIsLoaded === 1) {
                                        clearInterval(postMessageFunction);
                                        postDataToCasePage(strMemberId);
                                    }
                                    const intMultiplier = 1;
                                } catch (objException) {
                                    clearInterval(postMessageFunction);
                                }
                            }, 1000);

                            //Function to POst the message.
                            function postDataToCasePage(strMemId) {
                                const objCaseCreateFrame = document.getElementById('idCreateNewCaseLightningComponent_' + strAccountId).contentWindow;
                                if (strCaseDefaultsJSON) {
                                    const objResponse = {
                                        strIdDestination: strDestinationId,
                                        objParameters: {
                                            caseRuleId: JSON.parse(strCaseDefaultsJSON).Id,
                                            strMid: strMemId,
                                            strPlanId: objMidPlanId.strPlanId,
                                            caseObject: JSON.parse(strCaseDefaultsJSON)
                                        }
                                    };
                                    objCaseCreateFrame.postMessage(JSON.stringify(objResponse), '*');
                                } else {
                                    objCaseCreateFrame.postMessage(JSON.stringify(objParametersToBeSent), '*');
                                }
                            }
                        }
                    })
                    .catch(function (error) {
                        // Do nothing
                    });
            })
            .catch(function (error) {
                // Do nothing
            });
    }

    showExceptionOnModal = () => {
        if (this.template.querySelector('c-lwc-guiding-case-add-notes-modal')) {
            this.template.querySelector('c-lwc-guiding-case-add-notes-modal').showError('Request could not be completed, please try resubmitting. If unsuccessful, follow your designated process then submit a help desk ticket.');
        }
    }
    navigateToCase = () => {
        openSubtab(this.objTabData.tabId, { recordId: this.guidingProgramCase.Id,focus: true});
        this.closeToast();
    };
    closeToast = () => {
        this.showSuccessToast = false;
        this.guidingProgramCase = null;
        this.strMedicare = false;
    };

    //EVENT ARCHITECTURE
    disconnectedCallback() {
        if (this.objTabData.tabId) {
            if (this.boolVPSTabSpecificEvents) {
                window.removeEventListener(
                    'PlanSummaryEvent_' + this.objTabData.tabId,
                    this.capturePlanSummaryListener
                );
            } else {
                window.removeEventListener(
                    'PlanSummaryEvent',
                    this.capturePlanSummaryListener
                );
            }
        }
    }
}