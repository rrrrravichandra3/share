import {
	LightningElement,
	api,
	track,
    wire
} from 'lwc';
import { EnclosingTabId, getTabInfo, openSubtab} from 'lightning/platformWorkspaceApi';
import MemberContactDetails_FepSuccessMessage_ACE from '@salesforce/label/c.MemberContactDetails_FepSuccessMessage_ACE';
import NotificationPreferences_WarningMessageTrue_ACE from '@salesforce/label/c.NotificationPreferences_WarningMessageTrue_ACE';
import NotificationPreference_Disclaimer_ACE from '@salesforce/label/c.NotificationPreference_Disclaimer_ACE';
import MemberContactDetails_SuccessMessage_ACE from '@salesforce/label/c.MemberContactDetails_SuccessMessage_ACE';
import Read_Only_Profile from '@salesforce/label/c.Read_Only_Profile';
import fetchNotificationPreferences from '@salesforce/apexContinuation/NotificationPrefLWCController_ACE.fetchNotificationPreferences';
import saveNotificationPreferences from '@salesforce/apexContinuation/NotificationPrefLWCController_ACE.saveNotificationPreferences';
import createCaseforAutodoc from "@salesforce/apex/NotificationPrefLWCController_ACE.createCaseforAutodoc";
import ProfileName from '@salesforce/schema/User.Profile.Name';
import NotificationPreference_Digital_IDCard_ACE from '@salesforce/label/c.NotificationPreference_Digital_IDCard_ACE';
import  NotificationPreferences_ErrorMessage_ACE from '@salesforce/label/c.NotificationPreferences_ErrorMessage_ACE';
//Base Worksapce functions.
import BaseLWC from 'c/baseLWCFunctions_CF';

import CreateCasePage_MemberManagement_ACE from '@salesforce/label/c.CreateCasePage_MemberManagement_ACE';
import CreateCasePage_Telephone_ACE from '@salesforce/label/c.CreateCasePage_Telephone_ACE';
import CommunicationPreferencesLabel_ACE from '@salesforce/label/c.CommunicationPreferencesLabel_ACE';
import CreateCasePage_Closed_ACE from '@salesforce/label/c.CreateCasePage_Closed_ACE';

import USER_ID from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi';
export default class LwcNotificationPreferenceACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
	@api objPlanData;
	@api strMID;
	@api strCorpCode;
	@api strGroupNumber;
    //CEAS-85522
     strCaseURL;
     strToastMessagePre;
     strToastMessagePost;
     strUrlLabel;
     boolShowUrl;
	//CEAS-85501
    @api boolIsFEP;
    boolFEPTextMessage = false;
	@track boolIsPaperless;
	@track objRenderResponse;
	objResponse;
    strOrignalResponseValue;
	boolError = false;
	boolShowSpinner = false;
    boolDisablePaperless = false;
    boolDisableSave = false;
	lstLabel = {
        MemberContactDetails_FepSuccessMessage_ACE,
        NotificationPreferences_ErrorMessage_ACE,
        NotificationPreference_Digital_IDCard_ACE,
		NotificationPreference_Disclaimer_ACE,
        NotificationPreferences_WarningMessageTrue_ACE,
        Read_Only_Profile,
        MemberContactDetails_SuccessMessage_ACE,
        CreateCasePage_MemberManagement_ACE,
        CreateCasePage_Telephone_ACE,
        CommunicationPreferencesLabel_ACE,
        CreateCasePage_Closed_ACE
	};
	@track strToastType = 'success';
	@track strToastMessage;
	@track messageIsHtml = false;
	@track showToastBar = false;
	@api autoCloseTime = 5000;
	@track strToastIcon = '';
    profileName;
    boolIsReload = false;
    @api strAccountId;
    @api strSubId;
    strBaseCurrentTabUrl;
    strInteractionIdForPlanSummaryStamp;
    strClientMemberId;
    strLineOfBusiness;
    strPolicyId;
    boolAEP;
    strSource;
    strMarketType;
    strRelationshipTypeCode;
    strEffectiveDate;
    strTerminationDate;
    strGroupCostCenter;
    boolPerfGurantee;
    strAccInformation;
    securedGroupNecessaryRole;
    strFamilyCaseNumber;
    strSectionNumber;
    strAddOnServices;
    strIntialNotes ='';
    @wire(getRecord, { recordId: USER_ID, fields: [ProfileName] })
    wireUserData({ error, data }) {
        if (data) {
            this.profileName = data.fields.Profile.value.fields.Name.value;
        } else if (error) {

        }
    }

    get strTextLabel() {
        if(this.strLineOfBusiness && (this.strLineOfBusiness.toUpperCase() === 'GMS' || this.strLineOfBusiness.toUpperCase() === 'RETAIL')) {
            return 'Text';
        }
        return 'Text Alert';
    }

	get getIconName() {
		if (this.strToastIcon) {
			return this.strToastIcon;
		}
		return 'utility:' + this.strToastType;
	}
	get innerClass() {
		return 'slds-icon_container slds-icon-utility-' + this.strToastType + ' slds-m-right_small slds-no-flex slds-align-top';
	}
	get outerClass() {
		return 'slds-notify slds-notify_toast slds-theme_' + this.strToastType;
	}
	connectedCallback() {
		this.boolShowSpinner = true;
        if (this.strAccountId && this.strAccountId.startsWith('001')) {
            const strActiveInteractionLogId = BaseLWC.helperBaseGetItem('strInteractionLogIdForPlanSummaryStamp_' + this.strAccountId);
            this.strInteractionIdForPlanSummaryStamp =strActiveInteractionLogId;
        }
		if (this.objPlanData) {
            this.strClientMemberId = this.objPlanData.strClientMemberId;
            this.strLineOfBusiness = this.objPlanData.strAceLineOfBusiness;
            if(typeof this.strLineOfBusiness === 'string' && this.strLineOfBusiness.toUpperCase() === 'FEP') {
                this.boolIsFEP = true;
            }
            this.boolAEP = this.objPlanData.boolGroupAEP;
            this.strPolicyId = this.objPlanData.strPolicyId;
            this.strSource = this.objPlanData.strSourceSystemName;
            this.strMarketType = this.objPlanData.strMarketType;
            this.strRelationshipTypeCode = this.objPlanData.strRelationshipTypeCode;
            this.strEffectiveDate = this.objPlanData.strEffectiveDate;
            this.strTerminationDate = this.objPlanData.strTerminationDate;
            this.strGroupCostCenter = this.objPlanData.strGroupCostCenterNumber;
            this.boolPerfGurantee = this.objPlanData.boolPgIndicator;
            this.strAccInformation = this.objPlanData.strAccountNumber;
            this.securedGroupNecessaryRole = this.objPlanData.securedGroupNecessaryRole;
            this.strFamilyCaseNumber = this.objPlanData.strFamilyCaseNumber;
            if(this.objPlanData.objViewEmployerGroupWrapper) {
                this.strSectionNumber = this.objPlanData.objViewEmployerGroupWrapper.strGroupSectionNumber;
            }
            if(this.objPlanData.lstCoverageCodes) {
                let lstAddOnServices = this.objPlanData.lstCoverageCodes;
                const strPolicyStatus = this.objPlanData.strEnrollmentStatus;
                if (lstAddOnServices) {
                    this.strAddOnServices = "";
                    for (let intCount = 0; intCount < lstAddOnServices.length; intCount++) {
                        let codeDate = new Date(lstAddOnServices[intCount].strEffectiveEndDate);
                        let CurrentDate = new Date();
                        CurrentDate.setHours(0, 0, 0, 0);
                        if (lstAddOnServices[intCount].strCode !== null && strPolicyStatus &&
                            strPolicyStatus !== '' && strPolicyStatus.toUpperCase() !== 'INACTIVE' && codeDate >= CurrentDate) {
                            if (this.strAddOnServices === "") {
                                this.strAddOnServices = lstAddOnServices[intCount].strCode;
                            } else {
                                this.strAddOnServices = this.strAddOnServices + ',' + lstAddOnServices[intCount].strCode;
                            }
                        } else if (lstAddOnServices[intCount].strCode !== null && strPolicyStatus &&
                            strPolicyStatus !== '' && strPolicyStatus.toUpperCase() === 'INACTIVE') {
                            if (this.strAddOnServices === "") {
                                this.strAddOnServices = lstAddOnServices[intCount].strCode;
                            } else {
                                this.strAddOnServices = this.strAddOnServices + ',' + lstAddOnServices[intCount].strCode;
                            }
                        }
                    }
                }
            }
			this.fetchNotificationPreferencesCallout();
		}
	}
    handleErrors(error) {
        this.boolShowSpinner = false;
    }
	fetchNotificationPreferencesCallout() {
		fetchNotificationPreferences({
				strMid: this.strMID,
				strCorpCode: this.strCorpCode,
				strGroupNumber: this.strGroupNumber
			})
			.then((strResponse) => {
				if (strResponse) {
					const objResponse = JSON.parse(strResponse);
					if (objResponse && objResponse.boolError === 'false' && objResponse.strResponseBody) {
						this.objResponse = JSON.parse(objResponse.strResponseBody);
                        //CEAS-81760 Filtering based on LOB
                        this.filterNotificationLOB();
						this.objRenderResponse = this.formatResponseData(this.objResponse);
                        this.strOrignalResponseValue = objResponse.strResponseBody;
					} else {
						this.boolError = true;
					}
                    if(this.boolIsReload) {
                        this.boolIsReload = false;
                        if(this.boolIsFEP){
                            this.showToast('success',this.lstLabel.MemberContactDetails_SuccessMessage_ACE +' '+ this.lstLabel.MemberContactDetails_FepSuccessMessage_ACE,'utility:success',900000);
                        } else {
                        this.showToast('success',this.lstLabel.MemberContactDetails_SuccessMessage_ACE,'utility:success',900000);
                        }
                    }
				} else {
					this.boolError = true;
				}
				this.boolShowSpinner = false;
			})
			.catch((error) => {
				this.boolSpinner = false;
			});
	}
    filterNotificationLOB() {
        let lstFilteredResponse = this.objResponse;
        let lstFinalList = [];
        const lstGMSNotification = ['Policy Information and Documents','Health Care Resources','Member Feedback','Digital Id Card'];
        const lstRetailNotification = ['Policy Information and Documents','Billing and Payments','Health Care Resources','Member Feedback','Digital Id Card'];
        //CEAS-85501
        const lstFEPNotification = ['Text Messaging'];
        if(typeof this.strLineOfBusiness === 'string' && this.strLineOfBusiness.toUpperCase() === 'GMS') {
            lstFilteredResponse.forEach((objElement) => {
                if(objElement && lstGMSNotification.includes(objElement.strNotification)) {
                    lstFinalList.push(objElement);
                }
            });
        } else if(typeof this.strLineOfBusiness === 'string' && this.strLineOfBusiness.toUpperCase() === 'RETAIL') {
            lstFilteredResponse.forEach((objElement) => {
                if(objElement && lstRetailNotification.includes(objElement.strNotification)) {
                    lstFinalList.push(objElement);
                }
            });
        } else if(typeof this.strLineOfBusiness === 'string' && this.strLineOfBusiness.toUpperCase() === 'FEP') {
            lstFilteredResponse.forEach((objElement) => {
                if(objElement && lstFEPNotification.includes(objElement.strNotification)) {
                    lstFinalList.push(objElement);
                }
                if(lstFinalList && lstFinalList[0] && lstFinalList[0].boolText === true) {
                    this.boolFEPTextMessage = true;
                } else {
                    this.boolFEPTextMessage = false;
                }
            });
        } else {
            lstFilteredResponse.forEach((objElement) => {
                if(objElement && !(lstGMSNotification.includes(objElement.strNotification) || lstRetailNotification.includes(objElement.strNotification))) {
                    lstFinalList.push(objElement);
                } else if(objElement.strNotification === 'Member Feedback') {
                    lstFinalList.push(objElement);
                }
            });
        }
        this.objResponse = lstFinalList;
	}
    handleCheckboxEmail(objEvent) {
        let boolMakePaperless = false;
        if(objEvent && objEvent.detail && objEvent.detail.checked) {
            if(objEvent.target && objEvent.target.dataset && objEvent.target.dataset.id) {
                const intIndex = parseInt(objEvent.target.dataset.id);
                this.objRenderResponse[intIndex].boolEmail = true;
                this.objResponse[intIndex].boolEmail = true;
            }
            this.objRenderResponse.forEach((objElement) => {
                if(!objElement['boolEmail']) {
                    boolMakePaperless = false;
                    return;
                } else {
                    boolMakePaperless = true;
                }
            });
        }else if(objEvent && objEvent.detail && !objEvent.detail.checked) {
            if(objEvent.target && objEvent.target.dataset && objEvent.target.dataset.id) {
                const intIndex = parseInt(objEvent.target.dataset.id);
                this.objRenderResponse[intIndex].boolEmail = false;
                this.objResponse[intIndex].boolEmail = false;
            }
            this.objRenderResponse.forEach((objElement) => {
                if(!objElement['boolEmail']) {
                    boolMakePaperless = false;
                }
            });
        }
        this.boolIsPaperless = boolMakePaperless;
    }
    //CEAS-84880
    handleCheckboxDigital(objEvent) {
        if(objEvent && objEvent.detail && objEvent.detail.checked) {
            if(objEvent.target && objEvent.target.dataset && objEvent.target.dataset.id) {
                const intIndex = parseInt(objEvent.target.dataset.id);
                this.objRenderResponse[intIndex].boolIDCard = true;
                this.objResponse[intIndex].boolIDCard = true;
           }
       } else if(objEvent && objEvent.detail && !objEvent.detail.checked) {
        if(objEvent.target && objEvent.target.dataset && objEvent.target.dataset.id) {
            const intIndex = parseInt(objEvent.target.dataset.id);
            this.objRenderResponse[intIndex].boolIDCard = false;
            this.objResponse[intIndex].boolIDCard = false;
          }

        }
   }
	formatResponseData(objResponse) {
		if (objResponse) {
            let boolMakePaperless = true;
			let intCounter = 0;
			let objFormattedData = [];
            objResponse.forEach((objElement) => {
                if(!this.formatBool(objElement['boolEmail'])) {
                    boolMakePaperless = false;
                    return;
                } else {
                    //Do nothing
                }
            });
            this.boolIsPaperless = boolMakePaperless;
			for (let itrRow of objResponse) {
				let data = {};
				data['strNotification'] = itrRow['strNotification'];
                if(itrRow['strNotification'] === 'Policy Information and Documents') {
                    data['boolHelpText'] = true;
                    data['strHelpText'] = 'may include: Explanation of Benefits (EOB), Claim letters, Coordination of Benefits, Referral and Preauthorization Updates, Summary of Benefits and Coverage, Policy Kits, Privacy Practices Notices, Regulatory Statement from the Department of Insurance, Health Care Plan Features';
                } else if(itrRow['strNotification'] === 'Billing and Payments') {
                    data['boolHelpText'] = true;
                    data['strHelpText'] = 'may include: Billing statements, Billing notices, Payment processing notices';
                } else if(itrRow['strNotification'] === 'Health Care Resources') {
                    data['boolHelpText'] = true;
                    data['strHelpText'] = 'may include: Care program information and wellness programs from our clinicians, vendors, or your provider.';
                } else if(itrRow['strNotification'] === 'Member Feedback' && (this.strLineOfBusiness.toUpperCase() === 'RETAIL' || this.strLineOfBusiness.toUpperCase() === 'GMS')) {
                    data['boolHelpText'] = true;
                    data['strHelpText'] = 'may include: Survey opportunities to provide feedback on your Blue Cross and Blue Shield of Illinois (BCBSIL) membership experience and request improvements.';
                } else if(itrRow['strNotification'] === 'Digital Id Card') {
                    data['boolDisableIdCard'] = true;
                    data['boolShowIdCard'] = true;
                    data['boolHelpText'] = true;
                    data['strHelpText'] = "When checkbox is selected, the member's ID card preference will be updated in BAM. This does not determine the delivery method.";
                    if(itrRow['boolIDCard'] === null || this.formatBool(itrRow['boolIDCard']) === false){
                        data['boolIDCard'] = false;
                    }
                    if(this.strLineOfBusiness && this.strLineOfBusiness === 'GMS') {
                        data['boolDisableIdCard']= false;
                    }
                } else {
                    //Do Nothing
                }
				data['boolEmail'] = this.formatBool(itrRow['boolEmail']);
				data['boolText'] = this.formatBool(itrRow['boolText']);
                data['boolIDCard'] = this.formatBool(itrRow['boolIDCard']);
				data['intIndex'] = intCounter;
                if(this.profileName && (boolMakePaperless || this.lstLabel.Read_Only_Profile.split(',').includes(this.profileName))) {
                    data['boolDisableEmail'] = true;
                } else {
                    data['boolDisableEmail'] = false;
                }
                if(this.profileName && this.lstLabel.Read_Only_Profile.split(',').includes(this.profileName)) {
                    data['boolDisableText'] = true;
                } else {
                    data['boolDisableText'] = false;
                }
				intCounter = intCounter + 1;
				objFormattedData.push(data);
			}
            if(this.profileName && this.lstLabel.Read_Only_Profile.split(',').includes(this.profileName)) {
                this.boolDisablePaperless = true;
                this.boolDisableSave = true;
            }
			return objFormattedData;
		}
	}
	formatBool(objValue) {
		if (objValue === true || objValue === 'true') {
			return true;
		} else {
			return false;
		}
	}
	handlePaperlessToggle(objEvent) {
		if(objEvent && objEvent.detail && objEvent.detail.checked) {
            this.objRenderResponse.forEach((objElement) => {
                objElement['boolEmail'] = true;
                objElement['boolDisableEmail'] = true;
            });
            this.objResponse.forEach((objElement) => {
                objElement['boolEmail'] = true;
            });
        } else if(objEvent && objEvent.detail && !objEvent.detail.checked) {
            this.objRenderResponse.forEach((objElement) => {
                objElement['boolEmail'] = false;
                objElement['boolDisableEmail'] = false;
            });
            this.objResponse.forEach((objElement) => {
                objElement['boolEmail'] = false;
            });
        }
	}
	handleRefresh(objEvent) {
		this.boolShowSpinner = true;
        this.boolError = false;
        this.boolIsReload = true;
        this.boolIsPaperless = null;
        this.strUrlLabel = '';
		this.fetchNotificationPreferencesCallout();
	}
    showToast(strToastType, strToastMessage, strToastIcon, time) {
		this.strToastType = strToastType;
		this.strToastMessagePre  = strToastMessage;
        this.strToastMessagePost = '';
		this.strToastIcon = strToastIcon;
		this.autoCloseTime = time;
		this.showToastBar = true;
        this.boolShowUrl = false;
		setTimeout(() => {
			this.closeToastMessage();
		}, this.autoCloseTime);
	}

    //CEAS-85522
    showToastWithURL(strToastType, strToastMessagePre,strUrlLabel,strToastMessagePost, strToastIcon, time) {
            this.strToastType = strToastType;
            this.strToastMessagePre = strToastMessagePre;
            this.strToastMessagePost = strToastMessagePost;
            this.strUrlLabel = strUrlLabel;
            this.strToastIcon = strToastIcon;
            this.autoCloseTime = time;
            this.showToastBar = true;
            this.boolShowUrl = true;
            setTimeout(() => {
               this.closeToastMessage();
            }, this.autoCloseTime);
        }

	closeToastMessage() {
		this.showToastBar = false;
		this.strToastType = '';
		this.strToastMessage = '';
	}
    handleSave(objEvent) {
        if(this.objResponse) {
            this.boolShowSpinner = true;
            this.boolError = false;
            const strRequest = JSON.stringify(this.objResponse);
            const strOldResponse = this.strOrignalResponseValue;
            //Auto Doc Logic;
            
            //API Callout
                saveNotificationPreferences({
                        strRequest: strRequest,
                        strOldResponse: strOldResponse,
                        strMid: this.strMID,
                        strCorpCode: this.strCorpCode,
                        strGroupNumber: this.strGroupNumber
                    })
                    .then((strResponse) => {
                        if (strResponse) {
                            const objResponse = JSON.parse(strResponse);
                            if (objResponse && objResponse.boolError === 'false') {
                            if(this.strInteractionIdForPlanSummaryStamp && this.strOrignalResponseValue && this.objRenderResponse) {
                                //Auto Doc Logic
                                const objOldResponse = JSON.parse(this.strOrignalResponseValue);
                                let lstChange = [];
                                let formatted_date = BaseLWC.currentDateFormat(); 
                                this.strIntialNotes = 'Created on '+formatted_date+'\n\n'+'NOTIFICATION PREFERENCES'+'\n\n';
                                //String for Email & Text.
                                this.objRenderResponse.forEach((objElement) => {
                                    objOldResponse.forEach((objOldElement) => {
                                    if(objElement && objOldElement && objElement['strNotification'] && objOldElement['strNotification'] && objElement['strNotification'].toUpperCase() === objOldElement['strNotification'].toUpperCase()) {
                                        let oldValue =  objOldElement['boolIDCard'];
                                        let newValue = objElement['boolIDCard'];
                                        let strArrayNew = '';
                                            if(objElement && objElement['strNotification'] === 'Digital Id Card'){
                                                    if (oldValue  !== null && newValue !== null && oldValue !== newValue) {
                                                        strArrayNew = '{"strInteractionLogId":' + '"' + this.strInteractionIdForPlanSummaryStamp + '"' + ',' + '"lstValues":';
                                                        strArrayNew = strArrayNew + '[{"strFieldLabel":"Old value","strFieldValue":"' + oldValue + '"},{"strFieldLabel":"New Value","strFieldValue":"' + newValue + '"}]';
                                                        strArrayNew = strArrayNew + ',"lstSections": [{"strLabel":"Notification Preference",';
                                                        strArrayNew = strArrayNew + '"strIcon": "person_account","strIconFamily":"standard","strIconColor": "#62b7ed","strVisibleFor":"default"},{"strLabel":"';
                                                        strArrayNew = strArrayNew + objElement['strNotification'] + '"' + ',"strIcon": "person_account","strIconFamily":"standard","strIconColor": "#62b7ed","strVisibleFor":"default"}]}';
                                                        lstChange.push(strArrayNew);
                                                        this.strIntialNotes = this.strIntialNotes + '\t  '+objElement['strNotification'] +'\n\t\t\t'+'Old value: '+'\t\t'+oldValue+'\n\t\t\t'+'New value: '+'\t\t'+newValue+'\n\n';

                                                    }
                                                } else if(objElement && objElement['strNotification'] === 'Text Messaging'){
                                                    oldValue = objOldElement['boolText'];
                                                    newValue = objElement['boolText'];
                                                    if (oldValue  !== null && newValue !== null && oldValue !== newValue) {
                                                        strArrayNew = '{"strInteractionLogId":' + '"' + this.strInteractionIdForPlanSummaryStamp + '"' + ',' + '"lstValues":';
                                                        strArrayNew = strArrayNew + '[{"strFieldLabel":"Old value","strFieldValue":"' + oldValue + '"},{"strFieldLabel":"New Value","strFieldValue":"' + newValue + '"}]';
                                                        strArrayNew = strArrayNew + ',"lstSections": [{"strLabel":"Notification Preference",';
                                                        strArrayNew = strArrayNew + '"strIcon": "person_account","strIconFamily":"standard","strIconColor": "#62b7ed","strVisibleFor":"default"},{"strLabel":"';
                                                        strArrayNew = strArrayNew + objElement['strNotification'] + '"' + ',"strIcon": "person_account","strIconFamily":"standard","strIconColor": "#62b7ed","strVisibleFor":"default"}]}';
                                                        lstChange.push(strArrayNew);
                                                        this.strIntialNotes = this.strIntialNotes + '\t  '+objElement['strNotification'] +'\n\t\t\t'+'Old value: '+'\t\t'+oldValue+'\n\t\t\t'+'New value: '+'\t\t'+newValue+'\n\n';

                                                    }
                                                } else {
                                                    oldValue = objOldElement['boolText'];
                                                    newValue = objElement['boolText'];
                                                    strArrayNew = '';
                                                    if (oldValue !== newValue) {
                                                        strArrayNew = '{"strInteractionLogId":' + '"' + this.strInteractionIdForPlanSummaryStamp + '"' + ',' + '"lstValues":';
                                                        strArrayNew = strArrayNew + '[{"strFieldLabel":"Old value","strFieldValue":"' + oldValue + '"},{"strFieldLabel":"New Value","strFieldValue":"' + newValue + '"}]';
                                                        strArrayNew = strArrayNew + ',"lstSections": [{"strLabel":"Notification Preference",';
                                                        strArrayNew = strArrayNew + '"strIcon": "person_account","strIconFamily":"standard","strIconColor": "#62b7ed","strVisibleFor":"default"},{"strLabel":"';
                                                        strArrayNew = strArrayNew + objElement['strNotification'] + ' Text"' + ',"strIcon": "person_account","strIconFamily":"standard","strIconColor": "#62b7ed","strVisibleFor":"default"}]}';
                                                        lstChange.push(strArrayNew);
                                                        this.strIntialNotes = this.strIntialNotes + '\t  '+objElement['strNotification'] + ' Text' +'\n\t\t\t'+'Old value: '+'\t\t'+oldValue+'\n\t\t\t'+'New value: '+'\t\t'+newValue+'\n\n';
                                                    }
                                                    oldValue = objOldElement['boolEmail'];
                                                    newValue = objElement['boolEmail'];
                                                    strArrayNew = '';
                                                    if (oldValue !== newValue) {
                                                        strArrayNew = '{"strInteractionLogId":' + '"' + this.strInteractionIdForPlanSummaryStamp + '"' + ',' + '"lstValues":';
                                                        strArrayNew = strArrayNew + '[{"strFieldLabel":"Old value","strFieldValue":"' + oldValue + '"},{"strFieldLabel":"New Value","strFieldValue":"' + newValue + '"}]';
                                                        strArrayNew = strArrayNew + ',"lstSections": [{"strLabel":"Notification Preference",';
                                                        strArrayNew = strArrayNew + '"strIcon": "person_account","strIconFamily":"standard","strIconColor": "#62b7ed","strVisibleFor":"default"},{"strLabel":"';
                                                        strArrayNew = strArrayNew + objElement['strNotification'] + ' Email"' + ',"strIcon": "person_account","strIconFamily":"standard","strIconColor": "#62b7ed","strVisibleFor":"default"}]}';
                                                        lstChange.push(strArrayNew);
                                                        this.strIntialNotes = this.strIntialNotes + '\t  '+objElement['strNotification'] + ' Email' +'\n\t\t\t'+'Old value: '+'\t\t'+oldValue+'\n\t\t\t'+'New value: '+'\t\t'+newValue+'\n\n';
                                                    }
                                            }
                                        }
                                    });
                                });
                                let strAutoDoc = '';
                                let intCounter = 0;
                                if (lstChange && lstChange.length !== 0) {
                                    for (intCounter = 0; intCounter < lstChange.length; intCounter++) {
                                        if (intCounter == 0 && strAutoDoc === '') {
                                            strAutoDoc = strAutoDoc + lstChange[intCounter];
                                        } else {
                                            if(strAutoDoc ==='') {
                                                strAutoDoc =strAutoDoc + lstChange[intCounter];
                                            } else {
                                                strAutoDoc = strAutoDoc + ',' + lstChange[intCounter];
                                            }
                                        }
                                    }
                                }
                                if (strAutoDoc !== null && strAutoDoc !== '') {
                                    strAutoDoc = '[' + strAutoDoc + ']';
                                }
                                if (this.strInteractionIdForPlanSummaryStamp && this.strInteractionIdForPlanSummaryStamp !== '') {
                                    this.setAutoDoc(strAutoDoc);
                                }
                                this.strOrignalResponseValue = JSON.stringify(this.objResponse);
                            } else {
                                if(this.boolIsFEP) {
                                    this.showToast('success',this.lstLabel.MemberContactDetails_SuccessMessage_ACE +' '+ this.lstLabel.MemberContactDetails_FepSuccessMessage_ACE,'utility:success',900000);
                                } else { 
                                       this.showToast('success',this.lstLabel.MemberContactDetails_SuccessMessage_ACE,'utility:success',9000);
                                    }
                            }
                            
                            } else {
                                this.boolError = true;
                            }
                            if(this.boolIsReload) {
                                this.boolIsReload = false;
                                if(this.boolIsFEP) {
                                    this.showToast('success',this.lstLabel.MemberContactDetails_SuccessMessage_ACE +' '+ this.lstLabel.MemberContactDetails_FepSuccessMessage_ACE,'utility:success',900000);
                                } else {
                                        this.showToast('success',this.lstLabel.MemberContactDetails_SuccessMessage_ACE,'utility:success',9000);
                                    }
                            }
                        } else {
                            this.boolError = true;
                        }
                        this.boolShowSpinner = false;
                    })
                    .catch((error) => {
                        this.boolSpinner = false;
                    });
            
        }
    }
    setAutoDoc(strAutoDoc) {
        try{
        let strProviderInfoNotification = BaseLWC.helperBaseGetItem('MemberSearchProviderData_ACE');
			if (strProviderInfoNotification === undefined || strProviderInfoNotification === null) {
				strProviderInfoNotification = '';
			}
            if (this.strInteractionIdForPlanSummaryStamp !== null && this.strInteractionIdForPlanSummaryStamp !== '') {
                createCaseforAutodoc({
                    strInteractionLogAutodoc : this.strInteractionIdForPlanSummaryStamp, 
                    strCaseTypeAutodoc:this.lstLabel.CreateCasePage_MemberManagement_ACE, 
                    strCaseSubTypeAutodoc:this.lstLabel.CommunicationPreferencesLabel_ACE, 
                    strCaseOriginAutodoc:this.lstLabel.CreateCasePage_Telephone_ACE, 
                    strCaseStatusAutodoc:this.lstLabel.CreateCasePage_Closed_ACE, 
                    strCaseMidAutodoc:this.strMID, 
                    strCaseSubscriberIdAutodoc:this.strSubId, 
                    strCaseGroupNumberAutodoc:this.strGroupNumber, 
                    strCaseCmidAutodoc:this.strClientMemberId,
                    strCaseSectionNumberAutodoc:this.strSectionNumber, 
                    strCaseCorpCodeAutodoc:this.strCorpCode, 
                    boolPerfGuranteeAutodoc:this.boolPerfGurantee, 
                    strCaseGroupCostCenterAutodoc:this.strGroupCostCenter, 
                    strCaseAccInformationAutodoc:this.strAccInformation, 
                    strPolicyId:this.strPolicyId, 
                    strEffectiveDate:this.strEffectiveDate, 
                    strTerminationDate:this.strTerminationDate, 
                    strCodes:this.strAddOnServices, 
                    strProviderInfo:strProviderInfoNotification, 
                    boolIsAccountsAPICallAvailable:this.objPlanData.boolIsAccountsAPICallAvailable, 
                    boolIsCbcApiCallAvailable:this.objPlanData.boolIsCbcApiCallAvailable,
                    strLOB:this.strLineOfBusiness, 
                    strSourceSystem:this.strSource,
                    securedGroupNecessaryRole:this.securedGroupNecessaryRole, 
                    strFamilyCaseNumber:this.strFamilyCaseNumber,
                    strIntialNotes: this.strIntialNotes
            }).then((data) => {
                    if(data && data.Id){
                        this.strCaseNumber = data.CaseNumber;
                        this.strCaseId = data.Id;
                        const strParams = '?mid=' + this.strMID+ '&caseNumber=' + this.strCaseNumber;
                        const strUrl =  BaseLWC.helperBaseEncodeUrl(strParams);
                        this.strCaseURL = '/lightning/r/Case/' + this.strCaseId + '/view' + strUrl;
                    }
                //AutoDoc Event
                this.postMessageToAutoDoc(strAutoDoc);
                    if (this.boolIsFEP) {
                       this.showToastWithURL('success',this.lstLabel.MemberContactDetails_SuccessMessage_ACE +' '+'Case', this.strCaseNumber ,'successfully created.'+' '+this.lstLabel.MemberContactDetails_FepSuccessMessage_ACE,'utility:success',900000);
                    } else {
                        this.showToast('success',this.lstLabel.MemberContactDetails_SuccessMessage_ACE,'utility:success',900000);
                    }

                }).catch((error)=> {
                    this.handleErrors(error);
                });
                }
            } catch(objErrors) {
                this.handleErrors(objErrors);
            }
    }
    
    //CEAS-85522
    openCaseUrl(){
            if(this.enclosingTabId) {
                getTabInfo(this.enclosingTabId).then((objTabData) => {
                    openSubtab(objTabData.parentTabId, { recordId: this.strCaseId,focus: true})
                }).catch(function(error) {
                         this.handleErrors(error);
                        });
            } 
        }

   postMessageToAutoDoc(strAutoDoc) {
        let localIframe = document.getElementById('proxy');
        if (!localIframe) {
            let iframe = document.createElement("iframe");
            iframe.src = '/apex/SetlocalstoragePage_ACE';
            iframe.id = "proxy";
            document.body.appendChild(iframe);
            iframe.onload = function() {
                
                iframe.contentWindow.postMessage({
                    key: 'strKeepAutodocActive',
                    value: 'true',
                   boolIsLocalStorageEvent: true,
                   boolSetSecureLocalStorage:true
                }, '*');
                iframe.contentWindow.postMessage({
                    key: 'strAutodoc',
                    value: strAutoDoc,
                   boolIsLocalStorageEvent: true,
                   boolSetSecureLocalStorage:true
                }, '*');
            }
        } else {
            localIframe.contentWindow.postMessage({
                key: 'strKeepAutodocActive',
                value: 'true',
                boolIsLocalStorageEvent: true,
                boolSetSecureLocalStorage:true
            }, '*');
            localIframe.contentWindow.postMessage({
                key: 'strAutodoc',
                value: strAutoDoc,
               boolIsLocalStorageEvent: true,
               boolSetSecureLocalStorage:true
            }, '*');
        }
    }
    
    handleCheckboxText(objEvent) {
        if(objEvent && objEvent.detail && objEvent.detail.checked) {
            if(objEvent.target && objEvent.target.dataset && objEvent.target.dataset.id) {
                const intIndex = parseInt(objEvent.target.dataset.id);
                this.objRenderResponse[intIndex].boolText = true;
                this.objResponse[intIndex].boolText = true;
                
            }
            this.showToast('warning',this.lstLabel.NotificationPreferences_WarningMessageTrue_ACE,'utility:warning',8000);
        } else if(objEvent && objEvent.detail && !objEvent.detail.checked) {
            if(objEvent.target && objEvent.target.dataset && objEvent.target.dataset.id) {
                const intIndex = parseInt(objEvent.target.dataset.id);
                this.objRenderResponse[intIndex].boolText = false;
                this.objResponse[intIndex].boolText = false;
            }
        }
    }
    //CEAS-85501
    handleFEPTextMessaging(objEvent) {
        if(objEvent && objEvent.detail && objEvent.detail.checked) {
            if(this.objResponse && this.objResponse.length) {
                this.objResponse[0].boolText = true;
            }
        } else {
            if(this.objResponse && this.objResponse.length) {
                this.objResponse[0].boolText = false;
            }
        }
    }
}