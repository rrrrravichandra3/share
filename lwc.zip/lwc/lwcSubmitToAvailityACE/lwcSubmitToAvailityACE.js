import { LightningElement, api } from 'lwc';
import submitToAvailityCallout from '@salesforce/apexContinuation/SubmitToAvailityController_ACE.submitToAvailityCallout'
import PendedStatus_ACE from '@salesforce/label/c.PendedStatus_ACE';
import Closed_Maintained_Status_ACE from '@salesforce/label/c.Closed_Maintained_Status_ACE';
import Closed_Adjusted_Status_ACE from '@salesforce/label/c.Closed_Adjusted_Status_ACE';
import SubmitToAvailityHeader_ACE from '@salesforce/label/c.SubmitToAvailityHeader_ACE';
import Closed_Forwarded_Status_ACE from '@salesforce/label/c.Closed_Forwarded_Status_ACE';
import OpenStatus_ACE from '@salesforce/label/c.OpenStatus_ACE';

export default class LwcSubmitToAvailityACE extends LightningElement {
    @api strStatus;
    @api recordId;
    @api strCaseNumber;
    @api strReqStatus;
    @api strPortalId;
  boolTemplateLoading = true;
  boolTemplateAPIError = false;
  header;
  lstStatus = [];
  caseStatusDefaultValues = null;
  
  boolSuccessMessage = false;
  boolErrorMessage = false;
  label = {
    PendedStatus_ACE,
    SubmitToAvailityHeader_ACE,
    OpenStatus_ACE,
    Closed_Maintained_Status_ACE,
    Closed_Adjusted_Status_ACE,
    Closed_Forwarded_Status_ACE
  }
    setPicklistValue() {
        const lstLocalStatus = [];
        const objTypePended = {
                label: this.label.PendedStatus_ACE,
                value: this.label.PendedStatus_ACE
            };
        const objTypeClosedAdjusted = {
                label: this.label.Closed_Adjusted_Status_ACE,
                value: this.label.Closed_Adjusted_Status_ACE
            };
        const objTypeClosedMaintained = {
                label: this.label.Closed_Maintained_Status_ACE,
                value: this.label.Closed_Maintained_Status_ACE
            }
            const objTypeClosedForwarded = {
                label: this.label.Closed_Forwarded_Status_ACE,
                value: this.label.Closed_Forwarded_Status_ACE
            }
           
        if(this.strStatus !== this.label.PendedStatus_ACE) {
            lstLocalStatus.push(objTypePended);
         }
        lstLocalStatus.push(objTypeClosedAdjusted);
        lstLocalStatus.push(objTypeClosedMaintained);
        lstLocalStatus.push(objTypeClosedForwarded);
        if(lstLocalStatus && lstLocalStatus.length > 0){
            this.caseStatusDefaultValues = lstLocalStatus[0].value;
        }
   
        this.lstStatus = lstLocalStatus; //lstLocalStatus;
        this.boolTemplateLoading = false;
    }

    connectedCallback() {
        this.header = this.label.SubmitToAvailityHeader_ACE; 
        this.setPicklistValue(); 
    }
    
    handleCloseTemplateClick() {
        const availityCloseModal = new CustomEvent("availityclosemodal",{detail : {boolSuccessMessage : this.boolSuccessMessage,boolErrorMessage : this.boolErrorMessage}}, this);
        this.dispatchEvent(availityCloseModal);
    }

  /* Method To Handle On Change of Origin*/
    handleChangeStatus(objEvent) {
        this.caseStatusDefaultValues = objEvent.detail.value;
    }

    handleSubmitClick() {
        
        this.boolTemplateLoading = true;
        if(this.strStatus && this.caseStatusDefaultValues && this.strCaseNumber && this.strPortalId && this.recordId) {
            const lstReq = [];
            let strReqStatus = ''

            if(this.strStatus === this.label.OpenStatus_ACE && this.caseStatusDefaultValues === this.label.PendedStatus_ACE) {
                strReqStatus = 'In Progress';
            } else if((this.strStatus === this.label.OpenStatus_ACE || this.strStatus === this.label.PendedStatus_ACE) && this.caseStatusDefaultValues === this.label.Closed_Maintained_Status_ACE) {
                strReqStatus = 'Closed-Maintained';
            } else if((this.strStatus === this.label.OpenStatus_ACE || this.strStatus === this.label.PendedStatus_ACE) && this.caseStatusDefaultValues === this.label.Closed_Adjusted_Status_ACE) {
                strReqStatus = 'Closed-Adjusted';
            } else if((this.strStatus === this.label.OpenStatus_ACE || this.strStatus === this.label.PendedStatus_ACE) && this.caseStatusDefaultValues === this.label.Closed_Forwarded_Status_ACE) {
                strReqStatus = 'Closed-Forwarded';
            } else {
                // Do Nothing
            }
        
            const objReq = {
                caseNumber : this.strCaseNumber,
                status: strReqStatus,
                externalId: this.strPortalId
            }
            lstReq.push(objReq);
            
            submitToAvailityCallout({
                lstReq : lstReq,
                strcaseId : this.recordId,
                strNewStatus : this.caseStatusDefaultValues 
            }).then(result => {
                if(result && result === true) {
                    this.boolSuccessMessage = true;
                } else {
                    this.boolErrorMessage  = true;
                }
                
                this.handleCloseTemplateClick();
                this.boolTemplateLoading = false;
            }).catch(()=> {
                this.boolErrorMessage  = true;
                this.handleCloseTemplateClick();
                this.boolTemplateLoading = false;
            });

        }
        
    }

}