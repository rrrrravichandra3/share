import { LightningElement, wire, track } from 'lwc';
import strUserId from '@salesforce/user/Id';
import {getRecord} from 'lightning/uiRecordApi';
import PROFILE_NAME_FIELD from '@salesforce/schema/User.Profile.Name';
import System_Administrator_profile_ACE from '@salesforce/label/c.System_Administrator_profile_ACE';
import Supervisor_Profile_ACE from '@salesforce/label/c.Supervisor_Profile_ACE';
import Standard_Profile_ACE from '@salesforce/label/c.Standard_Profile_ACE';
import ReportingAdministrator_Profile_ACE from '@salesforce/label/c.ReportingAdministrator_Profile_ACE';
import InventoryManager_Profile_ACE from '@salesforce/label/c.InventoryManager_Profile_ACE';
import Clinician_Profile_ACE from '@salesforce/label/c.Clinician_Profile_ACE';
import DebugOnly_Profile_ACE from '@salesforce/label/c.DebugOnly_Profile_ACE';
import ChatUser_Profile_ACE from '@salesforce/label/c.ChatUser_Profile_ACE';
import BusinessAdministrator_Profile_ACE from '@salesforce/label/c.BusinessAdministrator_Profile_ACE';
import CustomerAdvocateSpecialist_Profile_ACE from '@salesforce/label/c.CustomerAdvocateSpecialist_Profile_ACE';
import Developer_profile_ACE from '@salesforce/label/c.Developer_profile_ACE';
import SFDC_IT_Product_Admin_Prod_profile_ACE from '@salesforce/label/c.SFDC_IT_Product_Admin_Prod_profile_ACE';
import SFDC_IT_Product_Admin_Test_profile_ACE from '@salesforce/label/c.SFDC_IT_Product_Admin_Test_profile_ACE';
//Base LWC functions. 
import BaseLWC from 'c/baseLWCFunctions_CF';
import fetchAllUserQueues from '@salesforce/apex/MyCaseListDashboardController_ACE.fetchAllUserQueues';

export default class CaseManagementLwcACE extends LightningElement {
    boolShowRefreshIcon = false;
    get boolShowPeerGroup() {
        return BaseLWC.stringIsNotBlank(this.strProfileName) && this.boolQueuesFetched && 
        (this.strProfileName === System_Administrator_profile_ACE || this.strProfileName === Supervisor_Profile_ACE || 
            this.strProfileName === Standard_Profile_ACE || this.strProfileName === ReportingAdministrator_Profile_ACE || 
            this.strProfileName === InventoryManager_Profile_ACE || this.strProfileName === Clinician_Profile_ACE || 
            this.strProfileName === DebugOnly_Profile_ACE || this.strProfileName === ChatUser_Profile_ACE || 
            this.strProfileName === BusinessAdministrator_Profile_ACE || this.strProfileName === CustomerAdvocateSpecialist_Profile_ACE || 
            this.strProfileName === Developer_profile_ACE || this.strProfileName === SFDC_IT_Product_Admin_Test_profile_ACE || 
            this.strProfileName === SFDC_IT_Product_Admin_Prod_profile_ACE); 
    }
    get boolShowMyCaseTable() {
        return BaseLWC.stringIsNotBlank(this.strProfileName) && (this.strProfileName === System_Administrator_profile_ACE || 
            this.strProfileName === Supervisor_Profile_ACE || this.strProfileName === Standard_Profile_ACE || 
            this.strProfileName === ReportingAdministrator_Profile_ACE || this.strProfileName === InventoryManager_Profile_ACE || 
            this.strProfileName === Clinician_Profile_ACE || this.strProfileName === DebugOnly_Profile_ACE || 
            this.strProfileNacme === ChatUser_Profile_ACE || this.strProfileName === BusinessAdministrator_Profile_ACE || 
            this.strProfileName === CustomerAdvocateSpecialist_Profile_ACE || this.strProfileName === Developer_profile_ACE); 
    }
    strProfileName;
    @wire(getRecord, { recordId: strUserId, fields: [PROFILE_NAME_FIELD]}) 
    fetchProfileName({error, data }) {
        if (error) {
           this.error = error ; 
        } else if (data) {
            this.strProfileName =data.fields.Profile.value.fields.Name.value;     
        }
    }

    @track
    queueData;
    boolQueuesFetched = false;
    objTabData;
    objError;
    strBaseCurrentTabId;
    shownTabId = 'tab-mywork';
    connectedCallback() {
        this.fetchAllUserQueues();
    }

    handleErrors(error) {
        this.objError = error;
    }

    async fetchAllUserQueues() {
        try {
            const objResult = await fetchAllUserQueues();
            const lstGroupNames = [];
            objResult.forEach((data) => {
                lstGroupNames.push(data.Name);
            });
            this.queueData = lstGroupNames;
            this.boolQueuesFetched = true;
        } catch (error) {
            this.handleErrors(error);
        }
    }

    get displayRefreshIcon() {
        return this.boolShowRefreshIcon && this.shownTabId === 'tab-mywork';
    }

    changeTab(event){
        const objTarget = event.currentTarget;
        const currentContentId = objTarget.getAttribute('aria-controls');
        this.shownTabId = objTarget.getAttribute('data-tab');
        const objTabs = objTarget.closest('.slds-tabs_default');
        objTarget.setAttribute('aria-selected','true');
        objTabs.querySelector('.slds-is-active a').setAttribute('aria-selected','false');
        objTabs.querySelector('.slds-is-active').classList.remove('slds-is-active');
        objTabs.querySelector('.slds-show').classList.add('slds-hide');
        objTabs.querySelector('.slds-show').classList.remove('slds-show');        
        
        objTarget.parentElement.classList.add('slds-is-active');
        objTabs.querySelector('#'+currentContentId).classList.remove('slds-hide');
        objTabs.querySelector('#'+currentContentId).classList.add('slds-show');
    }
    showRefresh = (event) => {
        const response = JSON.parse(event.detail);
        this.boolShowRefreshIcon = response.showRefresh;
        
    }
    handleRefresh() {
        if (this.boolShowRefreshIcon) {
            this.template.querySelector('c-lwc-dashboard-my-work-e-inventory_-a-c-e').refreshCmp();
        }
    }
}