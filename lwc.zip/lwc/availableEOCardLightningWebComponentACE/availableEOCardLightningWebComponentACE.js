import { LightningElement,wire } from 'lwc';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
//CEAS-82979 Platform Workspace API
import { EnclosingTabId, getTabInfo, focusTab} from 'lightning/platformWorkspaceApi';

import EO_204Message_ACE from '@salesforce/label/c.EO_204Message_ACE';
import EO_403Message_ACE from '@salesforce/label/c.EO_403Message_ACE';
import AvailableEOCard500Message_ACE from '@salesforce/label/c.AvailableEOCard500Message_ACE';
import EngagementOpportunities_ACE from '@salesforce/label/c.EngagementOpportunities_ACE';
import AvailableEOCardTitle_ACE from '@salesforce/label/c.AvailableEOCardTitle_ACE';

export default class AvailableEOCardLightningWebComponentACE extends LightningElement {

    //Console Tab Variables
    //Primary Tab Indicator.
    boolPrimaryTab = false;
    //Used to store tab Data.
    objTabData = null;
    //To show safe Mode error.
    boolShowSafeMode = false;
    //Used for Show/hide spinner.
    boolSpinner = true;
    boolShowCmp = false;
    //Used for show/hide Error Block.
    boolError = false;
    boolWarning = false;
    strErrorMessage = '';
    strTriggerEventName = 'TriggerEOHCDSection';
    //Destination Id if Required.
    strDestinationId = 'AvailableEOCard_ACE';
    //Custom event Name.
    strCustomEventName = 'EODetailsUpdate';
    strUnexpectedError = '';
    strClassName = '';
    lstEOCardData = [];
    intEOCount = 0;
    label = {
        EO_204Message_ACE,
        EO_403Message_ACE,
        AvailableEOCard500Message_ACE,
        EngagementOpportunities_ACE,
        AvailableEOCardTitle_ACE
    }
    //Dynamic class for Yellow and Grey background
    get className() {
        if(this.intEOCount === 0) {
        this.strClassName = 'slds-notify slds-notify_alert';
        } else {
        this.strClassName =  'slds-notify slds-notify_alert slds-alert_warning';
        }
        return this.strClassName;
      }
    set className(value) {
        this.strClassName = value
    }

    
    @wire(EnclosingTabId) enclosingTabId;
    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.fetchTabData();
        } catch (error) {
            //Handle Error
            this.handleErrors(error);
        }

    }

    fetchTabData() {
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objTabData => {
                this.objTabData = objTabData;
                //Always add executeInitialFunctionality function which can be reused for refresh.
                this.executeInitialFunctionality();
    
            }).catch((error) => {
                //Handle Error
                this.handleErrors(error);
                
            });
        }
    }

    executeInitialFunctionality() {
        if (this.objTabData.isSubtab === true) {
            //Always segregate the Main tab and Sub tab functions.
            this.executeSubTabFunctionality();
        } 
    }

    executeSubTabFunctionality() {
        this.boolPrimaryTab = false;
        this.addSubTabListeners();
        this.fireEventToFetchDataFromHCDEOCard();

    }

    fireEventToFetchDataFromHCDEOCard() {
        BaseLWC.fireCustomEvent(this.strTriggerEventName, null, this.strDestinationId,
            true, this.objTabData.parentTabId);
    }

    addSubTabListeners() {
        this.strDynamicCustomEventName = this.strCustomEventName + '_' + this.objTabData.parentTabId;
        window.addEventListener(this.strDynamicCustomEventName, this.fetchCommunicationData);
    }

    fetchCommunicationData = (objEoCardData) => {
        const objResponseData = objEoCardData;
        if (objResponseData && objResponseData.boolError === true) {
            //Do Nothing
        } else {
            const boolFireEvent = objResponseData.detail.boolDataAvailable;
            const boolIntegrationError = objResponseData.detail.boolIntegrationError;
            
            if(boolFireEvent && !boolIntegrationError) {
                if(objResponseData.detail.strAction && objResponseData.detail.strAction === 'Show204Message') {
                    
                    this.boolSpinner = false;
                    this.boolWarning = true;
                    this.boolError = true;
                    this.strErrorMessage = this.label.EO_204Message_ACE;
                } else if (objResponseData.detail.strAction && objResponseData.detail.strAction === 'Show403Message') {
                    
                    this.boolSpinner = false;
                    this.boolWarning = true;
                    this.boolError = true;
                    this.strErrorMessage = this.label.EO_403Message_ACE;
                } else {
                this.lstEOCardData = objResponseData.detail.lstAvailableEOCardData;
                this.intEOCount = objResponseData.detail.lstAvailableEOCardData.length;
                this.boolSpinner = false;
                this.boolWarning = false;
                this.boolError = false;
                }
                this.boolShowCmp = true;
            } else if(boolFireEvent && boolIntegrationError) {
                this.boolError = true;
                this.boolSpinner = false;
                this.boolWarning = false;
                this.strErrorMessage = this.label.AvailableEOCard500Message_ACE;
                this.boolShowCmp = true;
            } else {
                //Do Nothing
            }
        }
    }

//When any of the EO card is selected then get its EOID and send it to HCD Eo Card Cmp so that speicifc EO card can be expanded
    openEoCardHCD(event){
        
        const objParameterstobesent = {
            strOpenEoId : event.currentTarget.dataset.value
        }
        BaseLWC.fireCustomEvent(this.strTriggerEventName, objParameterstobesent, this.strDestinationId,
            true, this.objTabData.parentTabId);
            focusTab(this.objTabData.parentTabId);
        
    }

    disconnectedCallback() {
        window.removeEventListener(this.strDynamicCustomEventName, this.fetchCommunicationData);
     }

     handleErrors(error) {
        //Handle error
        this.strUnexpectedError = error;
     }
}