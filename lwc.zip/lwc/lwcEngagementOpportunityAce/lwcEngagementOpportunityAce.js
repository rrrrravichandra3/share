import { LightningElement, api, track, wire } from 'lwc';
import EO_ScriptLabel_ACE from '@salesforce/label/c.EO_ScriptLabel_ACE';
import EO_LowerPriorityTooltip_ACE from '@salesforce/label/c.EO_LowerPriorityTooltip_ACE';
import EO_OfferAcceptedLabel_ACE from '@salesforce/label/c.EO_OfferAcceptedLabel_ACE';
import EO_Offer_Accepted_Label_Description from '@salesforce/label/c.EO_Offer_Accepted_Label_Description';
import EO_CaseCreatedLabel_ACE from '@salesforce/label/c.EO_CaseCreatedLabel_ACE';
import EO_CaseUpdatedLabel_ACE from '@salesforce/label/c.EO_CaseUpdatedLabel_ACE';
import EO_CaseLabel_ACE from '@salesforce/label/c.EO_CaseLabel_ACE';
import EO_BackLabel_ACE from '@salesforce/label/c.EO_BackLabel_ACE';
import EO_NotesLabel_ACE from '@salesforce/label/c.CaseNotesModal_Notes_ACE';
import EO_PleaseExplainLabel_ACE from '@salesforce/label/c.EO_PleaseExplainLabel_ACE';
import EO_RequiredFieldLabel_ACE from '@salesforce/label/c.EO_RequiredFieldLabel_ACE';
import EO_LowerPriorityLabel_ACE from '@salesforce/label/c.EO_LowerPriorityLabel_ACE';
import EO_SelectAValueLabel_ACE from '@salesforce/label/c.EO_SelectAValueLabel_ACE';
import EO_SaveLabel_ACE from '@salesforce/label/c.EO_SaveLabel_ACE';
import EO_204Message_ACE from '@salesforce/label/c.EO_204Message_ACE';
import EO_403Message_ACE from '@salesforce/label/c.EO_403Message_ACE';
import ViewCaseSummary_NoCasesError_ACE from '@salesforce/label/c.ViewCaseSummary_NoCasesError_ACE';
import retrieveEngagementOpportunities from '@salesforce/apexContinuation/EOControllerLWC_ACE.retrieveEngagementOpportunities';
import checkOutBoundCases from '@salesforce/apex/EOControllerLWC_ACE.checkOutBoundCases';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import DISMISSALL_FIELD from '@salesforce/schema/Case.DismissAll_ACE__c';
import upsertCase from '@salesforce/apex/EOControllerLWC_ACE.upsertCase';
import EO_ViewOutboundCasesButton_ACE from '@salesforce/label/c.EO_ViewOutboundCasesButton_ACE';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
import { openSubtab} from 'lightning/platformWorkspaceApi';

import createEOCases from '@salesforce/apex/EOControllerLWC_ACE.createEOCases';
import eoUpdateCallout from '@salesforce/apex/EOControllerLWC_ACE.eoUpdateCallout';
import {getRecord, getFieldValue} from 'lightning/uiRecordApi';
import PROFILE_NAME_FIELD from '@salesforce/schema/User.Profile.Name';
import USER_ID from '@salesforce/user/Id';
import EO_Evive360Link_ACE from '@salesforce/label/c.EO_Evive360Link_ACE';
import GroupNumberForWalgreensMember_ACE from '@salesforce/label/c.GroupNumberForWalgreensMember_ACE';
export default class LwcEngagementOpportunityAce extends LightningElement {
    dismissAllMap;
    @api
    boolReadOnlyProfile;
    //Global variables.
    @api strRecordId;
    @api strparams;
    emptyArray = []
    strPriorityOne = '1';
    strEOStatusYes = '1';
    boolshowTooltip = false;
    intSelectionLast = 0;
    intSelectionBeforeLast = 0;
    intSelectionCurrent = 0;
    boolClinicalYesPriorityOne;
    boolRequireSaveBtn;
    boolIsButtonAction;
    strSelectedEOId;
    boolAutoOpenCase;
    intSelectedEO;
    strPreviousRequest;
    strEOStatusInvalidTrigger = '5';
    strRecommendedAssetClinicalIntroduction = '1';
    strRecommendedAssetScheduleAnAppointment = '2';
    strProgramLabel = ''; 
    strProgramBackgroundColor = '';
    objEoList = [];  
    strErrorMessage = ''; 
    objEngagementOpportunities = null; 
    boolSpecialMessage204 = false; 
    boolSpecialMessage403 = false;
    strAction = '';
    objCatch;
    strAction = '';
    boolIntegrationErrorEO;
    get boolHasRecords() {
        return this.objEngagementOpportunities !== undefined && this.objEngagementOpportunities !== null && this.objEngagementOpportunities !== undefined && this.objEngagementOpportunities.eoList !== null && this.objEngagementOpportunities.eoList.length > 0;
    }
     
    @track boolIsEoUser='';
    @track boolIsScheduled = false;
    get boolIsRiskStats() {
        return !this.boolIsEoUser && this.boolriskStrat;
    }
    @api objPlanSummaryData;
    strRationaleValue = '';
    boolInitializing = false;
     filteredTemplateData = [];
    lstRecommendedAssets = [];
    currentTabId;
    @api objTabData;
    boolRendered = true;
    intCount = 1;
    strOne = 'Accepted';
    strTwo = 'Interested Later';
    strThree = 'Not Interested';
    strFour = 'Not Applicable';
    strFive = 'Already Initiated/Engaged';
    strSix = 'Member Prefers to Schedule';
    mapEODescription;
    mapRecommendedAssets;
    mapEOStatus;
    mapRationalForLowerPriority;
    mapStatusReasonDependency;
    STRING_EO_STATUS_YES = '1';
    strInteractionLogIdInternal;
    STRING_EO_STATUS_INTERESTED_LATER = '2';
    STRING_EO_STATUS_NOT_INTERESTED = '3';
    STRING_EO_STATUS_ALREADY = '4';
    STRING_EO_STATUS_INVALID_TRIGGER = '5';
    STRING_EO_STATUS_PREFERES_SCHEDULE = '6';
    lstRationalForLowerPriority = [];
    dismissAllValues;
    selectedDismissAllValue;
    boolShowEODimissModal = false;
    boolSaveBtnClicked = false;
    strAddOnServices;
    strCaseOne;
    strCaseTwo;
    strCaseThree;
    objAvailableEOData;
    boolCbcApiCallAvailable = false;
    boolAccountsAPICallAvailable = false;
    strAgentId;
    dismissAllOptions = [];
    disableDismissAll = false;
    @api boolIsClinicalIntroductionPresent = false;
    boolIsClinicalIntroductionSubmit = false;
    label = {
        EO_ScriptLabel_ACE,
        EO_OfferAcceptedLabel_ACE,
        EO_Offer_Accepted_Label_Description,
        EO_CaseCreatedLabel_ACE,
        EO_CaseUpdatedLabel_ACE,
        EO_CaseLabel_ACE,
        EO_BackLabel_ACE,
        EO_NotesLabel_ACE,
        EO_PleaseExplainLabel_ACE,
        EO_RequiredFieldLabel_ACE,
        EO_LowerPriorityLabel_ACE,
        EO_SelectAValueLabel_ACE,
        EO_204Message_ACE,
        EO_403Message_ACE,
        ViewCaseSummary_NoCasesError_ACE,
        EO_SaveLabel_ACE,
        EO_LowerPriorityTooltip_ACE,
        EO_ViewOutboundCasesButton_ACE,
        EO_Evive360Link_ACE,
        GroupNumberForWalgreensMember_ACE
    };
    //CEAS-77478
    strCaseType = '';
    strCaseSubType = '';
    strGuidingNotes = '';
    clinicalButtonEvent;
    EOUSER_PROFILE = 'EO User';
    @track cssClassCall = 'slds-button slds-button_brand buttonBorder';
    @track cssClassChat = 'slds-button slds-button_neutral buttonBorder';
    @track showScriptToCopy = false;
    @track strRiskStrat ='';
    @track boolriskStrat = true;
    STRING_RISK_STRAT_G = 'G';
    STRING_RISK_STRAT_Y = 'Y';
    STRING_RISK_STRAT_R = 'R';
    STRING_TIER_1 = 'TIER 1';
    STRING_TIER_2 = 'TIER 2';
    STRING_TIER_3 = 'TIER 3';
    @track boolIsScheduledAccepted = false;
    @track boolChatDisabled = false;
    boolIsAlreadyInitiated = false;
    boolIsSaveClicked = false;
    strCreatedCaseId;
    get boolErrorMessageNotNull() {
        return this.strErrorMessage;
    }

    get boolNoRecordsMessage() {
        return !this.boolHasRecords && !this.boolHasOutboundOpenCases && (this.strErrorMessage === null || this.strErrorMessage === '' || this.strErrorMessage === undefined);
    }

    get boolMessageSectionError() {
        return !this.boolSpecialMessage204 && !this.boolSpecialMessage403;
    }

    get boolHasMessageToDisplay() {
        return this.strErrorMessage || (!this.strErrorMessage && !this.boolHasRecords);
    }

    get boolhideEvive() {
        return this.objPlanSummaryData && this.objPlanSummaryData.strAceLineOfBusiness === 'GMS' && this.objPlanSummaryData.strAccountNumber === this.label.GroupNumberForWalgreensMember_ACE;
    }

    @wire(getPicklistValues, { recordTypeId: '012000000000000AAA', fieldApiName: DISMISSALL_FIELD })
    picklistValues({ data}) {
        if (data) {
            this.dismissAllValues = data.values;
           this.dismissAllMap = new Map();
            this.dismissAllValues.forEach((elem) => {
                if(this.boolIsEoUser) {
                    if (elem.value !== '5' && elem.value !== '6') {
                        this.dismissAllOptions.push({
                            label: elem.label,
                            value: elem.label
                        });
                        this.dismissAllMap.set(elem.label, elem.value);
                    }
                } else {
                    this.dismissAllOptions.push({
                        label: elem.label,
                        value: elem.label
                    });
                    this.dismissAllMap.set(elem.label, elem.value);
                }
            }) 
           }
    }
    enableRefresh(){
        const spinnerCheck = new CustomEvent('spinnerlogic', {
            detail: { spinner: false,
            boolRefreshDisable : false }
        });

        // Fire the custom event

        this.dispatchEvent(spinnerCheck);
    }

    handleDismissAllChange = (event) => {
        this.selectedDismissAllValue = event.detail.value;
        this.boolShowEODimissModal = true;
       
    };

    switchChannel(event) {
        let buttonName= event.target.name;
        if(buttonName === 'callButton') {
            this.cssClassCall = 'slds-button slds-button_brand buttonBorder';
            this.cssClassChat = 'slds-button slds-button_neutral buttonBorderUnselected';
            this.showScriptToCopy = false;
    
        } else if (buttonName === 'chatButton') {
            this.cssClassChat = 'slds-button slds-button_brand buttonBorder';
            this.cssClassCall = 'slds-button slds-button_neutral buttonBorderUnselected';
            this.showScriptToCopy = true;    
        } else if (buttonName === 'secureMessageButton') {
            this.cssClassChat = 'slds-button slds-button_neutral buttonBorder';
            this.cssClassCall = 'slds-button slds-button_neutral buttonBorder';
            this.showScriptToCopy = true;        } 
    }

    copyToClipboard(event){
        event.preventDefault();
        let strHTMLToBeCopied = '';
        strHTMLToBeCopied = event.currentTarget.dataset.copytext;

        const clipboardlistener = (objEvent) => {
            objEvent.clipboardData.setData("text/html", strHTMLToBeCopied);
	        objEvent.clipboardData.setData("text/plain", strHTMLToBeCopied);
	        objEvent.preventDefault();
        }

        document.addEventListener("copy", clipboardlistener);
        document.execCommand("copy");
        document.removeEventListener("copy", clipboardlistener);



    }


    connectedCallback() {
        this.executeInitialFunctionaltity();
    }
    strProfile
    @wire(getRecord, {
        recordId: USER_ID,
        fields: [PROFILE_NAME_FIELD]
    }) wireUserData({error, data}) {
        if (data) {
            const strProfileName = data.fields.Profile.value.fields.Name.value;
            this.strProfile = strProfileName;
            this.boolIsEoUser = strProfileName === this.EOUSER_PROFILE || strProfileName === this.SYSTEM_ADMIN_PROFILE;
        } else if (error) {

        }
    }
    boolHasOutboundOpenCases = false;
    get showOutboundCases() {
        if (this.boolHasOutboundOpenCases && this.objPlanSummaryData && this.objPlanSummaryData.strAceLineOfBusiness !== 'Government-Medicare Supplemental') {
            return true;
        }
        return false;
    }
    get showClinicalCmp() {
        if (this.objPlanSummaryData && this.objPlanSummaryData.strAceLineOfBusiness !== 'Government-Medicare Supplemental' && this.objPlanSummaryData.strAceLineOfBusiness !== 'Government-Medicare' && 
        (this.objPlanSummaryData.strAceLineOfBusiness !== 'Government-Medicaid' || this.objPlanSummaryData.strCorporationCode !== 'NM1')) {
            return true;
        }
        return false;
    }
    get notMedSupp() {
        return this.objPlanSummaryData && this.objPlanSummaryData.strAceLineOfBusiness !== 'Government-Medicare Supplemental';
    }
    
    executeInitialFunctionaltity(){
        checkOutBoundCases({'idRecord':this.strRecordId}).then(objResult => {
            if (objResult) {
                this.boolHasOutboundOpenCases = true;
            }
        }).catch(error => {

        })
        retrieveEngagementOpportunities({
            strRecordId: this.strparams.id,
            objStr: JSON.stringify(this.strparams),
            isEoUser: this.boolIsEoUser
        }).then((data) => {
               
                const objData = JSON.parse(data);
                if(objData) {
                    this.objEngagementOpportunities = objData[0];
                    if(objData[0] && objData[0].eoList) {
                        this.objEoList = objData[0].eoList;
                    }

                    this.strProgramLabel = objData[1];
                    this.strProgramBackgroundColor = objData[2];
                    this.boolSpecialMessage204 = objData[3];
                    this.boolSpecialMessage403 = objData[4];
                    this.mapEODescription = objData[5];
                    this.mapRecommendedAssets = objData[6][0];
                    this.mapEOStatus = objData[6][1];
                    this.mapRationalForLowerPriority = objData[6][2];
                    this.mapStatusReasonDependency = objData[6][3];
                    this.strErrorMessage = objData[7];
                    this.strAgentId = objData[6][4];
                    if(this.objEoList && this.objEoList.length) {
                        this.setClassData();
                    }
                }
                this.boolInitializing = true;
                this.childSpinnerLogic(false);
                this.setPlanSummaryData();
                //CEAS-82954
                this.setAvailableEOCardData();
                this.sendMessageToAvailableEOCardHelper(null);
                if(this.strErrorMessage || (!this.strErrorMessage && !this.boolHasRecords)) {
                    this.enableRefresh();
                }
                this.boolIsClinicalIntroductionPresent = this.checkClinicalIntroduction(this.objEngagementOpportunities);
            }).catch((error) => {
               this.handleError(error)
            });
        //Add listner for Available EO Card
        this.availableEOListner();
    }
    setAvailableEOCardData() {
        let boolDataAvailableEO = false;
        let boolIntegrationErrorEO = true;
        let strAction = '';
        this.objAvailableEOData = {};
        if(this.objEoList && !this.strErrorMessage) {
            boolDataAvailableEO = true;
            boolIntegrationErrorEO = false;
        } else if(this.strErrorMessage) {
            boolDataAvailableEO = true;
            boolIntegrationErrorEO = true;
            strAction = '';
        }else if(this.boolSpecialMessage204 && !this.boolHasRecords) {
            boolDataAvailableEO = true;
            boolIntegrationErrorEO = false;
            strAction = 'Show204Message';
        } else if(this.boolSpecialMessage403 && !this.boolHasRecords) {
            boolDataAvailableEO = true;
            boolIntegrationErrorEO = false;
            strAction = 'Show403Message';
        } else if(!this.boolSpecialMessage403 && !this.boolSpecialMessage204 && !this.boolHasRecords) {
            boolDataAvailableEO = true;
            boolIntegrationErrorEO = false;
            strAction = 'Show403Message';
        } else {
            //Do Nothing
        }
        this.boolIntegrationErrorEO = boolIntegrationErrorEO;
        this.strAction = strAction;
        if(strAction === ''&& !boolIntegrationErrorEO) {
            this.formatDataforAvailableEOCard();
        }
    }
    formatDataforAvailableEOCard() {
        const objEoList = this.objEoList;
        const objRecAssets = this.mapRecommendedAssets;
        let lstAvailableEOCardData = [];
        if(objEoList && this.objEoList.length > 0) {
            for (let intIterator = 0; intIterator < objEoList.length; intIterator++) {
                const objAvailableEOCardData = {
                    strEoId : objEoList[intIterator].eoID,
                    strLabel : objRecAssets[objEoList[intIterator].eoRecommendedAsset],
                    strDescription : objEoList[intIterator].eoDescription
                }
                lstAvailableEOCardData.push(objAvailableEOCardData);

            }
        }
        this.objAvailableEOData = lstAvailableEOCardData;
    }
    availableEOListner() {
        //objEngagementOpportunities;
        const objEOCardData = this.sendMessageToAvailableEOCardHelper;
        const strEventName = 'TriggerEOHCDSection_' + this.objTabData.tabId;
        window.addEventListener(strEventName, objEOCardData );
    }
    sendMessageToAvailableEOCardHelper = (objEventData) => {
        const boolDataAvailable = this.boolHasRecords;
        let strEOID = '';
        if(objEventData && typeof objEventData.detail === 'string') {
            const objData = JSON.parse(objEventData.detail);
            if(objData.strMessage) {
                strEOID = objData.strMessage.strOpenEoId;

            const querySelectorString = '[data-id="' + strEOID + '"]';
            if(this.template.querySelector(querySelectorString)) {
            this.template.querySelector(querySelectorString).click();
            }   
            }
        }
        if(this.objEngagementOpportunities){
            const lstAvailableEOCardData = this.objAvailableEOData;
            const strAction = this.strAction;
            const boolIntegrationError = this.boolIntegrationErrorEO;

            const strParameterToBeSent = {
                "boolDataAvailable" : boolDataAvailable,
                "lstAvailableEOCardData" : lstAvailableEOCardData,
                "boolIntegrationError" : boolIntegrationError,
                "strAction":strAction
            };
            let objCustomEvent = new CustomEvent('EODetailsUpdate_' + this.objTabData.tabId, {detail : strParameterToBeSent});
            window.dispatchEvent(objCustomEvent); 
        }
    }
    checkClinicalIntroduction(objEngagementOpportunities) {
        let isClinical =false;
        if(objEngagementOpportunities && objEngagementOpportunities.eoList){
            objEngagementOpportunities.eoList.forEach((objEO) =>{
                if(this.mapRecommendedAssets && this.mapRecommendedAssets[objEO.eoRecommendedAsset] === 'Clinical Introduction') {
                    isClinical = true;
                }
            });
        }
        if(isClinical) {
            //Send Event to disable Guiding Care Button
            let objCustomEvent = new CustomEvent('clinicalintroductionasset', 
                                    {detail : isClinical}
                                    );
            this.dispatchEvent(objCustomEvent);  
        }
        return isClinical;
    }
    get paddingClass() {
        if (this.boolIsEoUser) {
            return 'slds-p-around_medium';
        }
        return '';
    }
    renderedCallback() {

        if(this.boolRendered && this.template.querySelectorAll('.preSelection .selectionButton') && this.template.querySelectorAll('.preSelection .selectionButton').length ) {
            const lstButtons = this.template.querySelectorAll('.preSelection .selectionButton');

        const nodelistToArray = Array.apply(null, lstButtons);
      
        nodelistToArray.forEach((acc) => {
            const recommendedAsset = acc.dataset.recommendedasset;
            const eoStatus = acc.dataset.eostatus;
            this.lstRecommendedAssets.forEach(el => {
                if (el.strRecommendedAsset === recommendedAsset && el.lstActiveButtons.includes(eoStatus)) {
                    acc.parentElement.classList.remove('slds-hide');
                    
                }
            })
        });

        this.boolRendered = false;
        
        }
        
    }
    childSpinnerLogic(boolSpinnerShow) {
        const spinnerCheck = new CustomEvent('spinnerlogic', {
            detail: { spinner: boolSpinnerShow,
                boolRefreshDisable : true }
        });

        // Fire the custom event

        this.dispatchEvent(spinnerCheck);
    }

    setClassData() {
        this.filteredTemplateData = this.objEngagementOpportunities.eoList.map((objEO) => {
            const intCount = this.intCount;
            const strId = `${intCount}-${objEO.eoID}`;
            const additionalProperties = {
                strId: `${intCount}-${objEO.eoID}`,
                intCount: intCount,
                strParentClass: `parent-${strId}`,
                strCollapseButtonDataTarget: `#collapse-${strId}`,
                strCollapseButtonClass: `collapse-button-${strId}`,
                strCollapseId: `collapse-${strId}`,
                strNotesId: `notes-${strId}`,
                strExplanationId: `explanation-${strId}`,
                strRationaleId: `rationale-${strId}`,
                strPopOverId: `popover-${strId}-${objEO.eoRecommendedAsset}`,
                eoRecommendedAssetUI: this.mapRecommendedAssets[objEO.eoRecommendedAsset],
                boolClinicalIntroductionRecommenededAsset: (this.mapRecommendedAssets[objEO.eoRecommendedAsset] === 'Clinical Introduction'),
                eoScriptList : objEO.eoScriptList.filter(obj=> obj.boolIsCall === true)
            };
            this.intCount++;
           
            return { ...objEO, ...additionalProperties };
        });

     
     
        for (const intIndex in this.mapRationalForLowerPriority) {
            this.lstRationalForLowerPriority.push({ label: this.mapRationalForLowerPriority[intIndex], value: intIndex });
        }
        if(this.lstRationalForLowerPriority && this.lstRationalForLowerPriority.length) {
            this.lstRationalForLowerPriority.sort(function(a, b){return a.value-b.value});
        }
        Object.keys(this.mapStatusReasonDependency).forEach(el=>{
            this.lstRecommendedAssets.push({
                                strRecommendedAsset: el,
                                lstActiveButtons: [...this.mapStatusReasonDependency[el]]
                            });
                        
        })
     
        this.lstRationalForLowerPriority = [...this.lstRationalForLowerPriority];
    }

    showTooltip() {
        this.boolshowTooltip = true;
    }

    hideTooltip() {
        this.boolshowTooltip = false;
    }

    toggleAccordion(objEvent) {
        if(!(objEvent.target.classList.contains('accordionHeader') || objEvent.target.closest(".accordionHeader"))
         && !objEvent.target.classList.contains('eoDescription') && !objEvent.target.classList.contains('slds-accordion__list-item')){
            return;
        }
        const objTarget = objEvent.currentTarget;
        if (objTarget.tagName !== 'LI') {
            return;
        }
        const boolIsExpanded = objTarget.children[0].classList.contains('slds-is-open');
        const objGlobalParent = objTarget.parentElement.parentElement.parentElement;
        if (objGlobalParent.querySelector('.slds-is-open')) {
            objGlobalParent.querySelector('.slds-is-open').classList.remove('slds-is-open');
        }
        if (objGlobalParent.querySelector('ul.expanded')) {
            objGlobalParent.querySelector('ul.expanded').classList.remove('expanded');
        }

        if (!boolIsExpanded) {
            objTarget.children[0].classList.add('slds-is-open');
            objTarget.parentElement.classList.add('expanded');
        }
    }
    handleCancelEOModal = () => {
        this.boolShowEODimissModal = false;
        this.selectedDismissAllValue = '';
    };
    handleSubmitEOModal = () => {
        if (BaseLWC.isNotUndefinedOrNull(this.selectedDismissAllValue)) {
            this.createEoCases();
        }
    };
    @api createClincalIntroductionCase (strNotes) {
        this.strCaseSubType = 'Clinical Introduction';
        this.strCaseType = 'Engagement Opportunity';
        this.strGuidingNotes = strNotes;
        this.boolIsClinicalIntroductionSubmit = true;
        this.createEoCases();

}
    async createEoCases() {
        try {
            const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + this.strRecordId;
            const strInteractionLogId = BaseLWC.helperBaseGetItem(localStorageKey);
            const boolProvider = BaseLWC.helperBaseGetUrlParameters('ProviderSearch', this.strBaseCurrentTabUrl);
            const objCaseDefaults = {};
            const objResult = await createEOCases({'caseDetails' : JSON.stringify({
                strEngagementOpportunities: JSON.stringify(this.objEngagementOpportunities),
                mid: this.objPlanSummaryData.strMemberId,
                strGroupNum: this.objPlanSummaryData.strGroupNumber,
                strPolicyId: this.objPlanSummaryData.strPolicyId,
                strSubscriberId: this.objPlanSummaryData.strSubscriberId,
                strCorpCode: this.objPlanSummaryData.strCorporationCode,
                strAccountNumber: this.objPlanSummaryData.strAccountNumber,
                strInteractionId: strInteractionLogId,
                strSectionNumber: this.objPlanSummaryData.strGroupSectionNumber,
                strGroupCostCenter: this.objPlanSummaryData.strGroupCostCenterNumber,
                strGroupName: this.objPlanSummaryData.strGroupNumber,
                strCMID: this.objPlanSummaryData.strClientMemberId,
                strProductType: this.objPlanSummaryData.strNetwork,
                strMultiPlan: this.objPlanSummaryData.strMultiPlan,
                pgIndicator: this.objPlanSummaryData.boolPgIndicator,
                strEffectiveDate: this.objPlanSummaryData.strEffectiveDate,
                strTerminationDate: this.objPlanSummaryData.strTerminationDate,
                strCoverageCodes: this.strAddOnServices, 
                boolAccountsAPICallAvailable: this.boolAccountsAPICallAvailable,
                boolCbcApiCallAvailable: this.boolCbcApiCallAvailable,
                strLineOfBusiness: this.objPlanSummaryData.strAceLineOfBusiness,
                //CEAS-62221
                boolIsProvider: boolProvider,
                objCaseDefaults: JSON.stringify(objCaseDefaults),
                strDismissAllInteger: this.dismissAllMap.get(this.selectedDismissAllValue),
                //CEAS-77478
                strCaseType : this.strCaseType,
                strCaseSubType : this.strCaseSubType,
                strGuidingNotes : this.strGuidingNotes,
                boolClinicalIntroduction: this.boolIsClinicalIntroductionSubmit,
                boolIsEoUser: this.boolIsEoUser,
                strCreatedCaseId: this.strCreatedCaseId
            })});
            if (BaseLWC.stringIsNotBlank(objResult)) {
                if(this.boolIsClinicalIntroductionSubmit && JSON.parse(objResult)) {
                    let strCaseId = JSON.parse(objResult).strCaseId;
                    eoUpdateCallout({
                        strObjRequest : JSON.parse(objResult).strEOUpdateRequest,
                        strCreatedCaseId : JSON.parse(objResult).strCaseId,
                        boolClinicalIntroduction: this.boolIsClinicalIntroductionSubmit,
                        boolIsScheduledAccepted: this.boolIsScheduledAccepted,
                        boolIsEoUser: this.boolIsEoUser
                    }).then((objUpdateResponse)=>{
                        const objResponseMap = new Object();
                        objResponseMap['apiStatus'] =  objUpdateResponse;
                        objResponseMap['strCaseId'] =  strCaseId;
                    let objCustomEvent = new CustomEvent('submitclinicalaccept',{detail : JSON.stringify(objResponseMap)});
                    this.dispatchEvent(objCustomEvent);
                    this.performActionsOnCaseUpdate();
                    this.clinicalButtonEvent.classList.add('slds-button_brand');
                    this.clinicalButtonEvent.classList.add('selectedPriorityOne');
                    }).catch((error)=>{
                        this.handleError(error)
                    })
                } else {
                this.boolShowEODimissModal = false;
                this.selectedDismissAllValue = '';
                }
               
            }
        } catch (objException) {
           
            if (this.template.querySelector('c-lwc-e-o-dismiss-all-modal-component-_-a-c-e')) {
                this.template.querySelector('c-lwc-e-o-dismiss-all-modal-component-_-a-c-e').showError();
            }
        }
    }

    shouldShowRational = (strCurrentSelection, objPostSelection) => {
        if (!isNaN(strCurrentSelection) && typeof objPostSelection !== 'undefined' && objPostSelection !== null && parseInt(strCurrentSelection, 10) !== this.intSelectionCurrent) {
            const objRationale = objPostSelection.querySelector(`[data-class="rationale"]`);
            this.hide(objRationale);
            this.intSelectionBeforeLast = this.intSelectionLast;
            this.intSelectionLast = this.intSelectionCurrent;
            this.intSelectionCurrent = parseInt(strCurrentSelection, 10);

            //Now, we define all the combinations where the Rational field is shown.
            if (
                this.intSelectionCurrent !== parseInt(this.strPriorityOne, 10) &&
                ((this.intSelectionCurrent === 3 && this.intSelectionLast === 0 && this.intSelectionBeforeLast === 0) ||
                    (this.intSelectionCurrent === 2 && this.intSelectionLast === 3 && this.intSelectionBeforeLast === 0) ||
                    (this.intSelectionCurrent === 2 && this.intSelectionLast === 0 && this.intSelectionBeforeLast === 0) ||
                    (this.intSelectionCurrent === 2 && this.intSelectionLast === 0 && this.intSelectionBeforeLast === 0) ||
                    (this.intSelectionCurrent === 3 && this.intSelectionLast === 2 && this.intSelectionBeforeLast === 0) ||
                    (this.intSelectionCurrent === 3 && this.intSelectionLast === 1 && this.intSelectionBeforeLast === 0))
            ) {
                this.show(objRationale);
            }
        }
    };

    handlePreselectionButtonClick(event) {
        event.stopPropagation();
        const objEvent = event.currentTarget;
        if (objEvent) {
            let boolAutoOpen = false;
            const strCurrentRecommendedAsset = objEvent.dataset.recommendedasset;
            const streoId = objEvent.dataset.eoid;
            const strEOStatus = objEvent.dataset.eostatus;
            const objPostSelection = this.template.querySelector(`.postSelection[data-eoid="${streoId}"][data-recommendedasset="${strCurrentRecommendedAsset}"]`);
            const objPreSelection = this.template.querySelector(`.preSelection[data-eoid="${streoId}"][data-recommendedasset="${strCurrentRecommendedAsset}"]`);
            const strPriority = objPreSelection.dataset.priority;
            this.strSelectedEOId = objEvent.dataset.eoid;
            this.boolIsAlreadyInitiated = false;
            this.boolIsSaveClicked = false;
            const objPostSelectedButton = objPostSelection.querySelector('.selectedButton');
            objPostSelectedButton.innerHTML = objEvent.innerHTML;
            objPostSelectedButton.setAttribute('data-eostatus', strEOStatus);
            const objPostSaveTrigger = objPostSelection.querySelectorAll('.saveTrigger');
            const objNewPostSave = [...objPostSaveTrigger];
            objNewPostSave.forEach(objData=>{
                objData.setAttribute('data-eostatus', strEOStatus);

            });
            if(!this.boolIsEoUser && this.mapEOStatus[strEOStatus] === 'Already Initiated/Engaged') {
                this.boolIsAlreadyInitiated = true;
            }
            if(strCurrentRecommendedAsset && this.mapRecommendedAssets && this.mapRecommendedAssets[strCurrentRecommendedAsset] === 'Clinical Introduction' && objPostSelectedButton.innerHTML === 'Accepted') {
                //Open Notes Modal 
                const objCustomEvent = new CustomEvent('clinicalaccepted',  {detail:{
                    "objEvent": objEvent,
                    "boolIsEoUser": this.boolIsEoUser
                }});
                
                this.clinicalButtonEvent = objEvent;
                this.dispatchEvent(objCustomEvent);
            } else {
            //Now, we show the corresponding additional section.
            this.boolClinicalYesPriorityOne = false;
            this.show(objPostSelection);
            this.boolRequireSaveBtn = false;

            const lstPostSelectionDivs = objPostSelection.querySelectorAll(`[data-class="additionalFields"],[data-class="explain"], [data-class="notes"]`);
            //hide after loop
            const objList = [...lstPostSelectionDivs];
            objList.forEach((obj) => {
                this.hide(obj);
            });
            this.shouldShowRational(strPriority, objPostSelection);
            if (strPriority !== this.strPriorityOne) {
                this.hide(objPreSelection);

                this.reuseableTemplateQuerySelector(objPostSelection, `[data-class="additionalFields"]`, true, false);
                if (strEOStatus === this.strEOStatusInvalidTrigger) {
                    this.reuseableTemplateQuerySelector(objPostSelection, `[data-class="explain"]`, true, false);
                } else if (strEOStatus === this.strEOStatusYes && strCurrentRecommendedAsset === this.strRecommendedAssetClinicalIntroduction) {
                    this.reuseableTemplateQuerySelector(objPostSelection, `[data-class="notes"]`, true, false);
                } else {
                    //Do Nothing
                }
                this.boolRequireSaveBtn = true;
            } else if (strEOStatus === this.strEOStatusInvalidTrigger) {
                this.hide(objPreSelection);

                this.reuseableTemplateQuerySelectorAll(objPostSelection, `[data-class="additionalFields"],[data-class="explain"]`, true, false);
                this.boolRequireSaveBtn = true;
            } else if (strEOStatus === this.strEOStatusYes && strCurrentRecommendedAsset === this.strRecommendedAssetClinicalIntroduction) {
                this.hide(objPreSelection);

                this.reuseableTemplateQuerySelectorAll(objPostSelection, `[data-class="additionalFields"],[data-class="notes"]`, true, false);

                this.boolClinicalYesPriorityOne = true;
                this.boolRequireSaveBtn = true;
            } else {
                this.hide(objPostSelection);
                this.reuseableTemplateQuerySelector(objPreSelection, '.createdCase', true, false);
                const lstSelectionButton = this.template.querySelectorAll('.selectionButton');
                const arrSelectionButton = [...lstSelectionButton];
                arrSelectionButton.forEach((obj) => {
                    obj.setAttribute('disabled', true);
                });
            }

            const lstPreselectionButton = objPreSelection.querySelectorAll('.selectionButton');
            const arrLstSelectionButton = [...lstPreselectionButton];
            this.removeNeutralClass(arrLstSelectionButton);
            objEvent.classList.add('slds-button_brand');
            objEvent.classList.add('selectedPriorityOne');

            //Now, we create the Case.
            if (strCurrentRecommendedAsset === this.strRecommendedAssetScheduleAnAppointment && strEOStatus === this.strEOStatusYes && strPriority === this.strPriorityOne && this.boolIsEoUser) {
                boolAutoOpen = true;
            }
            if(strCurrentRecommendedAsset && this.mapRecommendedAssets && typeof this.mapRecommendedAssets[strCurrentRecommendedAsset] === 'string' && this.mapRecommendedAssets[strCurrentRecommendedAsset].toUpperCase() === 'CATASTROPHIC EVENT' && objPostSelectedButton.innerHTML.toUpperCase() === 'ACCEPTED') {
                boolAutoOpen = true;
            }
            this.boolIsButtonAction = true;
            this.upsertCaseRecord(objEvent, boolAutoOpen);
            }
        }
    }

    // hide an element
    hide = (elem) => {
        if(elem) {
            elem.classList.add('slds-hide');
        }
    };

    // show an element
    show = (elem) => {
        if(elem) {
            elem.classList.remove('slds-hide');
        }
    };

    reuseableTemplateQuerySelector = (ObjQuerySelector, strClass, strShow, strHide) => {
        if(ObjQuerySelector) {
            const newObjQuerySelector = ObjQuerySelector.querySelector(strClass);
            if (strShow) {
                this.show(newObjQuerySelector);
            } else if (strHide) {
                this.hide(newObjQuerySelector);
            } else {
                // Do Nothing
            }
        }
    };

    reuseableTemplateQuerySelectorAll = (ObjQuerySelector, strClass, strShow, strHide) => {
        if(ObjQuerySelector) {
            const newObjQuerySelectorAll = ObjQuerySelector.querySelectorAll(strClass);
            const lstObjQuerySelectorAll = [...newObjQuerySelectorAll];
            lstObjQuerySelectorAll.forEach((obj) => {
                if (strShow) {
                    this.show(obj);
                } else if (strHide) {
                    this.hide(obj);
                } else {
                    // Do Nothing
                }
            });
        }
    };

    upsertCaseRecord = (objSelectedElement, boolOpenRecordAfterCreation) => {
        const strEOId = objSelectedElement.dataset.eoid;
        const strEOName = objSelectedElement.dataset.eoname;
        const strPriority = objSelectedElement.dataset.priority;
        const strStatus = objSelectedElement.dataset.eostatus;

        //We set the autoopen action.
        this.boolAutoOpenCase = boolOpenRecordAfterCreation;

        //First, we get all the values.
        this.intSelectedEO = objSelectedElement.dataset.eonumber;
        this.strSelectedEOId = objSelectedElement.dataset.eoid;
        const strRecommendedAsset = objSelectedElement.dataset.recommendedasset;
        const strStatusReason = this.template.querySelector(`[data-id="rationale-${strPriority}-${strEOId}"]`).value;
        const strPleaseExplain = this.template.querySelector(`[data-id="explanation-${strPriority}-${strEOId}"]`).value;
        const strNotes = this.template.querySelector(`[data-id="notes-${strPriority}-${strEOId}"]`).value;
        if(!this.boolIsEoUser && strRecommendedAsset && this.mapRecommendedAssets && this.mapRecommendedAssets[strRecommendedAsset] === 'Schedule an Appointment' && strStatus == '1'){
            this.boolIsScheduledAccepted = true;
        } else{
            this.boolIsScheduledAccepted = false;
        }
        
        if(!this.boolIsEoUser && strRecommendedAsset && this.mapRecommendedAssets && this.mapRecommendedAssets[strRecommendedAsset] === 'Schedule an Appointment') {
            this.boolIsScheduled = true;
        } else {
            this.boolIsScheduled = false;
        }
        const objParamsForApex = {
            intSelectedEOUI: parseInt(this.intSelectedEO, 10),
            strEOIdUI: strEOId,
            strEONameUI: strEOName,
            strPriorityUI: strPriority,
            strStatusUI: strStatus,
            strStatusReasonUI: strStatusReason,
            strRecommendedAssetUI: strRecommendedAsset,
            strNotesUI: strNotes,
            strPleaseExplainUI: strPleaseExplain,
            mapEOStatusUI: this.mapEOStatus,
            mapEODescriptionUI: this.mapEODescription,
            mapRecommendedAssetsUI: this.mapRecommendedAssets,
            eoListUI : JSON.stringify(this.objEoList),
            strAddOnServicesUI : this.strAddOnServices,
            boolCbcApiCallAvailableUI : this.boolCbcApiCallAvailable,
            boolAccountsAPICallAvailableUI : this.boolAccountsAPICallAvailable,
            strAgentIdUI : this.strAgentId,
            strCaseOne : this.strCaseOne,
            strCaseTwo : this.strCaseTwo,
            strCaseThree : this.strCaseThree,
            strInteractionLogIdInternal : this.strInteractionLogIdInternal,
            strPreviousRequest : this.strPreviousRequest,
            boolIsEoUser : this.boolIsEoUser,
            boolIsScheduledAccepted: this.boolIsScheduledAccepted,
            boolIsScheduled : this.boolIsScheduled
        }

        //Now we send the request to upsert the Case record and to send the data to Aerial.
        upsertCase({
            objStr: JSON.stringify(this.strparams),
            objParamsForApex : JSON.stringify(objParamsForApex)

        }).then((objResult) => {
                if(objResult && objResult.includes(';')) {
                    const lstResult = objResult.split(';');
                    this.strCaseOne = '';
                    this.strCaseTwo = '';
                    this.strCaseThree = '';
                    this.strInteractionLogIdInternal = '';
                    if(lstResult[4] && lstResult[4] !== 'null') {
                        this.strCaseOne = lstResult[4];
                        this.strCreatedCaseId = this.strCaseOne;
                    }
                    if(lstResult[5] && lstResult[5] !== 'null') {
                        this.strCaseTwo = lstResult[5];
                        this.strCreatedCaseId = this.strCaseTwo;
                    }
                    if(lstResult[6] && lstResult[6] !== 'null') {
                        this.strCaseThree = lstResult[6];
                        this.strCreatedCaseId = this.strCaseThree;
                    }
                    if(lstResult[7] && lstResult[7] !== 'null') {
                        this.strInteractionLogIdInternal = lstResult[7];
                    }
                    const boolShouldSendUpdate = lstResult[0] === 'true';
                    this.strPreviousRequest = lstResult[8];
                    this.updateCaseLink(lstResult[2], lstResult[3], lstResult[1], boolShouldSendUpdate);
                }
            }).catch((error) => {
               this.handleError(error)
            });
    };

    handleError(error) {
        this.objCatch = error;
    }

    saveSelection(objButton) {
        objButton.stopPropagation();
        let boolAutoOpen = false;
  
        const objEvent = objButton.currentTarget;
        const streoIdLocal = objEvent.dataset.eoid;
        const strRecommendedAssetLocal = objEvent.dataset.recommendedasset;
        this.boolIsSaveClicked = true;
        const objPostSelection = this.template.querySelector(`.postSelection[data-eoid="${streoIdLocal}"][data-recommendedasset="${strRecommendedAssetLocal}"]`);
        if (objEvent.getAttribute('type') === 'button') {
            const lstExplnationRationale = objPostSelection.querySelectorAll('.explanation, .rationale');
            const arrExplanationRationale = [...lstExplnationRationale].filter(el=>el.clientHeight > 0);
           if (arrExplanationRationale.length === 0 || this.validateInputField(arrExplanationRationale) || this.boolClinicalYesPriorityOne) {
                if (objEvent.classList.contains('slds-button_neutral')) {
                    objEvent.classList.remove('slds-button_neutral');
                    objEvent.classList.add('slds-button_brand');
                }

                //Now, we save the record.
                    boolAutoOpen = true;
                this.upsertCaseRecord(objEvent, boolAutoOpen);
            } else {
                if (objEvent.classList.contains('slds-button_brand')) {
                    objEvent.classList.remove('slds-button_brand');
                    objEvent.classList.add('slds-button_neutral');
                }
            }
            this.boolSaveBtnClicked = true;
        } else {
            this.upsertCaseRecord(objEvent, false);
        }
    }

    onBackButtonClick(event) {
        event.stopPropagation();
        const objEvent = event.currentTarget;
        if (objEvent) {
            const strCurrentRecommendedAsset = objEvent.dataset.recommendedasset;
            const streoId = objEvent.dataset.eoid;
            const objPreSelection = this.template.querySelector(`.preSelection[data-eoid="${streoId}"][data-recommendedasset="${strCurrentRecommendedAsset}"]`);
            const lstPreselectionButton = objPreSelection.querySelectorAll('.selectionButton');
            const arrLstSelectionButton = [...lstPreselectionButton];
            this.removeNeutralClass(arrLstSelectionButton);
            const postQuerySelector = this.template.querySelector(`.postSelection[data-eoid="${streoId}"][data-recommendedasset="${strCurrentRecommendedAsset}"]`);
            this.hide(postQuerySelector);
            this.reuseableTemplateQuerySelector(objPreSelection, '.createdCase', false, true);
            this.show(objPreSelection);
        }
    }

    /**
     * This method collects all the data for Case creation.
     *
     * @param strCreatedCaseId Case Id.
     * @param strCreatedCaseNumber Case Number
     */
    updateCaseLink(strCreatedCaseId, strCreatedCaseNumber, strRequestEOCallout, boolShouldSendUpdate) {
        if(strCreatedCaseId && strCreatedCaseId.startsWith('500')) {
            if(boolShouldSendUpdate && strRequestEOCallout) {
                eoUpdateCallout({
                    strObjRequest : strRequestEOCallout,
                    strCreatedCaseId : strCreatedCaseId,
                    boolClinicalIntroduction: this.boolIsClinicalIntroductionSubmit,
                    boolIsScheduledAccepted: this.boolIsScheduledAccepted,
                    boolIsEoUser: this.boolIsEoUser
                }).then(()=>{
                    if(!this.boolIsEoUser && (!this.boolIsAlreadyInitiated || (this.boolIsAlreadyInitiated && this.boolIsSaveClicked)) && this.boolAutoOpenCase) {
                        this.openRecordInSubtab(strCreatedCaseId);
                    }
                    this.boolAutoOpenCase = true;
                        this.afterUpdateCaseLink(strCreatedCaseId, strCreatedCaseNumber);
                        this.performActionsOnCaseUpdate();
                }).catch((error)=>{
                    this.handleError(error)
                })
            }
            this.afterUpdateCaseLink(strCreatedCaseId, strCreatedCaseNumber);
            this.performActionsOnCaseUpdate();
        }
    }

    afterUpdateCaseLink(strCreatedCaseId, strCreatedCaseNumber) {
        //Now we update all the links.
        const lstLinkCaseSection = this.template.querySelectorAll(`.linkCaseSection[data-eonumber="${this.intSelectedEO}"]`)
        const arrLinkCaseSection = [...lstLinkCaseSection];
        arrLinkCaseSection.forEach(obj=>{
            this.show(obj)
        })
        const lstLinkCaseCreated = this.template.querySelectorAll(`.linkCaseCreated[data-eonumber="${this.intSelectedEO}"]`)
        const arrLinkCaseCreated = [...lstLinkCaseCreated];
        const lstLinkCreatedLabel = this.template.querySelectorAll(`.linkCreatedLabel[data-eonumber="${this.intSelectedEO}"]`)
        const arrLinkCreatedLabel = [...lstLinkCreatedLabel];
        const lstLinkUpdatedLabel = this.template.querySelectorAll(`.linkUpdatedLabel[data-eonumber="${this.intSelectedEO}"]`)
        const arrLinkUpdatedLabel = [...lstLinkUpdatedLabel];

        arrLinkCaseCreated.forEach((obj,index)=>{

            if(obj.innerHTML === "") {
                if(arrLinkCreatedLabel[index]) {
                    this.show(arrLinkCreatedLabel[index]); 
                }
                 if(arrLinkUpdatedLabel[index]) {
                    this.hide(arrLinkUpdatedLabel[index])
                 }

            } else {
                if(arrLinkCreatedLabel[index]) {
                    this.hide(arrLinkCreatedLabel[index]); 
                }
                 if(arrLinkUpdatedLabel[index]) {
                    this.show(arrLinkUpdatedLabel[index])
                 }
            }
            obj.innerHTML = strCreatedCaseNumber;
            obj.setAttribute("data-caseid",strCreatedCaseId);

        })
        //Now, we refresh the Case Summary card.
        if (this.boolIsButtonAction) {
            this.boolIsButtonAction = false;
        }

        //Finally, we display the ones that are hidden.
        let objPostSelection = this.template.querySelectorAll('.postSelection');

        objPostSelection = [...objPostSelection].filter(el=>el.clientHeight > 0);

        objPostSelection.forEach(obj=>{
            const objCreatedCasePost = obj.querySelector(`.createdCase[data-eonumber="${this.intSelectedEO}"]`);
            this.show(objCreatedCasePost);
        })
   
        if (strCreatedCaseNumber !== null || strCreatedCaseNumber !== 'undefined') {
            const lstSelectionButton = this.template.querySelectorAll('.selectionButton');
            const arrSelectionButton = [...lstSelectionButton];
            arrSelectionButton.forEach((obj) => {
                obj.removeAttribute('disabled');
            });
        }
    }

    performActionsOnCaseUpdate() {
        this.disableDismissAll = true;
        //CEAS-55967 Add "Offered" label
        this.template.querySelector(`.offered[data-id="${this.strSelectedEOId}"]`).classList.remove('slds-hide');
        const objCollapse = this.template.querySelector(`.slds-accordion__list-item[data-id="${this.strSelectedEOId}"]`)
        const boolIsExpanded = objCollapse.children[0].classList.contains('slds-is-open');
        if (this.boolRequireSaveBtn === true) {
            if (this.boolSaveBtnClicked === true) {
                
                if(boolIsExpanded) {
                    objCollapse.click();
                }

                this.boolSaveBtnClicked = false;
                this.boolRequireSaveBtn = false;
            }
        } else {
            //collapse EO and open case
            if(boolIsExpanded) {
                objCollapse.click();
            }

        }
    }

    validateInputField(objTemplate) {
        const lstValidityInp = [];
        objTemplate.forEach((obj) => {
            if ((obj.tagName === 'LIGHTNING-INPUT') || (obj.tagName === 'LIGHTNING-COMBOBOX')) {
                const inputCmp = obj;
                inputCmp.reportValidity();
                if(inputCmp.checkValidity()){
                    lstValidityInp.push(true);  
                }
            }
        });

        return objTemplate.length && lstValidityInp.length === objTemplate.length;
    }

    openRecordInSubtab(StrCaseId) {
        if(!this.objTabData) {
            this.objTabData = this.strparams.objTabData;
        }  
        if(StrCaseId) {
            const strCurrentURL = this.objTabData.url;
            if(strCurrentURL) {
                const durl = BaseLWC.helperBaseDecodeUrl(strCurrentURL);
                let paramsVal = durl.split('/view?')[1] ? durl.split('/view?')[1] : '';
                const regex = /(&timeInMillis=)\d+/i;
                paramsVal = paramsVal.replace(regex, '&timeInMillis='+Date.now());
                const strUrl = BaseLWC.helperBaseEncodeUrl(`/lightning/r/Case/${StrCaseId}/view?${paramsVal}`);
                openSubtab(this.objTabData.tabId,{url:strUrl, focus:true});
            }
        }
    }

    setPlanSummaryData() {
        const objPlanSummaryCardData = this.strparams.objPlanSummary;
        let strRiskStrat = '';
        if( objPlanSummaryCardData && objPlanSummaryCardData.boolIsAccountsAPICallAvailable && objPlanSummaryCardData.boolIsAccountsAPICallAvailable !== null) {
            this.boolAccountsAPICallAvailable = objPlanSummaryCardData.boolIsAccountsAPICallAvailable;
        }
        if( objPlanSummaryCardData && objPlanSummaryCardData.boolIsCbcApiCallAvailable  && objPlanSummaryCardData.boolIsCbcApiCallAvailable === true) {
            this.boolCbcApiCallAvailable = objPlanSummaryCardData.boolIsCbcApiCallAvailable;
        }
        strRiskStrat = this.setRiskStratLabelValue(this.objEngagementOpportunities.riskStratification);
        if(strRiskStrat && (objPlanSummaryCardData.strAceLineOfBusiness && objPlanSummaryCardData.strAceLineOfBusiness == 'Government-Medicaid' &&
			objPlanSummaryCardData.strCorporationCode && objPlanSummaryCardData.strCorporationCode == 'NM1')) {
				if(strRiskStrat === 'TIER 1') {
					strRiskStrat = 'LEVEL 1';
				} else if(strRiskStrat === 'TIER 2') {
					strRiskStrat = 'LEVEL 2';
				} else if(strRiskStrat === 'TIER 3') {
					strRiskStrat = 'LEVEL 3';
				}
			}
        this.strRiskStrat = strRiskStrat;
        if((strRiskStrat === null || strRiskStrat === '' || strRiskStrat === undefined) ||
        ((objPlanSummaryCardData && objPlanSummaryCardData.boolIsLineOfBusinessFEP === false &&
        objPlanSummaryCardData.strAceLineOfBusiness && objPlanSummaryCardData.strAceLineOfBusiness !== 'FEP' &&
        objPlanSummaryCardData.strAceLineOfBusiness !== 'GMS') &&
        !(objPlanSummaryCardData.strAceLineOfBusiness == 'Government-Medicaid' && objPlanSummaryCardData.strCorporationCode == 'NM1'))) {
             this.boolriskStrat = false;
         }
         if(objPlanSummaryCardData.strAceLineOfBusiness !== 'undefined' &&
		    objPlanSummaryCardData.strAceLineOfBusiness !== null && 
			objPlanSummaryCardData.strAceLineOfBusiness == 'Government-Medicaid' &&
			objPlanSummaryCardData.strCorporationCode !== 'undefined' &&
		    objPlanSummaryCardData.strCorporationCode !== null && 
			objPlanSummaryCardData.strCorporationCode == 'NM1') {
				this.boolChatDisabled = true;
			}

        if(typeof objPlanSummaryCardData.lstCoverageCodes !== 'undefined' && objPlanSummaryCardData.lstCoverageCodes !== null) {
            const lstAddOnServices = objPlanSummaryCardData.lstCoverageCodes;
            const strPolicyStatus = objPlanSummaryCardData.strEnrollmentStatus;
              if (lstAddOnServices) {
                   this.strAddOnServices = "";
                   for (let intCount = 0; intCount < lstAddOnServices.length; intCount++) {
                        const codeDate = new Date(lstAddOnServices[intCount].strEffectiveEndDate);
                        const CurrentDate = new Date();
                        CurrentDate.setHours(0, 0, 0, 0);
                        if (lstAddOnServices[intCount].strCode !== null &&  strPolicyStatus!==undefined && strPolicyStatus!== null
                        && strPolicyStatus!=='' && strPolicyStatus.toUpperCase() !=='INACTIVE' &&  codeDate >= CurrentDate ) {
                            if (intCount === 0) {
                                this.strAddOnServices = lstAddOnServices[intCount].strCode;
                            } else {
                                this.strAddOnServices = this.strAddOnServices +',' + lstAddOnServices[intCount].strCode;
                            }
                            
                   } else if(strPolicyStatus!==undefined && strPolicyStatus!== null
                        && strPolicyStatus!=='' && strPolicyStatus.toUpperCase() ==='INACTIVE'
                        && lstAddOnServices[intCount].strCode !== null){
                            if (intCount === 0) {
                                this.strAddOnServices = lstAddOnServices[intCount].strCode;
                            } else {
                                this.strAddOnServices = this.strAddOnServices +',' + lstAddOnServices[intCount].strCode;
                            }
                    } else {
                        // Do nothing
                    }
              }
              }
        } else {
            this.strAddOnServices = "";
        }
    }

    setRiskStratLabelValue(riskStratification) {
        let strRiskStratValue = '';
        if(riskStratification == this.STRING_RISK_STRAT_G) {
            strRiskStratValue = this.STRING_TIER_1;
        } else if(riskStratification == this.STRING_RISK_STRAT_Y) {
            strRiskStratValue = this.STRING_TIER_2;
        } else if(riskStratification == this.STRING_RISK_STRAT_R) {
            strRiskStratValue = this.STRING_TIER_3;
        }
        return strRiskStratValue;
    }
    handleCaseOpenClick(objEvent){
        const strCaseId = objEvent.currentTarget.dataset.caseid;
        if(strCaseId) {
            this.openRecordInSubtab(strCaseId)
        }
    }

    handleInput(event) {
        event.stopPropagation()
    }

    @api
    refreshPage(){
        this.boolRendered = true;
        this.executeInitialFunctionaltity();
    }

    removeNeutralClass(arrLstSelectionButton) {
        if(arrLstSelectionButton) {
            arrLstSelectionButton.forEach((obj) => {
                if (obj.classList.contains('slds-button_brand')) {
                    obj.classList.remove('slds-button_brand');
                    obj.classList.add('slds-button_neutral');
                }
                if (obj.classList.contains('selectedPriorityOne')) {
                    obj.classList.remove('selectedPriorityOne');
                }
            });
        }
    }
    handleOutboundClick() {
        // Here we create Custom Event and the dispatch the event
        const objParameterToBeSent = {'filter' : true};
        const objCustomEvent = new CustomEvent('FilterCaseSummary_'+ this.strRecordId, {
            bubbles : true, composed : true,detail: JSON.stringify(objParameterToBeSent)
        });
        this.dispatchEvent(objCustomEvent);
   }
}
