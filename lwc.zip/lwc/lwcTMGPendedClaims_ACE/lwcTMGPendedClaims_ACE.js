import BaseLWC from 'c/baseLWCFunctions_CF';
import { LightningElement, track, api } from 'lwc';
import {openSubtab, setTabIcon, setTabLabel } from 'lightning/platformWorkspaceApi';
import ViewBenefits_ViewAll_ACE from '@salesforce/label/c.ViewBenefits_ViewAll_ACE';
import fetchTMGPendedClaimsRecords from '@salesforce/apexContinuation/TMGPendedClaimsController_ACE.fetchTMGPendedClaimsRecords';

export default class LwcTMGPendedClaims extends LightningElement {

    label = {
        ViewBenefits_ViewAll_ACE        
    };
   
    @api tabId;
    @api lstTMGClaimsRecords = [];
    @api subscriberId = '';
    @track boolNoRecs = false;
    @track boolAPIError = false;
    @track boolShowSpinner = false;
    objTMGReqParams=null;
    boolShowResultsTable = true;
    @track boolShowViewAllLink = true;
    
    columns = [
        { label: 'DCN/CLAIM NUMBER', fieldName: 'claimNumber', sortable: false, type: '' },
        { label: 'SERVICE FROM', fieldName: 'fromDate', sortable: true, type: 'date', boolInitSort: true, boolAsc: false },
        { label: 'SERVICE TO', fieldName: 'toDate', sortable: false, type: 'date', boolInitSort: true, boolAsc: false },
        { label: 'GROUP NUMBER', fieldName: 'groupNumber', sortable: false, type: '' },
        { label: 'Status', fieldName: 'status', sortable: false, type: '' },
        { label: 'TOTAL BILLED', fieldName: 'billedAmt', sortable: false, type: '' },
        { label: 'BILLING PROVIDER NAME', fieldName: 'providerName', sortable: false, type: '' },
        { label: '', fieldName: 'strTextTooltipContent', sortable: false, boolHidden: false, type: '', boolIsTooltip: true, boolIsInfoIconTooltip: true }
    ];

    objTMGClaimsInitSetting = {
        pageSize: 5,
        restrictedPageSize: 5,
        boolViewMore: false,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: false,
        boolPagination: false,
        boolShowSearch: false,
        boolShowSearchLabel: false,
        searchPlaceholder : 'Search Text',
        boolShowCheckbox : false,
         boolShowHeader : false,
         filterData : [
             {strType : '', intCol : -1, strFilterName : 'Select a value'},
             {strType : 'text', intCol : 1, strFilterName : 'DCN/CLAIM NUMBER'},
             {strType : 'date', intCol : 2, strFilterName : 'SERVICE FROM'},
             {strType : 'date', intCol : 3, strFilterName : 'SERVICE TO'},
             {strType : 'text', intCol : 4, strFilterName : 'GROUP NUMBER'},
             {strType : 'text', intCol : 5, strFilterName : 'Status'},
             {strType : 'text', intCol : 6, strFilterName : 'TOTAL BILLED'},
             {strType : 'text', intCol : 7, strFilterName : 'BILLING PROVIDER NAME'}
         ]
         
    }
    
    connectedCallback() {
        this.fetchData();

    }

    @api
    fetchData() {
        if (!this.subscriberId) {
            return;
        }
        const strSubscriberId = this.subscriberId;
        this.boolShowResultsTable = false;
        this.boolShowSpinner = true;
        
        const startDate = new Date();
        const endDate = new Date();
        let curMonth = startDate.getMonth();
        startDate.setMonth(curMonth - 6);
        
        var strStartDt = this.convertDate(startDate);
        var strEndDt = this.convertDate(endDate);

        let jasonreqbody = '{"subscriberid": "'+strSubscriberId.substring(3) + '", "claimFromDate": "'+strStartDt + '",' + '"claimToDate": "' + strEndDt + '"}';
        
        fetchTMGPendedClaimsRecords({
            strDataJSON: jasonreqbody
        }).then(objResult => {

                this.boolShowResultsTable = true;
                this.boolShowSpinner = false;
                this.boolAPIError = false;
                this.boolNoRecs = false;
                this.boolShowViewAllLink = true;
                var lstTMGData = [];

                const lstData=JSON.parse(objResult).lstClaimsHistory;
                for(let i=0;i<lstData.length;i++) {
                    const obj={...lstData[i]};
                    obj.fromDate = this.convertDateFormat(obj.fromDate);
                    obj.toDate = this.convertDateFormat(obj.toDate);
                    obj.billedAmt = '$' + obj.billedAmt;
                    obj.providerName = (obj.providerFirstName ? obj.providerFirstName + ' ' : '') + (obj.providerLastName ? obj.providerLastName : '');
                    obj['strTextTooltipContent']={
                        value:'',
                        strCellValue: `<div>
                        Description: ${obj.status}</br>
                        Billing Provider Number: ${obj.providerNum}</br>
                        Billing Provider NPI: ${obj.npi}
                        </div>`,
                        strTextTooltipContent: `<div>
                        Description: ${obj.status}</br>
                        Billing Provider Number: ${obj.providerNum}</br>
                        Billing Provider NPI: ${obj.npi}
                    </div>`
                    }
                    lstTMGData.push(obj);
                } 

                if (!lstTMGData.length)
                {
                    this.boolNoRecs = true;
                    this.boolShowViewAllLink = false;
                } else {
                    //Sort Array
                    lstTMGData.sort((a, b) => {
                        if (a.fromDate != '' && b.fromDate != ''){
                            const dateTime1 = Date.parse(a.fromDate);
                            const dateTime2 = Date.parse(b.fromDate);
                            
                            if (dateTime1 > dateTime2) {
                                return -1;
                            } else if (dateTime1 < dateTime2) {
                                return 1;
                            }
                            else {
                                return 0;
                            }
                        }
                        else if (a.fromDate != '') {
                            return -1;
                        } else if (b.fromDate != '') {
                            return 1;
                        } else {
                            return 0;
                        }
                      });

                    //Only first 5 records
                    lstTMGData = lstTMGData.slice(0, 5)

                    this.lstTMGClaimsRecords = lstTMGData;
                    this.boolNoRecordsGC = false;
                }
                    
            }).catch(error => {
                this.boolShowSpinner = false;
                this.boolShowViewAllLink = false;
                this.handleAPIErrors(error);
            });
 
    }

    convertDate(dateConvert){
        var strDate = dateConvert.getFullYear() + "-" + (((dateConvert.getMonth()+1) < 10 ? '0' : '') + (dateConvert.getMonth()+1)) + "-" + ((dateConvert.getDate() < 10 ? '0' : '') + (dateConvert.getDate()));  
        return strDate;
    }

    convertDateFormat(dateObj) {
        const dateTimeArray = dateObj.split("T");
        var strDate = dateTimeArray[0].toString();
        var strDateSplit =strDate.split("-");
        var finalDate = strDateSplit[1]+"/"+strDateSplit[2]+"/"+strDateSplit[0];
        return finalDate;
    }

    handleAPIErrors(error) {
        this.boolAPIError = true;
    }

    viewAll(){        
        // Navigate to the TMG Pended Claims history view.
          const strUrl=location.origin+'/lightning/n/ViewTMGPendedClaims_FlexiPage_ACE?c__subId='+this.subscriberId;        
          openSubtab(this.tabId, {url: strUrl, focus: true}).then((response) => {
            setTabLabel(response, "TMG Pended Claims History")
                .then(() => {
                    setTabIcon(response, 'custom:custom18', '')
                        .then(() => {
                            // Do nothing
                        }).catch(() => {
                            // Do nothing
                        })
                }).catch(() => {
                    // Do nothing
                })
        }).catch(() => {
            // Do nothing
        });
    }

}