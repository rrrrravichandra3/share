import { LightningElement, wire, track } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF'; 
import { openTab } from 'lightning/platformWorkspaceApi';
import getCaseList from '@salesforce/apex/MyCaseListDashboardController_ACE.getCaseList';
import GroupNumber from '@salesforce/label/c.ViewCaseSummary_GroupNumber_ACE';
import TypeAndSubType from '@salesforce/label/c.ViewCaseSummary_TypeAndSubType_ACE';
import Status from '@salesforce/label/c.ViewCaseSummary_Status_ACE';
import InquirerRelationship from '@salesforce/label/c.ViewCaseSummary_InquirerRelationship_ACE';
import Origin from '@salesforce/label/c.ViewCaseSummary_Origin_ACE';
import SMSTextMessage_Title_ACE from '@salesforce/label/c.SMSTextMessage_Title_ACE';
import CaseSummary_Title_ACE from '@salesforce/label/c.CaseSummary_Title_ACE';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import ORIGIN_FIELD from '@salesforce/schema/Case.Origin';

import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import InteractionHistoryPage_NoRecordFound_ACE from '@salesforce/label/c.InteractionHistoryPage_NoRecordFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import DefaultRecordTypeID_ACE from '@salesforce/label/c.DefaultRecordTypeID_ACE';

export default class LwcDashboardMyCasesACE extends LightningElement {
    label={
        GroupNumber,
        TypeAndSubType,
        Status,
        InquirerRelationship,
        Origin,
        SMSTextMessage_Title_ACE,
        CaseSummary_Title_ACE,
        SafeMode_ToastMessage_ACE,
        IntegrationFailMessage_ACE,
        InteractionHistoryPage_NoRecordFound_ACE
    }
    get lstCaseAgeOptions() {
        return [
            { label: 'Today', value: 'Today' },
            { label: 'Last 7 Days', value: 'Last 7 Days' },
            { label: 'Last 30 Days', value: 'Last 30 Days' },
            { label: 'Last 60 Days', value: 'Last 60 Days' },
            { label: 'Last 90 Days', value: 'Last 90 Days' }
        ];
    }

    strQueryCaseAge = 'Last 30 Days';
    strCaseOrigin = '';
    @track
    originOptions = [
        {label: 'Select Source', value: ''}
    ];

    @wire(getPicklistValues, {recordTypeId: DefaultRecordTypeID_ACE, fieldApiName: ORIGIN_FIELD})
    caseOriginPickList({ data}) {
        if (data) {
            const originValues = data.values;
            originValues.forEach((elem) => {
                this.originOptions.push({
                    label: elem.label,
                    value: elem.label
                });
            }) 
           }
    }

    boolDisplayData=false;
    boolSpinner=true;    
    boolAPIError=false;
    boolShowTasksModal = false;
    tasksModal = {};
    objError;
    boolShowNotesModal=false; 
    notesModal={};   
    @track
    lstTableData=[];
    get boolShowNoRecordsFound() {
        return !BaseLWC.arrayIsNotEmpty(this.lstTableData);
    }
    columns = [
        { label: 'CASE #', fieldName: 'CaseNumber', sortable: true, type: '' },
        { label: 'INTERACTION AGE', fieldName: 'InteractionAge_ACE__c', sortable: true, type: '' },
        { label: 'CASE AGE', fieldName: 'CaseAge', sortable: true, type: '', boolIsTooltip: true, boolInitSort: true, boolAsc: false},
        { label: 'SUBSCRIBER ID', fieldName: 'SubscriberID_ACE__c', sortable: true, type: '' },        
        { label: 'GROUP #', fieldName: 'GroupNumber_ACE__c', sortable: true,type: '' },        
        { label: this.label.TypeAndSubType, fieldName: 'TypeAndSubType_ACE__c', sortable: true, type: '' },       
        { label: this.label.Status, fieldName: 'Status', sortable: true, type: '' },
        { label: 'SUB-STATUS', fieldName: 'Sub_Status_ACE__c', sortable: true, type: '' },
        { label: 'FOLLOW-UP DATE', fieldName: 'Follow_Up_Date_ACE__c', sortable: true, type: 'date' },
        { label: 'SUBJECT', fieldName: 'Subject', sortable: false, boolHidden: true, type: '' },
        { label: 'CorporateReceivedDate_ACE__c', fieldName: 'CorporateReceivedDate_ACE__c', sortable: false, boolHidden: true, type: 'date' },
        { label: 'ACTION', fieldName: 'actionBtn', sortable: false, type: 'actionBtn', rowActions:[
            {key: "viewNotes", label:"View Notes"},
            {key: "viewTasks", label:"View Tasks"},
        ]},
        { label: 'Counter', fieldName: 'counter', sortable: false, type: '',boolHidden: true }
                    
    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize:5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: false,
        boolShowSearch: true,
        boolShowSearchLabel:true,
        boolShowRecordCount:true,
        filterData: [
            { strType: 'picklist', intCol: 5, strFilterName: 'Group #' },
            { strType: 'picklist', intCol: 6, strFilterName: this.label.TypeAndSubType },
            { strType: 'picklist', intCol: 7, strFilterName: 'Status' },
            {strType : 'picklist', intCol : 8, strFilterName : 'Sub-Status'},
            { strType: 'date', intCol: 9, strFilterName: 'Follow-Up Date' },
            { strType: 'dateRangeMF', intCol: 11, strFilterName: 'Corp Received Date' }
        ]
    };

    handleErrors(error) {
        this.objError = error;
    }

    connectedCallback() {
        this.fetchCases();
    }

    fetchCases() {
        this.boolSpinner = true;
        this.boolDisplayData = false;
        getCaseList({'selectedTimeframe': this.strQueryCaseAge, 'selectedSource': this.strCaseOrigin}).then(lstResultCaseData=>{
            this.processCaseDataForTable(lstResultCaseData);
        }).catch(_error=> {
            this.handleErrors(_error);
            this.boolSpinner=false;
            this.boolAPIError=true;
        });
    }

    handleCaseAgeFilterChange = (event) => {
        this.strQueryCaseAge = event.detail.value;
        this.fetchCases();
    }

    handleCaseOriginFilterChange = (event) => {
        this.strCaseOrigin = event.detail.value;
        this.fetchCases();
    }

    processCaseDataForTable(lstResultCaseData){
        try {
            const data=[...lstResultCaseData];
                //Loop through Data to modify for Table   
                this.lstTableData = [];             
                this.lstTableData=data.map((el)=>{
                    

                    const objCase={};
                    objCase['CaseNumber']={
                        value:el['CaseNumber'],
                        strCaseId:el['Id'],
                        strAccountId:el['AccountId'],
                        wrapper:`<a data-casenumber="${el.CaseNumber}">${el.CaseNumber}</a>`
                    };
                    objCase.InteractionAge_ACE__c = this.validateData(el.InteractionAge_ACE__c);
                    objCase.CaseAge_ACE__c = this.validateData(el.CaseAge_ACE__c);
                    objCase.SubscriberID_ACE__c = this.validateData(el.SubscriberID_ACE__c);
                    objCase.GroupNumber_ACE__c = this.validateData(el.GroupNumber_ACE__c);
                    objCase['TypeAndSubType_ACE__c'] = this.validateData(this.convertAPIToLabelForTypeAndSubtype(el.TypeAndSubType_ACE__c));
                    objCase.Status = this.validateData(el.Status);
                    objCase.Sub_Status_ACE__c = this.validateData(el.Sub_Status_ACE__c);
                    let datDateToShow = '';
                    if (BaseLWC.stringIsNotBlank(el.Follow_Up_Date_ACE__c)) {
                        datDateToShow=BaseLWC.dateFormatterHelper(el.Follow_Up_Date_ACE__c);
                    }
                    objCase.Follow_Up_Date_ACE__c = this.validateData(datDateToShow);
                    datDateToShow = '';
                    if (BaseLWC.stringIsNotBlank(el.CorporateReceivedDate_ACE__c)) {
                        datDateToShow=BaseLWC.dateFormatterHelper(el.CorporateReceivedDate_ACE__c);   
                    }
                    objCase.CorporateReceivedDate_ACE__c = this.validateData(datDateToShow);
                    let closedDate = '';
                    if (BaseLWC.stringIsNotBlank(el.ClosedDate)) {
                        closedDate=BaseLWC.dateFormatterHelper(el.ClosedDate);   
                    } else {
                        closedDate = 'NA';
                    }
                    const caseAge = objCase.CaseAge_ACE__c.toString();
                    if (caseAge) {
                        objCase['CaseAge'] = {
                            value: caseAge.toString(),
                            wrapper: caseAge.toString(),
                            strCellValue: `<p>Corp Received Date: ${objCase.CorporateReceivedDate_ACE__c}</p><p>Closed Date: ${closedDate}</p>`,
                            strTextTooltipContent:  `<p>Corp Received Date: ${objCase.CorporateReceivedDate_ACE__c}</p><p>Closed Date: ${closedDate}</p>`
                        }
                    } else {
                        objCase['CaseAge'] = {
                            value: '',
                            wrapper: '',
                            strCellValue: '',
                            strTextTooltipContent: ''
                        }
                    }
                    objCase.actionBtn = {
                        rowActions:[
                            {key: "viewNotes", label:"View Notes", disabled: false},
                            {key: "viewTasks", label:"View Tasks", disabled: false}
                        ],
                        objNotesData : {
                            value:el['CaseNumber'],
                            strCaseId:el['Id'],
                            strType:el['Type'],
                            strSubType:el['Sub_Type_ACE__c'],
                            strFacetsTaskId:el['Facets_Task_ID_ACE__c'],
                        },
                        objTasksData : {
                            strCaseId:el['Id'],
                            strAccountId:el['AccountId'],
                            strCaseNumber:el['CaseNumber'],
                            strType:el['Type'],
                            strSubType:el['Sub_Type_ACE__c']
                        }
                    };

                    
                    return objCase;
                })
                this.boolDisplayData=true;
                this.boolSpinner=false;
        } catch (error) {   
            this.handleErrors(error);
        }
    }

    validateData(data) {
        if (data !== null && data !== undefined && typeof data === 'number') {
            return data.toString();
        }
        if (data) {
            return data;
        }
        return '-';
    }

    convertAPIToLabelForTypeAndSubtype(strTypeSubtype) {
        let strNewTypeSubtype = strTypeSubtype;
        const strGMC = 'Grievance / Complaint';
        if (strNewTypeSubtype.includes(strGMC)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strGMC, 'Grievance / Member Complaint');
        }
        const strMemberPortal = 'Member Portal (BAM)';
        if (strNewTypeSubtype.includes(strMemberPortal)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMemberPortal, 'Member Portal');
        }
        const strMGPCP = 'PCP Update';
		if (strNewTypeSubtype.includes(strMGPCP)) {
		    strNewTypeSubtype = strNewTypeSubtype.replace(strMGPCP, 'MG / PCP Update');
		}
        const strPreAuth = 'Prior Authorization';
		if (strNewTypeSubtype.includes(strPreAuth)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strPreAuth, 'Preauth');
		}
        const strProspectiveMember = 'Prospective Member';
		if (strNewTypeSubtype.includes(strProspectiveMember)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strProspectiveMember, 'Temporary Member');
		}
		return strNewTypeSubtype;
    }
    closeTaskModal () {
        this.boolShowTasksModal=false;
    }

    handleRowAction(event){
        try {
            
            const column = JSON.parse(event.detail).activeColFieldName;
            const rowData=JSON.parse(event.detail);
            if(column === 'actionBtn' && rowData.strActionKey==='viewNotes'){           
                this.notesModal.strCaseNumber=rowData.activeColumnData.value.objNotesData.value;
                this.notesModal.strCaseId=rowData.activeColumnData.value.objNotesData.strCaseId;
                this.notesModal.strCaseType=rowData.activeColumnData.value.objNotesData.strType;
                this.notesModal.strCaseSubType=rowData.activeColumnData.value.objNotesData.strSubType;
                this.notesModal.strFacetsTaskId=rowData.activeColumnData.value.objNotesData.strFacetsTaskId;            
                this.boolShowNotesModal=true;
            } else if(column === 'actionBtn' && rowData.strActionKey==='viewTasks'){           
                this.tasksModal.strCaseId=rowData.activeColumnData.value.objTasksData.strCaseId;
                this.tasksModal.strAccountId=rowData.activeColumnData.value.objTasksData.strAccountId;
                this.tasksModal.strCaseNumber=rowData.activeColumnData.value.objTasksData.strCaseNumber;
                this.tasksModal.strCaseType=rowData.activeColumnData.value.objTasksData.strType;
                this.tasksModal.strCaseSubType=rowData.activeColumnData.value.objTasksData.strSubType;
                this.boolShowTasksModal=true;
            } else if(column === 'CaseNumber'){
                this.openCaseDetails(rowData.activeColumnData.value.strCaseId)
            }  else {
                //do nothing
            }
        } catch (error) {
            //Handle Error
            this.handleErrors(error);
        }        
    }

    closeModal(){
        this.boolShowNotesModal=false;
    }

    refreshData=()=>{
        this.fetchCases();
    }

    openCaseDetails= (strCaseId) => {
        openTab({recordId: strCaseId, focus: true}).then(() => {

        }). catch(error => {
            this.handleErrors(error);
        })
    }
}