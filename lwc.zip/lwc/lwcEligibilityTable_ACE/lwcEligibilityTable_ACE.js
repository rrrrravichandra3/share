import { LightningElement, api, wire } from 'lwc';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
//Base Workspace functions.
import Message_error_ACE from "@salesforce/label/c.Message_error_ACE";
import ViewPlanSummary_CardHeader_Refresh_ACE from "@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE";
import Message_warning_ACE from "@salesforce/label/c.MessageLightningComponent_Warning_ACE";
import SafeMode_ToastMessage_ACE from "@salesforce/label/c.SafeMode_ToastMessage_ACE";
import IntegrationFailMessage_ACE from "@salesforce/label/c.FacetsNotesAPIErrorMessage_ACE";
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import { EnclosingTabId, getTabInfo} from 'lightning/platformWorkspaceApi';

export default class LwcEligibilityTableACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;

    label = {
        ViewPlanSummary_CardHeader_Refresh_ACE,
        Message_warning_ACE,
        SafeMode_ToastMessage_ACE,
        IntegrationFailMessage_ACE,
        Message_error_ACE,
        EnableVPSTabSpecificEvents_ACE
    };
    
    objTabData = {};
    boolError=false;
    objAPIResponse={};
    boolShowSpinner = true;
    boolShowSafeMode = false;
    boolAPIError = false;
    facetsGroupId ='';
    subscriberId ='';
    boolPlanSummaryData = false;
    boolPrimaryTab = false;
    PlanSummaryData={};
    strBaseCurrentParentTabId;
    boolVPSTabSpecificEvents;


    //Table Data
    @api lstEligibilityNotes = [];


    //Table Settings
    objEligibilitySetting = {
        pageSize: 25,
        showPagination : true,
        boolViewMore: false,
        columnsData: [
            { label: 'EVENT NAME', fieldName: 'eventname', sortable: false, type: 'text' },
            { label: 'DATE', fieldName: 'date', sortable: false, type: 'date' },
            { label: 'REASON', fieldName: 'reason', sortable: false, type: 'text' },
            { label: 'EXPLANATION', fieldName: 'explaination', sortable: false, type: 'text' }
        ],
        boolSecondaryTable: false,
        boolShowFilter: true,
        boolPagination: true,
        boolShowSearch:true,
        searchPlaceholder : 'Search Text',
        boolHasSearchandFilterCustomMargins: true,
        objSearchandFilterCustomMargins:{
            top: "0.75rem",
            bottom: "0",
            right: "0",
        },
        filterData : [
            {strType : '', intCol : -1, strFilterName : 'Select a value'},
            {strType : 'text', intCol : 1, strFilterName : 'EVENT NAME'},
            {strType : 'date', intCol : 2, strFilterName : 'DATE'},
            {strType : 'text', intCol : 3, strFilterName : 'REASON'},
            {strType : 'text', intCol : 4, strFilterName : 'EXPLANATION'}
        ],
        boolShowCheckbox : false,
        boolShowHeader : false,
        boolShowSearchLabel: false,
        restrictedPageSize : false,
        boolPaginationwithSize:false
    };


    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.fetchTabData();
        } catch (error) {
            //Handle Error
        }
    }


    fetchTabData() {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objTabData => {
                this.objTabData = objTabData;
                if (this.objTabData.isSubtab === true) {
                    this.strBaseCurrentParentTabId = this.objTabData.parentTabId;
                } else {
                    this.strBaseCurrentParentTabId = this.objTabData.tabId;
                }
                if (BaseLWC.stringIsNotBlank(this.label.EnableVPSTabSpecificEvents_ACE) && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                    this.boolVPSTabSpecificEvents = true;
                }
                this.planSummaryListener();
                this.executeInitialFunctionality();
            }).catch(() => {
                this.handleErrors();
            });
        }
    }

    planSummaryListener() {
        if (this.boolVPSTabSpecificEvents) {
            window.addEventListener(
                "PlanSummaryEvent_" + this.strBaseCurrentParentTabId,
                this.capturePlanSummaryListener
            );
        } else {
            window.addEventListener(
                "PlanSummaryEvent",
                this.capturePlanSummaryListener
            );
        }
    }

    capturePlanSummaryListener = (planSummaryDataEvent) => {
        if (BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail) ) {
            if (this.boolVPSTabSpecificEvents) {
                window.removeEventListener("PlanSummaryEvent_" + this.strBaseCurrentParentTabId,this.capturePlanSummaryListener);
            } else {
                window.removeEventListener("PlanSummaryEvent",this.capturePlanSummaryListener);
            }
            this.PlanSummaryData = JSON.parse(planSummaryDataEvent.detail);
            
            if(this.PlanSummaryData.strIdDestination === 'PlanCardDetails_ACE') {
                this.boolPlanSummaryData = true;
                this.lstEligibilityNotes = this.fetchEligibilityData(); 
            }
           
        }
    };
    executeInitialFunctionality() {
        if (this.objTabData.isSubtab === true) {
            //Always segregate the Main tab and Sub tab functions.
            this.executeSubTabFunctionality();
        } else if (this.objTabData.isSubtab === false) {
            //Always segregate the Main tab and Sub tab functions.
            this.executeMainTabFunctionality();
        } else {
            //Do nothing
        }
    }

    executeSubTabFunctionality() {
        this.boolPrimaryTab = false;
    }

    executeMainTabFunctionality() {
        this.boolPrimaryTab = true;

    }

    fetchEligibilityData() {
        this.boolAPIError = false;
        this.boolShowSpinner = false;
        let lstmemberevent = [];
        let tableObject;
        if(this.PlanSummaryData.objParameters.objMessage !== null &&  this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails !== null ) {
            lstmemberevent = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.lstMemberEvents;
        }
        if(lstmemberevent !== null &&  lstmemberevent !== undefined && lstmemberevent.length > 0){
             tableObject = lstmemberevent.map((itrRow) => {
                itrRow['eventname'] = itrRow['eligibilityEventDescription'];
                itrRow['date'] = this.formatDate(itrRow['eligibilityEventDate']);
                itrRow['reason'] = itrRow['eligibilityReason'];
                itrRow['explaination'] = itrRow['eligibilityExplanation'];
                return itrRow;
            });
        }
        return tableObject;
    }


    handleErrors(error) {
        this.boolError = error;
    }


    formatDate(strUnformatedDate) {
        if(strUnformatedDate !== null && strUnformatedDate !== undefined && strUnformatedDate!== '') {
            const objDateTime = new Date(strUnformatedDate);
            let intMonth = objDateTime.getMonth() + 1;
            let intDay = objDateTime.getDate();
            const intYear = objDateTime.getFullYear();
            if (intMonth < 10) {
                intMonth = "0" + intMonth;
            }
            if (intDay < 10) {
                intDay = "0" + intDay;
            }
            return intMonth + "/" + intDay + "/" + intYear;
        }
        return null;
    }

    refreshCard = () => {
        try {
            this.executeInitialFunctionality();
            this.boolShowSpinner = true;
            this.executeInitialFunctionality();
            this.lstEligibilityNotes = this.fetchEligibilityData(); 
            this.boolShowSpinner = false;
        } catch (error) {
            
            this.handleErrors(error);
        }
    };

}