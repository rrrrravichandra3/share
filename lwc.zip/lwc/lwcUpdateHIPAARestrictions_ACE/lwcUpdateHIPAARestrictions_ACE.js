import { LightningElement, api, track } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
//Apex Class Methods
import getHIPPARestrictions from "@salesforce/apex/HIPAA_CCRF_RRF_DetailController_ACE.fetchHIPPARestrictionsAndCCR";
import fetchUserDetails from "@salesforce/apex/HIPAA_CCRF_RRF_DetailController_ACE.fetchUserDetailsForLightning";
//Label
import HIPAAAuthParty_Active_ACE from '@salesforce/label/c.HIPAAAuthParty_Active_ACE';
import HIPAAAuthParty_InActive_ACE from '@salesforce/label/c.HIPAAAuthParty_InActive_ACE';
import UpdateHIPAARestrictions_EditRRFIdentifier_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_EditRRFIdentifier_ACE';
import UpdateHIPAARestrictions_ModalIdentifier_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_ModalIdentifier_ACE';
import UpdateHIPAARestrictions_EditCCRFIdentifier_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_EditCCRFIdentifier_ACE';
import UpdateHIPAARestrictions_OpenDeactivationModal_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_OpenDeactivationModal_ACE';
import UpdateHIPAARestrictions_DeactivationModalIdentifier_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_DeactivationModalIdentifier_ACE';
import View_PreService_Member_Name from '@salesforce/label/c.View_PreService_Member_Name';
import UpdateHIPPARestrictions_PersonRestricted_ACE from '@salesforce/label/c.UpdateHIPPARestrictions_PersonRestricted_ACE';
import IDCardAddress_ACE from '@salesforce/label/c.IDCardAddress_ACE';
import PHONENUMBER_ACE from '@salesforce/label/c.PHONENUMBER_ACE';
import UpdateHIPAARestrictions_Email_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_Email_ACE';
import ViewAuthorizedParty_EffectiveDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_EffectiveDate_ACE';
import UpdateHIPPARestrictions_IMGReferenceNumber_ACE from '@salesforce/label/c.UpdateHIPPARestrictions_IMGReferenceNumber_ACE';
import UpdateHIPAARestrictions_BAMAccess_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_BAMAccess_ACE';
import UpdateHIPAARestrictions_Minor_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_Minor_ACE';
import IDCardStatus_ACE from '@salesforce/label/c.IDCardStatus_ACE';
import UpdateHIPAARestrictions_RRFHeaderName_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_RRFHeaderName_ACE';
import UpdateHIPAARestrictions_CCRFHeaderName_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_CCRFHeaderName_ACE';

export default class LwcUpdateHIPAARestrictions_ACE extends LightningElement {

    label = {
        HIPAAAuthParty_Active_ACE,
        HIPAAAuthParty_InActive_ACE,
        UpdateHIPAARestrictions_EditRRFIdentifier_ACE,
        UpdateHIPAARestrictions_ModalIdentifier_ACE,
        UpdateHIPAARestrictions_EditCCRFIdentifier_ACE,
        UpdateHIPAARestrictions_OpenDeactivationModal_ACE,
        UpdateHIPAARestrictions_DeactivationModalIdentifier_ACE,
        View_PreService_Member_Name,
        UpdateHIPPARestrictions_PersonRestricted_ACE,
        IDCardAddress_ACE,
        PHONENUMBER_ACE,
        UpdateHIPAARestrictions_Email_ACE,
        ViewAuthorizedParty_EffectiveDate_ACE,
        UpdateHIPPARestrictions_IMGReferenceNumber_ACE,
        UpdateHIPAARestrictions_BAMAccess_ACE,
        UpdateHIPAARestrictions_Minor_ACE,
        IDCardStatus_ACE,
        UpdateHIPAARestrictions_RRFHeaderName_ACE,
        UpdateHIPAARestrictions_CCRFHeaderName_ACE
    };

    columns = [
        { label: 'Name', fieldName: 'strMemberName', sortable: true, type: '' },
        { label: 'REPRESENTATIVE', fieldName: 'strRepresentative', sortable: true, type: '' },
        { label: 'Address', fieldName: 'strFullAddress', sortable: true, type: '' },
        { label: 'Phone Number', fieldName: 'strPhoneNumber', sortable: true, type: '' },
        { label: 'Email Address', fieldName: 'strEmailAddress', sortable: true, type: '' },
        { label: 'Effective Date', fieldName: 'strEffectiveDate', sortable: true, type: 'date' },
        { label: 'Image Ref. Number', fieldName: 'strImageRefNumber', sortable: true, type: '' },
        { label: 'Revoked BAM Access', fieldName: 'strBAMAccess', sortable: true, type: '' },
        { label: 'Minor', fieldName: 'strIsMinor', sortable: true, type: '' },
        { label: 'Status', fieldName: 'Active_ACE__c', sortable: true, type: '' },
        { label: 'RecIdentifier', fieldName: 'Id', sortable: false, boolHidden: true, type: '' },
        { label: 'Active', fieldName: 'strActive', sortable: false, boolHidden: true, type: '' }
    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: true,
        boolShowSearch: true,
        boolShowHeader: false,
        boolShowSearchLabel: false,
        filterData: [
            { strType: 'text', intCol: 1, strFilterName: 'Name' },
            { strType: 'text', intCol: 3, strFilterName: 'Address' },
            { strType: 'text', intCol: 4, strFilterName: 'Phone Number' },
            { strType: 'text', intCol: 5, strFilterName: 'Email Address' },
            { strType: 'text', intCol: 7, strFilterName: 'Image Ref. Number' },
            { strType: 'text', intCol: 8, strFilterName: 'Revoked BAM Access' },
            { strType: 'date', intCol: 6, strFilterName: 'Effective Date' },
            { strType: 'picklist', intCol: 9, strFilterName: 'Minor' },
            { strType: 'picklist', intCol: 12, strFilterName: 'Active' }
        ],
        lstDefaultFilter: [
            { strFilterName: 'Active', lstValues: ['Active'] }
        ]
    };

    boolSpinner = false;
    @track boolShowNoRestRecordsFound = false;
    @track boolShowNoCCRRecordsFound = false;
    @track boolDisplayCCRTable = false;
    @track boolDisplayRestrictionTable = false;

    @api strFamilyCmid;
    @api strGlobalMid;
    @api boolCheckForPermission;
    @api strMemberCmid;
    lstCCRTableData = [];
    lstRestrictionTableData = [];
    lstHippaRecords = [];

    /**
    * Connected Call back function.
    */
    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.fetchAllData();
        } catch (error) {
            //this.handleErrors(error);
        }
    }


    @api refreshViewHippaLWC() {
        this.fetchAllData();
    }

    fetchAllData() {
        /*Fetch updated HIPAA Restrictions records.*/
        this.getUpdatedHIPAAData();
    }

    resetTable() {
        this.boolShowNoRestRecordsFound = false;
        this.boolShowNoCCRRecordsFound = false;
        this.boolDisplayCCRTable = false;
        this.boolDisplayRestrictionTable = false;
        this.lstHippaRecords = [];
        this.lstCCRTableData = [];
        this.lstRestrictionTableData = [];
    }

    getUpdatedHIPAAData() {
        this.resetTable();
        getHIPPARestrictions({
            strFamilyCMID: this.strFamilyCmid
        }).then((result) => {
            if (result) {
                this.boolSpinner = true;
                let objResult = JSON.parse(result);
                let ccrtabeldate = [];
                let restrictiontabledata = [];
                this.lstHippaRecords = objResult;
                objResult.forEach(function (eachObj) {
                    if (eachObj.RecordType.DeveloperName == 'HIPAA_CCRF_ACE') {
                        ccrtabeldate.push({ ...eachObj });
                    } else {
                        restrictiontabledata.push({ ...eachObj });
                    }
                });

                this.createHIPAATable(ccrtabeldate, 'CCRTable');
                this.createHIPAATable(restrictiontabledata, 'RestrictionTable');
                this.boolSpinner = false;
                this.boolDisplayCCRTable = true;
                this.boolDisplayRestrictionTable = true;
            } else {
                this.boolSpinner = false;
                this.boolDisplayCCRTable = true;
                this.boolDisplayRestrictionTable = true;
                this.boolShowNoRestRecordsFound = true;
                this.boolShowNoCCRRecordsFound = true;
            }
        }
        ).catch(() => {
            this.boolSpinner = false;
            this.boolDisplayCCRTable = true;
            this.boolDisplayRestrictionTable = true;
            this.boolShowNoRestRecordsFound = true;
            this.boolShowNoCCRRecordsFound = true;
        });
    }

    createHIPAATable(objTableData, tableType) {
        let lstTableData = [];
        if (BaseLWC.isNotUndefinedOrNull(objTableData)) {
            for (let i = 0; i < objTableData.length; i++) {
                const obj = objTableData[i];
                let strDisableBtn = '';
                if (obj.Notes_ACE__c == undefined) {
                    obj.Notes_ACE__c = '';
                }

                if (obj.Address1_ACE__c !== undefined) {
                    obj.strFullAddress = obj.Address1_ACE__c;

                    if (obj.Address2_ACE__c != undefined) {
                        obj.strFullAddress += ', \n' + obj.Address2_ACE__c;
                    }
                    if (obj.City_ACE__c != undefined) {
                        obj.strFullAddress += ', \n' + obj.City_ACE__c;
                    }
                    if (obj.State_ACE__c != undefined) {
                        obj.strFullAddress += ', \n' + obj.State_ACE__c;
                    }
                    if (obj.ZipCode_ACE__c != undefined) {
                        obj.strFullAddress += ', \n' + obj.ZipCode_ACE__c;
                    }
                }

                obj['objSecTableStatus'] = {
                    boolExpanded: false
                }
                obj.strActive = obj.Active_ACE__c.toString()
                if ((obj.Active_ACE__c).toString() == this.label.HIPAAAuthParty_Active_ACE) {
                    obj['Active_ACE__c'] = {
                        value: obj.Active_ACE__c.toString(),
                        wrapper: `<span class="slds-badge hippabadgeClass hippaactiveBadge slds-badge_lightest"> Active </span>`
                    };
                    obj['objSecTableStatus'] = {
                        boolExpanded: true
                    }

                } else if ((obj.Active_ACE__c).toString() == this.label.HIPAAAuthParty_InActive_ACE) {
                    obj['Active_ACE__c'] = {
                        value: obj.Active_ACE__c.toString(),
                        wrapper: `<span class="slds-badge hippabadgeClass hippainactiveBadge"> Inactive </span>`
                    }
                } else {
                    obj['Active_ACE__c'] = {
                        value: obj.Active_ACE__c.toString(),
                        wrapper: `<span class="slds-badge hippabadgeClass hippainactiveBadge"> Deactivated </span>`
                    }
                    strDisableBtn = 'disabled="disabled"';
                }

                if (obj.Address1_ACE__c !== undefined) {
                    obj['strFullAddress'] = {
                        value: obj.strFullAddress,
                        wrapper: `<span> ${obj.strFullAddress} </span>`
                    }
                } else {
                    obj['strFullAddress'] = {
                        value: '-',
                        wrapper: `<center>-</center>`
                    }
                }

                if (obj.Phone_Number_ACE__c !== undefined) {
                    obj.strPhoneNumber = obj.Phone_Number_ACE__c.replace(/[^\d]+/g, '')
                        .replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');;
                } else {
                    obj['strPhoneNumber'] = {
                        value: '-',
                        wrapper: `<center>-</center>`
                    }
                }

                if (obj.EmailAddress_ACE__c !== undefined) {
                    obj.strEmailAddress = obj.EmailAddress_ACE__c;
                } else {
                    obj['strEmailAddress'] = {
                        value: '-',
                        wrapper: `<center>-</center>`
                    }
                }

                if (obj.Image_Ref_Number_ACE__c !== undefined) {
                    obj.strImageRefNumber = obj.Image_Ref_Number_ACE__c;
                } else {
                    obj['strImageRefNumber'] = {
                        value: '-',
                        wrapper: `<center>-</center>`
                    }
                }

                if (obj.RevokedBAMAccess_ACE__c !== undefined) {
                    obj.strBAMAccess = obj.RevokedBAMAccess_ACE__c;
                } else {
                    obj['strBAMAccess'] = {
                        value: '-',
                        wrapper: `<center>-</center>`
                    }
                }

                if (obj.IsMinor_ACE__c !== undefined && obj.IsMinor_ACE__c) {
                    obj.strIsMinor = 'Yes';
                } else {
                    obj.strIsMinor = 'No';
                }

                if (obj.Member_Plan_ACE__r.Name !== undefined && obj.Member_Plan_ACE__r.Name) {
                    obj.strMemberName = obj.Member_Plan_ACE__r.Name;
                } else {
                    obj['strMemberName'] = {
                        value: '-',
                        wrapper: `<center>-</center>`
                    }
                }

                if (obj.Person_Restricted_ACE__c !== undefined) {
                    obj.strRepresentative = obj.Person_Restricted_ACE__c;
                } else {
                    obj['strRepresentative'] = {
                        value: '-',
                        wrapper: `<center>-</center>`
                    }
                }

                if (obj.Date_Signed_ACE__c !== undefined) {
                    let dateObj = new Date(obj.Date_Signed_ACE__c);
                    dateObj = this.convertUTCDateToLocalDate(dateObj);
                    let month = dateObj.getMonth() + 1;
                    obj.strEffectiveDate = (month > 9 ? month : "0" + month) + "/" + dateObj.getDate() + "/" + dateObj.getFullYear();

                } else {
                    obj['strEffectiveDate'] = {
                        value: '-',
                        wrapper: `<center>-</center>`
                    }
                }

                if (obj.Member_Plan_ACE__r.CMID_ACE__c !== undefined && obj.Member_Plan_ACE__r.CMID_ACE__c && (obj.Member_Plan_ACE__r.CMID_ACE__c).toString() == this.strMemberCmid) {
                    obj.boolShowButtons = true;
                } else {
                    obj.boolShowButtons = false;
                }

                obj.disablebtn = strDisableBtn;
                obj['boolSecTable'] = true;
                if (this.boolCheckForPermission === 'true' && obj.boolShowButtons) {
                    obj['strSecTable'] = `<div class="slds-form-element">
                    <label class="slds-form-element__label" for="form-element-01">Notes</label>
                    <div class="slds-form-element__control"><textarea rows="5" style="height: 50px;" disabled>${obj.Notes_ACE__c}</textarea>
                    </div></div><div class="slds-float_right">
                    <button class="slds-button slds-button_neutral hippaedit">Edit</button>
                    <button class="slds-button slds-button_destructive" ${strDisableBtn} >Deactivate</button></div>`;
                } else {
                    obj['strSecTable'] = `<div class="slds-form-element">
                    <label class="slds-form-element__label" for="form-element-01">Notes</label>
                    <div class="slds-form-element__control"><textarea rows="5" style="height: 50px;" disabled>${obj.Notes_ACE__c}</textarea>
                    </div></div><div class="slds-float_right"></div>`;
                }

                lstTableData.push(obj);
            }
        }
        if (lstTableData.length > 0 && tableType === 'CCRTable') {
            this.lstCCRTableData = lstTableData;
            this.boolShowNoCCRRecordsFound = false;
        } else if (tableType === 'CCRTable') {
            this.boolShowNoCCRRecordsFound = true;
        }

        if (lstTableData.length > 0 && tableType === 'RestrictionTable') {
            this.lstRestrictionTableData = lstTableData
            this.boolShowNoRestRecordsFound = false;
        } else if (tableType === 'RestrictionTable') {
            this.boolShowNoRestRecordsFound = true;
        }

    }

    convertUTCDateToLocalDate = (dateObj) => {
        var newDate = new Date(dateObj.getTime() + dateObj.getTimezoneOffset() * 60 * 1000);
        var offset = dateObj.getTimezoneOffset() / 60;
        var hours = dateObj.getHours();
        newDate.setHours(hours - offset);
        return newDate;
    }

    handleRowAction(event) {
        let eventDetail = event.detail;
        if (BaseLWC.isNotUndefinedOrNull(eventDetail)) {
            let objData = JSON.parse(eventDetail);
            if (BaseLWC.isNotUndefinedOrNull(objData.objSecTableEvent) && BaseLWC.isNotUndefinedOrNull(objData.objSecTableParentRowData)) {
                let rowData = JSON.parse(objData.objSecTableParentRowData);
                let uniquValue = rowData.filter((obj) => obj.key == 'Id');
                let objRecord = this.filterarray(this.lstHippaRecords, 'Id', uniquValue[0].value);
                let isSafeUserEnabled = false;
                fetchUserDetails().then((result) => {
                    if (result) {
                        isSafeUserEnabled = result.Safe_Mode_Enabled_ACE__c;
                    }
                    if (objData.objSecTableEvent.textContent == 'Edit') {
                        this.invokeEventOnEdit(objRecord[0], isSafeUserEnabled);
                    }
                    if (objData.objSecTableEvent.textContent == 'Deactivate') {
                        this.invokeEventOnDeactivate(objRecord[0], isSafeUserEnabled);
                    }
                }).catch(() => {
                    //Do Nothing
                });
            }
        }

    }

    invokeEventOnEdit(objRecord, isSafeUserEnabled) {
        let objParams = null;
        if (objRecord.RecordType.DeveloperName == 'HIPAA_CCRF_ACE') {
            objParams = {
                strIdDestination: this.label.UpdateHIPAARestrictions_ModalIdentifier_ACE + this.strGlobalMid,
                objParameters: {
                    strAction: this.label.UpdateHIPAARestrictions_EditCCRFIdentifier_ACE,
                    objHIPAARecordDetail: objRecord,
                    boolSafeMode: isSafeUserEnabled
                }
            };
        } else {
            objParams = {
                strIdDestination: this.label.UpdateHIPAARestrictions_ModalIdentifier_ACE + this.strGlobalMid,
                objParameters: {
                    strAction: this.label.UpdateHIPAARestrictions_EditRRFIdentifier_ACE,
                    objHIPAARecordDetail: objRecord,
                    boolSafeMode: isSafeUserEnabled
                }
            };
        }
        const editHippaEvent = new CustomEvent("edithipparecord", {
            detail: { objParams },
        });
        // Fire the custom event
        this.dispatchEvent(editHippaEvent);
    }

    invokeEventOnDeactivate(objRecord, isSafeUserEnabled) {

        let objParams = {
            strIdDestination: this.label.UpdateHIPAARestrictions_DeactivationModalIdentifier_ACE + this.strGlobalMid,
            objParameters: {
                strAction: this.label.UpdateHIPAARestrictions_OpenDeactivationModal_ACE,
                objHIPAARecordDetail: objRecord,
                boolSafeMode: isSafeUserEnabled
            }
        };

        const editHippaEvent = new CustomEvent("edithipparecord", {
            detail: { objParams },
        });
        // Fire the custom event
        this.dispatchEvent(editHippaEvent);
    }

    filterarray(arrayObj, arrayField, valueToMatch) {
        return arrayObj.filter(arrayObj => (arrayObj[arrayField]).toString() == valueToMatch);
    }
}