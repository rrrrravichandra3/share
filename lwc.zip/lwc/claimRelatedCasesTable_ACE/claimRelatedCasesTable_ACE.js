import { LightningElement, api, track } from 'lwc';
import fetchCaseRelatedDetails from '@salesforce/apex/ClaimsCaseSummaryController_ACE.fetchCaseRelatedDetails';
import TypeAndSubType from '@salesforce/label/c.ViewCaseSummary_TypeAndSubType_ACE';
import Status from '@salesforce/label/c.ViewCaseSummary_Status_ACE';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import { openTab} from 'lightning/platformWorkspaceApi';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';

export default class ClaimRelatedCasesTableACE extends LightningElement {
    @api strClaimNumber;
    @api newui = false;
    boolDisplayData = false;
    boolSpinner = true;
    boolError = false;
    label = {
        TypeAndSubType,
        Status,
        IntegrationFailMessage_ACE
    };
    @track lstTableData = [];
    boolShowNotesModal = false;
    boolShowTasksModal = false;
    tasksModal = {};
    objError;
    notesModal = {};
    get boolShowNoRecordsFound() {
        return !BaseLWC.arrayIsNotEmpty(this.lstTableData);
    }

    get cardCss() {
        if (this.newui) {
            return 'slds-card slds-card_boundary';
        }
        return 'slds-card';
    }

    columns = [
        { label: 'CASE NUMBER', fieldName: 'CaseNumber', sortable: true, type: '' },
        { label: 'DATE/TIME OPENED', fieldName: 'CreatedDate', sortable: true, type: 'date'},
        { label: 'INQUIRER NAME', fieldName: 'InquirerName_ACE__c', sortable: true, type: '' },
        { label: 'SUBSCRIBER ID', fieldName: 'SubscriberID_ACE__c', sortable: true, type: '' },
        { label: 'GROUP NUMBER', fieldName: 'GroupNumber_ACE__c', sortable: true, type: '' },
        { label: 'TYPE/SUB-TYPE', fieldName: 'TypeAndSubType_ACE__c', sortable: true, type: '' },
        { label: this.label.Status, fieldName: 'Status', sortable: true, type: '' },
        { label: 'CASE OWNER', fieldName: 'OwnerName', sortable: true, type: '' },
        { label: 'ACTION', fieldName: 'actionLink', sortable: false, type: '' }
    ];

    objInitTableSettings = {
        pageSize: 10,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: false,
        boolSecondaryTable: false,
        boolShowSearch: false,
        boolShowSearchLabel: false,
        boolShowRecordCount: false,
        filterData: [
            { strType: 'picklist', intCol: 5, strFilterName: 'Group  Number' },
            { strType: 'picklist', intCol: 6, strFilterName: this.label.TypeAndSubType },
            { strType: 'picklist', intCol: 7, strFilterName: 'Status' }
        ]
    };

    connectedCallback() {
        if (this.strClaimNumber) {
            this.fetchCaseRelatedDetails();
        }
    }

    fetchCaseRelatedDetails() {
        this.boolSpinner = true;
        this.boolDisplayData = false;
        this.boolError = false;
        fetchCaseRelatedDetails({ strClaimId: this.strClaimNumber })
            .then((lstResultCaseData) => {
                this.processCaseDataForTable(lstResultCaseData);
            })
            .catch((_error) => {
                this.handleErrors(_error);
            });
    }
    processCaseDataForTable(lstResultCaseData) {
        try {
            const data = [...lstResultCaseData];
            const caseSet = new Set();
            //Loop through Data to modify for Table
            this.lstTableData = [];
            this.lstTableData = data.map((elem) => {
                const el = elem.caseDetail;
                caseSet.add(el.Related_Case_ACE__r.Id);
                const objCase = {};
                objCase['CaseNumber'] = {
                    value: el.Related_Case_ACE__r.CaseNumber,
                    strCaseId: el.Related_Case_ACE__r.Id,
                    strAccountId: el.Related_Case_ACE__r.AccountId,
                    wrapper: `<a data-casenumber="${el.Related_Case_ACE__r.CaseNumber}">${el.Related_Case_ACE__r.CaseNumber}</a>`
                };
                let datDateToShow = '';
                if (BaseLWC.dtDateTimeISOtoLocal(el.Related_Case_ACE__r.CreatedDate) !== 'Invalid Date') {
                    datDateToShow = BaseLWC.dtDateTimeISOtoLocal(el.Related_Case_ACE__r.CreatedDate);
                }
                objCase.CreatedDate = this.validateData(datDateToShow);
                objCase.InquirerName_ACE__c = this.validateData(el.Related_Case_ACE__r.InquirerName_ACE__c);
                objCase.CaseAge_ACE__c = this.validateData(el.CaseAge_ACE__c);
                objCase.SubscriberID_ACE__c = this.validateData(el.Related_Case_ACE__r.SubscriberID_ACE__c);
                objCase.GroupNumber_ACE__c = this.validateData(el.Related_Case_ACE__r.GroupNumber_ACE__c);
                objCase['TypeAndSubType_ACE__c'] = this.validateData(this.convertAPIToLabelForTypeAndSubtype(el.Related_Case_ACE__r.TypeAndSubType_ACE__c));
                objCase.Status = this.validateData(el.Related_Case_ACE__r.Status);
                objCase.OwnerName = this.validateData(el.Related_Case_ACE__r.Owner.Name);
                objCase.actionLink = {
                    value: el.Related_Case_ACE__r.CaseNumber,
                    strCaseId: el.Related_Case_ACE__r.Id,
                    strType: el.Related_Case_ACE__r.Type,
                    strSubType: el.Related_Case_ACE__r.Sub_Type_ACE__c,
                    strFacetsTaskId: el.Related_Case_ACE__r.Facets_Task_ID_ACE__c,
                    wrapper: `<a data-casenumber="${el.Related_Case_ACE__r.CaseNumber}">View Notes</a>`
                }
                return objCase;
            });
            let showBanner = false;
            if (this.lstTableData.length) {
                showBanner = true;
            }
            const objParameterToBeSent = {
                'showBanner' : showBanner
            }
            const objCustomEvent = new CustomEvent('showbanner', {
                detail: objParameterToBeSent
            });
            this.dispatchEvent(objCustomEvent);
            this.boolDisplayData = true;
            this.boolSpinner = false;
        } catch (error) {
            this.handleErrors(error);
        }
    }
    handleErrors(_error) {
        this.boolSpinner = false;
        this.boolError = _error;
    }
    validateData(data) {
        if (data !== null && data !== undefined && typeof data === 'number') {
            return data.toString();
        }
        if (data) {
            return data;
        }
        return '';
    }
    hideMessage() {
        this.boolShowMessage = false;
    }

    convertAPIToLabelForTypeAndSubtype(strTypeSubtype) {
        let strNewTypeSubtype = strTypeSubtype;
        const strGMC = 'Grievance / Complaint';
        if (strNewTypeSubtype.includes(strGMC)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strGMC, 'Grievance / Member Complaint');
        }
        const strMemberPortal = 'Member Portal (BAM)';
        if (strNewTypeSubtype.includes(strMemberPortal)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMemberPortal, 'Member Portal');
        }
        const strMGPCP = 'PCP Update';
        if (strNewTypeSubtype.includes(strMGPCP)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMGPCP, 'MG / PCP Update');
        }
        const strPreAuth = 'Prior Authorization';
        if (strNewTypeSubtype.includes(strPreAuth)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strPreAuth, 'Preauth');
        }
        const strProspectiveMember = 'Prospective Member';
        if (strNewTypeSubtype.includes(strProspectiveMember)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strProspectiveMember, 'Temporary Member');
        }
        return strNewTypeSubtype;
    }
    handleRowAction(event) {
        try {
            const column = JSON.parse(event.detail).activeColFieldName;
            const rowData = JSON.parse(event.detail);
            if (column === 'actionLink') {
                this.notesModal.strCaseNumber = rowData.activeColumnData.value.value;
                this.notesModal.strCaseId = rowData.activeColumnData.value.strCaseId;
                this.notesModal.strCaseType = rowData.activeColumnData.value.strType;
                this.notesModal.strCaseSubType = rowData.activeColumnData.value.strSubType;
                this.notesModal.strFacetsTaskId = rowData.activeColumnData.value.strFacetsTaskId;
                this.boolShowNotesModal = true;
            } else if (column === 'actionBtn' && rowData.strActionKey === 'viewTasks') {
                this.tasksModal.strCaseId = rowData.activeColumnData.value.objTasksData.strCaseId;
                this.tasksModal.strAccountId = rowData.activeColumnData.value.objTasksData.strAccountId;
                this.tasksModal.strCaseNumber = rowData.activeColumnData.value.objTasksData.strCaseNumber;
                this.tasksModal.strCaseType = rowData.activeColumnData.value.objTasksData.strType;
                this.tasksModal.strCaseSubType = rowData.activeColumnData.value.objTasksData.strSubType;
                this.boolShowTasksModal = true;
            } else if (column === 'CaseNumber') {
                this.openCaseDetails(rowData.activeColumnData.value.strCaseId);
            } else {
                //do nothing
            }
        } catch (error) {
            //Handle Error
            this.handleErrors(error);
        }
    }
    openCaseDetails = (strCaseId) => {
        openTab({recordId: strCaseId, focus: true})
            .then(() => {})
            .catch((error) => {
                this.handleErrors(error);
            });
    };
    closeModal() {
        this.boolShowNotesModal = false;
    }
    closeTaskModal() {
        this.boolShowTasksModal = false;
    }
    @api
    refreshData() {
        this.fetchCaseRelatedDetails();
    }
}