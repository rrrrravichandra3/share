import { LightningElement, track, wire, api } from 'lwc';
import fetchCases from '@salesforce/apex/AddToCaseController_ACE.getMedicaidCaseRcordList';
import fetchProfile from '@salesforce/apex/AddToCaseController_ACE.fetchProfile';

import addNotesCase from '@salesforce/apex/AddToCaseController_ACE.addNotestoCase';
import addCaseAttachmentToCase from '@salesforce/apex/AddToCaseController_ACE.addCaseAttachmentToCase';
import {EnclosingTabId,getTabInfo, openSubtab} from 'lightning/platformWorkspaceApi';
import BaseLWC from 'c/baseLWCFunctions_CF';
import insertTXMAppealsCaseRelatedRecords from '@salesforce/apex/AddToCaseController_ACE.insertTXMAppealsCaseRelatedRecords';
import fetchCaseRuleId from '@salesforce/apex/NewCaseCheckClass_ACE.sendCaseRuleId';
import fetchRecordTypeId from '@salesforce/apex/NewCaseCheckClass_ACE.sendCaseRecordTypeId';
import AppealsRecordType_ACE from '@salesforce/label/c.AppealsRecordType_ACE';
import CreateCasePage_GovMediciadValue_ACE from '@salesforce/label/c.CreateCasePage_GovMediciadValue_ACE';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import System_Administrator_profile_ACE from '@salesforce/label/c.System_Administrator_profile_ACE';
import CustomerAdvocateSpecialist_Profile_ACE from '@salesforce/label/c.CustomerAdvocateSpecialist_Profile_ACE';
import Supervisor_Profile_ACE from '@salesforce/label/c.Supervisor_Profile_ACE';

export default class MedicalRecordStatusViewerButtonLWCACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    @track tableSettings;
    @api medicalrecords;
    @api showmodal ;
    @api showNewCaseButton;
    @api boolCorrespondenceDoc;
    @api boolTXMAppealsAddToCase;
    @api boolShowButton;
    boolAfterSubmit = false;

    @track boolDisableAddCaseButton = true;
    @track boolDisableNewCaseButton = true;
    @track boolHideAddCaseDisabledHoverMessage = true;
    @track boolHideNewCaseDisabledHoverMessage = true;

    get strConfirmModalText () {
        let strconfimText = '';
        this.boolCorrespondenceDoc === 'true' ? strconfimText = 'Please confirm addition of Document(s) to Case' : strconfimText = 'Please confirm addition of Medical Record Status information to Case'
        //CEAS-77949
        if  (this.boolTXMAppealsAddToCase === 'true' )
            strconfimText = 'Please confirm addition of Appeal to Case ';
       
        return strconfimText;    
    }
    label = {  
        AppealsRecordType_ACE,
        CreateCasePage_GovMediciadValue_ACE,
        EnableVPSTabSpecificEvents_ACE,
        System_Administrator_profile_ACE,
        CustomerAdvocateSpecialist_Profile_ACE,
        Supervisor_Profile_ACE
    }
    activeCaseNumber;
    caseRuleId;
    strRecordTypeId;
    caseType;
    caseSubType;
    strFacetsTaskId;
    strLineOfBusiness;
    boolAddToCase = false;
    boolShowCaseNotes = false;
    boolDisplayData=false;
    strCMID = null;
    grpNo = null;
    mapAllCases = new Map();
    columns;
    boolSecondaryTable ;
    boolShowSpinner = false;
    addtocase = false;
    sboolDisplayData =false;
    strRecordId;
    strURL;
    parenttabId;
    lstTableData=[];
    caseRuleId;
    strRecordTypeId;
    strPlanSummaryEvent = 'PlanSummaryEvent';
    strPatientName;
    boolPlanSummaryData;
    PlanSummaryData;
    planSummaryListened;
    boolVPSTabSpecificEvents;
    @api strCorpCode;
    @api strLob;

    cASPRofile = false;
    boolCASCaseSelected = false;
    boolAllCaseSelected = true;
    boolShowNoRecordsFound = false;
    strProfileName; 

    columns = [
        { label: 'CASE NUMBER', fieldName: 'CaseNumber', sortable: true, type: '' },
        { label: 'DATE/TIME OPENED', fieldName: 'CreatedDate', sortable: true, type: 'date' },
        { label: 'TYPE/SUB-TYPE', fieldName: 'TypeAndSubType_ACE__c', sortable: false, type: ''},
        { label: 'TYPE', fieldName: 'Type', sortable: true, type: '', boolHidden: true },
        { label: 'SUB-TYPE', fieldName: 'Sub_Type_ACE__c', sortable: true, type: '', boolHidden: true },
        { label: 'BENEFIT/CLAIMTYPE', fieldName: 'Benefit_Claim_Type_ACE__c', sortable: true,type: '' },
        { label: 'STATUS', fieldName: 'Status', sortable: true, type: '' },
        { label: 'ACTION', fieldName: 'actionBtn', sortable: false, type: 'actionBtn', rowActions:[
            {key: "addToCase", label:"Add to Case"},
            {key: "viewNotes", label:"View Notes"}
        ]},
        { label: 'CASEID', fieldName: 'Id', sortable: false, type: '',boolHidden: true },
        { label: 'FACETSTASKID', fieldName: 'Facets_Task_ID_ACE__c', sortable: false, type: '',boolHidden: true},
        { label: 'LOB', fieldName: 'LineOfBusiness_ACE__c', sortable: false, type: '',boolHidden: true},
       ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize:5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: false,
        boolSecondaryTable: false,
        boolShowSearch: false,
        filterData: []
    };


    showAddtoCase() {
        this.boolAddToCase = false;
        this.showmodal = true;
    }
    closeAddtoCase() {
        this.boolAddToCase = false;
        this.showmodal = false;
        this.boolShowCaseNotes = false;
        this.closeModalEvent();
    }
    refreshTable() {
        //CEAS-80641
        this.boolDisplayData = false;
        this.boolAddToCase = false;
        this.boolShowSpinner =  true;
        this.fetchCaseData();
    }


    connectedCallback() {
        try {
            this.boolAddToCase = false;
            this.getCaseRuleId();
            this.getRecordTypeId();
            this.fetchTabData();
        } catch (error) {
            //Handle Error
            this.handleErrors();
        }
    }
    
    fetchTabData = () => {
        this.boolAddToCase = false;
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
                this.objTabData = objTabData;
                this.parenttabId = this.objTabData.parentTabId;
                this.strURL = this.objTabData.url;
                this.strCMID = BaseLWC.helperBaseGetUrlParameters('strcmid', this.strURL);
                if (this.strCMID == '') {
                    this.strCMID = BaseLWC.helperBaseGetUrlParameters('Cmid', this.strURL);
                }
                this.grpNo = BaseLWC.helperBaseGetUrlParameters('groupNumber', this.strURL);
                if (this.grpNo == '') {
                    this.grpNo = BaseLWC.helperBaseGetUrlParameters('groupName', this.strURL);
                }
                this.strProfileName = BaseLWC.helperBaseGetUrlParameters('pfn', this.strURL);
                this.checkprofileAndGetData();
            })
            .catch(() => {
                this.handleErrors();
            });
        }
    }

    checkprofileAndGetData() {
        if (!this.strProfileName) {
            fetchProfile({}).then((objProfileDetailsResult) => {
                try {
                    this.strProfileName = objProfileDetailsResult;
                    if (this.strProfileName === this.label.System_Administrator_profile_ACE || this.strProfileName === this.label.CustomerAdvocateSpecialist_Profile_ACE || this.strProfileName === this.label.Supervisor_Profile_ACE) {
                        this.cASPRofile = true;
                    } else {
                        this.cASPRofile = false;
                    }
                    this.fetchCaseData();
                } catch (exception) {
                    //No handling Needed.
                }
            }).catch(() => {
                    //do nothing
            });
        } else {
            if (this.strProfileName === this.label.System_Administrator_profile_ACE || this.strProfileName === this.label.CustomerAdvocateSpecialist_Profile_ACE || this.strProfileName === this.label.Supervisor_Profile_ACE) {
                this.cASPRofile = true;
            } else {
                this.cASPRofile = false;
            }
            this.fetchCaseData();
        }
    }

    @api
    fetchCaseData() {
        this.lstTableData.length = 0;
        this.lstTableData = [];
        this.boolDisplayData = false;
        this.boolShowSpinner = true;

        fetchCases({ cmId: this.strCMID, groupNumber: this.grpNo, getCASCase: this.boolCASCaseSelected })
            .then((result) => {
                for (let i = 0; i < result.length; i++) {
                    result[i]['CaseNumber'] = {
                        value: result[i]['CaseNumber'],
                        wrapper: `<a data-casenumber="${result[i].CaseNumber}">${result[i].CaseNumber}</a>`
                    };
                    result[i]['actionBtn'] = {
                        rowActions:[
                            {key: "addToCase", label:"Add to Case", disabled: false},
                            {key: "viewNotes", label:"View Notes", disabled: false}
                        ]
                    };
                    //CEAS-77949 modified for date/time
                    let dtTimeOpened = '';
                    if (result[i]["CreatedDate"] && new Date(result[i]["CreatedDate"]).toString() !== 'Invalid Date') {
                        dtTimeOpened = BaseLWC.dtDateTimeISOtoLocal(result[i]["CreatedDate"]);
                    }
                    result[i]["CreatedDate"] = {
                        value: result[i]["CreatedDate"],
                        wrapper: `<span>${dtTimeOpened}</span>`
                    };

                }

                this.lstTableData = [...result];
                this.boolDisplayData = true;
                this.boolShowSpinner = false;
                if (result.length == 0) {
                    this.boolShowNoRecordsFound = true;
                } else {
                    this.boolShowNoRecordsFound = false;
                }
                //NT 
                this.EnableDisableButtons();
        })
        .catch(() => {
            this.handleErrors();
            this.boolShowSpinner = false;
        });
    }

    handleRowAction(e) {
        try {
            const column = JSON.parse(e.detail).activeColumnData.key;
            const rowData = JSON.parse(JSON.parse(e.detail).renderedRowData);
            this.activeCaseNumber = rowData[0].value.value;
            this.strRecordId = rowData[8].value;
            this.caseType = rowData[3].value;
            this.caseSubType = rowData[4].value;
            this.strFacetsTaskId = rowData[9].value;
            this.strLineOfBusiness = rowData[10].value;
            if (column === 'CaseNumber') {
                this.showmodal = false;
                openSubtab(this.parenttabId, { recordId: this.strRecordId, focus: true});
                this.closeModalEvent();
            } else if (column === 'actionBtn') {
                const strActionKey = JSON.parse(e.detail).strActionKey;
                if(strActionKey === 'addToCase'){
                    this.boolAddToCase = true;
                    this.boolAddToExistingCase = false;
                } else if(strActionKey === 'viewNotes'){
                    this.boolShowCaseNotes = true;
                    this.showmodal = false;
                } else {
                    //do nothing
                }
            } else {
                //do nothing
            }
            this.boolDisplayData = true;
        } catch (error) {
            //Handle Error
            this.handleErrors();
        }
    }
    passDetailsToCaseDetailPage() {

        if(this.boolCorrespondenceDoc === 'true') {
            addCaseAttachmentToCase({ CaseId: this.strRecordId, strCorrespondenceObject : this.medicalrecords})
            .then((result) => {
                    this.showmodal = false;
                    if (this.strURL) {
                        let strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.strURL);
                        strDecodedURL = strDecodedURL.split('/view&')
                        if(strDecodedURL && strDecodedURL.length > 1) {
                            let strdecodedParams = strDecodedURL[1];
                            strdecodedParams = '?' + strdecodedParams+'&caseNumber=' + this.activeCaseNumber
                            const strUrl = '/lightning/r/Case/' + this.strRecordId + '/view' + BaseLWC.helperBaseEncodeUrl(strdecodedParams);
                             BaseLWC.helperBasePostTabIdMessageCustomEvents(
                                'refreshCaseAttachmentEvent' + this.parenttabId,
                                null,
                                null,
                                "RefreshCaseAttachment",
                                this.parenttabId
                            );
                           openSubtab(this.parenttabId,{ url: strUrl, focus: true });
                        }
                    }
                    this.boolAfterSubmit = true;
                    this.closeModalEvent();
                })
                .catch((error) => {
                    this.handleErrors();
                });
        } else {
            this.finalmedicalnotes = this.notesRecord + this.medicalrecords ;
            if (this.medicalrecords !== '' && this.medicalrecords !== 'undefined') {
            addNotesCase({ CaseId: this.strRecordId, medicalStatus: this.finalmedicalnotes,strContentNotes :this.medicalrecords})
            .then(() => {
                    this.showmodal = false;
                   openSubtab(this.parenttabId, { recordId: this.strRecordId, focus: true });
                    this.closeModalEvent();
                })
                .catch(() => {
                    this.handleErrors();
                });
            }
       }
    }
    //CEAS-77949 start
    passDetailsToTXMCaseDetailPage() {

        let completionDatetxm = this.medicalrecords.Completion_Date_ACE__c;
        let dateACEtxm = this.medicalrecords.Date_ACE__c;

        if (dateACEtxm) {
            const lstDateTimeOpened = dateACEtxm.split("/");
            dateACEtxm = lstDateTimeOpened[2] + '-' + lstDateTimeOpened[0] + '-' + lstDateTimeOpened[1];
        }
        if (completionDatetxm) {
            const lstDateTimeOpened = completionDatetxm.split("/");
            completionDatetxm = lstDateTimeOpened[2] + '-' + lstDateTimeOpened[0] + '-' + lstDateTimeOpened[1];
        }

        

        let medicalrecordsSend = {
            Claim_Number_ACE__c: this.medicalrecords.Claim_Number_ACE__c,
            Date_ACE__c: dateACEtxm,
            Status_ACE__c: this.medicalrecords.Status_ACE__c,
            Patient_Name_ACE__c: this.medicalrecords.Patient_Name_ACE__c,
            Completion_Date_ACE__c: completionDatetxm,
            Status_Reason_ACE__c: this.medicalrecords.Status_Reason_ACE__c,
            ComplaintClass_ACE__c: this.medicalrecords.ComplaintClass_ACE__c,
            GC_Appeal_ACE__c: true
        };
        let sendMedRecord = JSON.stringify(medicalrecordsSend);
        if(this.boolTXMAppealsAddToCase === 'true') {
            insertTXMAppealsCaseRelatedRecords({ CaseId: this.strRecordId, strCaseRelatedRecords : sendMedRecord})
            .then((result) => {
                    this.showmodal = false;
                    if (this.strURL) {
                        let strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.strURL);
                        strDecodedURL = strDecodedURL.split('/view&')
                        if(strDecodedURL && strDecodedURL.length > 1) {
                            let strdecodedParams = strDecodedURL[1];
                            strdecodedParams = '?' + strdecodedParams+'&caseNumber=' + this.activeCaseNumber
                            const strUrl = '/lightning/r/Case/' + this.strRecordId + '/view' + BaseLWC.helperBaseEncodeUrl(strdecodedParams);
                            openSubtab(this.parenttabId, { url: strUrl, focus: true });
                             BaseLWC.helperBasePostTabIdMessageCustomEvents(
                                'refreshCaseAttachmentEvent' + this.parenttabId,
                                 null,
                                 null,
                                 "RefreshCaseAttachment",
                                 this.parenttabId
                                );

                        }
                    }
                    this.boolAfterSubmit = true;
                    this.closeModalEvent();
                })
                .catch((error) => {
                    this.handleErrors();
                });
        } else {
            this.finalmedicalnotes = this.notesRecord + this.medicalrecords ;
            if (this.medicalrecords !== '' && this.medicalrecords !== 'undefined') {
            addNotesCase({ CaseId: this.strRecordId, medicalStatus: this.finalmedicalnotes,strContentNotes :this.medicalrecords})
            .then(() => {
                    this.showmodal = false;
                    openSubtab(this.parenttabId, { recordId: this.strRecordId, focus: true });
                    this.closeModalEvent();
                })
                .catch(() => {
                    this.handleErrors();
                });
            }
       }
       this.boolAddToCase = false;
    }

    getCaseRuleId() {
        fetchCaseRuleId({ caseRule: this.label.AppealsRecordType_ACE, strLineOfBusiness: this.label.CreateCasePage_GovMediciadValue_ACE})
            .then((result) => {
                this.caseRuleId = result.Id;
                
        })
        .catch(() => {
            this.handleErrors();
        });
    }

    getRecordTypeId() {
        fetchRecordTypeId({ caseRecordType: this.label.AppealsRecordType_ACE})
            .then((result) => {
                this.strRecordTypeId = result;
                
        })
        .catch(() => {
            this.handleErrors();
        });
    }


    navigateToTXMNewCase() {
        try {

            let completionDatetxm = this.medicalrecords.Completion_Date_ACE__c;
            let dateACEtxm = this.medicalrecords.Date_ACE__c;

                const hoverdetails = {
                        "Patient_Name_ACE__c": this.medicalrecords.Patient_Name_ACE__c,
                        "Completion_Date_ACE__c": completionDatetxm,
                        "Status_Reason_ACE__c":  this.medicalrecords.Status_Reason_ACE__c,
                        "ComplaintClass_ACE__c": this.medicalrecords.ComplaintClass_ACE__c
                        };
               
                const lstCaseRelatedDetail = [{
                    "RecordType": this.label.AppealsRecordType_ACE,
                    "Claim_Number_ACE__c": this.medicalrecords.Claim_Number_ACE__c,
                    "Date_ACE__c": dateACEtxm,
                    "Status_ACE__c": this.medicalrecords.Status_ACE__c,
                    "Hover_Related_Field_Appeals_ACE__c": hoverdetails,
                    "Status_Reason_ACE__c": this.medicalrecords.Status_Reason_ACE__c,
                    "Patient_Name_ACE__c": this.medicalrecords.Patient_Name_ACE__c,
                    "Completion_Date_ACE__c": completionDatetxm,
                    "ComplaintClass_ACE__c": this.medicalrecords.ComplaintClass_ACE__c,
                    "CorpCode_ACE__c": 'TX1',
                    "LineOfBusiness_ACE__c"  : CreateCasePage_GovMediciadValue_ACE,
                    "GC_Appeal_ACE__c": true
                    }];
        
                    const objCasedetails = {
                        "RecordTypeId": this.strRecordTypeId,
                        "Expedited_ACE__c": "No",
                        "Sub_Category_ACE__c": this.medicalrecords.Sub_Category_ACE__c,
                        "LineOfBusiness_ACE__c"  : CreateCasePage_GovMediciadValue_ACE
                    };
                          
                  
            let strIframeId = 'idCreateNewCaseLightningComponent';
            if (this.strURL) {
                let strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.strURL);
                strDecodedURL = strDecodedURL.split('/view&')
                if(strDecodedURL && strDecodedURL.length > 1) {
                    const arrFrameId = strDecodedURL[0].split("Account/");
                    strIframeId = strIframeId + '_' + arrFrameId[1];
                }
            }
            const strFlexipageNameUrl = '/lightning/n/Manual_Case_Create_ACE';
            const strUrl = '?Dynamic=true&timeInMillis=' + Date.now();
            const strFlexiPageUrl = strFlexipageNameUrl +  BaseLWC.helperBaseEncodeUrl(strUrl);
            openSubtab(this.parenttabId, { url: strFlexiPageUrl, focus: true });
            this.sendToFoundationCreateCasePage(objCasedetails,lstCaseRelatedDetail , this.caseRuleId,strIframeId);
        } 
        catch (exception) {
            this.handleErrors();
        }
    }

    //Posts a message to the iframe to capture the parent case details which needs to be handled in Manualcasecreation.js
    sendToFoundationCreateCasePage(objCasedetails,lstCaseRelatedDetail , caseRuleId,strIframeId) {
        try {
                let intCasePageInterval = 0;
                const objErrorData = {};
                objErrorData.strComponentName = 'medicalRecordStatusViewerButtonLWCACE';
                objErrorData.strMessage = 'SetIntervals';
                objErrorData.strFunctionName = 'sendToFoundationCreateCasePage';
                objErrorData.strStackTrace = 'MaxIntervalReached;\nClearedInterval;\n';
                objErrorData.strError = 'IframeId Not Found: ' +this.strIframeId;
                  
                const postMessageFunction = setInterval(() => { 
                try {
                      intCasePageInterval++;
                      const strDynamicCasePage = document.getElementById(strIframeId);
                      if (strDynamicCasePage !== undefined && strDynamicCasePage !== null && strDynamicCasePage.dataIsLoaded === 1) {
                          clearInterval(postMessageFunction);
                          this.postDataToCasePage(objCasedetails,lstCaseRelatedDetail , caseRuleId,strIframeId);
                          clearInterval(postMessageFunction);
                      }
                      BaseLWC.clearLoopedIntervalsInBase(this, intCasePageInterval, 1, postMessageFunction, objErrorData);
                  } catch (objException) {
                      clearInterval(postMessageFunction);
                  }
                }, 1000);
            } catch (exception) {
                return;
            }
        }
      
    postDataToCasePage(objCasedetails,lstCaseRelatedDetail , caseRuleId,strIframeId) {
        const objClaimSummaryFrame = document.getElementById(strIframeId).contentWindow;
        const objResponse = {
        strIdDestination: 'Manual_Case_Creation_Case_Related_Details',
        objParameters: {
                caseObject: objCasedetails,
                caseRuleId : caseRuleId,
                lstCaseRelatedDetail : lstCaseRelatedDetail ,
                strLOBViewClaimHistory : CreateCasePage_GovMediciadValue_ACE
                }
            };
            // Posting message
            objClaimSummaryFrame.postMessage(JSON.stringify(objResponse), '*');
    }
    //CEAS-77949 end

    cancelAddtoCase(){
        this.closeModalEvent();
        this.boolAddToCase = false;

    }
    closeModalEvent() {
        const casecloseModal = new CustomEvent('medicalclosemodal', {
            detail: { showmodal: false,
                boolAfterSubmit : this.boolAfterSubmit }
    });
    this.boolAfterSubmit = false
        // Fire the custom event
        this.dispatchEvent(casecloseModal);
    }
    navigateToNewCase() {
        BaseLWC.fireNativeCustomEvent('caseopen', '', this);
    }

    toggleCaseNotes() {
        this.boolShowCaseNotes = false;
        this.showmodal = true;
    }

    disconnectedCallback(){
        this.showmodal = false;
    }
     //Handle the error occurances
     handleErrors(){
        //Do nothing
    }
    
    openAddToCase() {
        this.fetchCaseData(); //NT: CEAS-84796 - Fetching of data moved to here to avoid displaying stale data
        this.showmodal = true;
    }

    generateCASCases(evt) {
        let ele = this.template.querySelector('.slds-tabs_default__item[title="CAS Cases"]');
        if (!ele.classList.contains('slds-is-active')) {
            this.template.querySelector('.slds-tabs_default__item[title="CAS Cases"]')?.classList.add('slds-is-active');
        }
        this.template.querySelector('.slds-tabs_default__item[title="Cases"]')?.classList.remove('slds-is-active');
        this.boolCASCaseSelected = true;
        this.boolAllCaseSelected = false;
        this.fetchCaseData();
    }
    generateAllCases(evt) {
        let ele = this.template.querySelector('.slds-tabs_default__item[title="Cases"]');
        if (!ele.classList.contains('slds-is-active')) {
            this.template.querySelector('.slds-tabs_default__item[title="Cases"]')?.classList.add('slds-is-active');
        }
        this.template.querySelector('.slds-tabs_default__item[title="CAS Cases"]')?.classList.remove('slds-is-active');
        this.boolCASCaseSelected = false;
        this.boolAllCaseSelected = true;
        this.fetchCaseData();
    }

    //NT: CEAS-85895
    showTooltip(event) {
        var buttonID = event.target.dataset.id;

        if (buttonID === 'addButton') {
            this.boolHideAddCaseDisabledHoverMessage = false;
        } else {
            this.boolHideNewCaseDisabledHoverMessage = false;
        }

    }

    //NT: CEAS-85895
    hideTooltip(event) {
        var buttonID = event.target.dataset.id;

        if (buttonID === 'addButton') {
            this.boolHideAddCaseDisabledHoverMessage = true;
        } else {
            this.boolHideNewCaseDisabledHoverMessage = true;
        }

    }

    //NT: CEAS-85895
    EnableDisableButtons() {
        if (this.strLob === 'GOVERNMENT-MEDICAID' && (this.strCorpCode == 'TX1' || this.strCorpCode == 'NM1')) {
            if (this.lstTableData && this.lstTableData.length ==0 ) {
                this.boolDisableAddCaseButton = true;
                this.boolDisableNewCaseButton = false;
            } else {
                this.boolDisableAddCaseButton = false;
                this.boolDisableNewCaseButton = true;
            }
        } else {
            this.boolDisableAddCaseButton = false;
            this.boolDisableNewCaseButton = false;
        }
    }
}