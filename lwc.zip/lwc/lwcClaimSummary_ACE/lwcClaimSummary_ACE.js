import {
	LightningElement,
	api,
	track,
	wire
} from 'lwc';
//Base LWC functions.
import BaseLWC from "c/baseLWCFunctions_CF";
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import LineOfBusinessDefault_ACE from '@salesforce/label/c.LineOfBusinessDefault_ACE';
import Retail_LineOfBusinessLabel_ACE from '@salesforce/label/c.Retail_LineOfBusinessLabel_ACE';
import BlueCard_Claims_ACE from '@salesforce/label/c.BlueCard_Claims_ACE';
import ClaimsAndAppeals_ACE from '@salesforce/label/c.ClaimsAndAppeals_ACE';
import PastDueClaims_ClaimsSummaryHeader_ACE from '@salesforce/label/c.PastDueClaims_ClaimsSummaryHeader_ACE';
import PastDueClaims_ClaimsSummaryDispositionDate_ACE from '@salesforce/label/c.PastDueClaims_ClaimsSummaryDispositionDate_ACE';
import PastDueClaims_ClaimsSummaryServiceToDate_ACE from '@salesforce/label/c.PastDueClaims_ClaimsSummaryServiceToDate_ACE';
import ViewMedicalDetails_Claims_ACE from '@salesforce/label/c.ViewMedicalDetails_Claims_ACE';
import IdCard_Medical_ACE from '@salesforce/label/c.IdCard_Medical_ACE';
import ViewClaimHistory_Pharmacy_ACE from '@salesforce/label/c.ViewClaimHistory_Pharmacy_ACE';
import IdCard_Dental_ACE from '@salesforce/label/c.IdCard_Dental_ACE';
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import ViewPlanSummary_CardHeader_Refresh_ACE from '@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE';
import fepClaimsSummaryRequest from '@salesforce/apexContinuation/ClaimSummaryController_ACE.fepClaimsSummaryRequest';
import claimsSummaryRequest from '@salesforce/apexContinuation/ClaimSummaryController_ACE.claimsSummaryRequest';
import fetchBlueCardMemberDetails from '@salesforce/apex/ClaimSummaryController_ACE.fetchBlueCardMemberDetails';
import fetchClaimsFEPDirectURL from '@salesforce/apex/ClaimSummaryController_ACE.fetchClaimsFEPDirectURL';
import blueCardClaimsSummaryRequest from '@salesforce/apexContinuation/ClaimSummaryController_ACE.blueCardClaimsSummaryRequest';
import appealsSummaryRequest from '@salesforce/apexContinuation/ClaimSummaryController_ACE.appealsSummaryRequest';
import disputeResolutionRequest from '@salesforce/apexContinuation/ClaimSummaryController_ACE.disputeResolutionRequest';
import HCSCClaimsStaticResource_ACE from '@salesforce/resourceUrl/HCSCClaimsStaticResource_ACE';
export default class LwcClaimSummary_ACE extends LightningElement {
	@wire(EnclosingTabId) enclosingTabId;
	@api recordId;
	@track objTabData = [];
	boolVPSTabSpecificEvents = false;
	strLOB = '';
	boolShowDisputeResolutionTab = true;
	boolShowAppealsTab = true;
	boolShowPharmacyTab = false;
	boolListenedFirstTime = false;
	strCorpCode = '';
	strSubscriberId = '';
	strGroupName = '';
	strMid = '';
	boolFEPMember = false;
	boolCalloutDone = false;
	boolIsPlanChanged = false;
	boolIsAppealClicked = false;
	strDDValue = '';
	strDOSValue = '';
		@track lstFEPClaims;
	@track objFEPData = [];
	boolIsPlanSummaryListenedForPCP = false;
	boolShowPDCContainer = false;
	boolDentalPlanSelected = false;
	strViewMoreFEPClaim = '';
	boolIsFEPClaimPresent = false;
	boolIsFEPClaimNoData = false;
	boolIsFEPClaimIntError = false;
	@track lstMedicalClaims = [];
	@track objMedicalData = [];
	strViewMoreMedical = '';
	boolIsMedicalPresent = false;
	boolIsMedicalNoData = false;
	boolIsMedicalIntError = false;
	boolIsPharamacyPresent = false;
	boolIsPharmacyIntError = false;
	boolIsPharmacyNoData = false;
	boolIsDentalPresent = false;
	boolIsDentalIntError = false;
	boolIsDentalNoData = false;
	@track lstPharmacyClaims = [];
	strViewMorePharamacy = '';
	@track objPharmacyData = [];
	@track lstDentalClaims = [];
	@track objDentalData;
	strViewMoreDental = '';
	objSafeModeUtilitySummaryListener;
	objPlanSummaryChangeCustomEventListener;
	boolIsSafeMode = false;
	objPlanSummaryListener;
	strAccountId = '';
	strPlanId = '';
	strCmid = '';
	strCompareGNandCorpCode = '';
	strProspectMember = '';
	boolBlueCardMember = false;
	strBlueCardAccId = '';
	strBlueCardPatName = '';
	strBlueCardPatDob = '';
	@track lstBlueCardClaims = [];
	@track objBlueCardData = [];
	strViewMoreBlueCard = '';
	boolIsBlueCardPresent = false;
	boolIsBlueCardNoData = false;
	boolIsBlueCardIntError = false;
	boolSpinner = false;
	strViewMoreAppeal = '';
	@track objAppealsData = [];
	boolIsAppealNoData = false;
	boolIsAppealPresent = false;
	boolIsAppealIntError = false;
	boolIsDisputeClicked = false;
	disputeCardSafeModeClass = 'slds-hide';
	disputeCardClass = 'slds-show';
	@track objDisputeData = [];
	strViewMoreDispute;
	boolIsDisputeNoData = false;
	boolIsDisputePresent = false;
	boolIsDisputeIntError = false;
	strParentTabId;
	@track strClaimsAppealclass = 'slds-show';
	@track strClaimsAppealSafeclass = 'slds-hide';
	@track strShowPDCContainerId = 'PDC' + this.recordId;
	boolShowTMGPendedClaimsTab = false;
	boolShowAppealsSubtabs = false;
	boolShowDenatalTab = true;
	appealsTabLabel = '';
	objPCPMGListener;
	booleanTXM = false;
	strErrorMessage = '';
	strTableClass = 'slds-table slds-table_cell-buffer slds-table_bordered slds-table_striped medicalSummaryTable dataTable';
	strTableIdrClass = 'slds-table slds-table_cell-buffer slds-table_bordered slds-table_striped medicalSummaryTable dataTable idrDispute';
	strMedicalClaimUrlParam = 'DCN/CLAIM NUMBER';
	strPharmacyClaimUrlParam = 'RXCLAIM NUMBER';
	strDentalClaimUrlParam = 'DCN/CLAIM NUMBER';
	strAppealUrlParam = 'APPEAL ID';
	iconMedicalPharmacyDetails = 'standard:record';
	iconAppealDetails = 'standard:related_list';
	iconAppealHistory = 'action:description';
	strDisputeUrlParam = 'DISPUTE ID';
	iconDisputeDetails = 'standard:related_list';
	iconDisputeHistory = 'action:description';
	strDisputeClaimsUrlParam = 'DCN/CLAIM NUMBER';
	strDisputeClaimsFlexiPage = 'ViewMedicalClaimDetailsFlexiPage_ACE';
	label = {
		EnableVPSTabSpecificEvents_ACE,
		LineOfBusinessDefault_ACE,
		Retail_LineOfBusinessLabel_ACE,
		BlueCard_Claims_ACE,
		ClaimsAndAppeals_ACE,
		PastDueClaims_ClaimsSummaryHeader_ACE,
		PastDueClaims_ClaimsSummaryDispositionDate_ACE,
		PastDueClaims_ClaimsSummaryServiceToDate_ACE,
		ViewMedicalDetails_Claims_ACE,
		IdCard_Medical_ACE,
		ViewClaimHistory_Pharmacy_ACE,
		IdCard_Dental_ACE,
		SafeMode_ToastMessage_ACE,
		ViewPlanSummary_CardHeader_Refresh_ACE
	};
	lstMedicalTableColumns = [{
			"Key": "DCN/CLAIM NUMBER",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": true,
			"isHoverIcon": false
		},
		{
			"Key": "SERVICE FROM",
			"isAescSorted": false,
			"isDescSorted": true,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "SERVICE TO",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "GROUP NUMBER",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "STATUS CODE",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "TOTAL BILLED",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "BILLING PROVIDER NAME",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "HOVERDETAILS",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": true
		}
	];
	lstPharmacyTableColumns = [{
			"Key": "RXCLAIM NUMBER",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": true,
			"isHoverIcon": false
		},
		{
			"Key": "PRESCRIPTION FILL DATE",
			"isAescSorted": false,
			"isDescSorted": true,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "GROUP NUMBER",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "CLAIM STATUS",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "TOTAL BILLED",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "MEMBER PAY AMOUNT",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "PRODUCT NAME",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "QUANTITY DISPENSED",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "DAY SUPPLY",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "HOVERDETAILS",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": true
		}
	];
	lstAppealsTableColumns = [{
			"Key": "APPEAL TYPE",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "PATIENT NAME",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "CORPORATE RECEIVED DATE",
			"isAescSorted": false,
			"isDescSorted": true,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "COMPLIANCE DUE DATE",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "APPEAL STATUS",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "APPEAL STATUS REASON",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "SUB CATEGORY",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "APPEAL ID",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": true,
			"isHoverIcon": false
		}
	];
	lstDisputeTableColumns = [{
			"Key": "DISPUTE ID",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": true,
			"isHoverIcon": false
		},
		{
            "Key": "REGULATION",
            "isAescSorted": false,
            "isDescSorted": false,
            "isHyperLink": false,
            "isHoverIcon": false
        },
		{
			"Key": "REQUESTING PROVIDER NAME",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "PATIENT NAME",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "SERVICE FROM",
			"isAescSorted": false,
			"isDescSorted": true,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "SERVICE TO",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "TOTAL BILLED AMOUNT",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "STATUS",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "DCN/CLAIM NUMBER",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": true,
			"isHoverIcon": false
		},
		{
			"Key": "HOVERDETAILS",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": true
		}
	];
	lstFEPClaimTableColumns = [{
			"Key": "DCN",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": true,
			"isHoverIcon": false
		},
		{
			"Key": "STAT",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "PLAN CODE",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "SERVICE FROM",
			"isAescSorted": false,
			"isDescSorted": true,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "SERVICE TO",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "TOTAL BILLED",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "BILLING PROVIDER NAME",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "DEF / DENIAL REASON",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "CHECK PAID TO",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": false
		},
		{
			"Key": "HOVERDETAILS",
			"isAescSorted": false,
			"isDescSorted": false,
			"isHyperLink": false,
			"isHoverIcon": true
		}
	];
	infoImageURL = HCSCClaimsStaticResource_ACE + '/Images/claims-red.svg';
	startTime;
	connectedCallback() {
		this.startTime = new Date();
		try {
			this.fetchTabData();
			this.safeModeUtilityComponentListenerForClaimsCard('SafeModeModalHCDEvent_ACE', 'SafeModeModalHCDEventId_ACE');
		} catch (error) {
			this.handleErrors(error);
		}
	}
	disconnectedCallback() {
		const endTime = new Date();
		const timeDiff = endTime - this.startTime;
		const mins = Math.floor(timeDiff / 60000);
		const secds = ((timeDiff % 60000) / 1000).toFixed(3);
			}
	get showHeaderContainerLabel() {
		return this.boolBlueCardMember || this.boolDentalPlanSelected;
	}
	get showAppealsTab() {
		return !this.boolBlueCardMember && !this.boolDentalPlanSelected && this.boolShowAppealsTab;
	}
	get showDisputeResolutionTab() {
		return !this.boolBlueCardMember && !this.boolDentalPlanSelected && this.boolShowDisputeResolutionTab;
	}
	fetchTabData() {
		if (!this.enclosingTabId) {
			return;
		}
		getTabInfo(this.enclosingTabId)
			.then((objTabData) => {
				this.boolShowTMGPendedClaimsTab = true;
				this.objTabData = objTabData;
				this.strParentTabId = this.objTabData.tabId;
				this.listenToPCPMGEvents();
				if (BaseLWC.stringIsNotBlank(this.label.EnableVPSTabSpecificEvents_ACE) && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
					this.boolVPSTabSpecificEvents = true;
				}
				this.setPlanSummaryChangeCustomEventListener();
				this.listenPlanSummaryEvent();
				this.safeModeUtilityComponentListenerForClaimsCard('SafeModeModalEventOnTab_ACE_', 'SafeModeModalEventIdOnTab_ACE_');
				const strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.objTabData.url);
				const objUrl = new URL(strDecodedURL);
				if (objUrl.pathname) {
					this.strAccountId = objUrl.pathname.substring(21, 39);
				}
				const strPlainIdMessage = objUrl.searchParams.get('planId');
				const strMidMessage = objUrl.searchParams.get('mid');
				const strCmid = objUrl.searchParams.get('Cmid');
				const strGroupName = objUrl.searchParams.get('groupName');
				const strSubscriberId = objUrl.searchParams.get('subscriberId');
				const strCorpCode = objUrl.searchParams.get('corpCode');
				const strLOB = objUrl.searchParams.get('urlLob');
				const isLineOfBusinessFEP = objUrl.searchParams.get('isLineOfBusinessFEP');
				const isFEPOOS = objUrl.searchParams.get('isFEPOOS');
				const isBlueCardOOS = objUrl.searchParams.get('isBlueCardOOS');
				const strProspectMember = objUrl.searchParams.get('boolProspectMember');
				this.strPlanId = strPlainIdMessage;
				this.strGroupName = strGroupName;
				this.strSubscriberId = strSubscriberId;
				this.strCorpCode = strCorpCode;
				if (strLOB == 'GMapd') {
					this.booleanTXM = true;
				}
				this.strMid = strMidMessage;
				this.strCmid = strCmid;
				this.strCompareGNandCorpCode = strCorpCode + strGroupName;
				const boolIsCallout = this.boolCalloutDone;
				if ((isBlueCardOOS && isBlueCardOOS === "true") || strProspectMember && strProspectMember === "true") {
					this.boolBlueCardMember = (isBlueCardOOS == "true" ? true : false);
					this.strProspectMember = (strProspectMember == "true" ? true : false);
					this.strBlueCardAccId = strMidMessage;
					this.fetchAccountDetails();
				} else if (isLineOfBusinessFEP && isLineOfBusinessFEP === "true") {
					this.boolFEPMember = true;
					this.boolShowPharmacyTab = false;
					if (!boolIsCallout) {
						this.boolCalloutDone = true;
						this.fepClaimSummaryContinuation();
						this.strTableClass = "slds-table slds-table_cell-buffer slds-table_bordered slds-table_striped medicalSummaryTable dataTable FEPTable";
					}
				} else if (isLineOfBusinessFEP && isLineOfBusinessFEP === "false") {
					this.boolFEPMember = false;
					this.boolShowPharmacyTab = true;
					if (strMidMessage && strMidMessage !== '' && !boolIsCallout) {
						this.boolCalloutDone = true;
						this.callSummaryContinuation();
					} else {
						//Do Nothing
					}
				} else {}
				if ((isLineOfBusinessFEP && isLineOfBusinessFEP === "true") || (isFEPOOS && isFEPOOS === "true")) {
					this.getClaimsFEPDirectURL();
				}
			})
			.catch((error) => {
				this.handleErrors(error);
			});
	}
	setPlanSummaryChangeCustomEventListener() {
		if (BaseLWC.isUndefinedOrNullOrBlank(this.objPlanSummaryChangeCustomEventListener)) {
			const objPlanSummaryChangeCustomEventListener = (objEventData) => {
				try {
					if (BaseLWC.isUndefinedOrNullOrBlank(this.objPlanSummaryChangeCustomEventListener) && this.boolVPSTabSpecificEvents) {
						window.removeEventListener("PlanChangedCustomEvent_" + this.objTabData.tabId, objPlanSummaryChangeCustomEventListener, false);
					} else {
						window.removeEventListener("PlanChangedCustomEvent", objPlanSummaryChangeCustomEventListener, false);
					}
					if (objEventData.detail && typeof objEventData.detail === 'string') {
						const strParsedData = JSON.parse(objEventData.detail);
						if (strParsedData.strIdDestination && strParsedData.strIdDestination === "PlanChangedDetails_PlanSummary_ACE" &&
							strParsedData.objParameters && strParsedData.objParameters.strParentTabId &&
							strParsedData.objParameters.strParentTabId === this.objTabData.tabId && strParsedData.objParameters.objMessage) {
							this.objPlanSummaryListener = null;
							this.boolCalloutDone = false;
							this.listenPlanSummaryEvent();
						} else {
							// Do nothing
						}
					}
				} catch (exception) {
					this.handleErrors(exception);
				}
			};
			this.objPlanSummaryChangeCustomEventListener = objPlanSummaryChangeCustomEventListener;
			if (this.boolVPSTabSpecificEvents) {
				window.addEventListener("PlanChangedCustomEvent_" + this.objTabData.tabId, objPlanSummaryChangeCustomEventListener, false);
			} else {
				window.addEventListener("PlanChangedCustomEvent", objPlanSummaryChangeCustomEventListener, false);
			}
		}
	}
	safeModeUtilityComponentListenerForClaimsCard(eventName, eventDestId) {
		try {
			const strTabId = this.objTabData.tabId;
			const strSafeModeModalEventName = eventName + strTabId;
			const strSafeModeModalEventDestinationId = eventDestId + strTabId;
			if (BaseLWC.isUndefinedOrNullOrBlank(this.objSafeModeUtilitySummaryListener)) {
				const objSafeModeSummaryListener = (objEventData) => {
					if (objEventData !== null && objEventData.detail !== null && typeof objEventData.detail === 'string') {
						if (BaseLWC.isUndefinedOrNullOrBlank(this.objSafeModeUtilitySummaryListener)) {
							window.removeEventListener(strSafeModeModalEventName, objSafeModeSummaryListener, false);
						}
						const strParsedData = JSON.parse(objEventData.detail);
						if (strParsedData.strIdDestination && strParsedData.strIdDestination === strSafeModeModalEventDestinationId) {
							if (strParsedData.boolSafeModeEnabled || strParsedData.objMessage) {
								this.strClaimsAppealclass = 'slds-hide';
								this.strClaimsAppealSafeclass = '';
								this.boolIsSafeMode = true;
							} else if (!strParsedData.boolSafeModeEnabled || !strParsedData.objMessage) {
								this.strClaimsAppealclass = '';
								this.strClaimsAppealSafeclass = 'slds-hide';
								this.boolIsSafeMode = false;
							} else {
								//Do Nothing
							}
						}
					}
				};
				this.objSafeModeUtilitySummaryListener = objSafeModeSummaryListener;
				window.addEventListener(strSafeModeModalEventName, objSafeModeSummaryListener, false);
			}
		} catch (objException) {
			this.handleErrors(objException);
		}
	}
	//Listen to Plan Summary
	listenPlanSummaryEvent() {
		if (BaseLWC.isUndefinedOrNullOrBlank(this.objPlanSummaryListener)) {
			const objPlanSummaryListener = (planSummaryDataEvent) => {
				if (this.objTabData.tabId && BaseLWC.isUndefinedOrNullOrBlank(this.objPlanSummaryListener) && this.boolVPSTabSpecificEvents) {
					window.removeEventListener("PlanSummaryChangeEvent_" + this.objTabData.tabId, objPlanSummaryListener, false);
				} else {
					window.removeEventListener("PlanSummaryChangeEvent", objPlanSummaryListener, false);
				}
				try {
					if (BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail) && typeof planSummaryDataEvent.detail === "string") {
						const strParsedData = JSON.parse(planSummaryDataEvent.detail);
						if (strParsedData) {
							if (strParsedData.objParameters.objMessage) {
								this.setBoolDentalPlanSelected(strParsedData.objParameters.objMessage);
								this.strLOB = strParsedData.objParameters.objMessage.strAceLineOfBusiness;
							}
							if (strParsedData.strIdDestination && strParsedData.strIdDestination === "PlanDetails_PlanSummary_ACE" &&
								strParsedData.objParameters && strParsedData.objParameters.strParentTabId &&
								strParsedData.objParameters.strParentTabId === this.objTabData.tabId && strParsedData.objParameters.objMessage) {
								if (this.boolVPSTabSpecificEvents) {
									window.removeEventListener("PlanSummaryChangeEvent_" + this.objTabData.tabId, objPlanSummaryListener, false);
								} else {
									window.removeEventListener("PlanSummaryChangeEvent", objPlanSummaryListener, false);
								}
								//Hide Dispute Resolution Tab
								if (strParsedData.objParameters.objMessage.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE' ||
									(strParsedData.objParameters.objMessage.strAceLineOfBusiness.toUpperCase().includes('GOVERNMENT-MEDICAID') &&
										strParsedData.objParameters.objMessage.strCorporationCode &&
										(strParsedData.objParameters.objMessage.strCorporationCode === 'NM1' || strParsedData.objParameters.objMessage.strCorporationCode === 'TX1'))) {
									this.boolShowDisputeResolutionTab = false;
								}
								//CEAS-75447 Show TMG Pended Claims Tab
								if (strParsedData.objParameters.objMessage.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICAID' ) {
									if(strParsedData.objParameters.objMessage.strCorporationCode &&
										strParsedData.objParameters.objMessage.strCorporationCode === 'TX1') {
											this.boolShowTMGPendedClaimsTab = true;
									} else {
										this.boolShowTMGPendedClaimsTab = false;
									}
									
									this.appealsTabLabel = 'EAA Appeals';
									this.booleanTXM = true;
								} else {
									this.boolShowTMGPendedClaimsTab = false;
									this.appealsTabLabel = 'Appeals';
								}
								//CEAS-73471 Hide Appeals Tab
								if (strParsedData.objParameters.objMessage.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL') {
									this.boolShowAppealsTab = false;
									this.boolShowDisputeResolutionTab = false;
								}
								//NT:CEAS-77680 - Appeals Subtabs visiblity
								if (this.strLOB.toUpperCase() == 'GOVERNMENT-MEDICAID') {
									this.boolShowAppealsSubtabs = true;
									this.booleanTXM = true;
									if(strParsedData.objParameters.objMessage.strCorporationCode &&
										strParsedData.objParameters.objMessage.strCorporationCode === 'TX1') {
											this.boolShowDenatalTab = false;
									}
								}
							}
							//Fetch data from View plan summary component.
							if (strParsedData.strIdDestination && strParsedData.strIdDestination === "PlanDetails_PlanSummary_ACE" &&
								strParsedData.objParameters && strParsedData.objParameters.strParentTabId &&
								strParsedData.objParameters.strParentTabId === this.objTabData.tabId && strParsedData.objParameters.objMessage) {
								if (BaseLWC.isUndefinedOrNullOrBlank(strParsedData.objParameters.objMessage.strCorporationCode) &&
									BaseLWC.isUndefinedOrNullOrBlank(strParsedData.objParameters.objMessage.strSubscriberId) &&
									BaseLWC.isUndefinedOrNullOrBlank(strParsedData.objParameters.objMessage.strGroupNumber) &&
									BaseLWC.isUndefinedOrNullOrBlank(strParsedData.objParameters.objMessage.strMemberId)) {
									return;
								}
								if (strParsedData.objParameters.objMessage) {
									const boolIsFEPPolicy = strParsedData.objParameters.objMessage.boolIsLineOfBusinessFEP;
									if (boolIsFEPPolicy) {
										this.boolShowPharmacyTab = false;
									} else {
										this.boolShowPharmacyTab = true;
									}
								}
								if (strParsedData.objParameters.objMessage && (!this.boolListenedFirstTime ||
										(strParsedData.objParameters.objMessage.strCorporationCode !== this.strCorpCode ||
											strParsedData.objParameters.objMessage.strSubscriberId !== this.strSubscriberId ||
											strParsedData.objParameters.objMessage.strGroupNumber !== this.strGroupName ||
											strParsedData.objParameters.objMessage.strMemberId !== this.strMid))) {
									if (!this.boolListenedFirstTime) {
										this.boolListenedFirstTime = true;
									}
									this.strCorpCode = strParsedData.objParameters.objMessage.strCorporationCode;
									this.strSubscriberId = strParsedData.objParameters.objMessage.strSubscriberId;
									this.strGroupName = strParsedData.objParameters.objMessage.strGroupNumber;
									this.strMid = strParsedData.objParameters.objMessage.strMemberId;
									this.boolFEPMember = strParsedData.objParameters.objMessage.boolIsLineOfBusinessFEP;
									if (!this.boolCalloutDone) { //check if false
										this.boolCalloutDone = true;
										if (strParsedData.objParameters.objMessage.boolIsLineOfBusinessFEP) {
											this.fepClaimSummaryContinuation();
											this.strTableClass = "slds-table slds-table_cell-buffer slds-table_bordered slds-table_striped medicalSummaryTable dataTable FEPTable";
										} else {
											this.callSummaryContinuation();
										}
									}
									this.boolIsPlanChanged = true;
									if (this.boolIsAppealClicked) {
										this.callAppealsSummaryContinuation();
										this.boolIsPlanChanged = false;
									}
								}
							}
						}
					}
				} catch (e) {
					this.handleErrors(e);
				}
				const dtDispositionDateValue = new Date();
				const dtServiceDateValue = new Date();
				dtDispositionDateValue.setDate(dtDispositionDateValue.getDate() - 30);
				dtServiceDateValue.setDate(dtServiceDateValue.getDate() - 45);
				let dtDispositionDate = '';
				let dtServiceDate = '';
				let dtServiceMonth = '';
				let dtDispositionMonth = '';
				if (dtServiceDateValue.getDate() < 10) {
					dtServiceDate = "0" + dtServiceDateValue.getDate();
				} else {
					dtServiceDate = dtServiceDateValue.getDate();
				}
				if (dtServiceDateValue.getMonth() < 9) {
					dtServiceMonth = "0" + (dtServiceDateValue.getMonth() + 1);
				} else {
					dtServiceMonth = dtServiceDateValue.getMonth() + 1;
				}
				if (dtDispositionDateValue.getDate() < 10) {
					dtDispositionDate = "0" + dtDispositionDateValue.getDate();
				} else {
					dtDispositionDate = dtDispositionDateValue.getDate();
				}
				if (dtDispositionDateValue.getMonth() < 9) {
					dtDispositionMonth = "0" + (dtDispositionDateValue.getMonth() + 1);
				} else {
					dtDispositionMonth = dtDispositionDateValue.getMonth() + 1;
				}
				const dtDispositionYear = dtDispositionDateValue.getFullYear();
				const dtServiceYear = dtServiceDateValue.getFullYear();
				this.strDDValue = dtDispositionMonth + "/" + dtDispositionDate + "/" + dtDispositionYear;
				this.strDOSValue = dtServiceMonth + "/" + dtServiceDate + "/" + dtServiceYear;
				// To indicate that value in DOS value is set.
				this.boolIsPlanSummaryListenedForPCP = true;
			};
			this.objPlanSummaryListener = objPlanSummaryListener;
			if (this.boolVPSTabSpecificEvents && this.objTabData.tabId) {
				window.addEventListener("PlanSummaryChangeEvent_" + this.objTabData.tabId, objPlanSummaryListener, false);
			} else {
				window.addEventListener("PlanSummaryChangeEvent", objPlanSummaryListener, false);
			}
		}
	}
	setBoolDentalPlanSelected(objPlanDetails) {
		try {
			const STRING_POLICY_TYPE_CODE_D = 'Dent';
			const lstHideDentalForLOB = [this.label.LineOfBusinessDefault_ACE, this.label.Retail_LineOfBusinessLabel_ACE];
			if (objPlanDetails.strPlanTypeCode === STRING_POLICY_TYPE_CODE_D && lstHideDentalForLOB.indexOf(objPlanDetails.strAceLineOfBusiness) > -1) {
				this.boolDentalPlanSelected = true;
			} else {
				this.boolDentalPlanSelected = false;
			}
		} catch (exception) {
			this.handleErrors(exception);
		}
	}
	fepClaimSummaryContinuation() {
		this.boolSpinner = true;
		let lstTableValues = [];
		fepClaimsSummaryRequest({
			strSubscriberId: this.strSubscriberId,
			strGroupNumber: this.strGroupName,
			strCorpCode: this.strCorpCode
		}).then(objResult => {
			if (objResult) {
				try {
					const objContinuationResponse = JSON.parse(objResult);
					if (BaseLWC.isUndefinedOrNullOrBlank(objContinuationResponse)) {
						return;
					} else if (objContinuationResponse) {
						if (objContinuationResponse.claimsRosterInfo) {
							if (objContinuationResponse.claimsRosterInfo.length > 0) {
								try {
									const lstMedicalClaimSummary = objContinuationResponse;
									this.lstFEPClaims = lstMedicalClaimSummary.claimsRosterInfo;
									this.formatFEPServiceFromServiceTo();
									lstTableValues = [];
									this.lstFEPClaims.forEach((objKey) => {
										const pattern = {};
										if (objKey) {
											if (objKey.processedDate) {
												const lstprocessedDate = objKey.processedDate.split('T');
												const lstCmpDateWithOutTimeStamp = lstprocessedDate[0].split('-');
												objKey.processedDate = lstCmpDateWithOutTimeStamp[1] + '/' + lstCmpDateWithOutTimeStamp[2] + '/' +
													lstCmpDateWithOutTimeStamp[0];
											}
											let strTotalCharges;
											if (objKey.totalCharges) {
												strTotalCharges = '$' + Number(objKey.totalCharges).toFixed(2);
											} else {
												strTotalCharges = '';
											}
											pattern['DCN'] = objKey.claimNumber;
											pattern['STAT'] = objKey.claimStatus;
											pattern['PLAN CODE'] = objKey.planCode;
											pattern['SERVICE FROM'] = objKey.incurredDate;
											pattern['SERVICE TO'] = objKey.serviceEndDate;
											pattern['TOTAL BILLED'] = strTotalCharges;
											pattern['BILLING PROVIDER NAME'] = objKey.performingProvider;
											pattern['DEF / DENIAL REASON'] = objKey.strDeferredDenialReason;
											pattern['CHECK PAID TO'] = objKey.payee;
											pattern['HOVERDETAILS'] = [{
													"strField": "Processed Date",
													"strValue": objKey.processedDate
												},
												{
													"strField": "In-State Claim",
													"strValue": objKey.strInStateClaim
												},
												{
													"strField": "Status Code",
													"strValue": objKey.dispositionCode
												}
											];
										}
										lstTableValues.push(pattern);
									});
																		//NT: CEAS-82803
									lstTableValues.sort(this.sortFunction('SERVICE FROM'));
									this.objFEPData = lstTableValues;
									const strViewMoreFEPClaim = '/lightning/n/Claims_History_FlexiPage_ACE' + '?c__BaseURLParam=' + window.btoa(unescape(encodeURIComponent('strClaimType=FEPClaim&mid=' +
										this.strMid + '&strClaimStatus=&strGroupNumber=' +
										this.strGroupName + '&strCorpCode=' + this.strCorpCode + '&idAccount=' + this.recordId)));
									this.strViewMoreFEPClaim = strViewMoreFEPClaim;
									this.boolIsFEPClaimPresent = true;
									this.boolIsFEPClaimNoData = false;
									this.boolIsFEPClaimIntError = false;
								} catch (exception) {
									this.boolIsFEPClaimPresent = false;
									this.boolIsFEPClaimNoData = false;
									this.boolIsFEPClaimIntError = true;
									this.handleErrors(exception);
								}
							} else {
								this.boolIsFEPClaimPresent = false;
								this.boolIsFEPClaimNoData = true;
								this.boolIsFEPClaimIntError = false;
							}
						} else if (objContinuationResponse.code && objContinuationResponse.code === 404) {
							this.boolIsFEPClaimPresent = false;
							this.boolIsFEPClaimNoData = true;
							this.boolIsFEPClaimIntError = false;
						} else {
							this.boolIsFEPClaimPresent = false;
							this.boolIsFEPClaimNoData = false;
							this.boolIsFEPClaimIntError = true;
						}
						this.boolSpinner = false;
					} else {
						this.boolIsFEPClaimPresent = false;
						this.boolIsFEPClaimNoData = false;
						this.boolIsFEPClaimIntError = true;
						this.boolSpinner = false;
					}
				} catch (exception) {
					this.boolIsFEPClaimPresent = false;
					this.boolIsFEPClaimNoData = false;
					this.boolIsFEPClaimIntError = true;
					this.boolSpinner = false;
					this.handleErrors(exception);
				}
			}
		}).catch((exception) => {
			this.handleErrors(exception);
		});
	}
	callSummaryContinuation() {
		let lstTableValues = [];
		this.boolSpinner = true;
		claimsSummaryRequest({
			strMid: this.strMid
		}).then(objResult => {
			if (objResult) {
				try {
					const objContinuationResponse = JSON.parse(objResult);
					if (BaseLWC.isUndefinedOrNullOrBlank(objContinuationResponse)) {
						this.boolSpinner = false;
						return;
					} else if (objContinuationResponse) {
						if (objContinuationResponse.claimMedicalSummary) {
							if (objContinuationResponse.claimMedicalSummary.claims.length > 0) {
								try {
									const lstMedicalClaimSummary = objContinuationResponse.claimMedicalSummary;
									this.lstMedicalClaims = lstMedicalClaimSummary.claims;
									this.formatServiceFromServiceTo();
									lstTableValues = [];
									this.lstMedicalClaims.forEach((objKey) => {
										const pattern = {};
										if (objKey) {
											if (objKey.adjustmentNumber && objKey.adjustmentNumber !== '0') {
												pattern['DCN/CLAIM NUMBER'] = objKey.claimNumber + '-' + objKey.adjustmentNumber;
											} else {
												pattern['DCN/CLAIM NUMBER'] = objKey.claimNumber;
											}
											pattern['SERVICE FROM'] = objKey.serviceFrom;
											pattern['SERVICE TO'] = objKey.serviceTo;
											pattern['GROUP NUMBER'] = objKey.groupNumber;
											pattern['STATUS CODE'] = objKey.claimProcessCompletionCode;
											if(objKey.billedAmount) {
												pattern['TOTAL BILLED'] = '$' + Number(objKey.billedAmount).toFixed(2);
											} else {
												pattern['TOTAL BILLED'] = '';
											}
											pattern['CLAIM ID'] = objKey.claimId;
											if ((objKey.claimId.split("^")[0] + objKey.groupNumber) === this.strCorpCode + this.strGroupName) {
												pattern['IS HIGHLIGHTED'] = true;
												pattern['COLUMN NAME'] = ['GROUP NUMBER'];
											}
											if (objKey.provider && objKey.provider.name) {
												pattern['BILLING PROVIDER NAME'] = objKey.provider.name;
											} else if (objKey.provider && BaseLWC.isUndefinedOrNullOrBlank(objKey.provider.name)) {
												pattern['BILLING PROVIDER NAME'] = '';
											} else {
												/* Do Nothing */ }
											pattern['HOVERDETAILS'] = [{
													"strField": "Description",
													"strValue": objKey.statusDescription,
													"strKey": "statusDescription"
												},
												{
													"strField": "Billing Provider Number",
													"strValue": objKey.provider.providerNumber,
													"strKey": "providerNumber"
												},
												{
													"strField": "Billing Provider NPI",
													"strValue": objKey.provider.npi,
													"strKey": "npi"
												}
											];
											pattern['URLPARAMS'] = '?' + window.btoa(unescape(encodeURIComponent('claimNumber=' + objKey.claimNumber + '&mid=' + this.strMid + '&claimId=' + objKey.claimId +
												'&adjNumber=' + objKey.adjustmentNumber + '&corpCode=' + objKey.claimId.split("^")[0] + '&groupNumber=' + objKey.groupNumber + '&idAccount=' + this.recordId)));
										}
										lstTableValues.push(pattern);
									});
									//NT: CEAS-82803
									lstTableValues.sort(this.sortFunction('SERVICE FROM'));
									this.objMedicalData = lstTableValues;
									const strViewMoreMedical = '/lightning/n/Claims_History_FlexiPage_ACE' + '?c__BaseURLParam=' + window.btoa(unescape('?strClaimType=Medical&mid=' + this.strMid + '&strClaimStatus=&strGroupNumber=' +
										this.strGroupName + '&strCorpCode=' + this.strCorpCode + '&idAccount=' + this.recordId +
										'&boolFEPMember=' + this.boolFEPMember));
									this.strViewMoreMedical = strViewMoreMedical;
									this.boolIsMedicalPresent = true;
									this.boolIsMedicalNoData = false;
									this.boolIsMedicalIntError = false;
								} catch (exception) {
									this.boolIsMedicalPresent = false;
									this.boolIsMedicalNoData = false;
									this.boolIsMedicalIntError = true;
									this.handleErrors(exception);
								}
								// Medical Summary Data Present
							} else {
								// Medical Summary No Data Present
								this.boolIsMedicalPresent = false;
								this.boolIsMedicalNoData = true;
								this.boolIsMedicalIntError = false;
							}
						} else {
							this.boolIsMedicalPresent = false;
							this.boolIsMedicalNoData = false;
							this.boolIsMedicalIntError = true;
						}
						if (objContinuationResponse.claimSummary) {
							// CEAS-48905 Calling callPharmacyClaimSummary function 
							this.callPharmacyClaimSummary(objContinuationResponse);
						} else {
							// Medical Summary Integration Error
							this.boolIsPharamacyPresent = false;
							this.boolIsPharmacyIntError = true;
							this.boolIsPharmacyNoData = false;
						}
						if (objContinuationResponse.claimDentalSummary) {
							// CEAS-48905 Calling callDentalClaimSummary function 
							this.callDentalClaimSummary(objContinuationResponse);
						} else {
							// Medical Summary Integration Error
							this.boolIsDentalPresent = false;
							this.boolIsDentalIntError = true;
							this.boolIsDentalNoData = false;
						}
						this.boolSpinner = false;
					} else {
						//Do Nothing
					}
				} catch (exception) {
					// Medical Summary Integration Error
					this.boolIsPharamacyPresent = false;
					this.boolIsPharmacyIntError = true;
					this.boolIsPharmacyNoData = false;
					this.boolSpinner = false;
					this.handleErrors(exception);
				}
			}
		}).catch((exception) => {
			this.boolIsPharamacyPresent = false;
			this.boolIsPharmacyIntError = true;
			this.boolIsPharmacyNoData = false;
			this.boolIsMedicalPresent = false;
			this.boolIsMedicalNoData = false;
			this.boolIsMedicalIntError = true;
			this.boolIsDentalPresent = false;
			this.boolIsDentalNoData = false;
			this.boolIsDentalIntError = true;
			this.handleErrors(exception);
		});
	}
	callAppealsSummaryContinuation() {
		appealsSummaryRequest({
			strMid: this.strMid,
			strGroupName: this.strGroupName,
			strSubscriberId: this.strSubscriberId,
			strCorpCode: this.strCorpCode
		}).then(objResult => {
			if (objResult) {
				try {
					const objAppealsData = JSON.parse(objResult);
					const lstTableValues = [];
					if (objAppealsData && objAppealsData.length > 0) {
						objAppealsData.forEach(function(objkey) {
							if (objkey) {
								if (objkey.completionDate && objkey.completionDate !== '') {
									const lstCompletionDate = objkey.completionDate.split('T');
									const lstCmpDateWithOutTimeStamp = lstCompletionDate[0].split('-');
									objkey.completionDate = lstCmpDateWithOutTimeStamp[1] + '/' + lstCmpDateWithOutTimeStamp[2] + '/' + lstCmpDateWithOutTimeStamp[0];
								}
								if (objkey.currentStatus.startDate && objkey.currentStatus.startDate !== '') {
									const lstStartDate = objkey.currentStatus.startDate.split('T');
									const lstStartDateWithOutTimeStamp = lstStartDate[0].split('-');
									objkey.currentStatus.startDate = lstStartDateWithOutTimeStamp[1] + '/' + lstStartDateWithOutTimeStamp[2] + '/' + lstStartDateWithOutTimeStamp[0];
								}
							}
						});
						objAppealsData.forEach((objKey) => {
							const pattern = {};
							if (objKey) {
								pattern['APPEAL TYPE'] = objKey.appealType;
								pattern['PATIENT NAME'] = objKey.patientName;
								pattern['CORPORATE RECEIVED DATE'] = objKey.currentStatus.startDate;
								pattern['COMPLIANCE DUE DATE'] = objKey.completionDate;
								pattern['APPEAL STATUS'] = objKey.status;
								pattern['APPEAL STATUS REASON'] = objKey.reason;
								pattern['SUB CATEGORY'] = objKey.priority;
								pattern['APPEAL ID'] = objKey.appealId;
								pattern['HOVER DETAILS'] = '';
								pattern['CORP CODE'] = objKey.corpCode;
								pattern['URLPARAMS'] = '?' + window.btoa(unescape(encodeURIComponent('strAppealId=' + objKey.appealId + '&mid=' + this.strMid + '&planId=' + this.strPlanId +
									'&Cmid=' + this.strCmid + '&strPatientName=' + objKey.patientName + '&strStatusReason=' + objKey.reason +
									'&strCorpCode=' + objKey.corpCode + '&strGroupNumber=' + objKey.groupId + '&idAccount=' + this.recordId)))
							}
							lstTableValues.push(pattern);
						});
						//NT: CEAS-82803
						lstTableValues.sort(this.sortFunction('CORPORATE RECEIVED DATE'));
						const strAppealViewMoreURL = '/lightning/n/Appeals_History_FlexiPage_ACE' + BaseLWC.helperBaseEncodeUrl('?strGroupNumber=' + this.strGroupName + '&strSubscriberId=' +
							this.strSubscriberId + '&strCorpCode=' + this.strCorpCode + '&mid=' + this.strMid +
							'&planId=' + this.strPlanId + '&Cmid=' + this.strCmid + '&idAccount=' + this.recordId + '&boolFEPMember=' + this.boolFEPMember);
						this.strViewMoreAppeal = strAppealViewMoreURL;
						this.objAppealsData = lstTableValues;
						this.boolIsAppealNoData = false;
						this.boolIsAppealPresent = true;
						this.boolIsAppealIntError = false;
						this.boolSpinner = false;
					} else {
						this.boolIsAppealNoData = true;
						this.boolIsAppealPresent = false;
						this.boolIsAppealIntError = false;
						this.boolSpinner = false;
					}
				} catch (exception) {
					this.boolIsAppealNoData = false;
					this.boolIsAppealPresent = false;
					this.boolIsAppealIntError = true;
					this.boolSpinner = false;
					this.handleErrors(exception);
				}
			} else {
				this.boolIsAppealNoData = false;
				this.boolIsAppealPresent = false;
				this.boolIsAppealIntError = true;
			this.boolSpinner = false;
			}
		}).catch(function(exception) {
			this.boolIsAppealNoData = false;
			this.boolIsAppealPresent = false;
			this.boolIsAppealIntError = true;
			this.boolSpinner = false;
			this.handleErrors(exception);
		});
	}
	formatFEPServiceFromServiceTo() {
		this.lstFEPClaims.forEach(function(strKey) {
			if (strKey) {
				if (strKey.incurredDate) {
					const lstIncurredDate = strKey.incurredDate.split('T');
					const lstIncurredDateWithOutTimeStamp = lstIncurredDate[0].split('-');
					strKey.incurredDate = lstIncurredDateWithOutTimeStamp[1] + '/' + lstIncurredDateWithOutTimeStamp[2] + '/' + lstIncurredDateWithOutTimeStamp[0];
				}
				if (strKey.serviceEndDate) {
					const lstServiceEndDate = strKey.serviceEndDate.split('T');
					const lstServiceEndDateWithOutTimeStamp = lstServiceEndDate[0].split('-');
					strKey.serviceEndDate = lstServiceEndDateWithOutTimeStamp[1] + '/' + lstServiceEndDateWithOutTimeStamp[2] + '/' + lstServiceEndDateWithOutTimeStamp[0];
				}
			}
		});
	}
	formatServiceFromServiceTo() {
		this.lstMedicalClaims.forEach(function(strKey) {
			if (strKey) {
				if (strKey.serviceFrom) {
					const lstServiceFrom = strKey.serviceFrom.split('-');
					strKey.serviceFrom = lstServiceFrom[1] + '/' + lstServiceFrom[2] + '/' + lstServiceFrom[0];
				}
				if (strKey.serviceTo) {
					const lstServiceTo = strKey.serviceTo.split('-');
					strKey.serviceTo = lstServiceTo[1] + '/' + lstServiceTo[2] + '/' + lstServiceTo[0];
				}
			}
		});
	}
	callPharmacyClaimSummary(objContinuationResponse) {
		this.boolSpinner = true;
		const lstTableValues = [];
		if (objContinuationResponse && objContinuationResponse.claimSummary && objContinuationResponse.claimSummary.claims && objContinuationResponse.claimSummary.claims.length > 0) {
			try {
				const lstPharmacyClaimSummary = objContinuationResponse.claimSummary;
				this.lstPharmacyClaims = lstPharmacyClaimSummary.claims;
				this.lstPharmacyClaims.forEach(function(strKey) {
					if (strKey) {
						if (strKey.fillDate) {
							const lstServiceFrom = strKey.fillDate.split('-');
							strKey.fillDate = lstServiceFrom[1] + '/' + lstServiceFrom[2] + '/' + lstServiceFrom[0];
						}
					}
				});
				this.lstPharmacyClaims.forEach((objKey) => {
					const pattern = {};
					if (objKey) {
						if (objKey.adjustmentNumber && objKey.adjustmentNumber !== '0') {
							pattern['RXCLAIM NUMBER'] = objKey.claimNumber + '-' + objKey.adjustmentNumber;
						} else {
							pattern['RXCLAIM NUMBER'] = objKey.claimNumber;
						}
						pattern['PRESCRIPTION FILL DATE'] = objKey.fillDate;
						pattern['GROUP NUMBER'] = objKey.groupNumber;
						pattern['CLAIM STATUS'] = objKey.claimStatus;
						if(objKey.totalBilledAmount) {
						pattern['TOTAL BILLED'] = '$' + Number(objKey.totalBilledAmount).toFixed(2);
						} else {
							pattern['TOTAL BILLED'] = '';
						}
						if(objKey.patientShareAmount) {
						pattern['MEMBER PAY AMOUNT'] = '$' + Number(objKey.patientShareAmount).toFixed(2);
						} else {
							pattern['MEMBER PAY AMOUNT'] ='';
						}
						pattern['PRODUCT NAME'] = objKey.drugLabelAbbreviation;
						if(objKey.dispenseQuantity) {
						pattern['QUANTITY DISPENSED'] = Number(objKey.dispenseQuantity).toFixed(2);
						} else {
							pattern['QUANTITY DISPENSED'] = '';
						}
						pattern['DAY SUPPLY'] = objKey.drugSupplyDayCount;
						pattern['CLAIM ID'] = objKey.claimId;
						if ((objKey.claimId.split("^")[0] + objKey.groupNumber) === this.strCorpCode + this.strGroupName) {
							pattern['IS HIGHLIGHTED'] = true;
							pattern['COLUMN NAME'] = ['GROUP NUMBER'];
						}
						pattern['HOVERDETAILS'] = [{
								"strField": "Pharmacy Name",
								"strValue": objKey.provider.name
							},
							{
								"strField": "Pharmacy Rx Number",
								"strValue": objKey.prescriptionNumber
							},
							{
								"strField": "Status Description",
								"strValue": objKey.claimStatus
							}
						];
						pattern['URLPARAMS'] = '?' + window.btoa(unescape(encodeURIComponent('claimNumber=' + objKey.claimNumber + '&mid=' + this.strMid + '&claimId=' + objKey.claimId +
							'&adjNumber=' + objKey.adjustmentNumber + '&corpCode=' + objKey.claimId.split("^")[0] + '&groupNumber=' + objKey.groupNumber + '&idAccount=' + this.recordId)));
					}
					lstTableValues.push(pattern);
				});
				//NT: CEAS-82803
				lstTableValues.sort(this.sortFunction('PRESCRIPTION FILL DATE'));
				const strViewMorePharmacy = '/lightning/n/Claims_History_FlexiPage_ACE' + '?c__BaseURLParam=' + window.btoa(unescape(encodeURIComponent('?strClaimType=Pharmacy&mid=' + this.strMid + '&strClaimStatus=&strGroupNumber=' +
					this.strGroupName + '&strCorpCode=' + this.strCorpCode + '&idAccount=' + this.recordId + '&boolFEPMember=' + this.boolFEPMember)));
				this.strViewMorePharamacy = strViewMorePharmacy;
				this.objPharmacyData = lstTableValues;
				this.boolIsPharamacyPresent = true;
				this.boolIsPharmacyIntError = false;
				this.boolIsPharmacyNoData = false;
			} catch (exception) {
				this.boolIsPharamacyPresent = false;
				this.boolIsPharmacyIntError = true;
				this.boolIsPharmacyNoData = false;
				this.boolSpinner = false;
				this.handleErrors(exception);
			}
		} else {
			this.boolIsPharamacyPresent = false;
			this.boolIsPharmacyIntError = false;
			this.boolIsPharmacyNoData = true;
			this.boolSpinner = false;
		}
	}
	callDentalClaimSummary(objContinuationResponse) {
		this.boolSpinner = true;
		if (objContinuationResponse.claimDentalSummary.claims.length > 0) {
			try {
				const lstDentalClaimSummary = objContinuationResponse.claimDentalSummary;
				let lstTableValues = [];
				this.lstDentalClaims = lstDentalClaimSummary.claims;
				this.formatServiceFromServiceTo();
				this.lstDentalClaims.forEach((objKey) => {
					const pattern = {};
					if (objKey) {
						if (objKey.adjustmentNumber && objKey.adjustmentNumber !== '0') {
							pattern['DCN/CLAIM NUMBER'] = objKey.claimNumber + '-' + objKey.adjustmentNumber;
						} else {
							pattern['DCN/CLAIM NUMBER'] = objKey.claimNumber;
						}
						pattern['SERVICE FROM'] = objKey.serviceFrom;
						pattern['SERVICE TO'] = objKey.serviceTo;
						pattern['GROUP NUMBER'] = objKey.groupNumber;
						pattern['STATUS'] = objKey.claimStatus;
						pattern['STATUS CODE'] = objKey.claimProcessCompletionCode;
						if(objKey.billedAmount) {
							pattern['TOTAL BILLED'] = '$' + Number(objKey.billedAmount).toFixed(2);
						} else {
							pattern['TOTAL BILLED'] = '';
						}
						
						pattern['CLAIM ID'] = objKey.claimId;
						if ((objKey.claimId.split("^")[0] + objKey.groupNumber) === this.strCorpCode + this.strGroupName) {
							pattern['IS HIGHLIGHTED'] = true;
							pattern['COLUMN NAME'] = ['GROUP NUMBER'];
						}
						if (objKey.provider && objKey.provider.name) {
							pattern['BILLING PROVIDER NAME'] = objKey.provider.name;
						} else if (objKey.provider && BaseLWC.isUndefinedOrNullOrBlank(objKey.provider.name)) {
							pattern['BILLING PROVIDER NAME'] = '';
						} else {
							/* Do Nothing */ }
						pattern['HOVERDETAILS'] = [{
								"strField": "Description",
								"strValue": objKey.statusDescription
							},
							{
								"strField": "Billing Provider Number",
								"strValue": ""
							},
							{
								"strField": "Billing Provider NPI",
								"strValue": objKey.provider.npi
							}
						];
						pattern['URLPARAMS'] = '?' + window.btoa(unescape(encodeURIComponent('claimNumber=' + objKey.claimNumber + '&mid=' + this.strMid + '&claimId=' + objKey.claimId +
							'&adjNumber=' + objKey.adjustmentNumber + '&corpCode=' + objKey.claimId.split("^")[0] + '&groupNumber=' + objKey.groupNumber + '&idAccount=' + this.recordId)));
					}
					lstTableValues.push(pattern);
				});
				//NT: CEAS-82803
				lstTableValues.sort(this.sortFunction('SERVICE FROM'));
				this.objDentalData = lstTableValues;
				const strViewMoreDental = '/lightning/n/Claims_History_FlexiPage_ACE' + '?c__BaseURLParam=' + window.btoa(unescape(encodeURIComponent('strClaimType=Dental&mid=' + this.strMid + '&strClaimStatus=&strGroupNumber=' +
					this.strGroupName + '&strCorpCode=' + this.strCorpCode + '&idAccount=' + this.recordId + '&boolFEPMember=' + this.boolFEPMember)));
				this.strViewMoreDental = strViewMoreDental;
				this.boolIsDentalPresent = true;
				this.boolIsDentalNoData = false;
				this.boolIsDentalIntError = false;
				this.boolSpinner = false;
			} catch (exception) {
				this.boolIsDentalPresent = false;
				this.boolIsDentalNoData = false;
				this.boolIsDentalIntError = true;
				this.boolSpinner = false;
				this.handleErrors(exception);
			}
		} else {
			// Dental No Data Present
			this.boolIsDentalPresent = false;
			this.boolIsDentalNoData = true;
			this.boolIsDentalIntError = false;
			this.boolSpinner = false;
		}
	}
	fetchAccountDetails() {
		this.boolSpinner = true;
		if (this.strBlueCardAccId) {
			fetchBlueCardMemberDetails({
				idRecordId: this.strBlueCardAccId
			}).then(objResponse => {
				if (objResponse) {
					try {
						const objResultOfBlueCard = JSON.parse(objResponse);
						if (objResponse && objResultOfBlueCard.RecordType.DeveloperName === 'BlueCard_Member_ACE') {
							this.boolBlueCardMember = true;
							this.strBlueCardPatName = objResultOfBlueCard.FirstName_ACE__c;
							this.strBlueCardPatDob = objResultOfBlueCard.BirthDate_ACE__c;
							this.strSubscriberId = objResultOfBlueCard.SubscriberId_ACE__c;
							if (objResultOfBlueCard.GroupNumber_ACE__c) {
								this.strGroupName = objResultOfBlueCard.GroupNumber_ACE__c;
							}
							this.callBlueCardSummaryCont();
							this.boolSpinner = false;
						}
					} catch (exception) {
						this.boolSpinner = false;
						this.handleErrors(exception);
					}
				}
			}).catch(function(exception) {
				this.boolSpinner = false;
				this.handleErrors(exception);
			});
		}
	}
	getClaimsFEPDirectURL() {
		fetchClaimsFEPDirectURL({}).then(objResult => {
			if (objResult) {
				try {
					this.strClaimsFEPDirectURL = objResult;
				} catch (exception) {
					this.handleErrors(exception);
				}
			}
		}).catch(function(exception) {
			this.handleErrors(exception);
		});
	}
	callBlueCardSummaryCont() {
		let lstTableValues = [];
		let strTrimZeros = '';
		let strGroupNameFirst = '';
		const grpNameMapping = {
			'XO': 'IL1',
			'YI': 'NM1',
			'YU': 'OK1',
			'ZG': 'TX1',
			'YD': 'MT1'
		};
		if (BaseLWC.isUndefinedOrNullOrBlank(this.strCorpCode) && this.strGroupName) {
			const strGroupName = this.strGroupName;
			if (strGroupName) {
				strTrimZeros = strGroupName.replace(/^0+/, '');
			}
			if (strTrimZeros) {
				strGroupNameFirst = strTrimZeros.substring(0, 2);
			}
			this.strCorpCode = grpNameMapping[strGroupNameFirst] || null;
		}
		this.boolSpinner = true;
		blueCardClaimsSummaryRequest({
			srtSubscriberId: this.strSubscriberId,
			strCorpCode: this.strCorpCode,
			strGroupNumbers: this.strGroupName,
			strFirstName: this.strBlueCardPatName,
			strDOB: this.strBlueCardPatDob,
		}).then(objResult => {
			try {
				const objContinuationResponse = JSON.parse(objResult);
				if (BaseLWC.isUndefinedOrNullOrBlank(objContinuationResponse)) {
					return;
				} else if (objContinuationResponse && objContinuationResponse.claimMedicalSummary) {
					if (objContinuationResponse.claimMedicalSummary.claims.length > 0) {
						try {
							const lstMedicalClaimSummary = objContinuationResponse.claimMedicalSummary;
							this.lstBlueCardClaims = lstMedicalClaimSummary.claims;
							this.formatBlueCardServiceFromServiceTo();
							lstTableValues = [];
							this.lstBlueCardClaims.forEach((objKey) => {
								const pattern = {};
								if (objKey) {
									const StrNewGroupNo = objKey.groupNumber;
									const StrTrimGroupNo = StrNewGroupNo.replace(/^000/, '');
									let strClaimId = '';
									let strFormatCorpCode = '';
									if (objKey.corpCode && objKey.corpCode.length === 2) {
										strFormatCorpCode = objKey.corpCode + '1';
										strClaimId = strFormatCorpCode + '^' + objKey.claimNumber + '^BC0';
									} else {
										strFormatCorpCode = objKey.corpCode;
										strClaimId = strFormatCorpCode + '^' + objKey.claimNumber + '^BC0';
									}
									if (objKey.adjustmentNumber && objKey.adjustmentNumber !== '0') {
										pattern['DCN/CLAIM NUMBER'] = objKey.claimNumber + '-' + objKey.adjustmentNumber;
									} else {
										pattern['DCN/CLAIM NUMBER'] = objKey.claimNumber;
									}
									pattern['SERVICE FROM'] = objKey.serviceFrom;
									pattern['SERVICE TO'] = objKey.serviceTo;
									pattern['GROUP NUMBER'] = StrTrimGroupNo;
									pattern['STATUS'] = objKey.claimStatus;
									pattern['STATUS CODE'] = objKey.claimProcessCompletionCode;
									if(objKey.billedAmount) {
										pattern['TOTAL BILLED'] = '$' + Number(objKey.billedAmount).toFixed(2);
									} else {
										pattern['TOTAL BILLED'] = '';
									}
									
									if (objKey.provider && objKey.provider.name) {
										pattern['BILLING PROVIDER NAME'] = objKey.provider.name;
									} else if (objKey.provider && objKey.provider.name) {
										pattern['BILLING PROVIDER NAME'] = '';
									} else {
										/* Do Nothing */ }
									pattern['HOVERDETAILS'] = [{
											"strField": "Description",
											"strValue": objKey.description
										},
										{
											"strField": "Billing Provider Number",
											"strValue": objKey.provider.providerNumber
										},
										{
											"strField": "Billing Provider NPI",
											"strValue": objKey.provider.npi
										}
									];
									if (objKey.adjustmentNumber) {
										pattern['URLPARAMS'] = '?' + window.btoa(unescape(encodeURIComponent('claimNumber=' + objKey.claimNumber + '&mid=' + this.strBlueCardAccId + '&claimId=' + strClaimId +
											'&adjNumber=' + '&corpCode=' + strFormatCorpCode + '&groupNumber=' + StrTrimGroupNo + '&idAccount=' + this.recordId + '&subscriberId=' + this.strSubscriberId +
											'&lob=' + 'GMS' + '&boolProspectMember=' + this.strProspectMember +
											'&isBlueCardOOS=' + this.boolBlueCardMember + '&latestAdjustment=true')));
									} else {
										pattern['URLPARAMS'] = '?' + window.btoa(unescape(encodeURIComponent('claimNumber=' + objKey.claimNumber + '&mid=' + this.strBlueCardAccId + '&claimId=' + strClaimId +
											'&adjNumber=' + objKey.adjustmentNumber + '&corpCode=' + strFormatCorpCode + '&groupNumber=' + StrTrimGroupNo + '&idAccount=' + this.recordId + '&subscriberId=' + this.strSubscriberId +
											'&lob=' + 'GMS' + '&boolProspectMember=' + this.strProspectMember +
											'&isBlueCardOOS=' + this.boolBlueCardMember)));
									}
								}
								lstTableValues.push(pattern);
							});
							//NT: CEAS-82803
							lstTableValues.sort(this.sortFunction('SERVICE FROM'));
							this.objBlueCardData = lstTableValues;
							const strViewMoreBlueCard = '/lightning/n/BlueCard_Claims_History_FlexiPage_ACE' + '?c__BaseURLParam=' + window.btoa(unescape(encodeURIComponent('strClaimType=Medical&mid=' + this.strMid +
								'&strClaimStatus=&strGroupNumber=' + this.strGroupName + '&strCorpCode=' + this.strCorpCode + '&idAccount=' + this.recordId +
								'&boolFEPMember=' + this.boolFEPMember + '&strFirstName=' + this.strBlueCardPatName + '&strSubscriberId=' + this.strSubscriberId +
								'&strDOB=' + this.strBlueCardPatDob + '&boolProspectMember=' + this.strProspectMember + '&isBlueCardOOS=' + this.boolBlueCardMember
							)));
							this.strViewMoreBlueCard = strViewMoreBlueCard;
							this.boolIsBlueCardPresent = true;
							this.boolIsBlueCardNoData = false;
							this.boolIsBlueCardIntError = false;
						} catch (exception) {
							this.boolIsBlueCardPresent = false;
							this.boolIsBlueCardNoData = false;
							this.boolIsBlueCardIntError = true;
							this.handleErrors(exception);
						}
						// BlueCard Summary Data Present
					} else {
						// BlueCard Summary No Data Present
						this.boolIsBlueCardPresent = false;
						this.boolIsBlueCardNoData = true;
						this.boolIsBlueCardIntError = false;
					}
					this.boolSpinner = false;
				} else {
					this.boolIsBlueCardPresent = false;
					this.boolIsBlueCardNoData = false;
					this.boolIsBlueCardIntError = true;
				}
			} catch (exception) {
				this.boolSpinner = false;
				this.handleErrors(exception);
			}
		}).catch(function(exception) {
			this.boolIsBlueCardPresent = false;
			this.boolIsBlueCardNoData = false;
			this.boolIsBlueCardIntError = true;
			this.boolSpinner = false;
			this.handleErrors(exception);
		});
	}
	onRefresh() {
		if (this.boolBlueCardMember) {
			this.callBlueCardSummaryCont();
		} else {
			if (this.boolFEPMember) {
				this.fepClaimSummaryContinuation();
			} else {
				this.callSummaryContinuation();
			}
			this.callAppealsSummaryContinuation();
			this.callDisputeContinuation();
		}
		//NT:CEAS-77680
		if (this.strLOB && this.strLOB.toUpperCase() == 'GOVERNMENT-MEDICAID' && this.strCorpCode == 'TX1') {
			if (this.template.querySelector('c-lwc-t-m-g-pended-claims_-a-c-e')) {
				this.template.querySelector('c-lwc-t-m-g-pended-claims_-a-c-e').fetchData();
			}
			if (this.template.querySelector('c-lwc-g-c-appeals-subtab_-a-c-e')) {
				this.template.querySelector('c-lwc-g-c-appeals-subtab_-a-c-e').fetchData();
			}
		}
	}
	getAppealSummary() {
		if (!this.boolIsSafeMode) {
			this.strClaimsAppealclass = '';
			this.strClaimsAppealSafeclass = 'slds-hide';
			const objPdcId = this.template.querySelector(`[data-id="${this.strShowPDCContainerId}"]`);
			if (objPdcId) {
				objPdcId.classList.add('slds-hide');
			}
			this.boolIsAppealClicked = true;
			if (this.objAppealsData && this.objAppealsData.length === 0 || this.boolIsPlanChanged) {
				this.boolSpinner = true;
				this.callAppealsSummaryContinuation();
				this.boolIsPlanChanged = false;
			}
		} else {
			this.strClaimsAppealSafeclass = '';
			this.strClaimsAppealclass = 'slds-hide';
		}
	}
	removeAppealSummary() {
		const objPdcId = this.template.querySelector(`[data-id="${this.strShowPDCContainerId}"]`);
		if (objPdcId) {
			objPdcId.classList.remove('slds-hide');
			this.boolIsAppealClicked = false;
		}
	}
	getDisputeResolutions() {
		if (this.boolIsSafeMode !== undefined && this.boolIsSafeMode === false) {
			this.disputeCardClass = '';
			this.disputeCardSafeModeClass = 'slds-hide';
			const objPdcId = this.template.querySelector(`[data-id="${this.strShowPDCContainerId}"]`);
			if (objPdcId) {
				objPdcId.classList.add('slds-hide');
			}
			this.boolIsDisputeClicked = true;
				if ((this.objDisputeData && this.objDisputeData.length === 0) || this.boolIsPlanChanged) {
					this.boolSpinner = true;
					this.callDisputeContinuation();
					this.boolIsPlanChanged = false;
				}
			
		} else {
			this.disputeCardSafeModeClass = '';
			this.disputeCardClass = 'slds-hide';
		}
	}
	callDisputeContinuation() {
		disputeResolutionRequest({
			strSubscriberId: this.strSubscriberId,
			strCorpCode: this.strCorpCode
		}).then(objResult => {
			if (objResult) {
				try {
					const objDisputeResponse = JSON.parse(objResult);
					const lstTableValues = [];
					if (objDisputeResponse && objDisputeResponse.iDRSummary && objDisputeResponse.iDRSummary.length > 0 && BaseLWC.isUndefinedOrNullOrBlank(objDisputeResponse.errorCode)) {
						const objDisputeData = objDisputeResponse.iDRSummary;
						objDisputeData.forEach((objKey) => {
							const pattern = {};
							const strAdjNumber = '';
							if (objKey) {
								let strTotalBilledAmount;
								if (objKey.totalBilled && objKey.totalBilled !== '') {
									strTotalBilledAmount = '$' + Number(objKey.totalBilled).toFixed(2);
								} else {
									strTotalBilledAmount = '';
								}
								pattern['DCN/CLAIM NUMBER'] = objKey.claimNumber;
								pattern['REQUESTING PROVIDER NAME'] = objKey.billingProvider.providerName;
								pattern['PATIENT NAME'] = objKey.patientName;
								pattern['SERVICE FROM'] = objKey.serviceDetail.serviceFromDate;
								pattern['SERVICE TO'] = objKey.serviceDetail.serviceToDate;
								pattern['TOTAL BILLED AMOUNT'] = strTotalBilledAmount;
								pattern['STATUS'] = objKey.status;
								pattern['DISPUTE ID'] = objKey.disputeId;
								pattern['CLAIM ID'] = objKey.claimId;
								pattern['HOVERDETAILS'] = [];
								pattern['REGULATION'] = objKey.regulation;
								if (objKey.renderingProvider) {
									pattern['HOVERDETAILS'].push({
										"strField": "Rendering Provider Name",
										"strValue": objKey.renderingProvider.providerName
									}, {
										"strField": "Rendering Provider NPI",
										"strValue": objKey.renderingProvider.npid
									});
								}
								if (objKey.billingProvider) {
									pattern['HOVERDETAILS'].push({
										"strField": "Billing Provider Name",
										"strValue": objKey.billingProvider.providerName
									}, {
										"strField": "Billing Provider NPI",
										"strValue": objKey.billingProvider.npid
									});
								}
								//added the disputeId,strPatientName, ProviderName in url parms for detail page
								pattern['URLPARAMS'] = '?' + window.btoa(unescape(encodeURIComponent('claimNumber=' + objKey.claimNumber + '&mid=' + this.strMid + '&claimId=' + objKey.claimsId + '&adjNumber=' + strAdjNumber +
									'&corpCode=' + objKey.claimsId.split("^")[0] + '&groupNumber=' + this.strGroupName + '&idAccount=' + this.recordId + '&strDisputeId=' + objKey.disputeId + '&strPatientName=' + objKey.patientName + '&strProviderName=' + objKey.providerName + '&idr=true')));
							}
							lstTableValues.push(pattern);
						});
						//NT: CEAS-82803
						lstTableValues.sort(this.sortFunction('SERVICE FROM DATE'));
						let lstTableValuesFinal = [];
						if (lstTableValues.length > 5) {
							lstTableValuesFinal = lstTableValues.slice(0, 5);
						} else {
							lstTableValuesFinal = lstTableValues;
						}
						const strDisputeViewMoreURL = '/lightning/n/Disputes_History_FlexiPage_ACE' + BaseLWC.helperBaseEncodeUrl('?strGroupNumber=' + this.strGroupName + '&strSubscriberId=' +
							this.strSubscriberId + '&strCorpCode=' + this.strCorpCode + '&mid=' + this.strMid + '&planId=' + this.strPlanId + '&Cmid=' + this.strCmid + '&idAccount=' + this.recordId +
							'&boolFEPMember=' + this.boolFEPMember);
						this.strViewMoreDispute = strDisputeViewMoreURL;
						this.objDisputeData = lstTableValuesFinal;
						this.boolIsDisputeNoData = false;
						this.boolIsDisputePresent = true;
						this.boolIsDisputeIntError = false;
						this.boolSpinner = false;
					} else {
						this.boolIsDisputeNoData = true;
						this.boolIsDisputePresent = false;
						this.boolIsDisputeIntError = false;
						this.boolSpinner = false;
					}
				} catch (exception) {
					this.boolIsDisputeNoData = false;
					this.boolIsDisputePresent = false;
					this.boolIsDisputeIntError = true;
					this.boolSpinner = false;
					this.handleErrors(exception);
				}
			} else {
				this.boolIsDisputeNoData = false;
				this.boolIsDisputePresent = false;
				this.boolIsDisputeIntError = true;
				this.boolSpinner = false;
			}
		}).catch(function(exception) {
			this.boolIsDisputeNoData = false;
			this.boolIsDisputePresent = false;
			this.boolIsDisputeIntError = true;
			this.boolSpinner = false;
			this.handleErrors(exception);
		});
	}
	formatBlueCardServiceFromServiceTo() {
		this.lstBlueCardClaims.forEach(function(strBlueKey) {
			if (strBlueKey) {
				if (strBlueKey.serviceFrom) {
					const lstBlueCdServiceFrom = strBlueKey.serviceFrom.split('-');
					strBlueKey.serviceFrom = lstBlueCdServiceFrom[1] + '/' + lstBlueCdServiceFrom[2] + '/' + lstBlueCdServiceFrom[0];
				}
				if (strBlueKey.serviceTo) {
					const lstBlueCdServiceTo = strBlueKey.serviceTo.split('-');
					strBlueKey.serviceTo = lstBlueCdServiceTo[1] + '/' + lstBlueCdServiceTo[2] + '/' + lstBlueCdServiceTo[0];
				}
			}
		});
	}
	listenToPCPMGEvents() {
		if (BaseLWC.isUndefinedOrNullOrBlank(this.objPCPMGListener)) {
			const strTabIdLocalVariable = this.objTabData.tabId;
			const objPCPMGEventHandler = (objEventData) => {
				if (BaseLWC.isUndefinedOrNullOrBlank(this.objPCPMGListener)) {
					window.removeEventListener('PCPMGEvents' + strTabIdLocalVariable, objPCPMGEventHandler, false);
				}
				try {
					if (objEventData.detail) {
						const objPCPMGDetails = JSON.parse(objEventData.detail);
						if (objPCPMGDetails.objParameters && objPCPMGDetails.objParameters.objMessage === 'MG') {
							this.boolShowPDCContainer = true;
							BaseLWC.helperBaseSetItem('PCPMGEvents' + strTabIdLocalVariable, objPCPMGDetails.objParameters.objMessage, 1);
						} else {
							this.boolShowPDCContainer = false;
						}
					} else {
						// Do nothing
					}
				} catch (objException) {
					this.handleErrors(objException);
				}
			};
			this.objPCPMGListener = objPCPMGEventHandler;
			window.addEventListener('PCPMGEvents' + strTabIdLocalVariable, objPCPMGEventHandler, false);
		}
	}
	handleErrors = (errorMessage) => {
		this.strErrorMessage = errorMessage;
	};
	
	//NT: CEAS-82803 - Returns a compare method for sorting based on Field Name, 
	//w/ Null Checks to address defect
	sortFunction = (strFieldName) => {
		return function(a, b) {

			let compare1;
			let compare2;
				
			if (b[strFieldName]) {
				const x = b[strFieldName].split("/");
				compare1 = x[2] + "/" + x[0] + "/" + x[1];
			} else {
				compare1 = "";
			}

			if (a[strFieldName]) {
				const y = a[strFieldName].split("/");
				compare2 = y[2] + "/" + y[0] + "/" + y[1];
			} else {
				compare2 = "";
			}
			return compare1.localeCompare(compare2);
		}
	}
}