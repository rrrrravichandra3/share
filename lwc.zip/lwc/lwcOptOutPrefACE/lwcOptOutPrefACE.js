import { LightningElement, track, api, wire } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF'; //Base LWC functions. 
//Import Lightning Message Service
import { subscribe, MessageContext } from 'lightning/messageService';
import messageChannelMemberDemographics from "@salesforce/messageChannel/LWCAuraVFBridgeMemberDemographics__c";
import sendAddressUpdate from '@salesforce/apexContinuation/CommunicationPreferSummaryController_ACE.sendAddressUpdate'; 
import getMemberContactDetails from "@salesforce/apexContinuation/NotificationPrefLWCController_ACE.getMemberContactDetails"; 
import MemberContactDetails_SuccessMessage_ACE from '@salesforce/label/c.MemberContactDetails_SuccessMessage_ACE'; 
import { EnclosingTabId,getTabInfo} from 'lightning/platformWorkspaceApi';


export default class LwcOptOutPref_ACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    //NT: Passed from Parent Component
    @api objPlanDetails;
    @api strAccountId;

    @track boolToggleDisabled = false;
    @track boolToggleChecked;
    @track boolSaveDisabled = false;
    @track boolShowSpinner = false;
    @track boolShowCard = false;
    @track boolShowToggle = false;
    strMemberId
    strCorporationCode
    strGroupNumber  
    @track lstNotificationPreferences = [];
    @track boolNotificationType = false;
    @track boolEnabled = false;
    @track boolOptPreEnable = false; 
    @track boolOldPreEnable = false;
    @track boolNewPreEnable = false;
    strRequestBody = ''; 
    @track strToastType = 'success';
	@track strToastMessage;
	@track showToastBar = false;
	@api autoCloseTime = 5000;
	@track strToastIcon = '';
    @track boolError = false;
    lstLabel = {
	    MemberContactDetails_SuccessMessage_ACE,
    };
    strInteractionId;
    parentTabId;

    @wire(MessageContext) MessageContext;

    strLOB = '';
    intAge = '';
    strCMID = ''
    subscribtion = null;
    boolMedicareSecondPayer = false;

    get getIconName() {
		if (this.strToastIcon) {
			return this.strToastIcon;
		}
		return 'utility:' + this.strToastType;
	}
	get innerClass() {
		return 'slds-icon_container slds-icon-utility-' + this.strToastType + ' slds-m-right_small slds-no-flex slds-align-top';
	}
	get outerClass() {
		return 'slds-notify slds-notify_toast slds-theme_' + this.strToastType;
	}

    //NT: Map used to map LOBs to minimum age for Toggle Visibility, 0 == Always visible
    mapLOBAge = new Map([
        ['GOVERNMENT-MEDICAID', 64],
        ['GMS', 64],
        ['RETAIL', 64],
        ['GOVERNMENT-MEDICARE', 0],
        ['GOVERNMENT-MEDICARE SUPPLEMENTAL', 0]
    ]);

    connectedCallback() {
        try {
            this.boolShowSpinner = true;
            this.fetchTabData();
            this.doInit();
            this.subscribeToMessageChannel();
            this.setVisibilities();
        } catch (error) {
            this.boolShowSpinner = false;
        }
    }

    fetchTabData() {
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objTabData => {
                this.objTabData = objTabData;
                const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + this.strAccountId;
                this.strInteractionId = BaseLWC.helperBaseGetItem(localStorageKey);
                this.parentTabId = objTabData.parentTabId;
                this.planSummaryListener();
            }).catch((error) => {
                this.boolShowSpinner = false;
            });
            }
    }

    planSummaryListener() {
        if (this.parentTabId) {
            const strPlanSummaryEvent = 'PlanSummaryInteractionEvent_' + this.parentTabId;
            window.addEventListener(strPlanSummaryEvent, this.planSummaryInteractionEventListnerProcess);
        }
    }

    planSummaryInteractionEventListnerProcess = (objCommEvent) => {
        if (BaseLWC.isNotUndefinedOrNull(objCommEvent.detail) && typeof objCommEvent.detail === 'string') {
            const objLocalStorageData = JSON.parse(objCommEvent.detail);

            if (objLocalStorageData && objLocalStorageData.objParameters && objLocalStorageData.objParameters.objMessage) {
                let response = objLocalStorageData.objParameters.objMessage;
                const interactionId = response.interactionId;
                const strAccountIdFromEvent = response.strAccountIdForCTI;
                const strAccountIdForCTI = this.strAccountId;
                if (strAccountIdFromEvent === strAccountIdForCTI) {
                    if (interactionId) {
                        this.strInteractionId = interactionId;
                    }
                }
            }
        }
    }

    //NT: Message Channel to recieve Medicare Demographics data from PatientCardLightningComponent,
    //avoiding additional API Call
    subscribeToMessageChannel() {
        this.subscription = subscribe(
            this.MessageContext,
            messageChannelMemberDemographics,
            (message) => {
                //NT: Ensure correct Members data
                if (message.strCMID == this.strCMID && message && message.lstFilteredMedicareData) {
                    //NT: Parse Medicare Data
                    let lstMedicareData = JSON.parse(message.lstFilteredMedicareData)
                    lstMedicareData.forEach((objMedicareData) => {
                        if (objMedicareData.strCoveragePrecedenceCode == 'Secondary') {
                            //NT: Has Medicare as Secondary Payer
                            this.boolMedicareSecondPayer = true;
                        }
                    });

                    //NT: Set visibilities
                    this.setVisibilities();
                }
            }
        );
    }

    //NT: Method to refresh card
    handleRefresh() {
        this.boolShowSpinner = true;
        this.boolError = false;
        try {
            setTimeout(() => { //NT: Refresh function is showing existing value but spins for 1 ms
                this.doInit();
            }, 1000);  
        } catch (error) {
            this.boolShowSpinner = false;
        }  
    }

    //NT: Initial Method
    doInit() {
        //NT: Disable Save button
        this.boolSaveDisabled = true;
        this.boolNotificationType = false;
        this.boolenabled = false;
        this.boolToggleChecked = null;
        this.boolOldPreEnable = false;
        this.boolNewPreEnable = false;

        //NT: Set Data from Plan Details
        if (this.objPlanDetails) {
            this.objPlanDetails = JSON.parse(JSON.stringify(this.objPlanDetails));

            //NT: Set Line of business
            if (this.objPlanDetails.strAceLineOfBusiness) {
                this.strLOB = this.objPlanDetails.strAceLineOfBusiness.toUpperCase();
            }

            //NT: Set Age
            if (this.objPlanDetails.strdateOfBirth) {
                this.intAge = this.calcAge(this.objPlanDetails.strdateOfBirth);
            }

            //NT: Set CMID
            if (this.objPlanDetails.objViewEmployerGroupWrapper) {
                this.strCMID = this.objPlanDetails.objViewEmployerGroupWrapper.strCMID;
            }

            //Set MID
            if (this.objPlanDetails.strMemberId) {
                this.strMemberId = this.objPlanDetails.strMemberId;
            }

            //Set Corp Code
            if (this.objPlanDetails.strCorporationCode) {
                this.strCorporationCode = this.objPlanDetails.strCorporationCode;
            }

            //Set Group Number
            if (this.objPlanDetails.strGroupNumber) {
                this.strGroupNumber = this.objPlanDetails.strGroupNumber;
            }

            this.fetchOptPreferenceDetails ();


        }
    }

    fetchOptPreferenceDetails () {
        getMemberContactDetails({
            strMid: this.strMemberId,
            strGroupNumber:this.strGroupNumber,
            strCorpCode: this.strCorporationCode,
            strLineOfBusiness: this.strLOB})
        .then((strResponse) => {
            if(strResponse) {
                this.populateDataFromResponse(strResponse);
                if (this.boolNotificationType === true && this.boolEnabled === true) {
                    this.boolToggleChecked = false;
                } else {
                    this.boolToggleChecked = true;
                }
            } else {
                this.boolError = true;
            }
            this.boolShowSpinner = false;
            })
        .catch((error) => {
            this.boolShowSpinner = false;
          });
    }

    populateDataFromResponse(objMemberContactDetailsWrapper) {
        if(objMemberContactDetailsWrapper) {
            if(objMemberContactDetailsWrapper.notificationPreferences) {
                this.lstNotificationPreferences = objMemberContactDetailsWrapper.notificationPreferences;
                if(this.lstNotificationPreferences && Array.isArray(this.lstNotificationPreferences)){
                    for (let i = 0; i < this.lstNotificationPreferences.length; i++) {
                        this.lstNotificationPreferences[i].index = i;
                        if((this.lstNotificationPreferences[i].notificationType === 'OPT_OUT_SALES_MARKETING_CALLS')) {
                            this.boolNotificationType = true;
                            this.boolEnabled = this.lstNotificationPreferences[i].enabled;
                        } 
                    }
                }
            }
        }
    }

    //NT: Toggle Event Handler
    handleTogleChange(event){
        this.boolOptPreEnable = (event.target.checked) ? false : true;
        this.boolSaveDisabled = (this.boolEnabled != this.boolOptPreEnable) ? false : true;
    }

    //NT: Save Button Handler
    async updateOptPreference(){
        this.createRequestBody();
        this.boolOldPreEnable = this.boolEnabled;
        this.boolNewPreEnable = this.boolOptPreEnable;
        sendAddressUpdate({
            strMid: this.strMemberId,
            strRequestBody: this.strRequestBody
        }).then((objResult) => {
            if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                const objResponse = JSON.parse(objResult);
                if (objResponse.strResponseStatusCode === '200' || objResponse.strResponseStatusCode === '201') {
                    this.showToast('success',this.lstLabel.MemberContactDetails_SuccessMessage_ACE,'utility:success',5000);
                    this.setAutoDocData(this.boolOldPreEnable, this.boolNewPreEnable);
                    this.handleRefresh();
                } else {
                    this.boolError = true;
                }            
            }
    
          })    
    }

    createRequestBody() {
        let objRequestBody;
        objRequestBody = {
            "notificationPreference": {
                "sourceSystem": "Correspondence_Profile",
                "preferences":[
                    {
                        "value": "OPT OUT SALES MARKETING CALLS",
                        "notificationType": "OPT_OUT_SALES_MARKETING_CALLS",
                        "enabled": this.boolOptPreEnable
                    }
                ]
            }
        }
        this.strRequestBody = JSON.stringify(objRequestBody);
    }

    showToast(strToastType, strToastMessage, strToastIcon, time) {
        this.strToastType = strToastType;
		this.strToastMessage = strToastMessage;
		this.strToastIcon = strToastIcon;
		this.autoCloseTime = time;
		this.showToastBar = true;
		setTimeout(() => {
			this.closeToastMessage();
		}, this.autoCloseTime);
    }

    closeToastMessage() {
		this.showToastBar = false;
		this.strToastType = '';
		this.strToastMessage = '';
	}
    
    setAutoDocData (oldEnable, newEnable) {
        let oldEnableValue = '';
        let newEnableValue = '';
        let lstOptPreValue = '';
        let lstOptPreArray = [];
        let sectionOptPre = '';
        let autodocOptPreLog = '';
        
        oldEnableValue = (oldEnable == true) ? 'Opted Out' : 'Opted In';
        newEnableValue = (newEnable == true) ? 'Opted Out' : 'Opted In';

        lstOptPreValue = '{' + '"strFieldLabel":' + '"OPT OUT PREFERENCE OLD"' + ',' + '"strFieldValue":' + '"' + oldEnableValue + '"' + '},' +
                    '{' + '"strFieldLabel":' + '"OPT OUT PREFERENCE NEW"' + ',' + '"strFieldValue":' + '"' + newEnableValue + '"' + '}';
        lstOptPreArray.push(lstOptPreValue);

        sectionOptPre = '],"lstSections":[' + '{' + '"strLabel":' + '"Opt-Out Preferences",' + '"strIcon":' + '"person_account",' + '"strIconFamily":' + '"standard",' + '"strIconColor":' + '"#62b7ed","strVisibleFor":"default"' + '},' +
             '{' + '"strLabel":' + '"Medicare Sales Calls",' + '"strIcon":' + '"person_account",' + '"strIconFamily":' + '"standard",' + '"strIconColor":' + '"#62b7ed","strVisibleFor":"default"' + '}]';
        autodocOptPreLog = '[' + lstOptPreArray + sectionOptPre;
        this.callAutoDocFunction(true, autodocOptPreLog);
    }

    callAutoDocFunction(boolSaveButton, autoDocResponse) {
        // check if the Interaction is on then processed with autodoc population
        //get web chat/phone interaction Id TODO
        if (this.strInteractionId && this.strInteractionId !== '') {
            let interactionId;
            const strChatTranscriptId = BaseLWC.helperBaseGetItem('strChatTranscriptId');
            const boolIsChat = BaseLWC.helperBaseGetItem(strChatTranscriptId + '_' + this.strAccountId);
            if (strChatTranscriptId &&( boolIsChat || boolIsChat ==="true")) {
                const isChatActive = BaseLWC.helperBaseGetItem(strChatTranscriptId + '_' + this.strAccountId);
                if (isChatActive && isChatActive === 'true') {
                    interactionId = BaseLWC.helperBaseGetItem('strInteractionLogIdForPlanSummaryStamp_' + this.strAccountId);
                }
            } else {
                interactionId = BaseLWC.helperBaseGetItem('strInteractionLogId');
            }
            if(interactionId) {
                this.setAutodocDetails(interactionId, boolSaveButton, autoDocResponse);
            }
        }
    }

    //Capture the changes made during intercation and post it to Autodoc
    setAutodocDetails(strInteractionIdCase, boolSaveButton, autoDocResponse) {
        // declare JSON for Autodoc
        let objResponses = [];
        let objResponse = {
            strInteractionLogId: '',
            lstValues: []
        };
        if (strInteractionIdCase !== null && strInteractionIdCase !== '') {
            objResponse.strInteractionLogId = strInteractionIdCase;
        }
        objResponse.lstValues = autoDocResponse;
        objResponses.push(objResponse);

        let strResponses = JSON.stringify(objResponses).replace(/\\/g, '');
        strResponses = strResponses.replace('"lstValues":"[{', '"lstValues":[{');
        strResponses = strResponses.replace('"lstValues":"{', '"lstValues":[{');
        strResponses = strResponses.replace('}]"}]', '}]}]');
        strResponses = strResponses.replace('"default"}]"}', '"default"}]}');
        strResponses = strResponses.replace('"default"}]"}', '"default"}]}');
        strResponses = strResponses.replace('"lstValues":"{', '"lstValues":[{');
        strResponses = strResponses.replace('"lstValues":"[]', '"lstValues":[]');
        // post the final response JSON to autodoc Iframe
        if (strInteractionIdCase !== null && strInteractionIdCase !== '') {
            this.postMessageToAutoDoc(strResponses);
            //objSecureLS.set('strAutodoc', strResponses);
            // Get Provider details from local storage
            let strProviderInfoMemContact = window.localStorage.getItem('MemberSearchProviderData_ACE');
            if (strProviderInfoMemContact === undefined || strProviderInfoMemContact === null) {
                strProviderInfoMemContact = '';
            }
           
        }
    }

    postMessageToAutoDoc(dataResponse) {
        let localIframe = document.getElementById('proxy');
        if (!localIframe) {
            let iframe = document.createElement("iframe");
            iframe.src = '/apex/SetlocalstoragePage_ACE';
            iframe.id = "proxy";
            document.body.appendChild(iframe);
            iframe.onload = function() {
                iframe.contentWindow.postMessage({
                    key: 'strAutodoc',
                    value: dataResponse,
                    boolIsFromMemberDetails: true
                }, '*');
                iframe.contentWindow.postMessage({
                    key: 'strKeepAutodocActive',
                    value: 'true',
                    boolIsFromMemberDetails: true
                }, '*');
            }
        } else {
            localIframe.contentWindow.postMessage({
                key: 'strKeepAutodocActive',
                value: 'true',
                boolIsFromMemberDetails: true
            }, '*');
            localIframe.contentWindow.postMessage({
                key: 'strAutodoc',
                value: dataResponse,
                boolIsFromMemberDetails: true
            }, '*');
        }
    }

    //NT: Calculates and Returns Age based on DOB
    calcAge(strDate) {
        var dtToday = new Date();
        var dtBirthDate = new Date(strDate);
        var strAge = dtToday.getUTCFullYear() - dtBirthDate.getUTCFullYear();
        var m = dtToday.getUTCMonth() - dtBirthDate.getUTCMonth();
        if (m < 0 || (m === 0 && dtToday.getUTCDate() < dtBirthDate.getUTCDate())) {
            strAge--;
        }
        return parseInt(strAge)
    }

    //NT: Enlables Card and Toggle
    setVisibilities() {

        //NT: Enable Card
        if (this.strLOB != "FEP") {
            this.boolShowCard = true;
        }

        //NT: Enable Toggle
        if (this.showLOBAge() || this.boolMedicareSecondPayer) {
            this.boolShowToggle = true
        }
    }

    //NT: Determines if Toggle should be shown based on LOB/Age Combo
    showLOBAge() {
        if (this.mapLOBAge.has(this.strLOB) && this.intAge >= this.mapLOBAge.get(this.strLOB)) {
            return true;
        } else {
            return false;
        }
    }

    disconnectedCallback() {
        if (this.parentTabId) {
            const strPlanSummaryEvent = 'PlanSummaryInteractionEvent_' + this.parentTabId;
            window.removeEventListener(strPlanSummaryEvent, this.planSummaryInteractionEventListnerProcess);
        }
    }

}