import {
	LightningElement,
	api,
	track
} from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
import getCaseRelatedDetailsRecords from '@salesforce/apex/CaseRelatedTableController_ACE.getCaseRelatedDetailsRecords';
export default class LwcCreateLetterheadACE extends LightningElement {
	@api recordid;
	@api boolopencreateletter;
	@api objCaseRecord;
	selectedRecipient;
	selectedTemplate = '';
	disableNext = true;
	showWarringBanner = false;
	isShowCCRorRR =false;
	bannerWarringMessage = 'Please ensure provider fields are populated in the case details of the case.';
	bannerCCRMessage ='Please navigate to Scribe to complete letter.';
    multiClaimBaner = 'There are multiple claims available. Select only one claim for this letter. To select a different claim, first deselect the current checkbox, then select another claim.'
	boolNoRecordFound = false;
	lstCaseRelatedDetails = [];
	caseRelatedDetailsNoFoundErr = 'A claim must first be added to the case before using this letter template.';
	boolOpenChildModal;
	caseDetailsTableData = [];
	boolShowCaseDetailTable = false;
	selectedRelatedCaseDetailId = '';
	moreThanOneClaim= false;
	selectedClaimNumber='';
	boolError = false;
	WarringMessage='';
	previousRecipientValue;
	get recipientOptions() {
		return [{
			label: 'Member Only',
			value: 'memberonly'
		}, {
			label: 'Provider Only',
			value: 'provideronly'
		}, {
			label: 'Provider + Member',
			value: 'providermember'
		}]
	}
	get letterTemplateOptions() {
		return [{
			label: 'Cannot Reach',
			value: 'Cannot Reach'
		}, {
			label: 'Claim Maintain After Review',
			value: 'Claim Maintain After Review'
		}, {
			label: 'Certificate of Credible Coverage (COCC)',
			value: 'CERTIFICATE OF CREDIBLE COVERAGE (COCC)'
		}, {
			label: 'Out of Country Proof of Insurance',
			value: 'OUT OF COUNTRY PROOF OF INSURANCE'
		}, {
			label: 'Out of Country Summary of Benefits',
			value: 'OUT OF COUNTRY SUMMARY OF BENEFITS'
		}, {
			label: 'PTC Maintain Denial',
			value: 'PTC Maintain Denial'
		}]
	}
	get CCROptions(){
		return [
            { label: 'Yes', value: 'yes' },
            { label: 'No', value: 'no' }
        ]
    }
	tableColumns = [{
		label: 'RECORD TYPE',
		fieldName: 'recordTypeName',
		type: ''
	}, {
		label: 'RECORD NUMBER',
		fieldName: 'recordNumber',
		type: ''
	}, {
		label: 'DATE',
		fieldName: 'date',
		type: ''
	}, {
		label: 'STATUS',
		fieldName: 'status',
		type: ''
	},{ label: '', fieldName: 'HelpText', sortable: false ,boolIsTooltip:true, boolIsInfoIconTooltip: true, type: 'text'}];
	objInitTableSettings = {
		pageSize: 10,
		restrictedPageSize: 5,
		boolViewMore: true,
		columnsData: this.tableColumns,
		boolShowFilter: false,
		boolSecondaryTable: false,
		boolShowSearch: false,
		boolShowSearchLabel: false,
		boolShowRecordCount: false,
		boolShowCheckbox: true,
		boolHideHeaderCheckbox: true,
        intMaxCheckBoxSelection : 1
	};
	closeModel() {
		let closeModal = new CustomEvent('cancelorclosemodal', {
			detail: {
				boolopencreateletter: false
			}
		});
		this.dispatchEvent(closeModal);
	}
	handleNext() {
		//to Store Total Billed Amount 
		let totalBillAmnt ='';
		for(let i=0 ; i < this.lstCaseRelatedDetails.length; i++) { 
			if(this.lstCaseRelatedDetails[i].Claim_Number_ACE__c === this.selectedClaimNumber){
				totalBillAmnt  = this.lstCaseRelatedDetails[i].Total_Billed_ACE__c;
			}
		}
		let createlettersubmitEvent = new CustomEvent('nextbutton', {
			detail: {
				boolopencreateletter: false,
				selectedRecipient: this.selectedRecipient,
				selectedTemplate: this.selectedTemplate,
				selectedClaimNumber: this.selectedClaimNumber,
				totalBilledAmount: totalBillAmnt
			}
		});
		this.dispatchEvent(createlettersubmitEvent);
	}
	handleTemplateChange(event) {
		this.selectedTemplate = event.detail.value;
		this.boolNoRecordFound = false;
		this.boolShowCaseDetailTable = false;
		this.moreThanOneClaim = false;
		this.selectedRelatedCaseDetailId = '';
		this.lstCaseRelatedDetails = [];
		this.caseDetailsTableData = [];
		if (this.selectedTemplate == 'Claim Maintain After Review' || this.selectedTemplate == 'PTC Maintain Denial') {
			this.fetchDataFromServer();
		}
		this.checkEnableNextButton();
	}
	async fetchDataFromServer() {
		getCaseRelatedDetailsRecords({
				strCaseId: this.recordid
			}).then((result) => {
				if (result) {
					this.lstCaseRelatedDetails = [...result];
					if (BaseLWC.isNotUndefinedOrNull(this.lstCaseRelatedDetails) && this.lstCaseRelatedDetails.length > 0) {
						this.boolShowCaseDetailTable = true;
						if (this.lstCaseRelatedDetails.length === 1) {
							this.selectedRelatedCaseDetailId = this.lstCaseRelatedDetails[0].Id;
						}
						this.formatCaseRelatedDetailData(this.lstCaseRelatedDetails);
					} else {
						this.boolNoRecordFound = true;
					}
					this.checkEnableNextButton();
				}
			})
			.catch((objError) => {
				this.handleError(objError);
			});
	}
	handleErrors(_error) {
        this.boolError = true;
    }
	formatCaseRelatedDetailData(caseRelatedDetails) {
		for (let objClaimData of caseRelatedDetails) {
			let datDateToShow;
			let dateToshow;
			if (objClaimData.Date_ACE__c) {
				let objDateTime = new Date(objClaimData.Date_ACE__c);
				let intMonth = objDateTime.getUTCMonth() + 1;
				let intDay = objDateTime.getUTCDate();
				let intYear = objDateTime.getUTCFullYear();
				if (intMonth < 10) {
					intMonth = "0" + intMonth;
				}
				if (intDay < 10) {
					intDay = "0" + intDay;
				}
				datDateToShow = intMonth + "/" + intDay + "/" + intYear;
			}
			if (objClaimData.Approved_Date_Range_ACE__c) {
				dateToshow = objClaimData.Approved_Date_Range_ACE__c
			} else {
				dateToshow = datDateToShow;
			}
            let strTooltipInfo = "SCCF Number: " + this.validateFieldValue(objClaimData.SCCF_Number_ACE__c) + "<br/>Total Billed: " + this.validateFieldValue(objClaimData.Total_Billed_ACE__c) 
                                        + "<br/>Provider Name: " + this.validateFieldValue(objClaimData.Billing_Provider_Name_Medical_Claim_ACE__c);

            let objTableElement = {};
            objTableElement['id'] = objClaimData.Id;
            objTableElement['recordTypeName'] = objClaimData.RecordType.Name;
            objTableElement['recordNumber'] = objClaimData.Claim_Number_ACE__c;
            objTableElement['status'] = objClaimData.Status_ACE__c;
            objTableElement['date'] = dateToshow;
            objTableElement['boolRowChecked'] = false;
            objTableElement['HelpText'] = {};
            objTableElement['HelpText'].strCellValue = strTooltipInfo;
            objTableElement['HelpText'].strTextTooltipContent = strTooltipInfo;
            // if (caseRelatedDetails && caseRelatedDetails.length === 1) {
			// 	objTableElement['boolRowChecked'] = true;
            //     this.selectedRelatedCaseDetailId = objTableElement['id'];
			// }
			this.caseDetailsTableData.push(objTableElement);

			if (caseRelatedDetails && caseRelatedDetails.length === 1) {
                	objTableElement['boolRowChecked'] = true;
					objTableElement['boolCheckBoxDisable'] = true;
                    this.selectedRelatedCaseDetailId = objTableElement['id'];
					this.selectedClaimNumber = objClaimData.Claim_Number_ACE__c;
			} else {
                //Do nothing
                }
            if(caseRelatedDetails && caseRelatedDetails.length>1) {
                this.moreThanOneClaim = true
            }
            
		}
			}

    validateFieldValue(strFieldValue) {
        if (BaseLWC.isUndefinedOrNullOrBlank(strFieldValue)){
            return '';
        } else {
            return strFieldValue;
		}
	}
	handleRelatedCaseRowsSelection(event) {
		this.selectedRelatedCaseDetailId = event.detail.relatedCaseId;
		this.checkEnableNextButton();
	}
	handleRecipient(event) {
		this.selectedRecipient = event.target.value;
		
		if(this.selectedRecipient && ((this.template.querySelector("[data-id='ccrValue']") && (this.template.querySelector("[data-id='ccrValue']").value !== 'yes' && this.template.querySelector("[data-id='ccrValue']").value !=='no'))||(this.previousRecipientValue && this.previousRecipientValue==='provideronly'))) {
			this.selectedCCR ='' ;
		}
		
		this.previousRecipientValue	= this.selectedRecipient;
		this.checkCCRQuestion();
		this.checkShowBanner();
		this.checkEnableNextButton();
	}
	checkEnableNextButton() {
		if (this.selectedRecipient && ((this.selectedTemplate && this.selectedTemplate != 'Claim Maintain After Review' && this.selectedTemplate != 'PTC Maintain Denial') 
            || ((this.selectedTemplate == 'Claim Maintain After Review' || this.selectedTemplate == 'PTC Maintain Denial')
            && this.selectedRelatedCaseDetailId != ''))) {
			this.disableNext = false;
			if((this.selectedRecipient == 'provideronly' && this.objCaseRecord && this.objCaseRecord.ProviderInfoName_ACE__c ) || 
			 (this.selectedRecipient == 'memberonly' && this.selectedCCR && this.selectedCCR === 'no') ||
			 (this.selectedRecipient == 'providermember' &&  this.selectedCCR && this.selectedCCR === 'no' && this.objCaseRecord && this.objCaseRecord.ProviderInfoName_ACE__c)) {
				this.disableNext = false;
			} else {
				this.disableNext = true;
			}
		} else {
			this.disableNext = true;
		}
	}
	checkCCRQuestion() {
		if(this.selectedRecipient == 'memberonly' || this.selectedRecipient == 'providermember') {
			this.isShowCCRorRR = true;
		} else {
			this.isShowCCRorRR = false;
		}
	}
	checkShowBanner() {
		if (this.selectedRecipient && (this.selectedRecipient == 'provideronly' || (this.selectedRecipient == 'providermember' && this.selectedCCR && this.selectedCCR === 'no'))) {
			this.showWarringBanner = true;
			this.WarringMessage =this.bannerWarringMessage;
		} else if(this.selectedRecipient && ((this.selectedRecipient == 'providermember' || this.selectedRecipient == 'memberonly') && this.selectedCCR && this.selectedCCR === 'yes')){
			this.showWarringBanner = true;
			this.WarringMessage =this.bannerCCRMessage;
		} else {
			this.showWarringBanner = false;
		}
	}
	handleCheckboxSelection(event) {
		if (event && event.detail && JSON.parse(event.detail)) {
            let strCaseDetail = '';
			if (JSON.parse(event.detail).action === 'ADD') {
				this.caseDetailsTableData = this.caseDetailsTableData.map(function(objData) {
					if (JSON.parse(event.detail).rowInfo && JSON.parse(event.detail).rowInfo[0] && JSON.parse(event.detail).rowInfo[0].length>0
						&& JSON.parse(event.detail).rowInfo[0][1] && objData.recordNumber !== JSON.parse(event.detail).rowInfo[0][1].value) {
						objData.boolCheckBoxDisable = true;
                        strCaseDetail = JSON.parse(event.detail).rowInfo[0][1].value;
					}
					return objData;
				});
				let selectedClaims = (JSON.parse(event.detail).rowInfo[0]);
				selectedClaims.forEach(objData => {
					if (objData.key === 'recordNumber') {
						this.selectedClaimNumber = objData.value;
					} else {
						//do nothing
					}
				});	
			} else {
				this.caseDetailsTableData = this.caseDetailsTableData.map(function(objData) {
					objData.boolCheckBoxDisable = false;
					return objData;
				});
			}
            
            this.selectedRelatedCaseDetailId = strCaseDetail;
            this.checkEnableNextButton();
		}
	}
	handleChangeCCR(event){
        try{
        	this.selectedCCR = event.target.value;
			this.checkShowBanner();
			
			this.checkEnableNextButton();
    	}catch (error) {
        	//Handle Error
       		this.handleErrors();
    	}

    }
}
