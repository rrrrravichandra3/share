import { LightningElement,wire} from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import BaseLWC from 'c/baseLWCFunctions_CF';
import {EnclosingTabId, getTabInfo, setTabIcon} from 'lightning/platformWorkspaceApi';
//Label
import ViewStandardAuthorization_SuccessNotification_ACE from '@salesforce/label/c.ViewStandardAuthorization_SuccessNotification_ACE';
import ViewStandardAuthorization_Success_ACE from '@salesforce/label/c.ViewStandardAuthorization_Success_ACE';
import ViewStandardAuthorization_Close_ACE from '@salesforce/label/c.ViewStandardAuthorization_Close_ACE';
import FacetsHIPAARestriction_FailureNotification_ACE from '@salesforce/label/c.FacetsHIPAARestriction_FailureNotification_ACE';
import UpdateHIPAARestrictions_HIPAARestrictionsHeader_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_HIPAARestrictionsHeader_ACE';
import ViewStandardAuthorization_CreateNewButton_ACE from '@salesforce/label/c.ViewStandardAuthorization_CreateNewButton_ACE';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import SafeMode_NotificationEvent_ACE from '@salesforce/label/c.SafeMode_NotificationEvent_ACE';
import SafeMode_DestinationId_ACE from '@salesforce/label/c.SafeMode_DestinationId_ACE';
import CreateCasePage_OptionNone_ACE from '@salesforce/label/c.CreateCasePage_OptionNone_ACE';
//Apex
import fetchPickListValues from '@salesforce/apex/HIPAA_CCRF_RRF_DetailController_ACE.fetchPickListValues';
import fetchMemberPlanRecord from '@salesforce/apex/HIPAA_CCRF_RRF_DetailController_ACE.fetchMemberPlanRecord';
import fetchUserDetails from "@salesforce/apex/HIPAA_CCRF_RRF_DetailController_ACE.fetchUserDetailsForLightning";


export default class LwcViewHippaRestrictionsComponent extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;


    labels = {
        ViewStandardAuthorization_SuccessNotification_ACE,
        ViewStandardAuthorization_Success_ACE,
        ViewStandardAuthorization_Close_ACE,
        FacetsHIPAARestriction_FailureNotification_ACE,
        UpdateHIPAARestrictions_HIPAARestrictionsHeader_ACE,
        ViewStandardAuthorization_CreateNewButton_ACE,
        EnableVPSTabSpecificEvents_ACE,
        SafeMode_NotificationEvent_ACE,
        SafeMode_DestinationId_ACE,
        CreateCasePage_OptionNone_ACE
    }

    //variables
    //booleans
    boolIsNMCC = false;
    boolOpenModalToDeactivate = false;
    boolIsEdit = false;
    boolDisplayMessage = false;
    boolActivateIframeLoad = false;
    boolShowHippaRecord = false;
    boolIsEditCCRF = false;
    boolIsEditRRF = false;
    boolShowSpinner = false;
    boolVPSTabSpecificEvents = false;
    _boolDMLStatus;
    facetsCalloutRestrictionSuccess = false;
    facetsCalloutRestrictionError = false;
    boolHipaaEventListnerAdded = false;
    boolplanSummaryListened = false;
    isShowModal = false;
    closeModal = false;


    //string
    /*********Plan/Member**********/
    idMemberPlan;
    strMemberName;
    strClientMemberId;
    strPlanDetails;
    strAccountId;
    strMid;
    strFamilyCmid;
    strFamilyClientMemberId
    body;
    content = '{Restrictions/Authorizations}';

    /**********************/

    objTabData
    strTabId;
    parentTabId;
    strBaseCurrentTabId;
    strBaseCurrentParentTabId;
    strState;
    strCurrentId;
    strInteractionLogId;
    strCheckForPermission;
    strObjAPIName = 'HIPAA_Restrictions_ACE__c';
    objHIPPARestrictionCopy;
    strSuccessNotification = this.labels.ViewStandardAuthorization_SuccessNotification_ACE;

    //object
    objHIPPARestrictionDefault = { sobjectType: 'HIPAA_Restrictions_ACE__c' };
    objHIPPARestriction = { sobjectType: 'HIPAA_Restrictions_ACE__c' };
    objType = { sobjectType: 'HIPAA_Restrictions_ACE__c' };
    objMemberPlan;
    objPlanEvent;
    objOpenHIPPAModal;
    objHippaMemberDetailEvent;
    mapStates;
    objHIPAARecord;
    objPlanSummaryListener;


    get boolDMLStatus() {
        return this._boolDMLStatus;
    }
    set boolDMLStatus(value) {
        this.setAttribute('boolDMLStatus', value);
        this._boolDMLStatus = value;
        this.openSuccessNotification();
    }


    /**
     * Connected Call back function.
     */
    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.initHandeler();
        } catch (error) {
            this.handleErrors(error);
        }
    }


    initHandeler = () => {
        this.boolShowSpinner = true;
        getTabInfo(this.enclosingTabId).then(objTabData => {
            if (BaseLWC.stringIsNotBlank(this.labels.EnableVPSTabSpecificEvents_ACE) && this.labels.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                this.boolVPSTabSpecificEvents = true;
            }
            this.objTabData = objTabData;
            let strBaseCurrentTabUrl = objTabData.url;
            this.strBaseCurrentTabId = objTabData.tabId;
            setTabIcon(this.strBaseCurrentTabId, 'custom:custom91');
            this.parentTabId = objTabData.parentTabId;
            this.strMID = BaseLWC.helperBaseGetUrlParameters('mid', strBaseCurrentTabUrl);
            this.strInteractionId = BaseLWC.helperBaseGetUrlParameters('strInteractionLogId', strBaseCurrentTabUrl);
            if (this.strInteractionId === null || this.strInteractionId === "" || this.strInteractionId === "null") {
                let strAccountIdFromUrl = BaseLWC.helperGetAccountRecordId(this.strAccountId, strBaseCurrentTabUrl);
                const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + strAccountIdFromUrl;
                this.strInteractionId = BaseLWC.helperBaseGetItem(localStorageKey);
            }

            this.planSummaryListener();
            this.loadHippaRestrictionEventListener();
        }).catch((error) => {
            this.handleErrors(error);
            this.boolShowSpinner = false;
        });
    }
    
    openSuccessNotification = () => {
        this.fireToastMessageToUI(false);
        this.fireHippaDataOnRefresh();
        this.getHIppaData();
    }


    planSummaryListener = () => {
        if (this.parentTabId) {
            if (this.boolVPSTabSpecificEvents) {
                window.addEventListener('PlanSummaryChangeEvent_' + this.parentTabId, this.capturePlanSummaryListener);
            } else {
                window.addEventListener('PlanSummaryChangeEvent_', this.capturePlanSummaryListener);
            }
        }
    }

    capturePlanSummaryListener = (objPlanEvent) => {
        try {

            let boolPlanEventListned = false;
            this.boolplanSummaryListened = true;
            if (BaseLWC.isNotUndefinedOrNull(objPlanEvent.detail) && typeof objPlanEvent.detail === "string") {
                const objListenerResponse = JSON.parse(objPlanEvent.detail);
                if (BaseLWC.isUndefinedOrNullOrBlank(objListenerResponse)) {
                    if (this.boolVPSTabSpecificEvents) {
                        window.removeEventListener('PlanSummaryChangeEvent_' + this.parentTabId, this.capturePlanSummaryListener, false);
                    } else {
                        window.removeEventListener('PlanSummaryChangeEvent_', this.capturePlanSummaryListener, false);
                    }
                }

                if (!boolPlanEventListned && BaseLWC.isNotUndefinedOrNull(objListenerResponse.strIdDestination) && objListenerResponse.objParameters.strParentTabId === this.parentTabId && objListenerResponse.strIdDestination === "PlanDetails_PlanSummary_ACE") {
                    boolPlanEventListned = true;

                    this.strClientMemberId = objListenerResponse.objParameters.objMessage.strClientMemberId;
                    const objPlanDetails = objListenerResponse.objParameters.objMessage;
                    this.strPlanDetails = JSON.stringify(objPlanDetails);

                    if (BaseLWC.isNotUndefinedOrNull(objPlanDetails.strAceLineOfBusiness) && objPlanDetails.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICAID') {
                        this.boolIsNMCC = true;
                    }

                    if (this.boolVPSTabSpecificEvents) {
                        window.removeEventListener('PlanSummaryChangeEvent_' + this.parentTabId, this.capturePlanSummaryListener, false);
                    } else {
                        window.removeEventListener('PlanSummaryChangeEvent', this.capturePlanSummaryListener, false);
                    }

                    this.getHIppaData();
                }

            }
        } catch (error) {
            this.handleErrors(error);
            this.boolShowSpinner = false;
        }

    };

    loadHippaRestrictionEventListener = () => {
        if (this.boolVPSTabSpecificEvents) {
            window.addEventListener("HippaRestrictionMemberDetail_" + this.parentTabId, this.hipaaMemberDetailEventHandler, false);
        } else {
            window.addEventListener("HippaRestrictionMemberDetail_" + this.parentTabId, this.hipaaMemberDetailEventHandler, false);
        }
        this.boolHipaaEventListnerAdded = true;
    }


    fireHippaDataOnRefresh = () => {
        if (this.boolHipaaEventListnerAdded == false) {
            this.loadHippaRestrictionEventListener();
        }
    }

    hipaaMemberDetailEventHandler = (objEvent) => {
        this.boolShowSpinner = false;
        if (objEvent !== null && objEvent.detail !== null && typeof objEvent.detail === 'string') {
            if (this.boolHipaaEventListnerAdded === true) {
                window.removeEventListener('HippaRestrictionMemberDetail_' + this.parentTabId, this.hipaaMemberDetailEventHandler, false);
                this.boolHipaaEventListnerAdded = false;
            }
            try {
                const objListenerResponse = JSON.parse(objEvent.detail);
                if (BaseLWC.isNotUndefinedOrNull(objListenerResponse.strIdDestination) &&
                    objListenerResponse.objParameters.objMessage.strParentTabId === this.parentTabId && objListenerResponse.strIdDestination === "HIPPAMemberDetail_ACE") {
                    //Get Client Member Id.
                    this.strFamilyCmid = objListenerResponse.objParameters.objMessage.familyCmid;
                    this.strMid = objListenerResponse.objParameters.objMessage.mid;
                    this.strClientMemberId = objListenerResponse.objParameters.objMessage.strCmid;
                    let objPlanDetails = this.strPlanDetails;
                    let lstFamilyDetails;
                    if (BaseLWC.isNotUndefinedOrNull(objPlanDetails)) {
                        lstFamilyDetails = objPlanDetails.lstFamilyWrapper;
                    }

                    let strFamilyCmid = '';
                    if (this.strFamilyCmid) {
                        strFamilyCmid = this.strFamilyCmid;
                    } else if (lstFamilyDetails) {
                        for (let intCount = 0; intCount < lstFamilyDetails.length; intCount++) {
                            if (intCount === 0) {
                                strFamilyCmid = lstFamilyDetails[intCount].strClientMemberId;
                            } else {
                                strFamilyCmid = strFamilyCmid + ',' + lstFamilyDetails[intCount].strClientMemberId;
                            }
                        }
                    }
                    this.strFamilyClientMemberId = strFamilyCmid;
                    this.getMemberPlanOnPlanChange();
                    if (this.boolVPSTabSpecificEvents) {
                        window.removeEventListener('HippaRestrictionMemberDetail_' + this.parentTabId, this.hipaaMemberDetailEventHandler, false);
                    } else {
                        window.removeEventListener('HippaRestrictionMemberDetail', this.hipaaMemberDetailEventHandler, false);
                    }
                    this.boolHipaaEventListnerAdded = false;
                }


            } catch (objException) {
                this.boolShowSpinner = false;
            }
        }
        this.boolShowSpinner = false;
    }

    getHIppaData = () => {
        const parentTanIdDetail = {
            strIdDestination: "HippaRestrictionMemebrDetailRequest_ACE",
            strParentTabId: this.parentTabId,

        };

        //Post message Window
        const objResponse = {
            strIdDestination: 'HippaRestrictionMemebrDetailRequest_ACE',
            objParameters: {
                objMessage: parentTanIdDetail,
                strParentTabId: this.parentTabId
            }
        };

        // Here we create Custom Event and the dispatch the event
        const objSubTabEvents = new CustomEvent("HippaRestrictionMemebrDetailRequestEvent_" + this.parentTabId, { detail: JSON.stringify(objResponse) });
        window.dispatchEvent(objSubTabEvents);

    }

    getMemberPlanOnPlanChange = () => {
        this.boolShowSpinner = true;
        fetchMemberPlanRecord({
            strCMID: this.strClientMemberId
        }).then((objFetchMemberPlanRecordResult) => {
            const objResult = JSON.parse(objFetchMemberPlanRecordResult);
            if (objResult.toString() !== 'FAILED') {
                this.strMemberName = objResult.objMemberPlan.Member.Name;
                this.idMemberPlan = objResult.objMemberPlan.Id;
                this.strAccountId = objResult.objMemberPlan.MemberId;
                this.strCheckForPermission = objResult.strCheckForPermission;
                this.boolShowSpinner = false;
            }
            this.boolShowHippaRecord = true;
            //Refresh LWC. 
            this.refreshHippaLWCTable();
        }
        ).catch(() => {
            this.boolShowSpinner = false;
        });
    }


    refreshHippaLWCTable = () => {
        let hippaRestrictionChildComp = this.template.querySelector('c-lwc-update-h-i-p-a-a-restrictions_-a-c-e');
        if (BaseLWC.isNotUndefinedOrNull(hippaRestrictionChildComp)) {
            hippaRestrictionChildComp.refreshViewHippaLWC();
        }
    }

    openHIPAAModalHelper = (event) => {
        if (BaseLWC.isNotUndefinedOrNull(event) && BaseLWC.isNotUndefinedOrNull(event.detail)) {
            try {
                let objPrams = event.detail;
                const strobjListenerResponse = JSON.stringify(objPrams);
                const objListenerResponseDetail = JSON.parse(strobjListenerResponse);
                const objListenerResponse = objListenerResponseDetail.objParams;
                const strMidVf = this.strMid;

                // Open Edit Modal
                if (objListenerResponse.strIdDestination !== '' && objListenerResponse.strIdDestination === 'OpenHIPPAModal_ACE' + strMidVf) {
                    this.boolShowSpinner = true;
                    const strAction = objListenerResponse.objParameters.strAction;
                    const boolSafeMode = objListenerResponse.objParameters.boolSafeMode;
                    if (boolSafeMode) {
                        this.fireSafeModeEvent();
                    } else {
                        this.objHIPPARestriction = this.objHIPPARestrictionDefault;
                        //Logic to be executed when editing CCRF record.
                        if (strAction === 'OpenEditCCRFModal' || strAction === 'OpenEditRRFModal') {
                            this.boolIsEdit = true;
                            this.objHIPPARestriction = objListenerResponse.objParameters.objHIPAARecordDetail
                            this.objHIPPARestrictionCopy = JSON.stringify(objListenerResponse.objParameters.objHIPAARecordDetail)
                        }
                        // CEAS-76260 set Edit Type
                        this.boolIsEditCCRF = '';
                        this.boolIsEditRRF = '';
                        if (strAction === 'OpenEditCCRFModal') {
                            this.boolIsEditCCRF = true;
                            this.boolIsEditRRF = false;
                        } else if (strAction === 'OpenEditRRFModal') {
                            this.boolIsEditRRF = true;
                            this.boolIsEditCCRF = false;
                        }
                        this.boolDMLStatus = false;
                        this.fetchAllPickListValues('State_ACE__c');
                    }
                    this.boolShowSpinner = false;
                }

                // Open DeactivateModal
                if (objListenerResponse.strIdDestination !== '' && objListenerResponse.strIdDestination === 'OpenHIPPADeactivationModal_ACE' + strMidVf) {
                    this.boolShowSpinner = true;
                    const boolSafeMode = objListenerResponse.objParameters.boolSafeMode;
                    if (boolSafeMode) {
                        this.fireSafeModeEvent();
                    } else {
                        const strAction = objListenerResponse.objParameters.strAction;
                        if (strAction === 'OpenDeactivationModal') {
                            //CEAS-71009
                            this.objHIPAARecord = objListenerResponse.objParameters.objHIPAARecordDetail;
                            this.strCurrentId = objListenerResponse.objParameters.objHIPAARecordDetail.Id;
                            this.boolOpenModalToDeactivate = true;
                        }
                    }
                    this.boolShowSpinner = false;
                }

                //Event listener for deactivation success.
                if (objListenerResponse.strIdDestination !== '' && objListenerResponse.strIdDestination === 'HIPAA_SuccessNotification_To_VFPage' + strMidVf) {
                    this.fireToastMessageToUI(event, true);
                }

            } catch (objError) {
                // Do nothing.
            }
        }
    }

    openHIPAAModalAndCheckSafeModeHelper() {
        fetchUserDetails().then((objFetchSafeModeAuraResult) => {
            if (objFetchSafeModeAuraResult && objFetchSafeModeAuraResult.objSafeModeUser &&
                objFetchSafeModeAuraResult.objSafeModeUser.Safe_Mode_Enabled_ACE__c !== undefined) {
                if (objFetchSafeModeAuraResult.objSafeModeUser.Safe_Mode_Enabled_ACE__c === true) {
                    this.fireSafeModeEvent();
                } else {
                    this.objHIPPARestriction = {};
                    this.objHIPPARestrictionCopy = '';
                    this.boolIsEdit = false;
                    this.boolDMLStatus = false;
                    this.boolIsEditCCRF = '';
                    this.boolIsEditRRF = '';
                    this.fetchAllPickListValues('State_ACE__c');
                }
            }
        }).catch(() => {
            //Do Nothing
        });
    }

    fireSafeModeEvent = () => {
        // Show the Safe Mode Activated modal.
        const strSafeModeModalEventName = this.labels.SafeMode_NotificationEvent_ACE;
        const strSafeModeEventDestinationId = this.labels.SafeMode_DestinationId_ACE;
        const objResponse = {
            strIdDestination: strSafeModeEventDestinationId,
            objMessage: {
                boolDisabledNotification: true,
                boolEnabledNotification: false
            }
        };
        const objSafeModeEvents = new CustomEvent(strSafeModeModalEventName, { detail: JSON.stringify(objResponse) });
        window.dispatchEvent(objSafeModeEvents);
    }

    fetchAllPickListValues = (strFieldAPIName) => {
        fetchPickListValues({
            objObjectDetail: this.objType,
            strFieldAPIName: strFieldAPIName
        })
            .then((objFetchPickListValuesResult) => {
                const mapResponse = objFetchPickListValuesResult;
                if (BaseLWC.isNotUndefinedOrNull(mapResponse)) {
                    const mapStateInputs = [];
                    mapStateInputs.push({
                        value: this.labels.CreateCasePage_OptionNone_ACE,
                        key: this.labels.CreateCasePage_OptionNone_ACE
                    });
                    for (const strKey in mapResponse) {
                        mapStateInputs.push({
                            value: mapResponse[strKey],
                            key: strKey
                        });
                    }
                    this.mapStates = mapStateInputs;
                    this.isShowModal = true;
                }
            })
            .catch((error) => {
                this.handleErrors(error);
                this.boolShowSpinner = false;
            });
    }

    fireToastMessageToUI = (boolDeactivated) => {
        if (this.boolDMLStatus) {
            this.strSuccessNotification = this.labels.ViewStandardAuthorization_SuccessNotification_ACE;
            if (this.boolIsNMCC) {
                if (this.facetsCalloutRestrictionSuccess) {
                    this.strSuccessNotification = this.labels.FacetsHIPAARestriction_SuccessNotification_ACE;
                    this.facetsCalloutRestrictionError = false;
                } else {
                    this.facetsCalloutRestrictionError = true;
                }
            }
            this.fireToastMessageContent();
            this.boolDMLStatus = '';
        }

        if (boolDeactivated) {
            //CEAS-71009
            if (this.boolIsNMCC) {
                if (this.facetsCalloutRestrictionSuccess) {
                    this.strSuccessNotification = this.labels.FacetsHIPAARestriction_SuccessNotification_ACE;
                    this.facetsCalloutRestrictionError = false;
                } else {
                    this.facetsCalloutRestrictionError = true;
                }
            }
            this.fireToastMessageContent();
        }
    }

    handleHIPAASuccessEvent(objEvent) {
        if (BaseLWC.isNotUndefinedOrNull(objEvent) && BaseLWC.isNotUndefinedOrNull(objEvent.detail)) {
            let objPrams = objEvent.detail;
            const strobjListenerResponse = JSON.stringify(objPrams);
            const objListenerResponse = JSON.parse(strobjListenerResponse);

            const boolDeactivationIdentifier = objListenerResponse.boolDeactivationIdentifier;
            this.facetsCalloutRestrictionSuccess = objListenerResponse.facetsCalloutRestrictionSuccess;
            this.boolDMLStatus = objListenerResponse.boolDMLStatus;
            this.fireHipaaEvent(objEvent);
            this.fireToastMessageToUI(boolDeactivationIdentifier);
        }
    }

    fireHipaaEvent(objEvent) {
        if (BaseLWC.isNotUndefinedOrNull(objEvent) && BaseLWC.isNotUndefinedOrNull(objEvent.detail)) {
            let objPrams = objEvent.detail;
            const strobjListenerResponse = JSON.stringify(objPrams);
            const objListenerResponse = JSON.parse(strobjListenerResponse);

            const strClientMemberId = objListenerResponse.strClientMemberId;
            const objAutodoc = objListenerResponse.objAutodoc;
            const boolRefresh = objListenerResponse.boolRefresh;
            let objParameter = {
                "strClientMemberId": strClientMemberId,
                "objAutodoc": objAutodoc,
                "boolRefresh": boolRefresh
            };

            if (BaseLWC.stringIsNotBlank(this.strBaseCurrentTabId)) {
                BaseLWC.helperBasePostTabIdMessageCustomEvents('HIPAAAuthPartySuccessAppEvent', null, objParameter, 'HIPAAAuthPartySuccessAppEvent', this.strBaseCurrentTabId).catch((error) => {
                });
            }
        }
    }

    fireToastMessageContent = () => {
        const event = new ShowToastEvent({
            variant: 'success',
            message: this.strSuccessNotification,
            title: ''
        });
        this.dispatchEvent(event);
    }

    handleErrors(error) {
        //do nothing
    }

    refreshHIPAARestrictions(event) {
        this.fireHippaDataOnRefresh();
        this.getHIppaData();
    }


    openHIPAAModalBox(event) {
        this.openHIPAAModalAndCheckSafeModeHelper();
    }

    closeHippaModal = (objevent) => {
        this.isShowModal = false;
        this.boolIsEdit = false;
    }

    handleHIPAASuccessOnEditCreate(event) {
        this.handleHIPAASuccessEvent(event);
    }

    fireAuthSuccessEvent(event) {
        this.fireHipaaEvent(event);
        this.fireHippaDataOnRefresh();
        this.getHIppaData();
        this.boolOpenModalToDeactivate = false;
    }

    closeDeactivateModal(event) {
        this.boolOpenModalToDeactivate = false;
    }

    disconnectedCallback() {
        //69682
        if (this.boolVPSTabSpecificEvents) {
            window.removeEventListener('PlanSummaryChangeEvent_' + this.parentTabId, this.capturePlanSummaryListener, false);
            window.removeEventListener('HippaRestrictionMemberDetail_' + this.parentTabId, this.hipaaMemberDetailEventHandler, false);
        } else {
            window.removeEventListener('PlanSummaryChangeEvent', this.capturePlanSummaryListener, false);
            window.removeEventListener('HippaRestrictionMemberDetail', this.hipaaMemberDetailEventHandler, false);
        }
    }
}