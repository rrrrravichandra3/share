import { api, LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

//import custom labels 
import CreateAssginedAdvocate_DefaultChangeReason from '@salesforce/label/c.LwcCreateAssignedAdvocate_DefaultChangeReason';
import CreateAssginedAdvocate_ModalTitle from '@salesforce/label/c.LwcCreateAssignedAdvocate_ModalTitle';

export default class LwcCreateAssignedAdvocate extends LightningElement {
    buttonSource;
    @api subscriberId;
    @track assignedAdvocateId;
    @track accountNumber;
    @track corpCode;    
    @track changeReason = CreateAssginedAdvocate_DefaultChangeReason;

    label = {
        CreateAssginedAdvocate_ModalTitle
    };


    handleInputPadding(event) {
        const fieldName = event.currentTarget.dataset.field;
        const fieldValue = event.target.value;
        let pad = '000000';
        if(fieldValue !== undefined && fieldValue !== null && fieldValue !== '') {
            switch (fieldName) {
                case 'SubscriberId':
                    pad = '000000000000';
                    this.subscriberId = (pad + fieldValue).slice(-pad.length);
                    break;
                case 'AccountNumber':
                    this.accountNumber = (pad + fieldValue).slice(-pad.length);
                    break;          
                default : break;
            }
        }        
    }


    handleSubmit(event) {
        event.preventDefault();
        const boolSubmissionValid = this.validateFormFields();
        this.buttonSource = event.target.name;
        if (boolSubmissionValid) {
            this.template.querySelector("lightning-record-edit-form").submit();
        }
    }

    handleSuccess() {
        const successEvent = new ShowToastEvent({
            title: 'Success',
            message: 'Record created successfully',
            variant: 'success',
            mode: 'pester'
        });
        this.dispatchEvent(successEvent);

        if(this.buttonSource !== 'save'){
            this.resetFormFields();
        } else {
            this.closeModal();
        }
    }

    handleError(event) {
        const errorEvent = new ShowToastEvent({
            title: 'Error',
            message: event.message,
            variant: 'error',
            mode: 'pester'
        });
        this.dispatchEvent(errorEvent);
    }

    validateFormFields() {
        let validInput = true;
        this.template.querySelectorAll('.requiredIp').forEach(field => {
            field.reportValidity();
                if(field.value === undefined || field.value === null || field.value === ''){
                validInput = false;
            }
        });
        return validInput;
    }

    resetFormFields() {
        const inputFields = this.template.querySelectorAll(
            '.requiredIp'
        );
        if (inputFields) {
            inputFields.forEach(field => {
                field.reset();
            });
        } 
    }

    closeModal() {
        this.dispatchEvent(new CustomEvent('cancelmodal'));
    }


}