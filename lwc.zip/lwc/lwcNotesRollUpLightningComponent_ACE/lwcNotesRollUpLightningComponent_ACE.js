import { LightningElement, wire, api } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
//import platformWorkspaceApi
import { EnclosingTabId, getTabInfo , openSubtab} from 'lightning/platformWorkspaceApi';
import { registerRefreshHandler, unregisterRefreshHandler } from "lightning/refresh";

//Controller Methods
import getContentDocuments from '@salesforce/apex/CaseNotesViewController_ACE.getContentDocuments';
import fetchCaseRelatedDetailsRecordsMultiple from '@salesforce/apex/CaseNotesViewController_ACE.fetchCaseRelatedDetailsRecordsMultiple';
//Lables
import HideContentNotesOnViewNotes_ACE from '@salesforce/label/c.HideContentNotesOnViewNotes_ACE';
import NotesRollUpSummary_ShowAllNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_ShowAllNotes_ACE';
import NotesRollUpSummary_HideAllNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_HideAllNotes_ACE';
import NotesRollUpSummary_CaseNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_CaseNotes_ACE';
import NotesRollUpSummary_CSTTimeZone_ACE from '@salesforce/label/c.NotesRollUpSummary_CSTTimeZone_ACE';
import NotesRollUpSummary_ParentCaseNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_ParentCaseNotes_ACE';
import NotesRollUpSummary_ChildCaseNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_ChildCaseNotes_ACE';


export default class LwcNotesRollUpLightningComponent_ACE extends LightningElement {
    refreshHandlerNotes;
    label = {
        HideContentNotesOnViewNotes_ACE,
        NotesRollUpSummary_HideAllNotes_ACE,
        NotesRollUpSummary_ShowAllNotes_ACE,
        NotesRollUpSummary_CaseNotes_ACE,
        NotesRollUpSummary_CSTTimeZone_ACE,
        NotesRollUpSummary_ParentCaseNotes_ACE,
        NotesRollUpSummary_ChildCaseNotes_ACE
    }

    //wire
    @wire(EnclosingTabId) enclosingTabId;

    //@api variables
    @api recordId;
    refreshHandlerID;

    //Variables
    boolSpinner = false;
    boolAPIError = false;
    boolCaseNotesAvailable = false;
    boolParentCaseNotesAvailable = false;
    boolChildCaseNotesAvailable = false;
    strIsExpanded = 'false';
    allNotesOpen = 'slds-is-open';
   // csssldssection = 'slds-section ' +allNotesOpen;
    strNotesRollUpSeperation = '------------------------';
    intTotalNotes = 0;
    intExpandedNotes = 0;
    lstCaseIds = [];
    lstRelatedDetails =[];
    objNotesWrapper;


    get csssldssection() {
       return  'slds-section ' + this.allNotesOpen;
    }
    get enableShowHideAllbuttons() {
        return this.boolCaseNotesAvailable || this.boolParentCaseNotesAvailable || this.boolChildCaseNotesAvailable;
    }

    // Init Method
    connectedCallback() {
        this.refreshHandlerNotes = registerRefreshHandler(
            this.template.host,
            this.getRefreshNotes.bind(this),
          );
        this.getNotes();
    }

    getRefreshNotes() {
        this.getNotes();
        return new Promise((resolve) => {
            resolve(true);
          });
    }

    refreshHandler() {
        this.getNotes();
    }

    refreshNotes() {
        this.strIsExpanded = 'true';
        this.allNotesOpen = 'slds-is-open';
        this.template.querySelector('.show-all-notes').classList.add('slds-hide');
        this.template.querySelector('.hide-all-notes').classList.remove('slds-hide');
        this.getNotes();
    }

    getNotes = () => {
        if(this.label.HideContentNotesOnViewNotes_ACE !== undefined && this.label.HideContentNotesOnViewNotes_ACE!== null && this.label.HideContentNotesOnViewNotes_ACE.toLowerCase() === 'true') {
            return;
        }
        // hide / stop spinner
        this.boolSpinner = true;
        this.boolAPIError = false;

         //Fetch Note Data from Controller
         getContentDocuments({ idParent: this.recordId}).then(objResult => {
            if (objResult) {
                const objResponse = objResult;
                    const lstCaseIds = [this.recordId];
                    if(objResponse.lstChildNotesWrapper.length) {
                        lstCaseIds.push(...objResponse.lstChildNotesWrapper.map(el => el.objCase.Id));
                    }
                    if(objResponse.lstParentNotesWrapper.length) {
                        lstCaseIds.push(...objResponse.lstParentNotesWrapper.map(el => el.objCase.Id));
                    }
                    this.lstCaseIds = lstCaseIds;
                    this.objNotesWrapper = objResponse;
                    this.getCaseRelatedDetails();
            }
        }).catch(() => {
            this.boolSpinner = false;
            this.boolAPIError = true;
        });
    }

    getCaseRelatedDetails = () => {
            this.boolSpinner = true;
            //get case related Data from Controller
            fetchCaseRelatedDetailsRecordsMultiple({ lstCases: this.lstCaseIds}).then(objResult => {
            if (objResult) {
                let intTotalNotes = 0;
                const objResponse = objResult;
                const wrapper = this.objNotesWrapper;
                for(let key in wrapper) {
                    if(key.length && (key === 'lstChildNotesWrapper' || key === 'lstParentNotesWrapper')) {
                        wrapper[key].forEach(el => {
                            if(typeof objResponse && objResponse.hasOwnProperty(el.objCase.Id)) {
                                const tempId = el.objCase.Id;
                                el.relatedDetails = objResponse[tempId];
                            } else {
                                el.relatedDetails = 'no related records';
                            }
                        })
                    }
                }
                if(objResponse.hasOwnProperty(this.recordId)) {
                    this.lstRelatedDetails = objResponse[this.recordId];
                }

                if (wrapper.lstNotes.length > 0) {
                    this.boolCaseNotesAvailable = true;
                    intTotalNotes += wrapper.lstNotes.length;
                }

                if (wrapper.lstParentNotesWrapper.length > 0) {
                    this.boolParentCaseNotesAvailable = true;
                    wrapper.lstParentNotesWrapper.forEach(el => {
                        intTotalNotes += el.lstNotes.length;
                    });
                }

                if (wrapper.lstChildNotesWrapper.length > 0) {
                    this.boolChildCaseNotesAvailable = true;
                    wrapper.lstChildNotesWrapper.forEach(el => {
                        intTotalNotes += el.lstNotes.length;
                    });
                }
                this.intTotalNotes = intTotalNotes;
                this.intExpandedNotes = intTotalNotes;
                this.boolSpinner = false;
            }
        }).catch(() => {
            this.boolSpinner = false;
            this.boolAPIError = true;
        });
    }

    showAllNotes = (objEvent) =>{
        this.strIsExpanded = 'true';
        this.allNotesOpen = 'slds-is-open';
        //objEvent.currentTarget.classList.add('slds-hide');
        [...this.template.querySelectorAll('.slds-section')].forEach(el => {
            el.classList.add('slds-is-open');
            el.querySelector('button').setAttribute('aria-expanded', 'true');
        });
       // this.template.querySelectorAll('.slds-section').classList.add('slds-is-open');
        this.template.querySelector('.show-all-notes').classList.add('slds-hide');
        this.template.querySelector('.hide-all-notes').classList.remove('slds-hide');
        objEvent.currentTarget.nextElementSibling.classList.remove('slds-hide');
        this.intExpandedNotes = this.intTotalNotes;
    }

    hideAllNotes = (objEvent) =>{
        this.strIsExpanded = false;
        this.allNotesOpen = '';
        [...this.template.querySelectorAll('.slds-section')].forEach(el => {
            el.classList.remove('slds-is-open');
            el.querySelector('button').setAttribute('aria-expanded', 'false');
        });
       // this.template.querySelectorAll('.slds-section').classList.remove('slds-is-open');
        this.template.querySelector('.show-all-notes').classList.remove('slds-hide');
        this.template.querySelector('.hide-all-notes').classList.add('slds-hide');
        this.intExpandedNotes = 0;
    }

    expandCollapse = (objEvent) =>{ 
        const componentElm = objEvent.currentTarget;
        const totalNotes = this.intTotalNotes;
        let expandedNotes = this.intExpandedNotes;
        if (componentElm.getAttribute('aria-expanded') === 'true') {
            componentElm.setAttribute('aria-expanded', 'false');
            componentElm.closest('.slds-section').classList.remove('slds-is-open');
            if (expandedNotes) {
                expandedNotes--;
            }
        } else {
            componentElm.setAttribute('aria-expanded', 'true');
            componentElm.closest('.slds-section').classList.add('slds-is-open');
            if (expandedNotes !== totalNotes) {
                expandedNotes++;
            }
        }

        if (expandedNotes === totalNotes) {
            this.template.querySelector('.show-all-notes').classList.add('slds-hide');
            this.template.querySelector('.hide-all-notes').classList.remove('slds-hide');
        } else {
            this.template.querySelector('.show-all-notes').classList.remove('slds-hide');
            this.template.querySelector('.hide-all-notes').classList.add('slds-hide');
        }
        this.intExpandedNotes = expandedNotes;
    }


    openCaseTab = (objEvent) => {
        const strCaseId = objEvent.target.getAttribute('data-case-id');
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
            const objParsedTabData = JSON.parse(JSON.stringify(objTabData));
            var strUrl = BaseLWC.helperBaseEncodeUrl('/lightning/r/Case/' + strCaseId + '/view');
            let parentTabId;
            if (objParsedTabData.isSubtab) {
                parentTabId = objParsedTabData.parentTabId;
            } else {
                parentTabId = objParsedTabData.tabId;
            } 
                openSubtab(parentTabId, { url: strUrl,focus: true})
                    .then(() => {
                        //Do nothing
                    }).catch(() => {
                        //Do nothing
                    })
        }).catch(function() {
            //Do nothing
        });
    }
    }

    disconnectedCallback() {
        unregisterRefreshHandler(this.refreshHandlerNotes);
    }

}
