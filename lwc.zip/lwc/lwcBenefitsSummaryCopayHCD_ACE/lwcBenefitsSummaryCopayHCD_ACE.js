import { LightningElement, track, api} from 'lwc';

export default class LwcBenefitsSummaryCopayHCD extends LightningElement {
    
    @api mapBenefits = new Map();
    @track lstCopayData = [];

    strGenOffPCP = 'General Office/PCP Visit';
    strNonEmerER = 'Non-Emergency ER';
    strHosInp = 'Hospital/Inpatient';
    strPharmGen = 'Pharmacy Generic';
    strPharmBrand = 'Pharmacy Brand';

    connectedCallback() {

        this.lstCopayData = [
            {
                "strName": this.strGenOffPCP,
                "strCopayValue": this.mapBenefits.has(this.strGenOffPCP) ? this.mapBenefits.get(this.strGenOffPCP) : ''
            },
            {
                "strName": this.strNonEmerER,
                "strCopayValue": this.mapBenefits.has(this.strNonEmerER) ? this.mapBenefits.get(this.strNonEmerER) : ''
            },
            {
                "strName": this.strHosInp,
                "strCopayValue": this.mapBenefits.has(this.strHosInp) ? this.mapBenefits.get(this.strHosInp) : ''
            },
            {
                "strName": this.strPharmGen,
                "strCopayValue": this.mapBenefits.has(this.strPharmGen) ? this.mapBenefits.get(this.strPharmGen) : ''
            },
            {
                "strName": this.strPharmBrand,
                "strCopayValue": this.mapBenefits.has(this.strPharmBrand) ? this.mapBenefits.get(this.strPharmBrand) : ''
            }
        ];
    }

    
}