/****************************************************************************************************************
 * Author: U434605
 * Created on 9/1/2022
 **************************************************************************************************************** 
 *      Version             Date                Author                  Comments
 *      1                   9/1/2022            U434605                 Inital Version (CEAS-65432)
 *      2                   9/5/2022            U434605                 Added date validations (CEAS-65433)
 *      
 ****************************************************************************************************************/
 import { LightningElement, track, api, wire } from 'lwc';
 //CEAS-82941 Changes
 import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
 import ARCHIVEDRECORDSLABEL from '@salesforce/label/c.Archived_Records_Label_ACE';
 import STARTDATELABEL from '@salesforce/label/c.Start_Date_Label';
 import ENDDATELABEL from '@salesforce/label/c.ProducerSummary_Certifications_EndDateHover';
 import INSTRUCTIONSLABEL from '@salesforce/label/c.ArchivedRecordsInstructionsLabel_ACE';
 import DATERANGELABEL from '@salesforce/label/c.DateRangeNotMoreThan2Years_ACE';
 import STARTPRIORTOTODAY from '@salesforce/label/c.StartDatePriorToToday_ACE';
 import ENDPRIORTOTODAY from '@salesforce/label/c.EndDatePriorToToday_ACE';
 import STARTPRIORTOEND from '@salesforce/label/c.StartDatePriorToEndDate_ACE';
 import MESSAGEAPIERROR from '@salesforce/label/c.ArchivedRecordsAPIError_ACE';
 import MESSAGEWARNING from '@salesforce/label/c.ViewCaseSummary_NoCasesError_ACE';
 import NUMBEROFRECORDS from '@salesforce/label/c.ArchivedNumberOfRec_ACE';
 import BaseLWC from "c/baseLWCFunctions_CF";
 import fetchArchiveRecords from '@salesforce/apexContinuation/ArchivedRecords_ACE.fetchArchiveRecords';
 import CaseNotesModal_Refresh_ACE from '@salesforce/label/c.CaseNotesModal_Refresh_ACE';
 import CaseNotesModal_Notes_ACE from '@salesforce/label/c.CaseNotesModal_Notes_ACE';
 import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
 
 export default class LwcArchivedRecords_ACE extends LightningElement {
     //CEAS-82941 Changes
     @wire(EnclosingTabId) enclosingTabId;

     @track boolResetDisabled = true;
     @track boolViewResultsDisabled = true;
     @track strSDErrorMessage;
     @track strEDErrorMessage;
     @track boolDateValid = true;
 
      //Table Data
      @api lstArchivedRecords = [];
 
      @track boolError=false;
      @api boolAPIError = false;
      @track boolWarning = false;
      @track boolShowSpinner = false;

      @track boolShowCaseNotes = false;
      @track boolCaseNotesAvailable =  false;

      lstOwnNotes = {};
      boolShowWarning = false;
      @api boolRefreshModal = false;
 
      boolPlanSummaryData;
      subscriberId;
      PlanSummaryData;
      corporationCode;
      groupNumber;
      boolShowResultsTable = true
 
     
      objArchiveRecordsSetting = {
         pageSize: 25,
         showPagination : true,
         pageMenu : [25],
         boolViewMore: true,
         columnsData: [
             { label: 'INQUIRY NUMBER', fieldName: 'strInquiryNumber', sortable: true, type: '' },
             { label: 'DATE / TIME OPENED', fieldName: 'strTimeOpened', sortable: true, boolInitSort: true, boolAsc: false, type: '' },
             { label: 'INQUIRER NAME', fieldName: 'strInquirerName', sortable: true, type: '' },
             { label: 'SUBSCRIBER ID', fieldName: 'strSubscriberID', sortable: true, type: '' },
             { label: 'GROUP NUMBER', fieldName: 'strGroupNumber', sortable: true, type: '' },
             { label: 'TYPE/SUB-TYPE', fieldName: 'strSubType', sortable: true, type: '' },
             { label: 'STATUS', fieldName: 'strStatus', sortable: true, type: '' },
             { label: 'OWNER', fieldName: 'strOwnerId', sortable: true, type: '' },
             { label: 'ACTION', fieldName: 'strNotes', sortable: true, type: '' }
         ],
         boolShowFilter: true,
         boolPagination: true,
         boolShowSearch:true,
         searchPlaceholder : 'Search Text',
         filterData : [
             {strType : '', intCol : -1, strFilterName : 'Select a value'},
             {strType : 'text', intCol : 1, strFilterName : 'INQUIRY NUMBER'},
             {strType : 'date', intCol : 2, strFilterName : 'DATE / TIME OPENED'},
             {strType : 'text', intCol : 3, strFilterName : 'INQUIRER NAME'},
             {strType : 'text', intCol : 4, strFilterName : 'SUBSCRIBER ID'},
             {strType : 'text', intCol : 5, strFilterName : 'GROUP NUMBER'},
             {strType : 'text', intCol : 6, strFilterName : 'TYPE/SUB-TYPE'},
             {strType : 'text', intCol : 7, strFilterName : 'STATUS'},
             {strType : 'text', intCol : 8, strFilterName : 'OWNER'}
         ],
         boolShowCheckbox : false,
         boolShowHeader : false,
         boolShowSearchLabel: false,
         restrictedPageSize : false,
         boolPaginationwithSize:false
     };
 
 
     selectedStartDate;
     selectedEndDate;
     strPlanSummaryEvent = 'PlanSummaryEvent';
     objTabData;
 
     label = {
         ARCHIVEDRECORDSLABEL,
         STARTDATELABEL,
         ENDDATELABEL,
         INSTRUCTIONSLABEL,
         DATERANGELABEL,
         STARTPRIORTOTODAY,
         ENDPRIORTOTODAY,
         STARTPRIORTOEND,
         MESSAGEWARNING,
         MESSAGEAPIERROR,
         NUMBEROFRECORDS,
         CaseNotesModal_Notes_ACE,
         CaseNotesModal_Refresh_ACE,
         EnableVPSTabSpecificEvents_ACE
     };
 
     /**
      * Method fired when a date is seleced in Start Date field
      */
     onStartDateSelection(objEvent) {
         this.selectedStartDate = objEvent.detail;
         if(this.selectedStartDate === null) {
             this.showHideStartDateError('', false);
         }
         this.enableDisableResetButton();
         this.enableDisableResultsButton();
     }
 
     /**
      * Method fired when a date is selected in End Date field
      */
     onEndDateSelection(objEvent) {
         this.selectedEndDate = objEvent.detail;
         if(this.selectedEndDate === null) {
             this.showHideEndDateError('', false);
         }
         this.enableDisableResetButton();
         this.enableDisableResultsButton();
     }
 
     /**
      * Method to enable or disable the Reset button
      */
     enableDisableResetButton() {
         this.boolResetDisabled = !(this.selectedStartDate || this.selectedEndDate);
     }
 
     /**
      * Method to enable or disable the View Results button
      */
     enableDisableResultsButton() {
         const isDateValid=(strDate)=>{
             return strDate && strDate.match(/[0-9][0-9]\/[0-9][0-9]\/[0-9][0-9][0-9][0-9]/)!==null && new Date(strDate)!=='Invalid Date'
         }

         this.boolViewResultsDisabled = !(isDateValid(this.selectedStartDate) && isDateValid(this.selectedEndDate));
     }
 
     /**
      * Reset button handler
      */
     handleReset() {
         this.template.querySelectorAll("c-date-picker-slds").forEach(element => {
             element.clearDate();
         });
         this.boolResetDisabled = true;
         this.boolViewResultsDisabled = true;
         this.showHideEndDateError('', false);
         this.showHideStartDateError('', false);
         this.boolError = false;
     }
 
     connectedCallback()
     {
        //Always run this below function in Connected Callback.
       this.fetchTabData();
    }

    fetchTabData() {
       //CEAS-82941 Changes 
       if (this.enclosingTabId) {
        getTabInfo(this.enclosingTabId).then((tabInfo) => {
            this.objTabData = tabInfo;
            if (BaseLWC.stringIsNotBlank(this.label.EnableVPSTabSpecificEvents_ACE) && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                this.strPlanSummaryEvent = 'PlanSummaryEvent_' + this.objTabData.parentTabId;
            }
             this.planSummaryListener();
        }).catch((error) => {
            //Do nothing
        });
    }
   }
 
    /**
      * Method to listen the plan summary event
      */
     planSummaryListener() {
        window.addEventListener(
            this.strPlanSummaryEvent,
            this.capturePlanSummaryListener
        );
     }
 
     capturePlanSummaryListener = (planSummaryDataEvent) => {
        
         if (BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail) ) {             
             this.PlanSummaryData = JSON.parse(planSummaryDataEvent.detail);             
             if(this.PlanSummaryData.strIdDestination === 'PlanCardDetails_ACE' && this.PlanSummaryData.objParameters.strParentTabId === this.objTabData.parentTabId) {
                 this.boolPlanSummaryData = true;
                 this.subscriberId = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strSubscriberId;             
                 this.corporationCode = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strCorporationCode;
                 this.groupNumber = this.PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails.strGroupNumber;
                 window.removeEventListener(this.strPlanSummaryEvent,this.capturePlanSummaryListener);
             }            
         }
     };
 
     /**
      * View Results button handler
      */
     handleViewResults() {
         var todayDate = new Date();
         var startDate = new Date(this.selectedStartDate);
         var endDate = new Date(this.selectedEndDate);
         var dateDifferenceInDays = this.getDateDifference(startDate, endDate);
         this.boolError = false;
 
         this.showHideStartDateError('', false);
         this.showHideEndDateError('', false);
 
         if(startDate >= todayDate) {
             this.showHideStartDateError(this.label.STARTPRIORTOTODAY, true);
             this.boolError = true;
         }
 
         if(endDate >= todayDate) {
             this.showHideEndDateError(this.label.ENDPRIORTOTODAY, true);
             this.boolError = true;
         }
 
         if(dateDifferenceInDays < 0) {
             this.showHideStartDateError(this.label.STARTPRIORTOEND, true);
             this.boolError = true;
         }
 
         if(dateDifferenceInDays > 730) {
             this.showHideEndDateError(this.label.DATERANGELABEL, true);
             this.boolError = true;
         }
         if(this.boolError === false){
             this.fetchArchivedData();
         }
         
     }
 
 
   /**
      * Method to call the Archived Records API and to get the response
      */
     fetchArchivedData() {
           var startDateObj = this.convertDate(this.selectedStartDate);
           var endDateObj = this.convertDate(this.selectedEndDate);
           this.boolShowSpinner = true;
           this.boolShowResultsTable = false;
            const jasonreqbody = '{ "subscriberId": "'+this.subscriberId + '", "groupNumber": "'+this.groupNumber + '",' + '"startDate": "' + startDateObj + '","endDate": "' + endDateObj + '","corpCode": "' + this.corporationCode + '","numberOfRecords": "'+this.label.NUMBEROFRECORDS+'"}';
             fetchArchiveRecords({
                 strRequestBody: jasonreqbody
             }).then(objResult => {
                     this.boolShowSpinner = false;
                     this.boolShowResultsTable = true;
                     this.boolAPIError = false;
                     this.boolWarning = false;
                     var objArchivedRec = JSON.parse(objResult);
                     this.lstArchivedRecords = this.formatData(objArchivedRec.lstCaseHistory);
                     if (objArchivedRec.strNumberOfRecords=="0")
                     {
                         this.boolWarning = true;
                     }
                     
             }).catch(error => {
                 this.boolShowSpinner = false;
                 this.boolShowResultsTable = true;
                 this.handleAPIErrors(error);
             });
 
     }
 
 
      /**
      * Method to handle the View Note link
      */
     formatData(objData) {
         for (let i = 0; i < objData.length; i++){
            const strViewNote = `<a data-inquiryNumber="${objData[i].strInquiryNumber}" href='javascript:void(0);'>View Notes</a>`;
            if(objData[i]['strNotes']==null){
                objData[i]['strNotes']="";
            }
            objData[i].strNotes = {wrapper: strViewNote,
                                    value: objData[i]['strNotes'],
                                    strIsAceRecord:objData[i]['strIsAceRecord']
                                };

            objData[i].strSubType =  objData[i].strType +' - '+ objData[i].strSubType;
            objData[i].strTimeOpened = this.convertDateFormat(objData[i].strTimeOpened);
         }
 
         return objData;
     }
    
     /**
      * Method to handle th api errors
      */
     handleAPIErrors(error) {
         this.boolAPIError = true;
     }
 
     convertDateFormat(dateObj)
     {
        const dateTimeArray = dateObj.split(" ");
        var strDate = dateTimeArray[0].toString()
        var strDateSplit =strDate.split("-");
        var finalDate = strDateSplit[1]+"/"+strDateSplit[2]+"/"+strDateSplit[0]

        var strTime = dateTimeArray[1].toString()
        var timeSplit = strTime.split(".");
        var actualTimeSplit = timeSplit[0].toString().split(":");
        var timeAmPm = timeSplit[0].toString();
        if(Number(actualTimeSplit[0])<=12)
                timeAmPm = timeAmPm + ' ' + 'AM';
        else{
         var convertTime = Number(actualTimeSplit[0])-12;
         if(convertTime<10)
             convertTime = "0"+convertTime
         
         timeAmPm = convertTime + ':' + actualTimeSplit[1] + ':' + actualTimeSplit[2]  + ' ' + 'PM';
        }          
        var finalDateTime = finalDate+' '+timeAmPm;
        return finalDateTime;
     }
 
     /**
      * Method to convert Start date and End date in requested format
      */
     convertDate(dateObj)
     {
         const dateArray = dateObj.split("/");
         var finalDate = dateArray[2]+'-'+ dateArray[0]+'-'+  dateArray[1]
         return finalDate;
     }
 
     /**
      * Method to get the difference between the End Date and Start Date
      */
     getDateDifference(startDate, endDate) {
         return (endDate - startDate) / (1000 * 3600 * 24);
     }
 
     /**
      * Method to show or hide the error message for Start Date field
      */
     showHideStartDateError(errMessage, boolShowError) {
         if(boolShowError) {
             this.strSDErrorMessage = errMessage;
             this.template.querySelector('.idStartDateError').classList.remove('slds-hide');
         } else {
             this.template.querySelector('.idStartDateError').classList.add('slds-hide');
             this.strSDErrorMessage = '';
         }
     }
 
     /**
      * Method to show or hide the error message for End Date field
      */
     showHideEndDateError(errMessage, boolShowError) {
         if(boolShowError) {
             this.strEDErrorMessage = errMessage;
             this.template.querySelector('.idEndDateError').classList.remove('slds-hide');
         } else {
             this.template.querySelector('.idEndDateError').classList.add('slds-hide');
             this.strEDErrorMessage = '';
         }
     }
 
     /**
      * Event handler when there is a date format error in datePickerSlds child component
      */
     handleFormatError(objEvent) {
         this.boolDateValid = objEvent.detail;
         this.enableDisableResultsButton();
     }
      /**
     * Action for Table ViewResults column'
     */
    handleRowAction(objEvent)
    {
        const objEventData = JSON.parse(objEvent.detail);
        if(objEventData.activeColumnData && objEventData.activeColumnData.key==='strNotes'){ 

                this.boolShowCaseNotes = true;
                this.boolCaseNotesAvailable =  true;
                this.boolShowWarning = false;
                
                const rowData = JSON.parse(JSON.parse(objEvent.detail).renderedRowData);

                this.activeCaseNumber = rowData[0].value;
                this.caseTypeCategory ='Single';
                var strTypeSubtype = rowData[5].value;
                let arrTypeSubtype = strTypeSubtype.split("-");
                this.caseType = arrTypeSubtype[0];
                this.caseSubType = arrTypeSubtype[1];
                
            var strResNotes =  rowData[8].value;
            var strIsAceRecord =  rowData[8].value.strIsAceRecord;
            if(!strResNotes) {
                this.boolShowWarning = true;
            }
            else if(strIsAceRecord.toUpperCase() === 'TRUE')
            {
                var splitNotes = strResNotes.value.split("|");
                let createdDate = splitNotes[0];
                createdDate = this.formatNoteDate(createdDate);
                let createdByName = splitNotes[1];
                let title = splitNotes[2];
                let content = splitNotes[3];
                
                this.lstOwnNotes = [
                    {"Content" : content,
                    "CreatedByName" :createdByName,
                    "LastModifiedDate" : createdDate,
                    "Title" : title}];
            }
            else
            {
                this.boolSiebelRecordNote = true;
                let content = strResNotes.value;
                this.lstOwnNotes = [
                    {"Content" : content}];
            }
        }
    }
    
    /**
     * Closes Modal
     */
    closeModal()
    {
        this.boolShowCaseNotes=false;
    }

    /**
     * Method used to refresh the card
     */
    refreshRecords()
    {
        try {
            if(!this.boolViewResultsDisabled) {
                this.fetchArchivedData();
            }
        } catch (error) {
            //Do nothing
           
        }
    }

     /**
     * Method to format response Note date
     */
    formatNoteDate(noteDateObj)
    {
        const noteDate = new Date(noteDateObj);

        var date = noteDate.getDate();
        if(date<10)
            date="0"+date;

        var month = noteDate.getMonth();
        month=month+1;
        if(month<10)
            month="0" + month;
        const year = noteDate.getFullYear();

        var hrs = noteDate.getHours();
        if(hrs<10)
        hrs = '0'+hrs;

        var minutes = noteDate.getMinutes();
        if(minutes<10)
            minutes = '0'+minutes;

        var sec = noteDate.getSeconds();
        if(sec<10)
            sec = '0'+sec

        var timeAmPm;
            if(Number(hrs)<=12)
                    timeAmPm = hrs+':'+minutes+':'+sec+ ' AM';
            else{
                var convertTime = Number(hrs)-12;
                if(convertTime<10)
                    convertTime = '0'+convertTime
                timeAmPm=convertTime+':'+minutes+':'+sec+ ' PM';
            }
        var finalDateTime=  month +'/'+ date +'/'+ year +' '+timeAmPm
        return finalDateTime;

    }
 
 }