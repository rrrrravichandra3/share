import { LightningElement,api, wire } from 'lwc';
//import platformWorkspaceApi
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
import BaseLWC from 'c/baseLWCFunctions_CF';
import deleteAuthorizedParty from '@salesforce/apex/CreateStandardAuthController_ACE.deleteAuthorizedParty';
import {publish,MessageContext} from 'lightning/messageService';
import bridgeHelper from '@salesforce/messageChannel/LWCAuraVFBridgeHelper__c';
import RemoveLegacy_Description_ACE from '@salesforce/label/c.RemoveLegacyModal_Description_ACE';
import ViewAuthorizedParty_EffectiveDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_EffectiveDate_ACE';
import ViewAuthorizedParty_ExpirationDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_ExpirationDate_ACE';
import ViewStandardAuthorization_Success_ACE from '@salesforce/label/c.ViewStandardAuthorization_Success_ACE';

export default class LwcRemoveLegacyComponentAce extends LightningElement {
    label = {  
        RemoveLegacy_Description_ACE,
        ViewAuthorizedParty_EffectiveDate_ACE,
        ViewAuthorizedParty_ExpirationDate_ACE,
        ViewStandardAuthorization_Success_ACE
    }

    //Used to store Legacy Id
    @api strLegacyId;  
    //Used to store Auth Desc
    @api strAuthPerson  
    //Used to store Effective Date
    @api strEffectiveDateFormat; 
    //Used to store Expiration Date       
    @api strExpirationDateFormat;
    //Used to Open De-activate Modal box
    @api boolOpenRemoveModal;
       
    boolSpinner;
    objCardError = {};
    boolSuccesOfRemoveLegacyModal;  //Used to Open De-activate Modal box
    strMid;

    //wire
    @wire(MessageContext) 
    messageContext;
    @wire(EnclosingTabId) enclosingTabId;
    
    connectedCallback() {
        this.fetchTabData();
    }

    /**
     * To handle Errors.
     * Helps to show case errors.
     * All components should have this code.
     */
    handleErrors = (error) => {
        this.objCardError = error;
    };

    fetchTabData() {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
                this.objTabData = objTabData; 
                this.strMid = BaseLWC.helperBaseGetUrlParameters('mid',this.objTabData.url);
            })
            .catch((exception) => {
                this.handleErrors(exception);
            });
    }
}

    closeModal() {
        this.closeModalEvent();
        this.boolOpenRemoveModal=false;
    }
    closeModalEvent() {
        const caseCloseModal = new CustomEvent('closelegacymodalevent', {
            detail: { boolOpenRemoveModal: false }
        });
        this.dispatchEvent(caseCloseModal);
    }
    goAndRemove(){
        this.boolSpinner = true;
        deleteAuthorizedParty({ 'strRecordId': this.strLegacyId })
        .then((result) => {
           try {
                if (result !== null && result === 'Success') {
                    this.boolSuccesOfRemoveLegacyModal = true;
                    const key = 'removeAuthParty_' + this.strMid;
                    const keyForUpdate = 'UpdateForremoveAuthParty_' + this.strMid;
                    const removeAuthPartyValues = {
                        key: key,
                        value: result
                    };
                    const removeAuthPartyValuesUpdate = {
                        key: keyForUpdate,
                        value: result
                    };
                    this.postMessageHelper(removeAuthPartyValues, true, false, 'setLocalStorageViaIframe');
                    this.postMessageHelper(removeAuthPartyValuesUpdate, true, false, 'setLocalStorageViaIframe');
                }
                this.boolSpinner = false;
            } catch (exception) {
                //No handling Needed.
                this.boolSpinner = false;
            }
           
        })
        .catch((exception) => {
            this.handleErrors(exception);
        });
    }

    postMessageHelper(objDataToBeSent, boolLocalStorage, boolPostMessage, strDestinationId) {
        try {
            const objParameterData = {
                strDestinationId: strDestinationId,
                objMessage: objDataToBeSent
            };
            const objPayload = {
                bridgeMessageData: objParameterData
            };
            if(this.messageContext !== undefined && this.messageContext !== null){
                publish(this.messageContext, bridgeHelper, objPayload);
            }
        } catch (exception) {
            this.handleErrors(exception);
        }
    
    }
}