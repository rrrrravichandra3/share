/**
 * @author Adwait Gupta.
 */

import { LightningElement, api, track, wire } from 'lwc';
import { getPicklistValues, getObjectInfo } from 'lightning/uiObjectInfoApi';
import AssignedAdvocateRecord_ACE_Object from '@salesforce/schema/AssignedAdvocateRecord_ACE__c';
import ChangeReason_ACE_Field from '@salesforce/schema/AssignedAdvocateRecord_ACE__c.ChangeReason_ACE__c';

//Import Apex class.
import reassignAdvocateRecord from '@salesforce/apex/ManageAssignedAdvocateController_ACE.reassignAdvocateRecord';
import removeAdvocateRecord from '@salesforce/apex/ManageAssignedAdvocateController_ACE.removeAdvocateRecord';

//Import Shared JS files.
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';

const STATUS_TYPE = {
    SUCCESS: 'success',
    ERROR: 'error'
};

const ACTIONS_TYPE = {
    REMOVE: 'Remove',
    REASSIGN: 'Reassign'
};

export default class MaintainAssignAdvocateActionModal extends LightningElement {

    @api listOfRecords;
    @api action;
    
    @track reasonOptions = [];
    @track fieldValues = {
        'EmployeeID': '',
        'Reason': ''
    };

    disableSubmit = true;
    heading = '';
    submitLabel = '';
    boolShowEmployeeIDField = false;
    alertType = '';
    alertMessage = '';
    boolIsError = false;
    boolIsSuccess = false;

    setAlert = {
        error: msg => {
            this.alertType = STATUS_TYPE.ERROR;
            this.alertMessage = msg;
            this.boolIsError = true;
            this.boolIsSuccess = false;
        },
        success: msg => {
            this.alertType = STATUS_TYPE.SUCCESS;
            this.alertMessage = msg;
            this.boolIsSuccess = true;
            this.boolIsError = false;
        },
        reset: () => {
            this.alertType = '';
            this.alertMessage = '';
            this.boolIsError = false;
            this.boolIsSuccess = false;
        }
    }

    /* Get Object Info for AssignedAdvocateRecord_ACE__c Object */
    @wire(getObjectInfo, {objectApiName: AssignedAdvocateRecord_ACE_Object})
    assignedAdvocateRecord_ACE_ObjectInfo;

    /* Get the value of Picklist Values for ChangeReason_ACE__c Field of AssignedAdvocateRecord_ACE__c Object */
    @wire(getPicklistValues, {
        recordTypeId: '$assignedAdvocateRecord_ACE_ObjectInfo.data.defaultRecordTypeId',
        fieldApiName: ChangeReason_ACE_Field
    })
    function ({
        error,
        data
    }) {
        if (data && data.values) {

            this.setAlert.reset();

            const picklistValuesList = [];

            for(const picklistValue of data.values) {
                if(picklistValue.label !== 'New Assignment') {
                    picklistValuesList.push({
                        label: picklistValue.label || null,
                        value: picklistValue.value || null
                    });
                } else {
                    //do nothing
                }
            }

            this.reasonOptions = picklistValuesList;
        } else if (error) {

            this.setAlert.error(error);
        } else {
            /*Do nothing */
        }
    }

    connectedCallback() {
        this.initializeForm();
    }

    initializeForm() {

        const noOfRecords = this.listOfRecords.length;
        
        if (noOfRecords > 0) {
            switch (this.action) {
                case ACTIONS_TYPE.REMOVE:
                    this.heading = `Are you sure want to remove (${noOfRecords}) assignment(s)?`;
                    this.submitLabel = `Remove`;
                    break;
                case ACTIONS_TYPE.REASSIGN:
                    this.boolShowEmployeeIDField = true;
                    this.heading = `Please enter the Employee ID that the (${noOfRecords}) selected subscriber(s) should be re-assigned to`;
                    this.submitLabel = `Reassign`;
                    break;
                default:
                    break;
            }
        } else {
            //do nothing
        }
    }

    handleChange(event) {
        const {name, value} = event.target;

        if(BaseLWC.stringIsNotBlank(value)) {
            this.fieldValues[name] = value;
        } else {
            this.fieldValues[name] = '';
        }
        
        this.validateFields();
    }

    validateFields() {
        if(this.action === ACTIONS_TYPE.REASSIGN) {
            if(!BaseLWC.stringIsNotBlank(this.fieldValues['EmployeeID'])) {
                this.disableSubmit = true;
                return;
            } else {
                //do nothing
            }
        } else {
            //do nothing
        }

        if(!BaseLWC.stringIsNotBlank(this.fieldValues['Reason'])) {
            this.disableSubmit = true;
            return;
        } else {
            //do nothing
        }

        this.disableSubmit = false;
    }

    handleCancel() {
        
        this.setAlert.reset();
        this.disableSubmit = true;
        this.fieldValues = {
            'EmployeeID': '',
            'Reason': ''
        };
        
        BaseLWC.fireNativeCustomEvent('close', {}, this);
    }
    
    closeModal(event) {
        this.handleCancel(event);
    }

    handleSubmit() {
        this.disableSubmit = true;
        if(this.action === ACTIONS_TYPE.REASSIGN) {
            this.handleReassignAdvocateRecord();
        } else if(this.action === ACTIONS_TYPE.REMOVE) {
            this.handleRemoveAdvocateRecord();
        } else {
            //do nothing
        }
    }

    handleReassignAdvocateRecord() {
        reassignAdvocateRecord({
            listOfRecordIds: this.listOfRecords,
            methodData: {
                employeeId: this.fieldValues.EmployeeID,
                reason: this.fieldValues.Reason
            }
        }).then(objResult => {
            if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                if(objResult.status === STATUS_TYPE.SUCCESS) {
                    this.setAlert.success(objResult.message);
                    BaseLWC.fireNativeCustomEvent(STATUS_TYPE.SUCCESS, {
                        type: ACTIONS_TYPE.REASSIGN,
                        data: {
                            employeeId: this.fieldValues.EmployeeID.toUpperCase()
                        }
                    }, this);
                } else if(objResult.status === STATUS_TYPE.ERROR) {
                    this.setAlert.error(objResult.message);
                } else {
                    //do nothing
                }
            } else {
                //do nothing
            }
        });
    }

    handleRemoveAdvocateRecord() {
        removeAdvocateRecord({
            listOfRecordIds: this.listOfRecords,
            methodData: {
                reason: this.fieldValues.Reason
            }
        }).then(objResult => {
            if (BaseLWC.isNotUndefinedOrNull(objResult)) {

                if(objResult.status === STATUS_TYPE.SUCCESS) {
                    this.setAlert.success(objResult.message);
                    BaseLWC.fireNativeCustomEvent(STATUS_TYPE.SUCCESS, {
                        type: ACTIONS_TYPE.REMOVE,
                        data: {}
                    }, this);
                } else if(objResult.status === STATUS_TYPE.ERROR) {
                    this.setAlert.error(objResult.message);
                } else {
                    //do nothing
                }
            } else {
                //do nothing
            }
        });
    }
}