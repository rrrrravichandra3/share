import { LightningElement} from 'lwc';

export default class LwcEligibilityAndMemberNotesACE extends LightningElement {
 

}