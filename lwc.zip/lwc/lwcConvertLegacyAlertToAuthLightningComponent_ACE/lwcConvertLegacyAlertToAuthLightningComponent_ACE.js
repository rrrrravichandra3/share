import { api, LightningElement } from 'lwc';
import createLegacyAuthorizationApexMethod from '@salesforce/apex/LegacyModalController_ACE.createLegacyAuthorization';
// Importing Custome Labels
import RemoveLegacyModal_Description_ACE from '@salesforce/label/c.RemoveLegacyModal_Description_ACE';
import RemoveLegacyModal_EffectiveDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_EffectiveDate_ACE';
import RemoveLegacyModal_ExpirationDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_ExpirationDate_ACE';
import ViewStandardAuthorization_Success_ACE from '@salesforce/label/c.ViewStandardAuthorization_Success_ACE';
import RemoveLegacyModal_SuccessMessage_ACE from '@salesforce/label/c.RemoveLegacyModal_SuccessMessage_ACE';
export default class LwcConvertLegacyAlertToAuthLightningComponentACE extends LightningElement {
    Label={
        RemoveLegacyModal_Description_ACE,
        RemoveLegacyModal_EffectiveDate_ACE,
        RemoveLegacyModal_ExpirationDate_ACE,
        ViewStandardAuthorization_Success_ACE,
        RemoveLegacyModal_SuccessMessage_ACE
    }

    //Attributes from parent component
    @api boolModalIsOpen;
    @api boolRefreshIframe;
    @api boolShowNtfType;
    @api strSelectedNotificationType;
    @api strClientMemberId;
    @api strSubscriberId;
    @api strGroupNumber;
    @api strCorporationCode;
    @api objRecordData;

    boolShowToastMessage=false;

    //function to close model-popup
    closeModal() {
        const closeModalEvent =new CustomEvent('closemodalevent',{
            detail:'close'
        });
        this.dispatchEvent(closeModalEvent);
    }

    //function after clicking back button
    back() {
        const backModalEvent =new CustomEvent('backmodalevent',{
            detail:'back'
        });
        this.dispatchEvent(backModalEvent);
    }

    // function to conert the legacy
    convertAuthorization() {
        let objRecord = JSON.stringify(this.objRecordData);
        objRecord=JSON.parse(objRecord);
        if (objRecord.datStartDate!==null && objRecord.datStartDate!==undefined && objRecord.datStartDate !== 'Invalid Date' && objRecord.datStartDate !== 'N/A') {
            objRecord.datStartDate = this.formatDate(objRecord.datStartDate);
        } else if (objRecord.datStartDate === 'Invalid Date' || objRecord.datStartDate === 'N/A') {
            objRecord.datStartDate = null;
        } else {
            // Do Nothing
        }
        if (objRecord.datEndDate!==null && objRecord.datEndDate!==undefined && objRecord.datEndDate !== 'Invalid Date' && objRecord.datEndDate !== 'N/A') {
            objRecord.datEndDate = this.formatDate(objRecord.datEndDate);
        } else if (objRecord.datEndDate === 'Invalid Date' || objRecord.datEndDate === 'N/A') {
            objRecord.datEndDate = null;
        } else {
            // Do Nothing
        }
        //Apex Method to Convert Legacy Authorizations
        createLegacyAuthorizationApexMethod({
            'strLegacyAlertRecord': JSON.stringify(objRecord),
            'strMemberId': this.strClientMemberId,
            'strSubscriberId': this.strSubscriberId,
            'strGroupNumber': this.strGroupNumber,
            'strCorpCode': this.strCorporationCode
        }).then(() => {
            this.fireToastMessageContent();
        })
        .catch(() => {
            // do nothing
        });

    }

    //method to fire toast success message
    fireToastMessageContent() {
        this.boolShowToastMessage=true;
        const refreshModalEvent =new CustomEvent('refreshmodalevent',{
            detail:'refresh'
        });
        this.dispatchEvent(refreshModalEvent);
    }
    // function to format the date to 'YYYY-MM-DD'
    formatDate(strUnformatedDate) {
        if(strUnformatedDate !== null && strUnformatedDate !== undefined && strUnformatedDate!== '') {
            const objDateTime = new Date(strUnformatedDate);
            let intMonth = objDateTime.getMonth() + 1;
            let intDay = objDateTime.getDate();
            const intYear = objDateTime.getFullYear();
            if (intMonth < 10) {
                intMonth = "0" + intMonth;
            }
            if (intDay < 10) {
                intDay = "0" + intDay;
            }
            return intYear + "-" + intMonth + "-" + intDay;
        }
        return null;
    }

}