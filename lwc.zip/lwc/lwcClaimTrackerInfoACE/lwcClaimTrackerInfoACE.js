import { LightningElement, api, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { EnclosingTabId, getTabInfo, openSubtab, setTabLabel } from 'lightning/platformWorkspaceApi';
import findClaimTrackerInfos from '@salesforce/apex/CaseRelatedTableController_ACE.getClaimTrackerInfos';

export default class LwcClaimTrackerInfoACE extends NavigationMixin(LightningElement) {
    @wire(EnclosingTabId) enclosingTabId;
    @api recordId;
    @api boolDetailView;

    lstTableData = [];
    boolViewMore = false;
    boolShowData = false;
    parentTabId = null;
    objTabData = null;
    value = '25';

    columns = [
        { label: 'CLAIM/DCN', fieldName: 'ClaimDCNNumber_ACE__c', sortable: false, type: '' },
        { label: 'ADJ', fieldName: 'AdjustmentNumber_ACE__c', sortable: false, type: '' },
        { label: 'DENIAL', fieldName: 'Denial_ACE__c', sortable: false, type: '' },
        { label: 'CHANGE', fieldName: 'ChangeTo_ACE__c', sortable: false, type: '' },
        { label: 'SERVICE LINE', fieldName: 'Serviceline_ACE__c', sortable: false, type: '' },
        { label: 'STATUS', fieldName: 'Status_ACE__c', sortable: false, type: '' }
    ];

    objInitTableSettings = {
        pageSize: 5,
        boolViewMore: false,
        columnsData: this.columns,
        boolShowFilter: false,
        boolSecondaryTable: false,
        boolShowSearch: false
    };

    get options() {
        return [
            { label: '25', value: '25' },
            { label: '50', value: '50' },
            { label: '100', value: '100' },
        ];
    }

    set options(value) {
        this.options = value;
    }

    handleChange(event) {
        this.value = event.detail.value;
        this.objInitTableSettings.pageSize = parseInt(this.value, 10);
        this.refreshComponent();
    }

    fetchData() {
        findClaimTrackerInfos({ strCaseRecordId: this.recordId }).then(data => {
            if (data) {
                if (data.length > 5 && !this.boolDetailView) {
                    this.lstTableData = data.slice(0, 5);
                    this.boolViewMore = true;
                } else {
                    this.objInitTableSettings.pageSize = this.value;
                    this.lstTableData = data
                }
                this.boolShowData = true;

            } else {
                this.boolShowData = false;
            }
        });
    }

    connectedCallback() {
        this.fetchTabData();
    }

    fetchTabData() {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objTabData => {
                this.parentTabId = objTabData.parentTabId;
                if (!this.recordId && objTabData.pageReference.state.c__BaseURLParam) {
                    this.recordId = window.atob(objTabData.pageReference.state.c__BaseURLParam);
                }
                this.fetchData();
            });
        }

    }

    refreshComponent() {
        this.boolShowData = false;
        this.fetchData();
    }

    viewAllClaimTrackerInfos() {
        // Navigate to the Task object's Open Tasks view.
        const strEncodedParams = window.btoa(unescape(encodeURIComponent(this.recordId)));
        const objPageReference = {
            "type": "standard__navItemPage",
            "attributes": {
                "apiName": "ViewOpenClaimTrackerFlexipg_ACE"
            },
            "state": {
                "c__BaseURLParam": strEncodedParams
            }
        };
        openSubtab(this.parentTabId, {pageReference: objPageReference, focus: true}).then((response) => {
            setTabLabel(response, "Claim Tracker Info");
        });
    }

}