import {LightningElement , api , track,wire} from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
import service_line from '@salesforce/label/c.ViewMedicalDetails_ServiceLine_ACE';
import view_medical_claim_detail from '@salesforce/label/c.ViewMedicalDetails_Claims_ACE';
import view_service_line_summary from '@salesforce/label/c.ViewMedicalDetails_ServiceLineSummary_ACE';
import checkIfAnyCasesAreOpen from '@salesforce/apex/NewCaseCheckClass_ACE.checkIfAnyCasesAreOpen';
import { openSubtab} from 'lightning/platformWorkspaceApi';
//CEAS-83660
import NotepadTransmissionChannel_ACE from '@salesforce/messageChannel/NotepadTransmissionChannel__c';
import {
    MessageContext,
    publish,
} from 'lightning/messageService';

export default class ClaimsServiceLineInformation_ACE extends LightningElement {
    serviceFromDate;
    NotepadTransmissionChannel = NotepadTransmissionChannel_ACE;
    @wire(MessageContext)
    messageContext;
    @track serviceLineInformation;
    @api serviceColumns;
    @api strDcnNumber;
    nestedColSpan;
    @track isDisabled;
    intServiceLineIndex;
    @track showCodeCheckModal = false;
    codeCheckArr = [];
    @api strUrlCorpCode;
    strClaimId;
    strAccountNum;
    strPrtTabId;
    strNotepadNotes;
    //CEAS-80678
    @track showOtherInsuranceModal = false;
    @track strLOB1;
    @track boolAutoDoc;
    @track otherInsuraceInformation;
    @track corpCode1;
    @api
    get otherInsuranceInfo() {
        return this.otherInsuraceInformation;
    }
    set otherInsuranceInfo(value) {
        if (value) {
            this.otherInsuraceInformation = this.deepCloneMap(value);
        }
    }
    @api
    get boolHideAutoDoc() {
        return this.boolAutoDoc;
    }

    set boolHideAutoDoc(value) {
            this.boolAutoDoc = value;
    }
    @api
    get strLineOfBusiness() {
        return this.strLOB1;
    }
    set strLineOfBusiness(value) {
        if (value) {
            this.strLOB1 = value;
        }
    }
    @api
    get strCorpCode() {
        return this.corpCode1;
    }
    set strCorpCode(value) {
        if (value) {
            this.corpCode1 = value;
        }
    }
    get showOtherInsuranceInfo(){
        if(this.strLOB1 && this.strLOB1.toUpperCase() === 'GOVERNMENT-MEDICAID'){
            if(this.corpCode1 && this.corpCode1 === 'NM1'){
                return true;
            }else{
                return false;
            }
        }else{
            if(this.strLOB1 && (this.strLOB1.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL' || this.strLOB1.toUpperCase() === 'GMS' || this.strLOB1.toUpperCase() === 'RETAIL')){
                return true;
            }else{
                return false;
            }
        }
    }
    @api 
    get serviceLineInfo() {
        return this.serviceLineInformation;
    }

    set serviceLineInfo(value) {
        if (value) {
            this.serviceLineInformation = this.deepCloneMap(value);
        }
    }
    @api 
    get strUrlClaimId() {
        return this.strClaimId;
    }

    set strUrlClaimId(value) {
        if (value) {
            this.strClaimId = value;
        }
    }
    @api 
    get strAccountId() {
        return this.strAccountNum;
    }

    set strAccountId(value) {
        if (value) {
            this.strAccountNum = value;
        }
    }
    @api 
    get strParentTabId() {
        return this.strPrtTabId;
    }

    set strParentTabId(value) {
        if (value) {
            this.strPrtTabId = value;
        }
    }
    deepCloneMap = (obj) => {
        let Val;
        if (typeof obj == 'number' || typeof obj == 'string' || typeof obj == 'undefined') {
            Val = obj;
        } else if (obj instanceof Map) {
            Val = new Map();
            for (const [key, value] of obj.entries()) {
                Val.set(key, this.deepCloneMap(value));
            }
        } else if (Array.isArray(obj)) {
            Val = obj.map(el => {
                return this.deepCloneMap(el);
            });
        } else {
            Val = JSON.parse(JSON.stringify(obj));
        }
        return Val;
    }
    @api strClaimNumber;
    @api strUrlAdjNumber;
    @track strMemId;
    @track grpNumber;
    @track strCmid;
    @track strInteractionId
    @api boolIsInternalInteraction;
    @api strCaseRecordTypeId;
    @api 
    get strInteractionLogId() {
        return this.strInteractionId;
    }

    set strInteractionLogId(value) {
        if (value) {
            this.strInteractionId = value;
        }
    }
    @api 
    get strMemeberId() {
        return this.strMemId;
    }

    set strMemeberId(value) {
        if (value) {
            this.strMemId = value;
        }
    }
    @api 
    get groupNumber() {
        return this.grpNumber;
    }

    set groupNumber(value) {
        if (value) {
            this.grpNumber = value;
        }
    }
    @api 
    get strCMID() {
        return this.strCmid;
    }

    set strCMID(value) {
        if (value) {
            this.strCmid = value;
        }
    }
    connectedCallback() {
        this.nestedColSpan = this.serviceColumns.length + 2;
    }

    handleShowNested(ev) {
        if (ev.currentTarget.classList.contains('expanded')) {
            ev.currentTarget.closest('tr').nextElementSibling.setAttribute('data-expanded', 'innerTable collapsed');
            ev.currentTarget.closest('tr').nextElementSibling.classList.remove('expanded');
        } else {
            ev.currentTarget.closest('tr').nextElementSibling.setAttribute('data-expanded', 'innerTable expanded');
            ev.currentTarget.closest('tr').nextElementSibling.classList.add('expanded');
        }
        ev.currentTarget.classList.toggle('expanded');
    }
    handleSort(ev) {
        const objTarget = ev.currentTarget;
        let intCol = objTarget.getAttribute('data-col');

        let isAsc = objTarget.querySelector(".upArrow").getAttribute('data-isascending');
        //Make the boolean opposite of previous self to activate click
        if (isAsc === '' || isAsc === 'true') {
            isAsc = 'false';
        } else {
            isAsc = 'true';
        }
        let isAscBool;
        [...objTarget.parentElement.querySelectorAll('.sortIcon')].forEach((el) => {
            el.setAttribute('data-isascending', '');
        });
        if (isAsc === "false") {
            objTarget.querySelector(".downArrow").setAttribute('data-isascending', 'false');
            objTarget.querySelector(".upArrow").setAttribute('data-isascending', 'false');
            isAscBool = false;
        } else {
            objTarget.querySelector(".downArrow").setAttribute('data-isascending', 'true');
            objTarget.querySelector(".upArrow").setAttribute('data-isascending', 'true');
            isAscBool = true;
        }
        const objParams = {
            isAsc: isAscBool,
            intCol: intCol
        };
        BaseLWC.fireNativeCustomEvent('sortservices', objParams, this);
    }
    handleAutoDoc(event) {
        let strNotepadNotes = '';
        let index = event.currentTarget.getAttribute('data-index');
        if (index === null || index === undefined || isNaN(index)) {
            return;
        }
        index = Number(index);
        const objRowData = this.serviceLineInformation[index];
        if (!this.boolHideAutoDoc && this.strInteractionLogId !== '' && !BaseLWC.isUndefinedOrNullOrBlank(this.strUrlAdjNumber) && !BaseLWC.isUndefinedOrNullOrBlank(this.strClaimNumber)) {
            this.getCurrentOpenCases();
        }
        const lstValuesData = [];
        const TotalPattern = [];
        const lstSectionsData = [];
        const objPattern = {
            strInteractionLogId: this.strInteractionLogId
        };
        const strServiceLine = ' DCN NUMBER - ' + ' ' + this.strDcnNumber + ' - ' + this.strUrlAdjNumber;
        const strServiceLineSequence = service_line + ' ' + (Number(objRowData["defaultSortedValue"]) + 1);
        const lstServiceLineData = [view_medical_claim_detail, strServiceLine, 'SERVICE LINE SUMMARY', strServiceLineSequence];
        
        for (let i = 0; i < lstServiceLineData.length; i++) {
            const subPatternForLstSections = {
                "strLabel": lstServiceLineData[i].toUpperCase()
            };
            strNotepadNotes += lstServiceLineData[i].toUpperCase() + '\n\n';
            if (lstServiceLineData[i].includes('DCN NUMBER -') || lstServiceLineData[i].includes(view_service_line_summary) ||
                lstServiceLineData[i].includes(service_line)) {
                subPatternForLstSections.strIcon = '';
                subPatternForLstSections.strIconFamily = '';
                subPatternForLstSections.strIconColor = '';
            } else {
                subPatternForLstSections.strIcon = 'add_contact';
                subPatternForLstSections.strIconFamily = 'action';
                subPatternForLstSections.strIconColor = '#5876a3';
            }
            lstSectionsData.push(subPatternForLstSections);
        }
        objPattern.lstSections = lstSectionsData;
        let sectionFieldsArray =[];
        let lstTitles =[]; 
        let lstTitleValues=[];
        sectionFieldsArray = this.serviceColumns;
        for(let i=0; i< sectionFieldsArray.length;i++) {
           let objFieldData = {}; 
            objFieldData.strFieldLabel = sectionFieldsArray[i].label.toUpperCase();
            if(!BaseLWC.isUndefinedOrNullOrBlank(sectionFieldsArray[i]) && objRowData[sectionFieldsArray[i].fieldName] ) {
                objFieldData.strFieldValue = objRowData[sectionFieldsArray[i].fieldName] ;
            } else {
                objFieldData.strFieldValue =  '';
            }
            strNotepadNotes += objFieldData.strFieldLabel + '\t\t' + objFieldData.strFieldValue+'\n';
            lstValuesData.push(objFieldData);
        }
        sectionFieldsArray = objRowData.fields1.fields;
        lstTitles = sectionFieldsArray.map(item => item.label);
        lstTitleValues = sectionFieldsArray.map(item => item.value);
        for (let i = 0; i < lstTitles.length; i++) {
            let objFieldData = {};
            objFieldData.strFieldLabel = lstTitles[i].toUpperCase();
            if( lstTitleValues[i] && !BaseLWC.isUndefinedOrNullOrBlank(lstTitleValues[i])) {
                objFieldData.strFieldValue =  lstTitleValues[i]; 
            } else {
                objFieldData.strFieldValue = '';
            }
            strNotepadNotes += objFieldData.strFieldLabel + '\t\t' + objFieldData.strFieldValue+'\n';
            lstValuesData.push(objFieldData);
        }
        sectionFieldsArray = objRowData.fields2.fields;
        lstTitles = sectionFieldsArray.map(item => item.label);
        lstTitleValues = sectionFieldsArray.map(item => item.value);
        for (let i = 0; i < lstTitles.length; i++) {
            let objFieldData = {};
            objFieldData.strFieldLabel = lstTitles[i].toUpperCase();
            if( lstTitleValues[i] && !BaseLWC.isUndefinedOrNullOrBlank(lstTitleValues[i])) {
                objFieldData.strFieldValue =  lstTitleValues[i]; 
            } else {
                objFieldData.strFieldValue = '';
            }
            strNotepadNotes += objFieldData.strFieldLabel + '\t\t' + objFieldData.strFieldValue+'\n';
            lstValuesData.push(objFieldData);
        }
        sectionFieldsArray = objRowData.fields3.fields;
        lstTitles = sectionFieldsArray.map(item => item.label);
        lstTitleValues = sectionFieldsArray.map(item => item.value);
        for (let i = 0; i < lstTitles.length; i++) {
            let objFieldData = {};
            objFieldData.strFieldLabel = lstTitles[i].toUpperCase();
            if( lstTitleValues[i] && !BaseLWC.isUndefinedOrNullOrBlank(lstTitleValues[i])) {
                objFieldData.strFieldValue =  lstTitleValues[i]; 
            } else {
                objFieldData.strFieldValue = '';
            }
            strNotepadNotes += objFieldData.strFieldLabel + '\t\t' + objFieldData.strFieldValue+'\n';
            lstValuesData.push(objFieldData);
        }
        let objFieldDataFooter = {};
        objFieldDataFooter.strFieldLabel =  objRowData.footerLabel.toUpperCase();
        objFieldDataFooter.strFieldValue = objRowData.footerValue;
        lstValuesData.push(objFieldDataFooter);

        objPattern.lstValues = lstValuesData; 

        TotalPattern.push(objPattern);
        this.strNotepadNotes = strNotepadNotes
        const strAutoDocStorageKey = 'idSERVICE_LINE_SUMMARY_' + index + '-' +this.strClaimNumber + this.strUrlAdjNumber + objRowData["strProcedureCode"] +
                                    objRowData["strProvisionId"] + '-' + this.strInteractionLogId + '-' + this.strMemeberId + '-' + this.strClaimNumber;
        this.sendAutoDocData(TotalPattern, strAutoDocStorageKey);
        this.publishToNotepad();
    }
    //CEAS-83660
    publishToNotepad() {
        const message = {
            method: 'POST',
            reqSource: "lwcNotepadAce",
            boolIsFromAutdoc : true,
            notes : this.strNotepadNotes.trim()
        };
        publish(this.messageContext, this.NotepadTransmissionChannel, message);
    }

    sendAutoDocData( TotalPattern, strAutoDocStorageKey) {
        if(this.strInteractionId && !this.boolHideAutoDoc) {
        const objIframe = document.createElement("iframe");
        objIframe.src = "/apex/ClaimsSetlocalstoragePage_ACE";
        objIframe.style.display = "none";
        document.body.appendChild(objIframe);
        objIframe.onload = function() {
            objIframe.contentWindow.postMessage({
                key: 'strAutodoc',
                value: JSON.stringify(TotalPattern),
                boolIsClaimsAutoDoc: true
            }, '*');
            if (this.strinteractionlogid !== '') {
                if (this.boolIsInternalInteraction === true && BaseLWC.isUndefinedOrNullOrBlank(this.boolIsInternalInteraction)) {
                    let strKey = 'strAutoDocIconInfo_ACE' + this.strAccountId;
                    if (!BaseLWC.isUndefinedOrNullOrBlank(BaseLWC.helperBaseGetItem(strKey)) && BaseLWC.helperBaseGetItem(strKey) !== '') {
                        const objInternalDetails = JSON.parse(BaseLWC.helperBaseGetItem(strKey));
                        objInternalDetails[strAutoDocStorageKey] = "Yes";
                        BaseLWC.helperBaseRemoveItem(strKey);
                        BaseLWC.helperBaseSetItem(strKey, JSON.stringify(objInternalDetails), 30);
                    } else {
                        const objInternalDetails = {
                            strAutoDocStorageKey: "Yes"
                        };
                        BaseLWC.helperBaseSetItem(strKey, JSON.stringify(objInternalDetails), 30);
                    }
                } else {
                    objIframe.contentWindow.postMessage({
                        key: 'strAutoDocIconInfo_ACE',
                        value: strAutoDocStorageKey,
                        boolIsClaimsAutoDoc: false
                    }, '*');
                }
                objIframe.contentWindow.postMessage({
                    key: 'strKeepAutodocActive',
                    value: 'true',
                    boolIsClaimsAutoDoc: true
                }, '*');
            }
        }
        }
    }


    getCurrentOpenCases = () => {
        checkIfAnyCasesAreOpen({
            mid: this.strMemeberId,
            type: 'Claims',
            subType: 'Claim Status_Claim Adjustment',
            strGroupNumber: this.groupNumber,
            strCmId: this.strCMID,
            strInteractionLogId: this.strInteractionLogId
        })
        .then(result => {
            try {
                if (!result) {
                    if (this.strinteractionlogid !== '') {
                        this.dispatchEvent(new CustomEvent('openmanualcase', {
                            detail: {
                                message: 'openmanualcase'
                            }
                        }));
                    }
                }
            } catch (exception) {
                //No handling Needed.
            }
        }
    ).catch(function() {
        // Failure Code
    });
    }
    /**
     * method to hide certifications hover
     */
    hideHoverDetails(event) {
        event.target.closest("div").querySelector(".slds-popover_tooltip").classList.add("slds-hide");
    }

    /**
     * method to show certifications hover
     */
    displayHoverDetails(event) {
        event.target.closest("div").querySelector(".slds-popover_tooltip").classList.remove("slds-hide");
    }
    handleRowAction(event) {
        if (event.detail) {
            const eventData = JSON.parse(event.detail);
            const renderedRowData = eventData.renderedRowData;
            if (eventData && eventData.renderedRowData && renderedRowData.uniqueId === 'duplicate-dcn-number' && renderedRowData.value) {
                let claimId = this.strClaimId;
                let claimIdArr = [];
                let strClaimId = '';
                 if(claimId) {
                    claimIdArr = claimId.split('^');
                    strClaimId = claimIdArr[0] + '^' +claimIdArr[1].replace(claimIdArr[1], renderedRowData.value) + '^' + claimIdArr[2];
                 }
                const strEncodedClaimsAndMemberId = '?' + window.btoa(unescape(encodeURIComponent('claimNumber=' + renderedRowData.value + '&mid=' + this.strMemeberId + '&claimId=' + strClaimId + '&adjNumber=&corpCode=' + this.strUrlCorpCode + '&groupNumber=' + this.groupNumber + '&idAccount=' + this.strAccountId + '&latestAdjustment=true')));
                
                const objPageReference = {
                    type: 'standard__navItemPage',
                    attributes: {
                        apiName: 'ViewMedicalClaimDetailsFlexiPage_ACE',
                        uid: this.strDcnNumber + '-' + this.strUrlAdjNumber
                    },
                    state: {
                        c__BaseURLParam: strEncodedClaimsAndMemberId
                    }
                }; 
                openSubtab(this.strParentTabId, {pageReference: objPageReference, focus: true}); 

            }
            const labelData = ['Primary DX', 'Procedure / HCPC Code', 'Diagnosis Code'];
            if (renderedRowData.label && labelData.includes(renderedRowData.label)) {
                const sectionInfo = JSON.parse(eventData.sectionInfo);
                let codesArr = sectionInfo.arrCodes;
                let selectedValue = eventData.textContent;
                if (codesArr && selectedValue) {
                    codesArr.forEach(elem => {
                        if (elem.code === selectedValue) {
                            elem.selected = true;
                        }
                    })
                }
                this.codeCheckArr = codesArr;
                this.serviceFromDate = sectionInfo.strServiceFrom;
                this.showCodeCheckModal = true;
            }
        }
    }

    closeModal() {
        this.showCodeCheckModal = false;
        this.showOtherInsuranceModal = false;
    }

    viewInformation(objEvent){
        if(objEvent && objEvent.target) {
            const strIndex = objEvent.target.getAttribute('data-id');
            this.intServiceLineIndex = Number(strIndex);
        }
        this.showOtherInsuranceModal = true;
    }
    handleAutoDocInsurance() {
        if (this,this.strinteractionlogid !== '') {
            this.dispatchEvent(new CustomEvent('openmanualcase', {
                detail: {
                    message: 'openmanualcase'
                }
            }));
        }
    }
}