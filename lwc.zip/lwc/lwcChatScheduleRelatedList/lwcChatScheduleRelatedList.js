/**
 * lwcChatScheduleRelatedList.js
 * Importing Decoraters and Libraries.
 */
import { LightningElement, track, wire, api } from "lwc";
import getDynamicTableDataList from "@salesforce/apex/ChatScheduleRelatedList_Controller.getChatSceheduleData";
import { NavigationMixin } from "lightning/navigation";
import { encodeDefaultFieldValues } from "lightning/pageReferenceUtils";
import { refreshApex } from "@salesforce/apex";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { deleteRecord } from "lightning/uiRecordApi";
import TIME_ZONE  from '@salesforce/i18n/timeZone';

//Quick Actions Labels
const actions = [
  { label: "Delete", name: "delete" },
  { label: "Edit", name: "edit" }
];

//Class Starts
export default class LwcChatScheduleRelatedList extends NavigationMixin(
  LightningElement
) {

  //Variable Declarations
  @track DataTableResponseWrappper;
  @track finalSObjectDataList;
  @track columns = [
    {
      label: "Name",
      fieldName: "nameURL",
      type: "url",
      typeAttributes: {
        label: {
          fieldName: "Holiday_Name__c"
        }
      }
    },
    {
      label: "Message Start",
      fieldName: "Message_Start_ACE__c",
      type: 'date',
  typeAttributes: {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZone: TIME_ZONE,
    hour12: true
  },
  sortable: false
    },
    {
      label: "Message End",
      fieldName: "Message_End_ACE__c",
      type: 'date',
  typeAttributes: {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZone: TIME_ZONE,
    hour12: true
  },
  sortable: false


    },
    {
      label: "Chat DownTime Message",
      fieldName: "Chat_Downtime_Message_ACE__c",
      type: 'checkbox'
    },
    {
      type: "action",
      typeAttributes: { rowActions: actions }
    }
  ];

  @track columns2 = [
    {
      label: "Days of the Week",
      fieldName: "nameURL",
      type: "url",
      typeAttributes: {
        label: {
          fieldName: "Days_of_the_Week__c"
        }
      }
    },
    {
      label: " Start Time",
      fieldName: "Start_Time__c"
    },
    {
      label: "End Time",
      fieldName: "End_Time__c"

    },
    {
      label: "Closed All Day",
      fieldName: "Closed_All_Day__c",
      type: "boolean"
    },
    {
      type: "action",
      typeAttributes: { rowActions: actions }
    }
  ];

  @api titleDatatable;
  @api isHoliday;
  defaultValues;
  @api recordtypeName;
  @api fieldSelector;
  @api recordId;
  //For Apex Refresh
  _wiredResult;

  //Calling Apex for Data
  @wire(getDynamicTableDataList, {
    strRecordtypeName: "$recordtypeName",
    strChatConfigID: "$recordId",
    strHolidayFields: "$fieldSelector"
  })

  //Apex Callback Method
  wiredContacts(value) {

    this._wiredResult = value;
    const { data, error } = value;
    if (data) {
      const sObjectRelatedFieldListValues = [];
      for (const row of data) {
        row;
        const finalSobjectRow = {};
        const rowIndexes = Object.keys(row);
        rowIndexes.forEach((rowIndex) => {
          const relatedFieldValue = row[rowIndex];
          if (relatedFieldValue.constructor === Object) {
            this._flattenTransformation(
              relatedFieldValue,
              finalSobjectRow,
              rowIndex
            );
          } else {
            if (rowIndex === "Id") {
              finalSobjectRow.nameURL = "/" + relatedFieldValue;
            } else if (rowIndex === "Start_Time__c" || rowIndex === "End_Time__c") {
                finalSobjectRow[rowIndex] = this.msToTime(relatedFieldValue);
              } else {
                finalSobjectRow[rowIndex] = relatedFieldValue;
              }
          }
        });
        sObjectRelatedFieldListValues.push(finalSobjectRow);
      }
      this.finalSObjectDataList = sObjectRelatedFieldListValues;
    } else if (error) {
      this.error = error;
    } else {
      //do nothing
    }
  }
  //For Flattening the data to wrapper
  _flattenTransformation = (fieldValue, finalSobjectRow, fieldName) => {
    if (fieldName === "Id") {
      fieldName = "nameUrl";
    }
    const rowIndexes = Object.keys(fieldValue);
    rowIndexes.forEach((key) => {
      const finalKey = fieldName + "." + key;
      finalSobjectRow[finalKey] = fieldValue[key];
    });
  };

  //For 'VIEW ALL' function
  viewRelatedList() {
    this[NavigationMixin.Navigate]({
      type: "standard__recordRelationshipPage",
      attributes: {
        recordId: this.recordId,
        objectApiName: "Holiday__c",
        relationshipApiName: "Holidays__r",
        actionName: "view"
      }
    });
  }
  //For 'NEW' function
  navigateToNewChatScehdule() {
    this.defaultValues = encodeDefaultFieldValues({
      Chat_Configuration__c: this.recordId
    });

    this[NavigationMixin.Navigate]({
      type: "standard__objectPage",
      attributes: {
        objectApiName: "Holiday__c",
        actionName: "new"
      },
      state: {
        useRecordTypeCheck: 1,
        defaultFieldValues: this.defaultValues
      }
    });
  }

//For Quick Actions functions
  handleRowAction(event) {
    const actionName = event.detail.action.name;
    const row = event.detail.row;
    switch (actionName) {
      case "delete": {
        this.deleteChatRecord(row.Id);
        break;
      }
      case "edit":{
        this[NavigationMixin.Navigate]({
          type: "standard__recordPage",
          attributes: {
            recordId: row.Id,
            objectApiName: "Holiday__c",
            actionName: "edit"
          }
        })

        break;
    }
      default:
    }
  }
  //For Delete action
  deleteChatRecord(recordId) {
    deleteRecord(recordId).then(() => {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "Success",
          message: "Record deleted",
          variant: "success"
        })
      );
      this.refreshData();
    });

  }

  msToTime(duration) {
    let seconds = Math.floor((duration / 1000) % 60),
      minutes = Math.floor((duration / (1000 * 60)) % 60),
      hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
      let amORpm = '';
      if(hours >= 12) {
        amORpm = 'PM';
      } else {
        amORpm = 'AM';
      }
    hours = ((hours + 11) % 12) + 1;
    if(hours < 10) {
      hours =  "0" + hours;
    }
    if(minutes < 10) {
      minutes =  "0" + minutes;
    }
    if(seconds < 10) {
      seconds =  "0" + seconds;
    }
    return hours + ":" + minutes + ":" + seconds + ' '+ amORpm;
  }
  //Calls refresh apex for data refresh from server
  refreshData() {
    return refreshApex(this._wiredResult);
  }
}