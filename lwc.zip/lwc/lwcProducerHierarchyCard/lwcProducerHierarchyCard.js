import { LightningElement, track, api, wire} from 'lwc';

//Import Shared JS files.

//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF'; 
 
//import platformWorkspaceApi
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';

//import Relavent Labels
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import Producer_Hierarchy_Header_ACE from '@salesforce/label/c.Producer_Hierarchy_Header_ACE';
import Producer_Hierarchy_Name_ACE from '@salesforce/label/c.ContactsCard_NameLabel_ACE';
import Producer_Hierarchy_ProducerID_ACE from '@salesforce/label/c.ContactsCard_ProducerIDLabel_ACE';
import Producer_Hierarchy_EffectiveDate_ACE from '@salesforce/label/c.Producer_Hierarchy_EffectiveDate_ACE';
import Producer_Hierarchy_EndDate_ACE from '@salesforce/label/c.Producer_Hierarchy_EndDate_ACE';


//import Relavent Apex Classes
import safeModeUserData from '@salesforce/apex/SafeModeController_ACE.fetchUserDetails';
import fetchAccountRecordType from '@salesforce/apex/AccountSummaryDashboardController_ACE.fetchAccountRecordType';
import producerDataCall from '@salesforce/apexContinuation/HierarchyCardController_ACE.hierarchyContinuationCall';


export default class LwcProducerHierarchyCard extends LightningElement {
    objTabData = null;
    boolShowSpinner = false;
    boolShowSafeMode = false;
    boolShowHierarchyCard = false;
    boolHierarchyAPIError = false;
    boolShowNoHierarchyDataWarning = false;
    objCardError = {};
    strCustomEventName = "ProviderSummaryEvent";
    strTriggerEventName = 'TriggerProviderSummaryData';
    strDestinationId = 'ProviderSummaryDetail_ACE';
    strTriggerSubTabEventName = "TriggerHierarchyCardData";
    strSubTabDestinationId = "HierarchyCardDetail_ACE";
    strSubTabCustomEventName = "HierarchyCardEvent";
    strDynamicCustomEventName="";
    strDynamicSubtabCustomEventName="";
    strProducerId="";
    lstProducerData = [];
    boolIsMainTab = false;
    @track lstProducerHierarchyList = [];

    label = {
        SafeMode_ToastMessage_ACE,
        IntegrationFailMessage_ACE,
        Producer_Hierarchy_Header_ACE,
        Producer_Hierarchy_Name_ACE,
        Producer_Hierarchy_ProducerID_ACE,
        Producer_Hierarchy_EffectiveDate_ACE,
        Producer_Hierarchy_EndDate_ACE,
    };

    //@api decorator
    @api recordId;
    @api objectApiName;

    //wire
    @wire(EnclosingTabId) enclosingTabId;
    
    //init
    connectedCallback() {
        try {
            this.boolShowSpinner=true;
            this.fetchTabData();
        } catch(error) {
            this.handleErrors(error);
        }
    } 

    /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     * All components should have this code.
     */
    fetchTabData = () => {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
            this.objTabData = objTabData;
            this.showHideProoducerHierarchyCard();
            this.fetchSafeModeUserData();
            this.addProducerSummaryListeners();
        }).catch((error) => {
            this.handleErrors(error);
        });
    }
}

    /**
     * Helps to set the safemode message for safe mode user
     */

    fetchSafeModeUserData = () => {
        safeModeUserData({}).then((objResult) => {
            if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                this.boolShowSafeMode = objResult.objSafeModeUser.Safe_Mode_Enabled_ACE__c;
                if(this.boolShowSafeMode === true) {
                    this.boolShowSpinner = false;
                }
            }
        }).catch(() => {
            this.boolShowSpinner = false;
        });

    }

    /**
     * Used to hide and show the cmp from the case details page depending on recordType Name.
     */
    showHideProoducerHierarchyCard = () => {
        if(this.objectApiName === 'Case'){
            fetchAccountRecordType({
                strCaseRecordId : this.recordId
            }).then((objResult) => {
                if (BaseLWC.isNotUndefinedOrNull(objResult) && objResult === 'Producer_ACE') {
                    if (!this.boolShowHierarchyCard) {
                        this.boolShowHierarchyCard = true;  
                    }                              
                } else {
                    this.boolShowHierarchyCard = false;
                }
            }).catch(() => {
                    //do nothing
            });
        } else {
            if (!this.boolShowHierarchyCard) {
                this.boolShowHierarchyCard = true;
            }
        }
    }

    /**
     * method to add prooducer summary listeners
     */

    addProducerSummaryListeners = () => {
        if(!this.objTabData.isSubtab){
            this.boolIsMainTab = true;
            this.executeMainTabFunctionality();
        } else {
            this.executeSubtabFunctionality();
        }
    }

    /**
     * Method to add main tab listeners
     */
    executeMainTabFunctionality = () => {
        this.strDynamicCustomEventName = this.strCustomEventName + '_' + this.objTabData.tabId;
        window.addEventListener(this.strDynamicCustomEventName, this.fetchProducerSummaryData);
        this.strDynamicSubtabCustomEventName = this.strTriggerSubTabEventName + '_' + this.objTabData.tabId;
        window.addEventListener(this.strDynamicSubtabCustomEventName, this.compareAndSendProducerHierarchyData);
    }

    /**
     * method to add sub tab listeners and then fire main tab trigger
     */
    executeSubtabFunctionality = () => {
        this.addSubTabListeners();
        this.fireEventToFetchDataFromParent();
    }

    /**
     * method to add sub tab listeners
     */
    addSubTabListeners = () => {
        this.strDynamicCustomEventName = this.strSubTabCustomEventName + '_' + this.objTabData.parentTabId;
        window.addEventListener(this.strDynamicCustomEventName, this.fetchHierarchyCardData);
    }

    /**
     * method to read hierarchy card data from main tab
     */
    fetchHierarchyCardData = (objHierarchyData) => {
        const objResponseData = BaseLWC.fetchComponentData(objHierarchyData, this.strSubTabDestinationId, true);
        try{
            this.boolHierarchyAPIError = objResponseData.boolHierarchyAPIError,
            this.boolShowNoHierarchyDataWarning = objResponseData.boolShowNoHierarchyDataWarning;
            this.boolShowSafeMode = objResponseData.boolShowSafeMode;
            this.lstProducerHierarchyList = objResponseData.lstProducerHierarchyList;
        } catch(exception){
            this.boolHierarchyAPIError = true;
        }
        this.boolShowSpinner = false;
    }

    /**
     * method to fire subtab custom event
     */
    fireEventToFetchDataFromParent = () => {
        BaseLWC.fireCustomEvent(this.strTriggerSubTabEventName, null, this.strSubTabDestinationId,
                true, this.objTabData.parentTabId);
    }

    /**
     * method to send data from primary tab card when secondary tab with card loads
     */
    compareAndSendProducerHierarchyData = (objCommEvent) => {
        const objParentTabHierarchyCardData = this.accumulateDataToBeSent();
        BaseLWC.sendComponentData(objCommEvent, this.strSubTabDestinationId, this.strSubTabCustomEventName,
        JSON.stringify(objParentTabHierarchyCardData), this.strSubTabDestinationId, true, this.objTabData.tabId);
    }

    /**
     * structure response for subtab card
     */
    accumulateDataToBeSent = () => {
        return {
            recordId: this.recordId,
            boolHierarchyAPIError: this.boolHierarchyAPIError,
            boolShowNoHierarchyDataWarning: this.boolShowNoHierarchyDataWarning,
            boolShowSafeMode: this.boolShowSafeMode,
            lstProducerHierarchyList: this.lstProducerHierarchyList
        };
    } 
    /**
     * method to process prooducer summary data
     */
    fetchProducerSummaryData = (objCommEventData) => {
        const objResponseData = BaseLWC.fetchComponentData(objCommEventData, this.strDestinationId, true);
        
        if (objResponseData.boolError === true) {
            this.boolHierarchyAPIError = true;
            this.boolShowSpinner = false;
        } else {
            this.recordId = objResponseData.recordId;
            this.strProducerId = objResponseData.objProducerSummaryData.producerId;
            this.producerDataCallOut();
            window.removeEventListener(this.strDynamicCustomEventName, this.fetchProducerSummaryData);
    
        }
    }

    /**
     * method to make producer hierarchy api callout
     */

     producerDataCallOut = () => {
        producerDataCall({
            producerId: this.strProducerId
        }).then((objResult) => {
             this.lstProducerData = JSON.parse(objResult);
             if(BaseLWC.isNotUndefinedOrNull(this.lstProducerData.strResponseStatusCode) && this.lstProducerData.strResponseStatusCode !== "200" && this.lstProducerData.strResponseStatusCode !== "201") {
                this.boolHierarchyAPIError = true;
                this.boolShowSpinner = false;
            } else {
                this.boolHierarchyAPIError = false;
                this.processProducerHierarchyData();
            }

        });
     }

    /**
     * method to process producer hierarchy data and view it on UI
     */

    processProducerHierarchyData = () => {
        if(this.lstProducerData.parentProducers && this.lstProducerData.parentProducers.length > 0) {
            this.getProducerList(this.lstProducerData.parentProducers[0]);
        }
        if(this.lstProducerHierarchyList.length > 0) {
            this.boolShowNoHierarchyData = false;
            if(this.lstProducerHierarchyList.length > 4) {
                this.lstProducerHierarchyList = this.lstProducerHierarchyList.slice(0,4);
            }
            this.lstProducerHierarchyList = this.lstProducerHierarchyList.reverse();
        } else {
            this.boolShowNoHierarchyDataWarning = true;
        }
        this.sendHierarchyCardData();
        this.boolShowSpinner = false;
    }

    /**
     * sends data to subtab once hierarchy card in parent tab loads
     */
    sendHierarchyCardData = () => {
        const objParentTabHierarchyCardData = this.accumulateDataToBeSent();
        BaseLWC.fireCustomEvent(this.strTriggerSubTabEventName, objParentTabHierarchyCardData, this.strSubTabDestinationId,
                true, this.objTabData.tabId);
    }

    /**
     * method to format producer hierarchy data into a linear array
     */

    getProducerList = (data) => {
        if(data.displayProducer){
            data.relationEffectiveDate = BaseLWC.dateFormatterHelper(data.relationEffectiveDate);
            data.relationEndDate = BaseLWC.dateFormatterHelper(data.relationEndDate);
            this.lstProducerHierarchyList.push(data);
        }
        if(data.parentProducers) {
            this.getProducerList(data.parentProducers[0]);
        } else {
            return false;
        }
    }
    //CEAS-56383-CHANGES
    disconnectedCallback() {
        if(this.objTabData.tabId) {
            this.strDynamicSubtabCustomEventName = this.strTriggerSubTabEventName + '_' + this.objTabData.tabId;
        window.removeEventListener(this.strDynamicSubtabCustomEventName, this.compareAndSendProducerHierarchyData);
        }
        if(this.objTabData.parentTabId) {
            this.strDynamicCustomEventName = this.strSubTabCustomEventName + '_' + this.objTabData.parentTabId;
        window.removeEventListener(this.strDynamicCustomEventName, this.fetchHierarchyCardData);
        }
    }

    /**
     * method to perform functionality on click of refresh button
     */

    refreshCard = () => {
        this.boolShowSpinner = true;
        this.boolShowSafeMode = false;
        this.boolHierarchyAPIError = false;
        this.boolShowNoHierarchyDataWarning = false;
        this.lstProducerData = [];
        this.lstProducerHierarchyList = [];
        this.fetchSafeModeUserData();
        this.producerDataCallOut();
    }
    
    /**
    * To handle Errors.
    * Helps to show case errors.
    * All components should have this code.
    */
    handleErrors = (error) => {
        //show Account API Error
        this.objCardError = error;
        this.boolHierarchyAPIError = true;
        this.boolShowSpinner = false;
    }           
}