import {
	LightningElement,
	api,
	track
} from 'lwc';
import AlternativeText_Close_ACE from '@salesforce/label/c.AlternativeText_Close_ACE';
import RemoveLegacyModal_Description_ACE from '@salesforce/label/c.RemoveLegacyModal_Description_ACE';
import ViewAuthorizedParty_EffectiveDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_EffectiveDate_ACE';
import ViewAuthorizedParty_ExpirationDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_ExpirationDate_ACE';
import UpdateHIPAARestrictions_InvalidPhoneNumberMessage_ACE from '@salesforce/label/c.UpdateHIPAARestrictions_InvalidPhoneNumberMessage_ACE';
import LegacyAlertSaveRemove_ACE from '@salesforce/label/c.LegacyAlertSaveRemove_ACE';
import ViewStandardAuthorization_Success_ACE from '@salesforce/label/c.ViewStandardAuthorization_Success_ACE';
import CreateCasePage_ChooseMembers_ACE from '@salesforce/label/c.CreateCasePage_ChooseMembers_ACE';
import RemoveLegacyModal_SuccessMessage_ACE from '@salesforce/label/c.RemoveLegacyModal_SuccessMessage_ACE';
import seasonsOfLifeCaseRemove from '@salesforce/apex/LegacyModalController_ACE.seasonsOfLifeCaseRemove';
import BaseLWC from "c/baseLWCFunctions_CF";
export default class LwcConvertAlertSeasonsofLife extends LightningElement {
	@api boolModalIsOpen;
	@api boolShowToastMessage;
	@api boolShowFailToastMessage;
	@api boolConfirmFunctionality;
	@api boolRemoveFunctionality;
	@api boolRefreshIframe;
	@api boolShowNtfType;
	boolShowDefaultScreen;
	@api boolIsValidated;
	@api strClientMemberId;
	strContactNumber;
	strContactName;
	@api strApplicableTo;
	@api strCaseStatus;
	@api strAdditionalMem;
	@api strAdditionalMemVal;
	@api strUniqueToken;
	@api lstAdditionalMember;
	@api objRecordData;
	@api objSelectedPlan;
	@api objPlanSummaryListener;
	strSelectedApplicableToKey;
	strApplicableToKey;
	memberMap = new Map();
	@track lstFamily;
	@track strApplicableToText = '';
	get caseOptions() {
		return [{
				label: 'OPEN',
				value: 'Open'
			},
			{
				label: 'CLOSED',
				value: 'Closed'
			},
			{
				label: 'PENDED',
				value: 'Pended'
			},
			{
				label: 'WITHDRAWN',
				value: 'Withdrawn'
			},
		];
	}
	label = {
		AlternativeText_Close_ACE,
		RemoveLegacyModal_Description_ACE,
		ViewAuthorizedParty_EffectiveDate_ACE,
		ViewAuthorizedParty_ExpirationDate_ACE,
		UpdateHIPAARestrictions_InvalidPhoneNumberMessage_ACE,
		LegacyAlertSaveRemove_ACE,
		ViewStandardAuthorization_Success_ACE,
		RemoveLegacyModal_SuccessMessage_ACE,
		CreateCasePage_ChooseMembers_ACE
	};
	connectedCallback() {
		this.boolShowDefaultScreen = true;
		if (!this.strCaseStatus) {
			this.strCaseStatus = 'Closed';
		}
		this.setInitialFamilyData();
	}
	back(objEvent) {
		this.boolShowDefaultScreen = true;
		this.boolShowDefaultScreen = true;
		this.boolRemoveFunctionality = false;
		this.boolConfirmFunctionality = false;
		this.boolShowFailToastMessage = false;
		this.boolShowToastMessage = false;
	}
	removeLegacyNtf(objEvent) {
		this.seasonsOfLifeRemove();
	}
	toggleElement(elementToFind) {
		//show div
		if (this.template.querySelector(elementToFind).classList.contains('slds-hide')) {
			this.showHideElement(elementToFind, true);
		} else {
			this.showHideElement(elementToFind, false);
		}
	}
	setInitialFamilyData() {

		if (this.lstAdditionalMember) {
			let lsdtMembers = this.lstAdditionalMember;
			let finallistMap = [];
			lsdtMembers.forEach((objElement) => {
				let mapMember = {};
				mapMember['value'] = objElement.strFirstName.trim() + ' ' + objElement.strLastName.trim();
				mapMember['key'] = objElement.strMemberId + '-' + objElement.strClientMemberId;
				finallistMap.push(mapMember);
			});
			this.strApplicableToText = finallistMap[0].value;
			this.strSelectedApplicableToKey = finallistMap[0].key;
			this.strApplicableToKey = finallistMap[0].key;
			this.strApplicableToText = finallistMap[0].value;
			this.strApplicableTo = finallistMap[0].value;
			this.setApplicableToMap(finallistMap);
			this.lstFamily = finallistMap;
		} else {
			this.lstFamily = [];
		}

	}
	showHideElement(elementToFind, show) {
		if (show) {
			this.template.querySelector(elementToFind)?.classList.remove('slds-hide');
		} else {
			this.template.querySelector(elementToFind)?.classList.add('slds-hide');
		}
	}
	closeModal(objEvent) {
		this.boolModalIsOpen = false;
		this.strAdditionalMem = '';
		this.strAdditionalMemVal = '';
		const alertSeasonOfLifeCloseModal = new CustomEvent("close", {}, this);
		this.dispatchEvent(alertSeasonOfLifeCloseModal);
	}
	openPickList(objEvent) {
		this.openPickListHelper(objEvent);
	}
	clickOnSaveAndRemoveLegacy(objEvent) {
		this.validateForm();
		if (this.boolIsValidated === false) {
			return;
		}
		this.boolShowDefaultScreen = false;
		this.boolRemoveFunctionality = true;
		this.boolConfirmFunctionality = false;
	}
	seasonOfLifeSaveCase(objEvent) {
		this.validateForm();
		this.seasonsOfLifeSaveandNew();
	}
	fireToastMessageContent() {
		const objIframeRefreshEvent = new CustomEvent("refreshiframeseasons", {}, this);
		this.dispatchEvent(objIframeRefreshEvent);
		this.boolShowToastMessage = true;
	}
	openPickListHelper(objEvent) {
		if (objEvent.currentTarget.classList.contains('slds-modal__container')) {
			BaseLWC.isUndefinedOrNullOrBlank(objEvent.currentTarget.querySelector('.slds-combobox'))
			if (BaseLWC.isUndefinedOrNullOrBlank(objEvent.currentTarget.querySelector('.slds-combobox'))) {
				return;
			}
			objEvent.currentTarget.querySelector('.slds-combobox').classList.remove('slds-is-open');
			objEvent.currentTarget.querySelector('.slds-combobox').setAttribute('aria-expanded', false);
			return;
		}
		const objPicklist = objEvent.currentTarget;
		if (objPicklist.parentElement.classList.contains('slds-is-open')) {
			objPicklist.parentElement.classList.remove('s	lds-is-open');
			objPicklist.parentElement.setAttribute('aria-expanded', false);
		} else {
			objPicklist.parentElement.classList.add('slds-is-open');
			objPicklist.parentElement.setAttribute('aria-expanded', true);
			const lstPicklistValues = objEvent.currentTarget.closest('.slds-combobox_container').querySelector('#idAdditionalMembers_listbox').querySelectorAll('li');
			lstPicklistValues.forEach(function (objElm) {
				if (!BaseLWC.isUndefinedOrNullOrBlank(objElm)) {
					if (objElm.getAttribute('data-value') === this.strAdditionalMemVal && !BaseLWC.isUndefinedOrNullOrBlank(objElm)) {
						objElm.querySelector('.slds-listbox__option').classList.add('slds-is-selected');
					}
				}
			});
		}
		objEvent.stopImmediatePropagation();
	}
	seasonsOfLifeRemove() {
		const objCaseDetails = {
			"attributes": {
				"type": "Case"
			},
			"Type": "Special Handling",
			"Sub_Type_ACE__c": "Seasons of Life / End of Life",
			"Status": this.strCaseStatus,
			"AccountId": "",
			"ContactId": "",
			"RecordTypeId": "",
			"SectionNumber_ACE__c": this.objSelectedPlan.objViewEmployerGroupWrapper.strGroupSectionNumber,
			"GroupNumber_ACE__c": this.objSelectedPlan.objViewEmployerGroupWrapper.strGroupNumber,
			"CorporationCode_ACE__c": this.objSelectedPlan.objViewEmployerGroupWrapper.strCorporationCode,
			"SubscriberID_ACE__c": this.objSelectedPlan.strSubscriberId,
			"CMID_ACE__c": "",
			"SecureGroupName_ACE__c": "",
			"Origin": "MEMBERSHIP MAINTENANCE",
			"GroupCostCenter_ACE__c": this.objSelectedPlan.strGroupCostCenterNumber,
			"SeasonsofLifeMember_ACE__c": this.strContactName,
			"SeasonsofLifeContact_ACE__c": this.strContactNumber
		};
		const idRecordId = this.objRecordData.Id;
		seasonsOfLifeCaseRemove({
			strCaseRecord: JSON.stringify(objCaseDetails),
			strSelectedMembers: this.strSelectedApplicableToKey,
			idRecord: idRecordId,
			boolNotification: true,
			boolAuthorization: false
		}).then(result => {
			try {
				const btnGroup = this.template.querySelector('.removeModalButtonSection');
				if (btnGroup && btnGroup.classList) {
					btnGroup.classList.add('slds-hide');
				}
				this.boolShowToastMessage = true;
				this.boolShowFailToastMessage = false;
				//evevnt to refrest iFrame
				const objIframeRefreshEvent = new CustomEvent("refreshiframeseasons", {}, this);
				this.dispatchEvent(objIframeRefreshEvent);
				//this.querySelector("idSpinner").set("v.class", 'slds-hide');
			} catch (exception) {
				const btnGroup = this.template.querySelector('idShowButtonGroup');
				if (btnGroup && btnGroup.classList) {
					btnGroup.classList.remove('slds-hide');
				}
				this.boolShowToastMessage = false;
				this.boolShowFailToastMessage = true;
				//this.querySelector("idSpinner").set("v.class", 'slds-hide');
			}
		}).catch(function () {
			// Failure Code
		});
	}
	seasonsOfLifeSaveandNew() {
		if (this.boolIsValidated === false) {
			return;
		}
		const objCaseDetails = {
			"attributes": {
				"type": "Case"
			},
			"Type": "Special Handling",
			"Sub_Type_ACE__c": "Seasons of Life / End of Life",
			"Status": this.strCaseStatus,
			"AccountId": "",
			"ContactId": "",
			"RecordTypeId": "",
			"SectionNumber_ACE__c": this.objSelectedPlan.objViewEmployerGroupWrapper.strGroupSectionNumber,
			"GroupNumber_ACE__c": this.objSelectedPlan.objViewEmployerGroupWrapper.strGroupNumber,
			"CorporationCode_ACE__c": this.objSelectedPlan.objViewEmployerGroupWrapper.strCorporationCode,
			"SubscriberID_ACE__c": this.objSelectedPlan.strSubscriberId,
			"CMID_ACE__c": "",
			"SecureGroupName_ACE__c": "",
			"Origin": "MEMBERSHIP MAINTENANCE",
			"GroupCostCenter_ACE__c": this.objSelectedPlan.strGroupCostCenterNumber,
			"SeasonsofLifeMember_ACE__c": this.strContactName,
			"SeasonsofLifeContact_ACE__c": this.strContactNumber
		};
		seasonsOfLifeCaseRemove({
			strCaseRecord: JSON.stringify(objCaseDetails),
			strSelectedMembers: this.strSelectedApplicableToKey
		}).then(result => {
			if (result) {
				try {
					const btnGroup = this.template.querySelector('.clsDefaultButtonGroup');
					if (btnGroup && btnGroup.classList) {
						btnGroup.classList.add('slds-hide');
					}
					this.boolShowToastMessage = true;
					this.boolShowFailToastMessage = false;
					const objIframeRefreshEvent = new CustomEvent("refreshiframeseasons", {}, this);
					this.dispatchEvent(objIframeRefreshEvent);
				} catch (exception) {
					const btnGroup = this.template.querySelector('idDefaultButtonGroup');
					if (btnGroup && btnGroup.classList) {
						btnGroup.classList.remove('slds-hide');
					}
					this.boolShowToastMessage = false;
					this.boolShowFailToastMessage = true;
					//No handling Needed.
				}
			} else {
				const btnGroup = this.template.querySelector('idDefaultButtonGroup');
				if (btnGroup && btnGroup.classList) {
					btnGroup.classList.remove('slds-hide');
				}
				this.boolShowToastMessage = false;
				this.boolShowFailToastMessage = true;
			}
			//this.querySelector("idSpinner").set("v.class", 'slds-hide');
		}).catch(function () {
			// Failure Code
		});
	}
	/**
	 * Method to Validate Form
	 */

	validateForm() {
		this.boolIsValidated = true;
		if (this.template.querySelector(".clsContactNumber") && !this.template.querySelector(".clsContactNumber").checkValidity()) {
			this.template.querySelector(".clsContactNumber").reportValidity();
			this.boolIsValidated = false;
		}
		if (!this.strApplicableToText) {
			const applicaleTo = this.template.querySelector(".idApplicableTo");
			if (applicaleTo && applicaleTo.classList) {
				applicaleTo.classList.remove('slds-hide');
			}
			this.boolIsValidated = false;
		}
	}
	hideShow() {
		let lstSelectedApplicableTo = [];
		if (this.strSelectedApplicableToKey) {
			if (this.strSelectedApplicableToKey.indexOf(';') > -1) {
				lstSelectedApplicableTo = this.strSelectedApplicableToKey.split(";");
			} else {
				lstSelectedApplicableTo.push(this.strSelectedApplicableToKey);
			}
		}
		if (this.strApplicableToKey) {
			if (this.strApplicableToKey.indexOf(';') > -1) {
				const lstApplicableTo = this.strApplicableToKey.split(';');
				let boolElementNotFound = false;
				for (let elem = 0; elem < lstApplicableTo.length; elem++) {
					this.template.querySelector('[data-id="mainDiv"]')
					if (this.template.querySelector('[data-id=' + '"' + lstApplicableTo[elem] + '"]')) {
						this.template.querySelector('[data-id=' + '"' + lstApplicableTo[elem] + '"]').firstChild.classList.remove("slds-hide");
					} else {
						boolElementNotFound = true;
						break;
					}
					if (this.boolIsUpdate) {
						if (lstSelectedApplicableTo.length > 0) {
							if (lstSelectedApplicableTo.indexOf(lstApplicableTo[elem]) === -1) {
								this.template.querySelector('[data-id=' + '"' + lstApplicableTo[elem] + '"]').classList.add("disableClass");
							}
						} else {
							this.template.querySelector('[data-id=' + '"' + lstApplicableTo[elem] + '"]').classList.add("disableClass");
						}
					}
				}
				if (boolElementNotFound) {
					return;
				} else {
					//do nothing
				}
			} else {
				if (this.template.querySelector('[data-id=' + '"' + this.strSelectedApplicableToKey + '"]')) {
					this.template.querySelector('[data-id=' + '"' + this.strSelectedApplicableToKey + '"]').firstChild.classList.remove("slds-hide");
					if (this.boolIsUpdate) {
						if (lstSelectedApplicableTo.length > 0) {
							if (lstSelectedApplicableTo.indexOf(this.strApplicableToKey) === -1) {
								this.template.querySelector('[data-id=' + '"' + this.strApplicableToKey + '"]').classList.add("disableClass");
							}
						} else {
							this.template.querySelector('[data-id=' + '"' + this.strApplicableToKey + '"]').classList.add("disableClass");
						}
					}
				} else {
					return;
				}
			}
		}
		//Toggle mainDiv on click, Note: added for CEAS-48824
		this.toggleElement('[data-id="mainDiv"]');
		//AM:CEAS-50239, Set focus on "mainDiv", this facilitates onblur function to execute
		if (this.template.querySelector(".mainDivCSS")) {
			this.template.querySelector(".mainDivCSS").focus();
		}
		/*
		Previously, an event listener was added on the window to trap the "click" event and
		close the mainDiv. It was causing issues, so I set up a timer to close the mainDiv after 5 seconds instead.
		Note: added for CEAS-48824
		*/
		//this.template.querySelector('[data-id="mainDiv"]')
		setTimeout(() => {
			if (!this.template.querySelector('.mainDiv')?.classList.contains("slds-hide")) {
				this.showHideElement(".mainDiv", false);
			}
		}, 5000);
	}
	setApplicableToMap(arr) {
		if (arr && Array.isArray(arr) && arr.length) {
			arr.forEach(el => {
				this.memberMap.set(el.value, el.key);
			})
		}
	}
	hideOnBlur() {
		this.showHideElement('[data-id="mainDiv"]', false);
	}
	selectOption(objEvent) {
		//Stores the value to display in the input field of the picklist.
		let strApplicableTo = this.strApplicableTo;
		let strApplicableToKey = this.strApplicableToKey;
		//Stores the values explicitly selected by the user and will be sent to apex on click of save.
		let strSelectedApplicableTo = this.strSelectedApplicableTo;
		let strSelectedApplicableToKey = this.strSelectedApplicableToKey;
		let lstApplicableTo = [];
		let lstApplicableToKey = [];
		let lstSelectedApplicableTo = [];
		let lstSelectedApplicableToKey = [];
		let strSelectedText = '';
		let selectId;
		if (objEvent.currentTarget && objEvent.currentTarget.childNodes.length > 1 &&
			this.memberMap.size && this.memberMap.has(objEvent.currentTarget.childNodes[1].defaultValue) &&
			this.memberMap.get(objEvent.currentTarget.childNodes[1].defaultValue)) {
			selectId = this.memberMap.get(objEvent.currentTarget.childNodes[1].defaultValue);
		}
		if (objEvent.currentTarget && selectId) {
			//The div tag class name decides if the user is selecting/un selecting the picklist value. The class 'picklistOpions' means user selected a value.
			if (objEvent.currentTarget.childNodes[0].classList.contains("slds-hide")) {
			    if (strApplicableToKey) {
					lstApplicableToKey = strApplicableToKey.split(';');
				}

				if (strSelectedApplicableToKey) {
					lstSelectedApplicableToKey = strSelectedApplicableToKey.split(';');
				}
				if (lstApplicableToKey.indexOf(selectId) === -1) {
					if (strApplicableToKey) {
						strApplicableTo = strApplicableTo + ';' + objEvent.currentTarget.childNodes[1].defaultValue;
						strApplicableToKey = strApplicableToKey + ';' + selectId;
						strSelectedText = (lstApplicableToKey.length + 1) + " Selected";
					} else {
						strApplicableTo = objEvent.currentTarget.childNodes[1].defaultValue;
						strApplicableToKey = selectId;
						strSelectedText = strApplicableTo;
					}
				}
				if (lstSelectedApplicableToKey.indexOf(selectId) === -1) {
					if (strSelectedApplicableToKey) {
						strSelectedApplicableTo = strSelectedApplicableTo + ';' + objEvent.currentTarget.childNodes[1].defaultValue;
						strSelectedApplicableToKey = strSelectedApplicableToKey + ';' + selectId;
					} else {
						strSelectedApplicableTo = objEvent.currentTarget.childNodes[1].defaultValue;
						strSelectedApplicableToKey = selectId;
					}
				}
				this.strApplicableTo = strApplicableTo;
				this.strApplicableToKey = strApplicableToKey;
				this.strSelectedApplicableTo = strSelectedApplicableTo;
				this.strSelectedApplicableToKey = strSelectedApplicableToKey;
				this.strApplicableToText = strSelectedText;
				objEvent.currentTarget.childNodes[0].classList.toggle('slds-hide');
			} else if (objEvent.currentTarget.childNodes.length && !objEvent.currentTarget.childNodes[0].classList.contains("slds-hide")) {
				//The below logic is used to remove a particular selection from the picklist array values.
				if (strApplicableTo) {
					lstApplicableTo = strApplicableTo.split(';');
				}
				if (strApplicableToKey) {
					lstApplicableToKey = strApplicableToKey.split(';');
				}
				if (strSelectedApplicableTo) {
					lstSelectedApplicableTo = strSelectedApplicableTo.split(';');
				}
				if (strSelectedApplicableToKey) {
					lstSelectedApplicableToKey = strSelectedApplicableToKey.split(';');
				}
				if (lstApplicableToKey.indexOf(selectId) > -1) {
					lstApplicableTo.splice(lstApplicableTo.indexOf(objEvent.currentTarget.childNodes[1].defaultValue), 1);
					lstApplicableToKey.splice(lstApplicableToKey.indexOf(selectId), 1);
					strApplicableTo = lstApplicableTo.join(';');
					strApplicableToKey = lstApplicableToKey.join(';');
					this.strApplicableToKey = strApplicableToKey;
					if (lstApplicableToKey.length > 1) {
						strSelectedText = lstApplicableToKey.length + " Selected";
					} else if (lstApplicableToKey.length === 1) {
						strSelectedText = strApplicableTo;
					} else {
						//Do Nothing
					}
					this.strApplicableTo = strApplicableTo;
					this.strApplicableToKey = strApplicableToKey;
					this.strApplicableToText = strSelectedText;
				}
				if (lstSelectedApplicableToKey.indexOf(selectId) > -1) {
					lstSelectedApplicableTo.splice(lstSelectedApplicableTo.indexOf(objEvent.currentTarget.childNodes[1].defaultValue), 1);
					lstSelectedApplicableToKey.splice(lstSelectedApplicableToKey.indexOf(selectId), 1);
					strSelectedApplicableTo = lstSelectedApplicableTo.join(';');
					strSelectedApplicableToKey = lstSelectedApplicableToKey.join(';');
					this.strSelectedApplicableTo = strSelectedApplicableTo;
					this.strSelectedApplicableToKey = strSelectedApplicableToKey;
				}
				objEvent.currentTarget.childNodes[0].classList.toggle('slds-hide')
			} else {
				return;
			}
		}
	}
	contactNumberData(event) {
	this.strContactNumber = event.target.value;
	}
	contactNameData(event) {
	this.strContactName = event.target.value;
	}
}