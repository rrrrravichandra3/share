import { LightningElement, api, track, wire} from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
import fetchArticleNumber from "@salesforce/apex/KnowledgeArticlesController_ACE.fetchArticleNumber";
import InvalidInformationMessage_ACE from '@salesforce/label/c.InvalidInformationMessage_ACE';
import KAFErrorMessage_ACE from '@salesforce/label/c.KAFErrorMessage_ACE';
import KAFSuccessMessage_ACE from '@salesforce/label/c.KAFSuccessMessage_ACE';
import FeedBackHeader_ACE from '@salesforce/label/c.FeedBackHeader_ACE';
import KACDescriptionLabel_ACE from '@salesforce/label/c.KACDescriptionLabel_ACE';
import saveData from "@salesforce/apex/KnowledgeArticlesController_ACE.saveFeedbackData";
import { getPicklistValues, getObjectInfo } from 'lightning/uiObjectInfoApi';
import KnowledgeFeedback_ACE_Object from '@salesforce/schema/Knowledge_Feedback_ACE__c';
import FEEDBACK_TYPE_Field from '@salesforce/schema/Knowledge_Feedback_ACE__c.FeedbackType_ACE__c';
import KAC_FEEDBACK_Field from '@salesforce/schema/Knowledge_Feedback_ACE__c.KnowledgeArticleCommittee_ACE__c';

export default class KnowledgeFeedbackLwcACE extends LightningElement {
    @api fieldLabel = 'Please describe your feedback and suggested resolution in detail.';
    @api disabled = false;
    @track fieldValues = {
      'Description': '',
      'FeedbackType': '',
      'KnowledgeArticleCommittee': ''
    };
    label = {
      InvalidInformationMessage_ACE,
      KAFErrorMessage_ACE,
      KAFSuccessMessage_ACE,
      FeedBackHeader_ACE,
      KACDescriptionLabel_ACE
    };  
    disableSubmit = true;
    boolDisplayKAC = false;
    boolDisplaySuccessMsg= false;
    boolDisplayErrorMsg = false;
    @track inputFeedback;
    @track inputKACValue;
    @track inputFeedbackType;
    @track FeedbackOptions = [];
    @track KACOptions = [];
    @api recordId;
    articleNumber;
    initialized = false;

    @wire(getObjectInfo, {objectApiName: KnowledgeFeedback_ACE_Object})
    KnowledgeFeedback_ACE_ObjectInfo;

    @wire(getPicklistValues, {
      recordTypeId: '$KnowledgeFeedback_ACE_ObjectInfo.data.defaultRecordTypeId',
      fieldApiName: FEEDBACK_TYPE_Field
    })
    feedbackPicklistVal ({
      error,
      data
    }) {
      if (data && data.values) {
  
        const picklistValuesList = [];
  
        for(const picklistValue of data.values) {
          picklistValuesList.push({
            label: picklistValue.label || null,
            value: picklistValue.value || null
          });
        }
  
        this.FeedbackOptions = picklistValuesList;

      } else if (error) {
        // Do Nothing
      } else {
        // Do Nothing
      }
    }
    
    @wire(getPicklistValues, {
      recordTypeId: '$KnowledgeFeedback_ACE_ObjectInfo.data.defaultRecordTypeId',
      fieldApiName: KAC_FEEDBACK_Field
    })
    kacPicklistVal ({
      error,
      data
    }) {
      if (data && data.values) {
        const picklistValuesList = [];
        picklistValuesList.push({
          label:  'Select',
          value:  null
        });  
        for(const picklistValue of data.values) {
          if(picklistValue.value !== 'Knowledge Management') {
            picklistValuesList.push({
              label: picklistValue.label || null,
              value: picklistValue.value || null
            });
          }
        }
        this.KACOptions = picklistValuesList;
      } else if (error) {
        // Do Nothing
      } else {
        // Do Nothing
      }
    }

    handlePicklistChange(event) {
      const {name, value} = event.target;
      if(BaseLWC.stringIsNotBlank(value)) {
        this.fieldValues[name] = value;
      } else {
        this.fieldValues[name] = '';
      }
      this.validateFields();
    }
  
    validateFields() {
      this.disableSubmit = true;
      if(BaseLWC.stringIsNotBlank(this.fieldValues['FeedbackType'])) {
        if(this.fieldValues['FeedbackType'] !== 'Invalid Information') {
          this.boolDisplayKAC =   false;
          if(BaseLWC.stringIsNotBlank(this.fieldValues['Description'])) {
            this.disableSubmit = false;
          }
          return;
        } else {
          this.boolDisplayKAC = true;
          if(BaseLWC.stringIsNotBlank(this.fieldValues['KnowledgeArticleCommittee']) && BaseLWC.stringIsNotBlank(this.fieldValues['Description'])) {
            this.disableSubmit = false;
            return;
          }
        }
      }
      this.disableSubmit = true;
    }

    connectedCallback(){

        fetchArticleNumber({
            strArticleID: this.recordId
        })
          .then((objResult) => {
            this.articleNumber = objResult;
          })
          .catch(() => {
            //Do Nothing
          });
    }

    submitData = () => {
        saveData({
            strArticleNumber: this.articleNumber,
            strFeedback : this.fieldValues['Description'],
            strFeedbackType : this.fieldValues['FeedbackType'],
            strKACValue : this.fieldValues['KnowledgeArticleCommittee'],
            strArticleId : this.recordId,
            strdomain : window.location.origin + '/lightning/articles/Knowledge/'
        })
          .then(() => {
            this.boolDisplaySuccessMsg = true;
            this.boolDisplayErrorMsg = false;
          })
          .catch(() => {
            this.boolDisplayErrorMsg = true;
            this.boolDisplaySuccessMsg = false;
          });
    }

}