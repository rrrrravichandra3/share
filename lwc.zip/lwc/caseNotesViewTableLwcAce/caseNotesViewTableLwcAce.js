import { LightningElement,wire, api } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import { EnclosingTabId, getTabInfo, openSubtab } from 'lightning/platformWorkspaceApi';
import { getRecord } from 'lightning/uiRecordApi';
import NotesRollUpSummary_CaseNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_CaseNotes_ACE';
import NotesRollUpSummary_ParentCaseNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_ParentCaseNotes_ACE';
import NotesRollUpSummary_ChildCaseNotes_ACE from '@salesforce/label/c.NotesRollUpSummary_ChildCaseNotes_ACE';
import NotesRollUpSummary_CSTTimeZone_ACE from '@salesforce/label/c.NotesRollUpSummary_CSTTimeZone_ACE';
import CaseNotesModal_CASE_ACE from '@salesforce/label/c.CaseNotesModal_CASE_ACE';
import CaseNotesModal_Notes_ACE from '@salesforce/label/c.CaseNotesModal_Notes_ACE';
import CaseNotesModal_Refresh_ACE from '@salesforce/label/c.CaseNotesModal_Refresh_ACE';
import ViewCaseSummary_NoCasesError_ACE from '@salesforce/label/c.ViewCaseSummary_NoCasesError_ACE';
import HideContentNotesOnViewNotes_ACE from '@salesforce/label/c.HideContentNotesOnViewNotes_ACE';
import ACCOUNT_ID_FIELD from '@salesforce/schema/Account.Id';
import DEVELOPER_NAME_FIELD from '@salesforce/schema/Account.RecordType.DeveloperName';
const fields = [ACCOUNT_ID_FIELD, DEVELOPER_NAME_FIELD];

export default class CaseNotesViewTableLwcAce extends LightningElement {    
    @wire(EnclosingTabId) enclosingTabId;
    recordId;
    @api label = {
        NotesRollUpSummary_CaseNotes_ACE,
        NotesRollUpSummary_ParentCaseNotes_ACE,
        NotesRollUpSummary_ChildCaseNotes_ACE,
        NotesRollUpSummary_CSTTimeZone_ACE,
        CaseNotesModal_CASE_ACE,
        CaseNotesModal_Notes_ACE,
        CaseNotesModal_Refresh_ACE,
        ViewCaseSummary_NoCasesError_ACE,
        HideContentNotesOnViewNotes_ACE
    };
    @api boolCaseNotesAvailable = false;
    @api boolParentCaseNotesAvailable = false;
    @api boolChildCaseNotesAvailable = false;
    @api boolShowWarning = false;
    @api fromNotepad;
    @api currTabId;
    boolShowSpinner = false;
    @api caseDetails = {};
    @api lstOwnNotes = {};
    @api lstParentNotes = {};
    @api lstChildNotes = {};
    @api strCaseTypeCategory = null;
    @api strCaseId;
    @api strCaseNumber;
    @api strCaseType;
    @api strCaseSubType;
    @api lstOwnRelatedDetails;
     //CEAS-71333
    @api boolSiebelRecordNote = false;
    objAccRecords;
    strCaseSubTypeFinal;
    boolwireUserCalled = false;
    objParsedTabData;
    error; 


    @wire(getRecord, {
        recordId: '$recordId',
        fields: fields
    }) wireuser({
        error,
        data
    }) {
        if (error) {
            this.error = error;
        } else if (data) {
            this.objAccRecords=data.fields;
            this.boolShowSpinner=false;
        }else{
            //do nothing
        }
        this.boolwireUserCalled = true;
    }

    get hideAllNotes() {
        return BaseLWC.stringIsNotBlank(this.label.HideContentNotesOnViewNotes_ACE) && this.label.HideContentNotesOnViewNotes_ACE.toLowerCase() === 'true';
    }

    connectedCallback() {
        this.boolShowSpinner=true;
        this.strCaseSubTypeFinal = this.strCaseSubType;
        if (this.strCaseSubType === 'Prior Authorization') {
            this.strCaseSubTypeFinal = "Preauth";
        }
        if (this.strCaseSubType === 'Grievance / Complaint') {
			this.strCaseSubTypeFinal = "Grievance / Member Complaint";
		}
		if (this.strCaseSubType === 'Member Portal (BAM)') {
			this.strCaseSubTypeFinal = "Member Portal";
		}
		if (this.strCaseSubType === 'Prospective Member') {
			this.strCaseSubTypeFinal = "Temporary Member";
		}
		if (this.strCaseSubType === 'Prior Authorization') {
			this.strCaseSubTypeFinal = "Preauth";
		}
        let currTabId = this.enclosingTabId;
        if (this.fromNotepad) {
            currTabId = this.currTabId;
        }
        if (currTabId) {
            //Get Tab Data
            getTabInfo(currTabId).then(objTabData => {
                const objParsedTabData = JSON.parse(JSON.stringify(objTabData));
                
                if (objParsedTabData.url) {
                    this.recordId = objParsedTabData.recordId;
                    this.objParsedTabData = objParsedTabData;
                    if(!this.recordId && this.boolwireUserCalled) {
                        this.boolShowSpinner=false;
                    }
                }
            }).catch(() => {
                //Do nothing
            })
        }
    }

    navigateToRecordViewPage=(objEvent)=>{
        const strCaseId = objEvent.currentTarget.dataset.id;
        const strCaseNumber = objEvent.currentTarget.dataset.casenumber;
        
        const strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.objParsedTabData.url);
        
        if (!BaseLWC.isValidUrl(strDecodedURL)) {
            return
        }
        
        const objUrl = new URL(strDecodedURL);
        const strProducerId = objUrl.searchParams.get("producerId");
        const strUrlMemberId = objUrl.searchParams.get("mid");
        const boolProspectMember = objUrl.searchParams.has("boolProspectMember") && objUrl.searchParams.get("boolProspectMember") === 'true';
        let strParams = '?mid=' + strUrlMemberId + '&caseNumber=' + strCaseNumber;
        if (boolProspectMember) {
            strParams += '&boolProspectMember=true&boolProducer=false&boolURLFormed=true'
        } else {
            let strRecordType;
            if(this.objAccRecords) {
                strRecordType = this.objAccRecords.RecordType.value.fields.DeveloperName.value;
            } else if(typeof strProducerId === 'string' && strProducerId.length) {
                strRecordType = 'Producer_ACE';
            } else {
                //DO Nothing
            }
            if (strRecordType === 'Producer_ACE') {
                strParams += '&boolProducer=true&producerId=' + strProducerId
            } else {
                strParams += '&boolProducer=false'
            }
        }

        const strUrl = '/lightning/r/Case/' + strCaseId + '/view' + BaseLWC.helperBaseEncodeUrl(strParams);
        const strTabId=((this.objParsedTabData.isSubtab && this.objParsedTabData.parentTabId) ||
        (!this.objParsedTabData.isSubtab && this.objParsedTabData.tabId));
        if (strTabId) {
            openSubtab(strTabId, {url: strUrl, focus: true})
                .then(() => {
                    //Do nothing
                }).catch(() => {
                    //Do nothing
                })
        } else {
            return;
        }
        
    }

}