//import required Decorators
import { LightningElement, api, wire } from "lwc";

//import required static resource assets
import HCSCClaimsStaticResource_ACE from "@salesforce/resourceUrl/HCSCClaimsStaticResource_ACE";

//Import Shared JS files.
//Base LWC functions.
import BaseLWC from "c/baseLWCFunctions_CF";

//import platformWorkspaceApi
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';

//import required labels
import ViewPlanSummary_CardHeader_Refresh_ACE from "@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE";
import IntegrationFailMessage_ACE from "@salesforce/label/c.IntegrationFailMessage_ACE";
import SafeMode_ToastMessage_ACE from "@salesforce/label/c.SafeMode_ToastMessage_ACE";
import Message_warning_ACE from "@salesforce/label/c.MessageLightningComponent_Warning_ACE";
import Message_error_ACE from "@salesforce/label/c.Message_error_ACE";
import ProviderPNICard_CardHeader_ACE from "@salesforce/label/c.ProviderPNICard_CardHeader_ACE";
import ProviderPNICard_NPILabel_ACE from "@salesforce/label/c.ViewMedical_NPI_ACE";
import ProviderPNICard_ProviderNumberLabel_ACE from "@salesforce/label/c.ProviderSearchProviderNumberDataTable_ACE";
import ProviderPNICard_TaxIdLabel_ACE from "@salesforce/label/c.ProviderPNICard_TaxIdLabel_ACE";
import ProviderPNICard_ProviderOrgNameLabel_ACE from "@salesforce/label/c.ProviderPNICard_ProviderOrgNameLabel_ACE";
import ProviderPNICard_FirstNameLabel_ACE from "@salesforce/label/c.General_FirstName_ACE";
import ProviderPNICard_InstitutionLastNameLabel_ACE from "@salesforce/label/c.ProviderPNICard_InstitutionLastNameLabel_ACE";

import ProviderPNICard_StatusCodeLabel_ACE from "@salesforce/label/c.ViewClaimHistory_MedicalClaimStatusCode_ACE";
import ProviderPNICard_EffectiveDateLabel_ACE from "@salesforce/label/c.ProviderSearchEffectiveDate_ACE";
import ProviderPNICard_BillingProviderNumberLabel_ACE from "@salesforce/label/c.ProviderSearchBillingProvider_ACE";
import ProviderPNICard_ProviderAddressLabel_ACE from "@salesforce/label/c.ProviderSearchProviderAddress_ACE";

import ProviderPNICard_ProviderTypeLabel_ACE from "@salesforce/label/c.ProviderPNICard_ProviderTypeLabel_ACE";
import ProviderPNICard_ProviderSpecialityLabel_ACE from "@salesforce/label/c.SRDetailsView_ProviderSpecialty_ACE";
import ProviderPNICard_NetworkCodesLabel_ACE from "@salesforce/label/c.ProviderSearchNetworkCode_ACE";
import ProviderPNICard_ContractEffectiveDateLabel_ACE from "@salesforce/label/c.ProviderPNICard_ContractEffectiveDateLabel_ACE";
import ProviderPNICard_ContractTerminationDateLabel_ACE from "@salesforce/label/c.ProviderPNICard_ContractTerminationDateLabel_ACE";

//CEAS-75947
import lblEnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';

//import required apex classes
import providerNetworkInfoSearchResultCallout from "@salesforce/apexContinuation/SafeModeController_ACE.providerNetworkInfoSearchResultCallout";
import providerNetworkStatusCallout from "@salesforce/apexContinuation/SafeModeController_ACE.providerNetworkStatusCallout";
import safeModeUserData from "@salesforce/apex/SafeModeController_ACE.fetchUserDetails";

export default class LwcProviderNetworkInformationCardACE extends LightningElement {

     //wire
    @wire(EnclosingTabId) enclosingTabId;

    imageSource =
        HCSCClaimsStaticResource_ACE + "/Images/Rendering_Provider_Information.svg";
    boolshowPNICard = false;
    boolShowSpinner = false;
    boolShowSafeMode = false;
    boolShowNetworkBadge = false;
    boolAPIError = false;
    boolNoNetworkCodes = true;
    strProviderCorpEntity = "";
    strProviderNumber = "";
    objLocalstorageProviderData = "";
    objProviderUIData = {};
    objTabData = {};
    objCardError = {};
    boolCustomProvider = false;
    boolCaseProvider = false;
    boolCaseProviderFieldsBlank = false;
    boolCaseNoProviderFound = false;
    boolCaseRefresh = false;
    @api objectApiName;
    boolCaseProviderIndicator = false;
    strNetworkStatus = "";
    objPlanSummaryData = {};
    objProviderNetworkData = {};
    boolInNetwork = false;
    boolOutOfNetwork = false;
    boolNetworkUnAvailable = false;
    boolNetworkUnknown = false;
    boolBadgeLoaded = false;
    networkFinalValue = "";
    boolShowToolTipText = false;
    boolPlanSummaryData = false;
    boolProviderCheck = false;
    strCategory = "";
    strInNetworkValue = "";
    objUpdatedProviderData = {};
    npiInList = false;
    strNPIListValue = "";
    boolNetworkStatusLoaded = false;
    boolProspectAccount = false;
    //CEAS-76730 - Add Corp code to bypass speciality check in validateProviderData method.
    corpCodesArray = ['IL', 'IL1'];
    boolShowAttested = false;

    infoImageURL = HCSCClaimsStaticResource_ACE + "/Images/info.png";
    label = {
        ViewPlanSummary_CardHeader_Refresh_ACE,
        IntegrationFailMessage_ACE,
        SafeMode_ToastMessage_ACE,
        ProviderPNICard_CardHeader_ACE,
        ProviderPNICard_NPILabel_ACE,
        ProviderPNICard_ProviderNumberLabel_ACE,
        ProviderPNICard_TaxIdLabel_ACE,
        ProviderPNICard_ProviderOrgNameLabel_ACE,
        ProviderPNICard_FirstNameLabel_ACE,
        ProviderPNICard_InstitutionLastNameLabel_ACE,
        ProviderPNICard_StatusCodeLabel_ACE,
        ProviderPNICard_EffectiveDateLabel_ACE,
        ProviderPNICard_BillingProviderNumberLabel_ACE,
        ProviderPNICard_ProviderAddressLabel_ACE,
        ProviderPNICard_ProviderTypeLabel_ACE,
        ProviderPNICard_ProviderSpecialityLabel_ACE,
        ProviderPNICard_NetworkCodesLabel_ACE,
        ProviderPNICard_ContractEffectiveDateLabel_ACE,
        ProviderPNICard_ContractTerminationDateLabel_ACE,
        Message_warning_ACE,
        Message_error_ACE,
        lblEnableVPSTabSpecificEvents_ACE
    };

    connectedCallback() {
        try {
            this.boolShowSpinner = true;
            this.fetchTabData();
        } catch (error) {
            this.handleErrors(error);
        }
    }

    /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     * All components should have this code.
     */
    fetchTabData = () => {
        if(this.enclosingTabId){
            getTabInfo(this.enclosingTabId).then((objTabData) => {
            this.objTabData = objTabData;
            const strURL = this.objTabData.url;
            //CEAS-60593 -PNI CARD FOR TEMP MEMBERS
            const prospectCheck = BaseLWC.helperBaseGetUrlParameters("boolProspectMember", strURL);
            if(prospectCheck) {
                this.boolProspectAccount = true;
                this.boolBadgeLoaded = true;
                this.boolShowNetworkBadge = true;
                this.boolNetworkStatusLoaded = true;
            }
            this.fetchSafeModeUserData();
            this.checkForProviderDetails();
            this.captureUpdatedInfo();
            if(!prospectCheck) {
            this.planSummaryListener();
            this.planChangeListener();
            }
        }).catch((error) => {
            this.handleErrors(error);
        });
    }
    };

    /**
     * Capture Updated Provider Information.
     */
    captureUpdatedInfo() {
        const strCaptureProviderEvent =
            "ProviderUpdatedInfo_" + this.objTabData.tabId;
        window.addEventListener(
            strCaptureProviderEvent,
            this.captureProviderListener,
            false
        );
    }

    /*
     * Capture plan summary data.
     */

    planSummaryListener() {
        if (BaseLWC.stringIsNotBlank(this.label.lblEnableVPSTabSpecificEvents_ACE) && this.label.lblEnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
            window.addEventListener("PlanSummaryEvent_"+ this.objTabData.tabId,this.capturePlanSummaryListener);
         } else {
         window.addEventListener("PlanSummaryEvent",this.capturePlanSummaryListener);
         }
    }

    /*
     * Capture updated plan summary data.
     */

    planChangeListener() {
        if (BaseLWC.stringIsNotBlank(this.label.lblEnableVPSTabSpecificEvents_ACE) && this.label.lblEnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
            window.addEventListener("PlanChangedCustomEvent_"+ this.objTabData.tabId,this.capturePlanChangeListener);
         } else {
            window.addEventListener("PlanChangedCustomEvent",this.capturePlanChangeListener);
         }
    }

    /**
     * Fire Event to Open Modal.
     */
    openProviderModal() {
        const strProviderEvent = "OpenProviderModal_" + this.objTabData.tabId;
        const objProviderEvent = new CustomEvent(strProviderEvent, {
            detail: JSON.stringify(this.objProviderUIData)
        });
        window.dispatchEvent(objProviderEvent);
    }

    /**
     * Capture Provider Information from Event.
     */
    captureProviderListener = (providerDataEvent) => {
        this.resetProviderCaseFlags();

        if (
            BaseLWC.isNotUndefinedOrNull(providerDataEvent.detail) &&
            typeof providerDataEvent.detail === "string"
        ) {
            const objData = JSON.parse(providerDataEvent.detail);
            this.objUpdatedProviderData = objData;
            if (
                BaseLWC.isNotUndefinedOrNull(
                    objData.objProviderDetails.boolCustomProviderData
                )
            ) {
                this.boolCustomProvider = true;
                const objProviderCustomData = JSON.parse(
                    objData.objProviderDetails.strCustomProviderInfoData
                );
                this.setCustomProviderData(
                    objProviderCustomData,
                    objData.objProviderDetails.strCustomProviderInfoData
                );
                this.updateProviderStorage(
                    null,
                    true,
                    objData.objProviderDetails.strCustomProviderInfoData
                );

                const strURL = this.objTabData.url;
                const strURLMid = BaseLWC.helperBaseGetUrlParameters("mid", strURL);
                const strProviderEvent = "ProviderInfoUpdate_" + strURLMid;
                const objProviderEvent = new CustomEvent(strProviderEvent, {
                    detail: JSON.stringify(objData.objProviderDetails)
                });
                window.dispatchEvent(objProviderEvent);
            } else {
                this.boolCustomProvider = false;
                const objProviderUpdatedData = objData.objProviderDetails;
                this.updateProviderStorage(objProviderUpdatedData, false, null);
                this.formatUI(objProviderUpdatedData);
                this.objProviderNetworkData = objProviderUpdatedData;
                if (
                    !this.boolProspectAccount &&
                    this.validateProviderData() &&
                    BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData) &&
                    this.objPlanSummaryData.strAceLineOfBusiness &&
                    (this.objPlanSummaryData.strAceLineOfBusiness === "GMS" ||
                        this.objPlanSummaryData.strAceLineOfBusiness === "Retail")
                ) {
                    this.fetchNetworkData();
                } else {
                    this.boolNetworkStatusLoaded = true;
                    this.updateProviderStorage(objProviderUpdatedData, false, null);
                }
                this.objProviderNetworkData.strNetworkStatus = this.networkFinalValue;
                this.updateProviderStorage(this.objProviderNetworkData, false, null);
            }
        }
        this.refreshCard();
    };

    /**
     * Capture plan summary Information from Event.
     */
    capturePlanSummaryListener = (planSummaryDataEvent) => {
        if (
            BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail) &&
            typeof planSummaryDataEvent.detail === "string"
        ) {
            const PlanSummaryData = JSON.parse(planSummaryDataEvent.detail);
            this.objPlanSummaryData =
                PlanSummaryData.objParameters.objMessage.objSelectedPlanDetails;
            if (BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData)) {
                if (BaseLWC.stringIsNotBlank(this.label.lblEnableVPSTabSpecificEvents_ACE) && this.label.lblEnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                    window.removeEventListener("PlanSummaryEvent_"+ this.objTabData.tabId, this.capturePlanSummaryListener);
                } else {
                    window.removeEventListener("PlanSummaryEvent",this.capturePlanSummaryListener);
                 }
                this.boolPlanSummaryData = true;
                this.validatePlanSummaryData(this.objPlanSummaryData);
                if (this.boolProviderCheck) {
                    if (
                        !this.boolProspectAccount &&
                        this.validateProviderData() &&
                        BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData) &&
                        (this.objPlanSummaryData.strAceLineOfBusiness === "GMS" ||
                            this.objPlanSummaryData.strAceLineOfBusiness === "Retail")
                    ) {
                        this.fetchNetworkData();
                    } else {
                        if (
                            BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData) &&
                            this.objPlanSummaryData.strAceLineOfBusiness === "FEP"
                        ) {
                            this.boolBadgeLoaded = true;
                            this.boolShowNetworkBadge = false;
                        }
                        if (BaseLWC.isNotUndefinedOrNull(this.objProviderNetworkData)) {
                            this.boolNetworkStatusLoaded = true;
                            this.updateProviderStorage(
                                this.objProviderNetworkData,
                                false,
                                null
                            );
                        }
                    }
                }
            }
        }
    };

    /**
     * Capture plan change Information from Event.
     */
    capturePlanChangeListener = (planChangeDataEvent) => {
        if (BaseLWC.isNotUndefinedOrNull(planChangeDataEvent.detail)) {
            this.boolShowNetworkBadge = false;
            this.boolBadgeLoaded = false;
            const objPlanChangeData = JSON.parse(planChangeDataEvent.detail);
            this.objPlanSummaryData = objPlanChangeData.objParameters.objMessage;
            if (
                !this.boolProspectAccount &&
                this.validateProviderData() &&
                BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData) &&
                (this.objPlanSummaryData.strAceLineOfBusiness === "GMS" ||
                    this.objPlanSummaryData.strAceLineOfBusiness === "Retail")
            ) {
                this.validatePlanSummaryData(this.objPlanSummaryData);
                this.fetchNetworkData();
            } else {
                if (
                    BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData) &&
                    this.objPlanSummaryData.strAceLineOfBusiness === "FEP"
                ) {
                    this.boolBadgeLoaded = true;
                    this.boolShowNetworkBadge = false;
                }
                if (BaseLWC.isNotUndefinedOrNull(this.objProviderNetworkData)) {
                    this.boolNetworkStatusLoaded = true;
                    this.updateProviderStorage(this.objProviderNetworkData, false, null);
                }
            }
        }
    };

    /**
     * Update provider Storage.
     */
    updateProviderStorage(
        objProviderUpdatedData,
        boolCustomProviderData,
        strCustomProviderData
    ) {
        const strURL = this.objTabData.url;
        const strMid = BaseLWC.helperBaseGetUrlParameters("mid", strURL);
        const strProviderData = window.localStorage.getItem("lstProviderData_ACE");
        if (strProviderData !== null && strProviderData !== "") {
            const lstProviderStorage = JSON.parse(strProviderData);
            const lstUpdatedData = [];
            lstProviderStorage.forEach((element) => {
                if (element.mid !== strMid) {
                    lstUpdatedData.push(element);
                }
            });
            const boolCaseProviderData = this.boolCaseProviderIndicator;
            let strProviderCaseDetails = null;
            if (boolCaseProviderData === true) {
                if(typeof objProviderUpdatedData === "string") {
                    strProviderCaseDetails = objProviderUpdatedData;
                    if(objProviderUpdatedData !== ""){
                        try{
                            objProviderUpdatedData = JSON.parse(objProviderUpdatedData);
                        } catch(objException){
                            this.handleErrors(objException);
                        }
                    }
                } else {
                    strProviderCaseDetails = JSON.stringify(objProviderUpdatedData);
                }
            }
            let objSelectedData = {};
            if (boolCustomProviderData) {
                objSelectedData = this.setCustomDataInStorage(strCustomProviderData);
            } else {
                objSelectedData = {
                    mid: strMid,
                    pfinKeyId: objProviderUpdatedData.strProviderNumber,
                    corpEntityCode: objProviderUpdatedData.strstateCode,
                    boolCaseProviderData: boolCaseProviderData,
                    strProviderCaseDetails: strProviderCaseDetails,
                    boolCustomProviderData: false,
                    strCustomProviderData: null,
                    strNpid: objProviderUpdatedData.strNPI,
                    providerDetails: JSON.stringify(objProviderUpdatedData),
                    strNetworkStatus: this.networkFinalValue,
                    boolNetworkStatusLoaded: this.boolNetworkStatusLoaded
                };
            }
            lstUpdatedData.push(objSelectedData);
            window.localStorage.setItem(
                "lstProviderData_ACE",
                JSON.stringify(lstUpdatedData)
            );
        }
    }

    /**
     * Set CustomData In Storage.
     */
    setCustomDataInStorage = (strCustomProviderData) => {
        const strURL = this.objTabData.url;
        const strMid = BaseLWC.helperBaseGetUrlParameters("mid", strURL);
        let objCustomProviderData = {};
        objCustomProviderData = {
            mid: strMid,
            pfinKeyId: null,
            corpEntityCode: null,
            strNpid: null,
            boolCaseProviderData: false,
            strProviderCaseDetails: null,
            boolCustomProviderData: true,
            strCustomProviderData: strCustomProviderData,
            providerDetails: strCustomProviderData
        };
        return objCustomProviderData;
    };

    /**
     * Format UI Data.
     */
    formatUIData(strData) {
        if (BaseLWC.isNotUndefinedOrNull(strData)) {
            return strData;
        } else {
            return "-";
        }
    }

    /**
     * Hide Info Popup.
     */
    hideInfoPopup = (event) => {
        if (
            BaseLWC.isNotUndefinedOrNull(
                event.target.closest("div").querySelector(".info_tooltip")
            )
        ) {
            event.target
                .closest("div")
                .querySelector(".info_tooltip")
                .classList.add("slds-hide");
        }
    };

    /**
     * Display Info Popup.
     */
    displayInfoPopup = (event) => {
        if (
            BaseLWC.isNotUndefinedOrNull(
                event.target.closest("div").querySelector(".info_tooltip")
            )
        ) {
            event.target
                .closest("div")
                .querySelector(".info_tooltip")
                .classList.remove("slds-hide");
        }
    };

    /**
     * Set Custom Provider Data.
     */
    setCustomProviderData = (objCustomProviderData) => {
        this.objProviderUIData = {};
        this.objProviderUIData.strProviderNPI = this.formatUIData(
            objCustomProviderData.strNPI
        );
        this.objProviderUIData.strProviderTaxId = this.formatUIData(
            objCustomProviderData.strTaxID
        );
        this.objProviderUIData.strInstitutionalOrLastName = this.formatUIData(
            objCustomProviderData.strInstLstName
        );
        this.objProviderUIData.strProviderStatusCode = "-";
        this.objProviderUIData.strProviderNumber = "-";
        this.objProviderUIData.strProviderOrgName = "-";
        this.objProviderUIData.strProviderFirstName = "-";
        this.objProviderUIData.strEffectiveDate = "-";
        this.objProviderUIData.strProviderAddress = "-";
        this.objProviderUIData.strstateCode = this.formatUIData(
            objCustomProviderData.strstateCode
        );
        this.boolNoNetworkCodes = true;
        this.boolCustomProvider = true;
        this.boolshowPNICard = true;
        this.boolShowSpinner = false;
    };

    /**
     * Check For Provider Details.
     */
    checkForProviderDetails = () => {
        this.boolshowPNICard = false;
        this.boolCaseProviderIndicator = false;
        const strURL = this.objTabData.url;
        const boolIsProviderSearch = BaseLWC.helperBaseGetUrlParameters(
            "ProviderSearch",
            strURL
        );
        const strMid = BaseLWC.helperBaseGetUrlParameters("mid", strURL);
        const strProviderData = window.localStorage.getItem("lstProviderData_ACE");
        if (strProviderData !== null && strProviderData !== "") {
            const lstProviderData = JSON.parse(strProviderData);
            let objProviderData = null;
            lstProviderData.forEach((element) => {
                if (element.mid === strMid) {
                    objProviderData = element;
                    this.strNPIListValue = element.strNpid;
                }
            });
            this.boolCustomProvider = false;
            if (
                objProviderData !== null &&
                boolIsProviderSearch &&
                boolIsProviderSearch === "true"
            ) {
                if (
                    objProviderData.boolCustomProviderData &&
                    objProviderData.strCustomProviderData !== null
                ) {
                    const objCustomProviderData = JSON.parse(
                        objProviderData.strCustomProviderData
                    );
                    this.setCustomProviderData(objCustomProviderData);
                    this.updateProviderStorage(
                        null,
                        true,
                        objProviderData.strCustomProviderData
                    );
                } else if (
                    objProviderData.boolCaseProviderData &&
                    objProviderData.strProviderCaseDetails !== null
                ) {
                    let objCaseProviderData = {};
                    if (typeof objProviderData.strProviderCaseDetails === "string") {
                        objCaseProviderData = JSON.parse(
                            objProviderData.strProviderCaseDetails
                        );
                    } else {
                        objCaseProviderData = objProviderData.strProviderCaseDetails;
                    }
                    this.strNPIListValue = objCaseProviderData.strNPI;
                    this.strProviderNumber = objCaseProviderData.strProviderNumber;
                    if (
                        BaseLWC.isNotUndefinedOrNull(
                            objCaseProviderData.strProviderCorpCode
                        )
                    ) {
                        if (objCaseProviderData.strProviderCorpCode.length === 2) {
                            this.strProviderCorpEntity =
                                objCaseProviderData.strProviderCorpCode + "1";
                        } else {
                            this.strProviderCorpEntity =
                                objCaseProviderData.strProviderCorpCode;
                        }
                    } else if (
                        BaseLWC.isNotUndefinedOrNull(
                            objCaseProviderData.strcorporateEntityCode
                        )
                    ) {
                        this.strProviderCorpEntity =
                            objCaseProviderData.strcorporateEntityCode;
                    } else {
                        //do nothing
                    }
                    this.boolshowPNICard = true;
                    this.boolCaseProviderIndicator = true;
                    this.getProviderDataFromCase(objCaseProviderData);
                } else {
                    this.strProviderNumber = objProviderData.pfinKeyId;
                    if (
                        objProviderData.corpEntityCode &&
                        objProviderData.corpEntityCode.length === 2
                    ) {
                        this.strProviderCorpEntity = objProviderData.corpEntityCode + "1";
                    } else {
                        this.strProviderCorpEntity = objProviderData.corpEntityCode;
                    }
                    this.boolshowPNICard = true;
                   //CEAS-84982
                   if((this.strProviderCorpEntity === 'TX1' || this.strProviderCorpEntity === 'attested') && !BaseLWC.isNotUndefinedOrNull(this.strProviderNumber)) {
                     this.fetchAttestedProviderData(objProviderData.providerDetails);
                    }
                    else {
                        this.fetchProviderData();
                    }
                }
            }
        }
    };

    //CEAS-84982 - method to fetch Attested Provider Details
    fetchAttestedProviderData = (objAttestedProviderData) => {
        //console.log(JSON.stringify(objAttestedProviderData1));
        if (typeof objAttestedProviderData === "string") {
         objAttestedProviderData = JSON.parse(objAttestedProviderData);
        }
 
        if (objAttestedProviderData.strstateCode && objAttestedProviderData.strstateCode.length > 2) {
             objAttestedProviderData.strstateCode = objAttestedProviderData.strstateCode.substring(0,objAttestedProviderData.strstateCode.length-1);
        }
        let strProviderCorp= "";
        if (this.strProviderCorpEntity && this.strProviderCorpEntity === 'Attested') {
             strProviderCorp = this.strProviderCorpEntity.toLowerCase();
         }
         else {
             strProviderCorp = this.strProviderCorpEntity;
         }
        
         if (!BaseLWC.isNotUndefinedOrNull(objAttestedProviderData.strNPI)) {
            objAttestedProviderData.strNPI="";
        }

        if (!BaseLWC.isNotUndefinedOrNull(objAttestedProviderData.strTaxID)) {
            objAttestedProviderData.strTaxID="";
        }
 
        if (!BaseLWC.isNotUndefinedOrNull(objAttestedProviderData.strLastName)) {
             objAttestedProviderData.strLastName="";
         }
 
        let objRequestBody = {
         "npiNumber":objAttestedProviderData.strNPI,
         "taxIdNumber":objAttestedProviderData.strTaxID,
         "lastName":objAttestedProviderData.strLastName,
         "corporateEntityCode":strProviderCorp,
         "officeAddress":
             {
             "addressLine1":objAttestedProviderData.straddressLine1,
             "addressLine2":objAttestedProviderData.straddressLine2,
             "city":objAttestedProviderData.strcity,
             "stateCode":objAttestedProviderData.strstateCode,
             "postalCode":objAttestedProviderData.strpostalCode
             }
         };
     
        let strAttestedRequest = JSON.stringify(objRequestBody);
 
        if (
             (!BaseLWC.isNotUndefinedOrNull(objAttestedProviderData.strNPI) || !BaseLWC.isNotUndefinedOrNull(objAttestedProviderData.strTaxID)) && 
                 !(BaseLWC.isNotUndefinedOrNull(objAttestedProviderData.straddressLine1) && BaseLWC.isNotUndefinedOrNull(objAttestedProviderData.strpostalCode) && BaseLWC.isNotUndefinedOrNull(objAttestedProviderData.strcity)  && BaseLWC.isNotUndefinedOrNull(objAttestedProviderData.strstateCode)) && 
                 !BaseLWC.isNotUndefinedOrNull(this.strProviderCorpEntity))
           {
             this.boolshowPNICard = false;
         } else {
             if (
                 this.strProviderCorpEntity &&
                 this.strProviderCorpEntity.length === 2
             ) {
                 this.strProviderCorpEntity = this.strProviderCorpEntity + "1";
             }
 
             providerNetworkInfoSearchResultCallout({
                 strProviderNumber: this.strProviderNumber,
                 strProviderCorpEntity: this.strProviderCorpEntity,
                 strAttestedProviderDetails: strAttestedRequest,
                 boolAttestedCall: true
             }).then((objResult) => {
                 this.boolProviderCheck = true;
                 if (
                     BaseLWC.isNotUndefinedOrNull(objResult) &&
                     objResult !== "" &&
                     objResult !== "{}"
                 ) {
                     objResult = JSON.parse(objResult);
                     if (
                         BaseLWC.isNotUndefinedOrNull(objResult.strResponseStatusCode) &&
                         objResult.strResponseStatusCode !== "201" &&
                         objResult.strResponseStatusCode !== "200"
                     ) {
                         this.boolAPIError = true;
                         this.boolShowSpinner = false;
                     } else if (
                         (objResult.strResponseStatusCode === undefined ||
                             objResult.strResponseStatusCode === null) &&
                         this.objectApiName === "Account"
                     ) {
                         this.boolCaseProvider = true;
                         this.boolCaseNoProviderFound = true;
                         this.boolAPIError = false;
                         if (!this.boolCaseRefresh) {
                             this.refreshCard();
                         }
                     } else {
                         this.boolAPIError = false;
                         this.objProviderNetworkData = objResult;
                         if(this.strNPIListValue && this.objProviderNetworkData.strNPIList) {
                             this.npiInList = this.objProviderNetworkData.strNPIList.includes(
                                 this.strNPIListValue
                             );
                         }
                         if (this.objProviderNetworkData.strNPIList && !this.npiInList) {
                             objResult.strNPI = "";
                         }
                         if (!this.npiInList) {
                             objResult.strNPI = "";
                         } else {
                             objResult.strNPI = this.strNPIListValue;
                         }
                        if (objResult.strProviderCorpCode != null && objResult.strProviderCorpCode.toLowerCase()  === 'attested') {
                             objResult.strProviderCorpCode = 'Attested';
                         }
                         this.updateProviderStorage(objResult, false, null);
                         this.formatUI(objResult);
                         this.setCategory(
                             this.objProviderNetworkData.strProviderClassCode
                         );
                         if (this.boolPlanSummaryData) {
                             if (
                                 !this.boolProspectAccount &&
                                 this.validateProviderData() &&
                                 BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData) &&
                                 (this.objPlanSummaryData.strAceLineOfBusiness === "GMS" ||
                                     this.objPlanSummaryData.strAceLineOfBusiness === "Retail")
                             ) {
                                 this.objUpdatedProviderData = objResult;
                                 this.fetchNetworkData();
                             } else {
                                 if (
                                     BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData) &&
                                     this.objPlanSummaryData.strAceLineOfBusiness === "FEP"
                                 ) {
                                     this.boolBadgeLoaded = true;
                                     this.boolShowNetworkBadge = false;
                                 }
                                 this.boolNetworkStatusLoaded = true;
                                 this.updateProviderStorage(objResult, false, null);
                             }
                         }
                     }
                 } else {
                     this.boolshowPNICard = false;
                 }
                 this.boolShowSpinner = false;
             })
                 .catch((error) => {
                     this.handleErrors(error);
                 });
         }
     };

    /**
     * Helps to set the safemode message for safe mode user
     */
    fetchSafeModeUserData = () => {
        safeModeUserData({}).then((objResult) => {
            if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                this.boolShowSafeMode =
                    objResult.objSafeModeUser.Safe_Mode_Enabled_ACE__c;
                if (this.boolShowSafeMode === true) {
                    this.boolShowSpinner = false;
                }
            }
        })
            .catch(() => {
                this.boolShowSpinner = false;
            });
    };

    //method to fetch Provider Details
    fetchProviderData = () => {
        if (
            !BaseLWC.isNotUndefinedOrNull(this.strProviderNumber) ||
            !BaseLWC.isNotUndefinedOrNull(this.strProviderCorpEntity)
        ) {
            this.boolshowPNICard = false;
        } else {
            if (
                this.strProviderCorpEntity &&
                this.strProviderCorpEntity.length === 2
            ) {
                this.strProviderCorpEntity = this.strProviderCorpEntity + "1";
            }

            providerNetworkInfoSearchResultCallout({
                strProviderNumber: this.strProviderNumber,
                strProviderCorpEntity: this.strProviderCorpEntity,
                strAttestedProviderDetails: null,
                boolAttestedCall: false
            }).then((objResult) => {
                this.boolProviderCheck = true;
                if (
                    BaseLWC.isNotUndefinedOrNull(objResult) &&
                    objResult !== "" &&
                    objResult !== "{}"
                ) {
                    objResult = JSON.parse(objResult);
                    if (
                        BaseLWC.isNotUndefinedOrNull(objResult.strResponseStatusCode) &&
                        objResult.strResponseStatusCode !== "201" &&
                        objResult.strResponseStatusCode !== "200"
                    ) {
                        this.boolAPIError = true;
                        this.boolShowSpinner = false;
                    } else if (
                        (objResult.strResponseStatusCode === undefined ||
                            objResult.strResponseStatusCode === null) &&
                        this.objectApiName === "Account"
                    ) {
                        this.boolCaseProvider = true;
                        this.boolCaseNoProviderFound = true;
                        this.boolAPIError = false;
                        if (!this.boolCaseRefresh) {
                            this.refreshCard();
                        }
                    } else {
                        this.boolAPIError = false;
                        this.objProviderNetworkData = objResult;
                        if(this.strNPIListValue && this.objProviderNetworkData.strNPIList) {
                            this.npiInList = this.objProviderNetworkData.strNPIList.includes(
                                this.strNPIListValue
                            );
                        }
                        if (this.objProviderNetworkData.strNPIList && !this.npiInList) {
                            objResult.strNPI = "";
                        }
                        if (!this.npiInList) {
                            objResult.strNPI = "";
                        } else {
                            objResult.strNPI = this.strNPIListValue;
                        }
                        this.updateProviderStorage(objResult, false, null);
                        this.formatUI(objResult);
                        this.setCategory(
                            this.objProviderNetworkData.strProviderClassCode
                        );
                        if (this.boolPlanSummaryData) {
                            if (
                                !this.boolProspectAccount &&
                                this.validateProviderData() &&
                                BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData) &&
                                (this.objPlanSummaryData.strAceLineOfBusiness === "GMS" ||
                                    this.objPlanSummaryData.strAceLineOfBusiness === "Retail")
                            ) {
                                this.objUpdatedProviderData = objResult;
                                this.fetchNetworkData();
                            } else {
                                if (
                                    BaseLWC.isNotUndefinedOrNull(this.objPlanSummaryData) &&
                                    this.objPlanSummaryData.strAceLineOfBusiness === "FEP"
                                ) {
                                    this.boolBadgeLoaded = true;
                                    this.boolShowNetworkBadge = false;
                                }
                                this.boolNetworkStatusLoaded = true;
                                this.updateProviderStorage(objResult, false, null);
                            }
                        }
                    }
                } else {
                    this.boolshowPNICard = false;
                }
                this.boolShowSpinner = false;
            })
                .catch((error) => {
                    this.handleErrors(error);
                });
        }
    };
    //CEAS=50354
    //Setting category value as per strProviderClassCode value from Provider Network data
    setCategory(categoryValue) {
        if (categoryValue === "P") {
            this.strCategory = '"' + "Professional" + '"';
        } else if (categoryValue === "F" || categoryValue === "C") {
            this.strCategory = '"' + "Institutional" + '"';
        } else {
            this.strCategory = null;
        }
    }
    // CEAS-50354
    // fetch network status
    fetchNetworkData = () => {
        providerNetworkStatusCallout({
            serviceDate: new Date().toJSON().slice(0, 10).replace(/-/g, "-"),
            alphaPrefix: this.objPlanSummaryData.alphaPrefix,
            subscriberId: this.objPlanSummaryData.strSubscriberId,
            insuredMemberCode: this.objPlanSummaryData.imcCode,
            subPartyId: this.objPlanSummaryData.subscriberPartyId,
            memberId: this.objPlanSummaryData.memberId,
            firstName: this.objPlanSummaryData.strfirstName,
            lastName: this.objPlanSummaryData.strlastname,
            relationshipCode: this.objPlanSummaryData.strRelationshipTypeCode,
            medicareEligibilityInd: this.objPlanSummaryData.medicareEligibility,
            dateOfBirth: this.objPlanSummaryData.strdateOfBirth,
            corporateEntityCode: this.objPlanSummaryData.strCorporationCode,
            groupNumber: this.objPlanSummaryData.strGroupNumber,
            sectionNumber: this.objPlanSummaryData.strGroupSectionNumber,
            packageCode: this.objPlanSummaryData.packageCode,
            productType: this.objPlanSummaryData.strProductType,
            planId: this.objPlanSummaryData.planId,
            category: this.strCategory,
            speciality: this.validateAPIParams(this.objProviderNetworkData.strProviderSpecialty, 'speciality'),
            providerType: this.validateAPIParams(this.objProviderNetworkData.strProviderType, 'providerType'),
            npi: '"' + this.objProviderNetworkData.strNPI + '"',
            taxId: '"' + this.objProviderNetworkData.strTaxID + '"',
            pfinNumber: '"' + this.strProviderNumber + '"',
            providerNetworkCodes: this.manipulateNetWorkCodes()
        }).then((objStatusResult) => {
            this.boolNetworkStatusLoaded = true;
            if (
                BaseLWC.isNotUndefinedOrNull(objStatusResult) &&
                objStatusResult !== "" &&
                objStatusResult !== "{}"
            ) {
                objStatusResult = JSON.parse(objStatusResult);
                if (
                    !BaseLWC.isNotUndefinedOrNull(
                        objStatusResult.providerNetworkServices
                    )
                ) {
                    this.boolNetworkUnAvailable = true;
                    this.resetNetworkBadgeFlags("apiError");
                    this.boolBadgeLoaded = true;
                    this.boolShowNetworkBadge = true;
                } else {
                    if (objStatusResult.providerNetworkServices === "" ||
                        !BaseLWC.isNotUndefinedOrNull(objStatusResult.providerNetworkServices[0].networkServices) ||
                        !BaseLWC.isNotUndefinedOrNull(objStatusResult.providerNetworkServices[0].networkServices[0].network) ||
                        !BaseLWC.isNotUndefinedOrNull(objStatusResult.providerNetworkServices[0].networkServices[0].network.status)) {
                        this.strNetworkStatus = "";
                    } else {
                        this.strNetworkStatus =
                            objStatusResult.providerNetworkServices[0].networkServices[0].network.status;
                        this.strInNetworkValue =
                            objStatusResult.providerNetworkServices[0].networkServices[0].network.binqTierDescription;
                    }
                    this.networkStatusCheck(this.strNetworkStatus);
                    this.objProviderNetworkData.strNetworkStatus = this.networkFinalValue;
                    this.boolShowNetworkBadge = true;
                }
            } else {
                this.boolshowPNICard = false;
            }
            this.updateProviderStorage(this.objProviderNetworkData, false, null);
            const strURL = this.objTabData.url;
            const strURLMid = BaseLWC.helperBaseGetUrlParameters("mid", strURL);
            const strProviderEvent = "ProviderInfoUpdate_" + strURLMid;
            const objProviderEvent = new CustomEvent(strProviderEvent, {
                    detail: JSON.stringify(this.objUpdatedProviderData)
            });
            window.dispatchEvent(objProviderEvent);
            this.boolShowSpinner = false;
        })
            .catch((error) => {
                this.handleErrors(error);
            });
    };

    //CEAS-79830 - SPECIALITY CHECK BYPASS NULL
    validateAPIParams(param, name) {
        if(!param || (param === 'null' || param === 'undefined')) {
            return null;
        } else {
            if(name === 'speciality') {
                return '"' + param.match(/\d/g).join("") + '"';
            } else {
                return '"' + param.substring(0,param.indexOf("-")) +'"';
            }
        }
    }
    
    manipulateNetWorkCodes = () => {
        if (
            BaseLWC.isNotUndefinedOrNull(
                this.objProviderNetworkData.strNetworkCodes
            ) &&
            this.objProviderNetworkData.strNetworkCodes.trim() !== ""
        ) {
            return (
                '"' +
                this.objProviderNetworkData.strNetworkCodes
                    .substring(
                        0,
                        this.objProviderNetworkData.strNetworkCodes.lastIndexOf("/")
                    )
                    .replace(/\//g, '","')
                    .replace(/\s/g, "") +
                '"'
            );
        } else {
            return "";
        }
    };

    /**
     * CEAS-50324
     * Check whether the Provider data is valid and returns boolean
     * @returns Boolean - whether provider data is valid
     */
    validateProviderData() {
        if (
            this.strProviderCorpEntity && this.corpCodesArray &&
           (this.corpCodesArray.includes(this.strProviderCorpEntity) || this.objProviderNetworkData.strProviderSpecialty) &&
            this.objProviderNetworkData.strProviderType &&
            this.objProviderNetworkData.strNPI &&
            this.objProviderNetworkData.strTaxID &&
            this.strProviderNumber
        ) {
            return true;
        } else {
            this.boolBadgeLoaded = true;
            this.boolShowNetworkBadge = true;
            this.boolNetworkUnknown = true;
            this.resetNetworkBadgeFlags("");
            return false;
        }
    }

    // CEAS-50534
    // Method to determine which network type to be shown on the PNI component.
    networkStatusCheck(networkValue) {
        switch (networkValue) {
            case "InNetwork":
                this.boolInNetwork = true;
                this.networkFinalValue = "In Network";
                this.resetNetworkBadgeFlags(networkValue);
                break;
            case "OutOfNetwork":
                this.boolOutOfNetwork = true;
                this.networkFinalValue = "Out of Network";
                this.resetNetworkBadgeFlags(networkValue);
                break;
            case "":
                this.boolNetworkUnknown = true;
                this.resetNetworkBadgeFlags(networkValue);
                break;
            default:
                break;
        }
        this.boolBadgeLoaded = true;
    }

    //show Network Codes hover message
    displayNetworkMessage = (event) => {
        if (
            BaseLWC.isNotUndefinedOrNull(
                event.target.closest("div").querySelector(".slds-popover_tooltip")
            )
        ) {
            event.target
                .closest("div")
                .querySelector(".slds-popover_tooltip")
                .classList.remove("slds-hide");
        }
    };

    //hide Network Codes hover message
    hideNetworkMessage = (event) => {
        if (
            BaseLWC.isNotUndefinedOrNull(
                event.target.closest("div").querySelector(".slds-popover_tooltip")
            )
        ) {
            event.target
                .closest("div")
                .querySelector(".slds-popover_tooltip")
                .classList.add("slds-hide");
        }
    };

    //on click of refresh button
    refreshCard = () => {
        try {
            this.boolShowSpinner = true;
            this.boolCaseRefresh = true;
            this.fetchSafeModeUserData();
            this.checkForProviderDetails();
        } catch (error) {
            this.handleErrors(error);
        }
    };

    /**
     * To handle Errors.
     * Helps to show case errors.
     * All components should have this code.
     */
    handleErrors = (error) => {
        //show Account API Error
        this.objCardError = error;
        this.boolAPIError = true;
        this.boolShowSpinner = false;
    };

    /* validate plan summary data to send as request for BINQ Callout*/
    validatePlanSummaryData = (objPlanSummaryData) => {
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.alphaPrefix) &&
            objPlanSummaryData.alphaPrefix !== ""
        ) {
            this.objPlanSummaryData.alphaPrefix =
                '"' + objPlanSummaryData.alphaPrefix + '"';
        } else {
            this.objPlanSummaryData.alphaPrefix = objPlanSummaryData.alphaPrefix;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.strSubscriberId) &&
            objPlanSummaryData.strSubscriberId !== ""
        ) {
            this.objPlanSummaryData.strSubscriberId =
                '"' + objPlanSummaryData.strSubscriberId + '"';
        } else {
            this.objPlanSummaryData.strSubscriberId =
                objPlanSummaryData.strSubscriberId;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.imcCode) &&
            objPlanSummaryData.imcCode !== ""
        ) {
            this.objPlanSummaryData.imcCode = '"' + objPlanSummaryData.imcCode + '"';
        } else {
            this.objPlanSummaryData.imcCode = objPlanSummaryData.imcCode;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.subscriberPartyId) &&
            objPlanSummaryData.subscriberPartyId !== ""
        ) {
            this.objPlanSummaryData.subscriberPartyId =
                '"' + objPlanSummaryData.subscriberPartyId + '"';
        } else {
            this.objPlanSummaryData.subscriberPartyId =
                objPlanSummaryData.subscriberPartyId;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.memberId) &&
            objPlanSummaryData.memberId !== ""
        ) {
            this.objPlanSummaryData.memberId =
                '"' + objPlanSummaryData.memberId + '"';
        } else {
            this.objPlanSummaryData.memberId = objPlanSummaryData.memberId;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.strfirstName) &&
            objPlanSummaryData.strfirstName !== ""
        ) {
            this.objPlanSummaryData.strfirstName =
                '"' + objPlanSummaryData.strfirstName + '"';
        } else {
            this.objPlanSummaryData.strfirstName = objPlanSummaryData.strfirstName;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.strlastname) &&
            objPlanSummaryData.strlastname !== ""
        ) {
            this.objPlanSummaryData.strlastname =
                '"' + objPlanSummaryData.strlastname + '"';
        } else {
            this.objPlanSummaryData.strlastname = objPlanSummaryData.strlastname;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(
                objPlanSummaryData.strRelationshipTypeCode
            ) &&
            objPlanSummaryData.strRelationshipTypeCode !== ""
        ) {
            this.objPlanSummaryData.strRelationshipTypeCode =
                '"' + objPlanSummaryData.strRelationshipTypeCode + '"';
        } else {
            this.objPlanSummaryData.strRelationshipTypeCode =
                objPlanSummaryData.strRelationshipTypeCode;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.medicareEligibility) &&
            objPlanSummaryData.medicareEligibility !== ""
        ) {
            this.objPlanSummaryData.medicareEligibility =
                '"' + objPlanSummaryData.medicareEligibility + '"';
        } else {
            this.objPlanSummaryData.medicareEligibility =
                objPlanSummaryData.medicareEligibility;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.strdateOfBirth) &&
            objPlanSummaryData.strdateOfBirth !== ""
        ) {
            this.objPlanSummaryData.strdateOfBirth =
                '"' + objPlanSummaryData.strdateOfBirth + '"';
        } else {
            this.objPlanSummaryData.strdateOfBirth =
                objPlanSummaryData.strdateOfBirth;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.strCorporationCode) &&
            objPlanSummaryData.strCorporationCode !== ""
        ) {
            this.objPlanSummaryData.strCorporationCode =
                '"' + objPlanSummaryData.strCorporationCode + '"';
        } else {
            this.objPlanSummaryData.strCorporationCode =
                objPlanSummaryData.strCorporationCode;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.strGroupNumber) &&
            objPlanSummaryData.strGroupNumber !== ""
        ) {
            this.objPlanSummaryData.strGroupNumber =
                '"' + objPlanSummaryData.strGroupNumber + '"';
        } else {
            this.objPlanSummaryData.strGroupNumber =
                objPlanSummaryData.strGroupNumber;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.strGroupSectionNumber) &&
            objPlanSummaryData.strGroupSectionNumber !== ""
        ) {
            this.objPlanSummaryData.strGroupSectionNumber =
                '"' + objPlanSummaryData.strGroupSectionNumber + '"';
        } else {
            this.objPlanSummaryData.strGroupSectionNumber =
                objPlanSummaryData.strGroupSectionNumber;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.packageCode) &&
            objPlanSummaryData.packageCode !== ""
        ) {
            this.objPlanSummaryData.packageCode =
                '"' + objPlanSummaryData.packageCode + '"';
        } else {
            this.objPlanSummaryData.packageCode = objPlanSummaryData.packageCode;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objPlanSummaryData.strProductType) &&
            objPlanSummaryData.strProductType !== ""
        ) {
            this.objPlanSummaryData.strProductType =
                '"' + objPlanSummaryData.strProductType + '"';
        } else {
            this.objPlanSummaryData.strProductType =
                objPlanSummaryData.strProductType;
        }
    };

    //set Data to be shown on UI
    formatUI = (objResult) => {
        if (BaseLWC.isNotUndefinedOrNull(objResult.strTaxID) && objResult.strTaxID !== "") {
            this.objProviderUIData.strProviderTaxId = objResult.strTaxID;
        } else {
            this.objProviderUIData.strProviderTaxId = objResult.strTaxID;
        }
        if (BaseLWC.isNotUndefinedOrNull(objResult.strcorporateEntityCode) && objResult.strcorporateEntityCode !== "") {
            this.objProviderUIData.strcorporateEntityCode = objResult.strcorporateEntityCode;
        } else {
            this.objProviderUIData.strcorporateEntityCode = "-";
        }
        if (BaseLWC.isNotUndefinedOrNull(objResult.strStatusCode) && objResult.strStatusCode !== "") {
            if (objResult.strStatusCode === "A") {
                this.objProviderUIData.strProviderStatusCode = "ACTIVE";
            } else {
                this.objProviderUIData.strProviderStatusCode = "HOLD";
            }
        } else {
            this.objProviderUIData.strProviderStatusCode = "-";
        }

        if (BaseLWC.isNotUndefinedOrNull(objResult.strProviderType) && objResult.strProviderType !== "") {
            this.objProviderUIData.strProviderType = objResult.strProviderType;
        } else {
            this.objProviderUIData.strProviderType = "-";
        }

        if (BaseLWC.isNotUndefinedOrNull(objResult.strProviderSpecialty) && objResult.strProviderSpecialty !== "") {
            this.objProviderUIData.strProviderSpecialty = objResult.strProviderSpecialty;
        } else {
            this.objProviderUIData.strProviderSpecialty = "-";
        }

        if (BaseLWC.isNotUndefinedOrNull(objResult.strProviderOrgName) && objResult.strProviderOrgName !== "") {
            this.objProviderUIData.strProviderOrgName = objResult.strProviderOrgName;
        } else {
            this.objProviderUIData.strProviderOrgName = "-";
        }

        if (BaseLWC.isNotUndefinedOrNull(objResult.strProviderNumber) && objResult.strProviderNumber !== "") {
            this.objProviderUIData.strProviderNumber = objResult.strProviderNumber;
        } //CEAS-84982
        else if((this.strProviderCorpEntity === 'TX1' || this.strProviderCorpEntity.toLowerCase() === 'attested') && !BaseLWC.isNotUndefinedOrNull(this.strProviderNumber)) {
            this.objProviderUIData.strProviderNumber = objResult.strProviderNumber;
        } 
        else {
            this.objProviderUIData.strProviderNumber = "-";
            this.boolshowPNICard = false;
        }

        if (BaseLWC.isNotUndefinedOrNull(objResult.strNPI) && objResult.strNPI !== "") {
            this.objProviderUIData.strProviderNPI = objResult.strNPI;
        } else {
            this.objProviderUIData.strProviderNPI = "-";
        }

        if (BaseLWC.isNotUndefinedOrNull(objResult.strFirstName) && objResult.strFirstName !== "") {
            this.objProviderUIData.strProviderFirstName = objResult.strFirstName;
            if (BaseLWC.isNotUndefinedOrNull(objResult.strLastName) && objResult.strLastName !== "") {
                this.objProviderUIData.strInstitutionalOrLastName = objResult.strLastName;
            } else {
                this.objProviderUIData.strInstitutionalOrLastName = "-";
            }
        } else {
            this.objProviderUIData.strProviderFirstName = "-";
            if (BaseLWC.isNotUndefinedOrNull(objResult.strInstitutionalName) && objResult.strInstitutionalName !== "") {
                this.objProviderUIData.strInstitutionalOrLastName = objResult.strInstitutionalName;
            } else {
                this.objProviderUIData.strInstitutionalOrLastName = "-";
            }
        }

        if (BaseLWC.isNotUndefinedOrNull(objResult.strBillingProviderNumber) && objResult.strBillingProviderNumber !== "") {
            this.objProviderUIData.strBillingProviderNumber = objResult.strBillingProviderNumber;
        } else {
            this.objProviderUIData.strBillingProviderNumber = "-";
        }

        this.objProviderUIData.strProviderAddress = "";
        if (BaseLWC.isNotUndefinedOrNull(objResult.straddressLine1) && objResult.straddressLine1 !== "") {
            this.objProviderUIData.strProviderAddress = this.objProviderUIData.strProviderAddress + objResult.straddressLine1;
        }
        if (BaseLWC.isNotUndefinedOrNull(objResult.straddressLine2) && objResult.straddressLine2 !== "") {
            if (this.objProviderUIData.strProviderAddress !== "") {
                this.objProviderUIData.strProviderAddress = this.objProviderUIData.strProviderAddress +
                                                            ", " + objResult.straddressLine2;
            } else {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress + objResult.straddressLine2;
            }
        }
        if (BaseLWC.isNotUndefinedOrNull(objResult.strcity) && objResult.strcity !== "") {
            if (this.objProviderUIData.strProviderAddress !== "") {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress + ", " + objResult.strcity;
            } else {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress + objResult.strcity;
            }
        }
        if (BaseLWC.isNotUndefinedOrNull(objResult.strstateCode) && objResult.strstateCode !== "") {
            if (this.objProviderUIData.strProviderAddress !== "") {
                this.objProviderUIData.strProviderAddress = this.objProviderUIData.strProviderAddress +
                                                            ", " + objResult.strstateCode;
            } else {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress + objResult.strstateCode;
            }

            if (objResult.strstateCode.length === 2) {
                this.objProviderUIData.strstateCode = objResult.strstateCode + "1";
            }
        }
        if (BaseLWC.isNotUndefinedOrNull(objResult.strpostalCode) && objResult.strpostalCode !== "") {
            if (this.objProviderUIData.strProviderAddress !== "") {
                this.objProviderUIData.strProviderAddress = this.objProviderUIData.strProviderAddress +
                    " " + objResult.strpostalCode;
            } else {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress + objResult.strpostalCode;
            }
        }
        if (this.objProviderUIData.strProviderAddress === "") {
            this.objProviderUIData.strProviderAddress = "-";
        }

        if (BaseLWC.isNotUndefinedOrNull(objResult.strEffectiveDate) && objResult.strEffectiveDate !== "") {
            this.objProviderUIData.strEffectiveDate = BaseLWC.dateFormatterHelper(objResult.strEffectiveDate);
        } else {
            this.objProviderUIData.strEffectiveDate = "-";
        }

        //CEAS-78793 
        if (BaseLWC.isNotUndefinedOrNull(objResult.strNetworkCodes) && objResult.strNetworkCodes !== "" 
            && objResult.strNetworkCodes.toLowerCase() == 'attested') {
                this.objProviderUIData.lstNetworkCodes = objResult.strNetworkCodes.toUpperCase();
                this.boolShowAttested = true;
        } else if (BaseLWC.isNotUndefinedOrNull(objResult.networkDetails) && objResult.networkDetails.length > 0) {
            this.boolNoNetworkCodes = false;
             this.boolShowAttested = false;
            objResult.networkDetails.sort((objData1, objData2) => {
                if (objData1.networkCode > objData2.networkCode) {
                    return 1;
                } else {
                    return -1;
                }
            });
            this.objProviderUIData.lstNetworkCodes = [];
            objResult.networkDetails.forEach((data, index) => {
                data.effectiveDate = BaseLWC.dateFormatterHelper(data.effectiveDate);
                data.endDate = BaseLWC.dateFormatterHelper(data.endDate);
                if (index === objResult.networkDetails.length - 1) {
                    data.boolIsLastData = true;
                } else {
                    data.boolIsLastData = false;
                }
                this.objProviderUIData.lstNetworkCodes.push(data);
            });
        } else {
            this.objProviderUIData.lstNetworkCodes = [];
            this.boolNoNetworkCodes = true;
            this.boolShowAttested = false;
        }
    };

    setCaseProviderData = (objCaseProviderData) => {
        this.updateProviderStorage(objCaseProviderData, false, null);
        this.objProviderUIData = {};
        this.objProviderUIData.strProviderNPI = this.formatUIData(
            objCaseProviderData.strNPI
        );
        this.objProviderUIData.strProviderTaxId = this.formatUIData(
            objCaseProviderData.strTaxID
        );
        this.objProviderUIData.strInstitutionalOrLastName = this.formatUIData(
            objCaseProviderData.strLastName
        );
        this.objProviderUIData.strProviderStatusCode = "-";
        this.objProviderUIData.strProviderNumber = this.formatUIData(
            objCaseProviderData.strProviderNumber
        );
        this.objProviderUIData.strProviderOrgName = "-";
        this.objProviderUIData.strProviderFirstName = "-";
        this.objProviderUIData.strEffectiveDate = "-";

        //format address
        this.objProviderUIData.strProviderAddress = "";
        if (
            BaseLWC.isNotUndefinedOrNull(objCaseProviderData.straddressLine1) &&
            objCaseProviderData.straddressLine1 !== ""
        ) {
            this.objProviderUIData.strProviderAddress =
                this.objProviderUIData.strProviderAddress +
                objCaseProviderData.straddressLine1;
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objCaseProviderData.straddressLine2) &&
            objCaseProviderData.straddressLine2 !== ""
        ) {
            if (this.objProviderUIData.strProviderAddress !== "") {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress +
                    ", " +
                    objCaseProviderData.straddressLine2;
            } else {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress +
                    objCaseProviderData.straddressLine2;
            }
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objCaseProviderData.strcity) &&
            objCaseProviderData.strcity !== ""
        ) {
            if (this.objProviderUIData.strProviderAddress !== "") {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress +
                    ", " +
                    objCaseProviderData.strcity;
            } else {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress +
                    objCaseProviderData.strcity;
            }
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objCaseProviderData.strstateCode) &&
            objCaseProviderData.strstateCode !== ""
        ) {
            if (this.objProviderUIData.strProviderAddress !== "") {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress +
                    ", " +
                    objCaseProviderData.strstateCode;
            } else {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress +
                    objCaseProviderData.strstateCode;
            }
        }
        if (
            BaseLWC.isNotUndefinedOrNull(objCaseProviderData.strpostalCode) &&
            objCaseProviderData.strpostalCode !== ""
        ) {
            if (this.objProviderUIData.strProviderAddress !== "") {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress +
                    " " +
                    objCaseProviderData.strpostalCode;
            } else {
                this.objProviderUIData.strProviderAddress =
                    this.objProviderUIData.strProviderAddress +
                    objCaseProviderData.strpostalCode;
            }
        }
        if (this.objProviderUIData.strProviderAddress === "") {
            this.objProviderUIData.strProviderAddress = "-";
        }

        this.boolNoNetworkCodes = true;
        this.boolCaseProvider = true;
        this.boolshowPNICard = true;
        this.boolShowSpinner = false;
    };

    getProviderDataFromCase(objCaseProviderData) {
        //checking if provider number or corp code for case is blank
        if (
            BaseLWC.isNotUndefinedOrNull(this.strProviderNumber) &&
            BaseLWC.isNotUndefinedOrNull(this.strProviderCorpEntity)
        ) {
            this.fetchProviderData();
            if (this.boolCaseProvider && this.boolCaseNoProviderFound) {
                this.setCaseProviderData(objCaseProviderData);
            }
        } //CEAS-84982 - call for attested provider case search
        else if ((BaseLWC.isNotUndefinedOrNull(objCaseProviderData.strNPI) || BaseLWC.isNotUndefinedOrNull(objCaseProviderData.strTaxID)) && 
	             (BaseLWC.isNotUndefinedOrNull(objCaseProviderData.straddressLine1) && BaseLWC.isNotUndefinedOrNull(objCaseProviderData.strpostalCode) && 
                  BaseLWC.isNotUndefinedOrNull(objCaseProviderData.strcity) && BaseLWC.isNotUndefinedOrNull(objCaseProviderData.strstateCode)) && 
                 BaseLWC.isNotUndefinedOrNull(this.strProviderCorpEntity)) {
            //CEAS-85564
            if (BaseLWC.isNotUndefinedOrNull(objCaseProviderData.strLastName)) {
                objCaseProviderData.strLastName = "";
            } 
            this.fetchAttestedProviderData(objCaseProviderData);
            if (this.boolCaseProvider && this.boolCaseNoProviderFound) {
                this.setCaseProviderData(objCaseProviderData);
            }
        }  else {
            this.setCaseProviderData(objCaseProviderData);
            this.boolCaseProviderFieldsBlank = true;
        }
    }

    resetProviderCaseFlags() {
        this.boolCaseProvider = false;
        this.boolCaseProviderFieldsBlank = false;
        this.boolCaseRefresh = false;
        this.boolCaseNoProviderFound = false;
    }

    resetNetworkBadgeFlags(networkValue) {
        switch (networkValue) {
            case "InNetwork":
                this.boolInNetwork = true;
                this.boolOutOfNetwork = false;
                this.boolNetworkUnknown = false;
                this.boolNetworkUnAvailable = false;
                break;
            case "OutOfNetwork":
                this.boolInNetwork = false;
                this.boolOutOfNetwork = true;
                this.boolNetworkUnknown = false;
                this.boolNetworkUnAvailable = false;
                break;
            case "":
                this.boolInNetwork = false;
                this.boolOutOfNetwork = false;
                this.boolNetworkUnknown = true;
                this.boolNetworkUnAvailable = false;
                break;
            case "apiError":
                this.boolInNetwork = false;
                this.boolOutOfNetwork = false;
                this.boolNetworkUnknown = false;
                this.boolNetworkUnAvailable = true;
                break;
            default:
                this.boolInNetwork = false;
                this.boolOutOfNetwork = false;
                this.boolNetworkUnknown = true;
                this.boolNetworkUnAvailable = false;
                break;
        }
    }

    //CEAS-56383 -TECH DEBT
    disconnectedCallback() {
        if (BaseLWC.stringIsNotBlank(this.label.lblEnableVPSTabSpecificEvents_ACE) && this.label.lblEnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
            window.removeEventListener("PlanChangedCustomEvent_" + this.objTabData.tabId, this.capturePlanChangeListener);
         } else {
            window.removeEventListener("PlanChangedCustomEvent",this.capturePlanChangeListener);
         }
        if(this.objTabData.tabId) {
        const strCaptureProviderEvent =
            "ProviderUpdatedInfo_" + this.objTabData.tabId;
            window.removeEventListener(
            strCaptureProviderEvent,
            this.captureProviderListener,
            false
        );
    }

    }

    /*
     * To Show Network Status Message on Hover
     */
    displayNetworkToolTip = () => {
        this.boolShowToolTipText = true;
    };
    /*
     * To Hide Network Status Message on Hover
     */
    hideNetworkToolTip = () => {
        this.boolShowToolTipText = false;
    };
}