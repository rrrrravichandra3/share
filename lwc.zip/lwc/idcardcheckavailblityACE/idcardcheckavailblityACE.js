/**
 * Created by Adarsh Dandriyal
 */
import {
    LightningElement,
    api,
    wire,
    track
} from 'lwc';


import {
    getPicklistValues,
    getObjectInfo
} from 'lightning/uiObjectInfoApi';
import case_object from '@salesforce/schema/Case';
import submitCaseFromIdCard from '@salesforce/apexContinuation/IdCardController_ACE.submitCaseFromIdCard';
import getIdCardTypeForMembers from '@salesforce/apexContinuation/IdCardController_ACE.getIdCardTypeForMembers';
import SelfServiceRecipient_Field from '@salesforce/schema/Case.SelfServiceRecipient_ACE__c';
import DeliveryMethod_Field from '@salesforce/schema/Case.DeliveryMethod_ACE__c';
import CaseOrigin_Field from '@salesforce/schema/Case.Origin';
import Status_Field from '@salesforce/schema/Case.Status';
import SubStatus_Field from '@salesforce/schema/Case.Sub_Status_ACE__c';
import CreateCasePage_IdCardRequest_ACE from '@salesforce/label/c.CreateCasePage_IdCardRequest_ACE';
import IDCardRecipient_ACE from '@salesforce/label/c.IDCardRecipient_ACE';
import IDCardDeliveryMethod_ACE from '@salesforce/label/c.IDCardDeliveryMethod_ACE';
import IDCardRequiredError_ACE from '@salesforce/label/c.IDCardRequiredError_ACE';
import IDCardCaseOrigin_ACE from '@salesforce/label/c.IDCardCaseOrigin_ACE';
import IDCardEmailToMember_ACE from '@salesforce/label/c.IDCardEmailToMember_ACE';
import IDCardCardType_ACE from '@salesforce/label/c.IDCardCardType_ACE';
import IDCardFaxToMember_ACE from '@salesforce/label/c.IDCardFaxToMember_ACE';
import IDCardStatus_ACE from '@salesforce/label/c.IDCardStatus_ACE';
import IDCardSUBStatus_ACE from '@salesforce/label/c.IDCardSUBStatus_ACE';
import IDCardFaxNotAvailable_ACE from '@salesforce/label/c.IDCardFaxNotAvailable_ACE';
import IDCardFaxToProvider_ACE from '@salesforce/label/c.IDCardFaxToProvider_ACE';
import IDCardSupressLabels_ACE from '@salesforce/label/c.IDCardSupressLabels_ACE';
import IDCardMailToMember_ACE from '@salesforce/label/c.IDCardMailToMember_ACE';
import IDCardMember_ACE from '@salesforce/label/c.IDCardMember_ACE';
import IDCardAddress_ACE from '@salesforce/label/c.IDCardAddress_ACE';
import IDCardAlternateAddress_ACE from '@salesforce/label/c.IDCardAlternateAddress_ACE';
import IDCardState_ACE from '@salesforce/label/c.IDCardState_ACE';
import IDCardZipCodeError_ACE from '@salesforce/label/c.IDCardZipCodeError_ACE';
import IDCardProviderName_ACE from '@salesforce/label/c.IDCardProviderName_ACE';
import IDCardFaxNumber_ACE from '@salesforce/label/c.IDCardFaxNumber_ACE';
import IDCardFaxCaseCreatedSuccessMessage_ACE from '@salesforce/label/c.IDCardFaxCaseCreatedSuccessMessage_ACE';
import IDCardInCareOf_ACE from '@salesforce/label/c.IDCardInCareOf_ACE';
import IDCardCity_ACE from '@salesforce/label/c.IDCardCity_ACE';
import IDCardZipCode_ACE from '@salesforce/label/c.IDCardZipCode_ACE';
import IDCardCaseSubmited_ACE from '@salesforce/label/c.IDCardCaseSubmited_ACE';
import IDCardType_ACE from '@salesforce/label/c.IDCardType_ACE';
import IDCardSubType_ACE from '@salesforce/label/c.IDCardSubType_ACE';
import IDCardPendedCaseMessagePRefix_ACE from '@salesforce/label/c.IDCardPendedCaseMessagePRefix_ACE';
import IDCardPendedCaseMessageSuffix_ACE from '@salesforce/label/c.IDCardPendedCaseMessageSuffix_ACE';
import IDCardIntegrationError_ACE from '@salesforce/label/c.IDCardIntegrationError_ACE';

import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';
import {
    getRecord
} from 'lightning/uiRecordApi';
import InquirerName_Field from '@salesforce/schema/InteractionLog_ACE__c.InquirerName_ACE__c';
import InquirerNameRelationship_Field from '@salesforce/schema/InteractionLog_ACE__c.Inquirer_Relationship_ACE__c';
import RecordTypeFormula_Field from '@salesforce/schema/InteractionLog_ACE__c.RecordTypeFormulaACE__c';
import CallType_Field from '@salesforce/schema/InteractionLog_ACE__c.Call_Type_ACE__c';
import IVRAuthenticated_Field from '@salesforce/schema/InteractionLog_ACE__c.IVRAuthenticated_ACE__c';
import ProviderInformationDetails_Field from '@salesforce/schema/InteractionLog_ACE__c.ProviderInformationDetails_ACE__c';
import State_Field from '@salesforce/schema/Case.StateIdCard_ACE__c';

export default class IdCardCheckAvailblityACE extends LightningElement {
    /*Variables*/
    /*Track Variables*/
    @track showModal = false;
    /*@Api Variables*/
    @api currentTabId;
    @api strPlanSummaryData;
    @api recordTypeId;
    @api objCommunicationPreferenceData;
    @api strEmail;
    @api strAccountId;
    @api strInteractionLogId;
    @api strOldFamilyData;
    @api objCaseData;
    /*List Variables*/
    lstRecipient = [];
    lstDeliveryMethod = [];
    lstDeliveryMethodBackup = [];
    lstFamilyMemberNameOfOrderCard = [];
    objRequestForCardType = [];
    listOfFamilyname = [];
    lstStatus = [];
    lstState = [];
    lstSubStatus = [];
    lstCaseOrigin = [];
    lstsupressedLables = [];
    /*String Variables*/
    caseOriginDefaultValues = '';
    strUniqueIdentifier = '';
    objFamilyCardTypeHeader;
    recipientDefaultValue;
    deliveryMethodDefaultValue;
    strAddressOfMember = '';
    strAlternateAddressOfMember = '';
    strIdCardLevelIndicator;
    SubstatusDefaultValue = '';
    strSubscriberName = '';
    statusDefaultValue;
    objPlanData;
    isSubmitResultText;
    caseNumbers;
    caseNumbersPended;
    caseType;
    caseSubtype;
    strInCareOf = '';
    strADDRESS = '';
    strCity = '';
    strState = '';
    strZipCode = '';
    strInquirerName = '';
    strInquirerRelationship = '';
    strRecordTypeName = '';
    strProviderInfo = '';
    /*Boolean Variables*/
    boolSupressedLables = false;
    isLoaded = false;
    boolStatusDisabled = false;
    isSubmitResultSuccess = false;
    boolIsRecipientAndMail = false;
    isSubmitEnabled = true;
    boolSubstatus = false;
    boolzipError = false;
    boolMailAddress = true;
    boolAlteranteMailAddress = false;
    boolAddressNotAvailable = false;
    isError = false;
    isResultPendedSuccess = false;
    isResultSuccess = false;
    isErrorOfCheck = false;
    boolCaseOrigin = false;
    boolrefresh = true;
    boolStandAloneCards = false;
    /*Map variables*/
    mapOfFamilyMemberAndMemberNumber = {};
    MapOfFamilyMemberNameAndMemberId = {};
    MapOfFamilyMemberNumberAndMid = {};
    MapOfFamilyMemberIdAndCMID = {};
    label = {
        CreateCasePage_IdCardRequest_ACE,
        IDCardRecipient_ACE,
        IDCardDeliveryMethod_ACE,
        IDCardRequiredError_ACE,
        IDCardCaseOrigin_ACE,
        IDCardEmailToMember_ACE,
        IDCardCardType_ACE,
        IDCardFaxToMember_ACE,
        IDCardStatus_ACE,
        IDCardSUBStatus_ACE,
        IDCardFaxNotAvailable_ACE,
        IDCardFaxToProvider_ACE,
        IDCardSupressLabels_ACE,
        IDCardMailToMember_ACE,
        IDCardMember_ACE,
        IDCardAddress_ACE,
        IDCardAlternateAddress_ACE,
        IDCardState_ACE,
        IDCardZipCodeError_ACE,
        IDCardProviderName_ACE,
        IDCardFaxNumber_ACE,
        IDCardFaxCaseCreatedSuccessMessage_ACE,
        IDCardInCareOf_ACE,
        IDCardCity_ACE,
        IDCardZipCode_ACE,
        IDCardCaseSubmited_ACE,
        IDCardType_ACE,
        IDCardSubType_ACE,
        IDCardPendedCaseMessagePRefix_ACE,
        IDCardPendedCaseMessageSuffix_ACE,
        IDCardIntegrationError_ACE
    };
    /*To Get Case Object Info*/
    @wire(getObjectInfo, {
        objectApiName: case_object
    })
    objectInfo;
    /*To Fetch Recipeint PickList Value*/
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: SelfServiceRecipient_Field
    })
    recipientPicklistValues({
        error,
        data
    }) {
        if (data && data.values) {
            this.isError = false;
            const lstLocalRecipientValues = [];
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalRecipientValues.push(objType)
            }
            this.recipientDefaultValue = 'Member';
            this.lstRecipient = lstLocalRecipientValues;

        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Fetch Case Origin PickList Value*/
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: CaseOrigin_Field
    })
    originPicklistValues({
        error,
        data
    }) {
        if (data && data.values) {
            this.isError = false;
            const objTypeNull = {
                label: '--None--',
                value: ''
            };

            const lstLocaloriginvalues = [];
            lstLocaloriginvalues.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocaloriginvalues.push(objType)
            }
            this.caseOriginDefaultValues = 'TELEPHONE';
            this.lstCaseOrigin = lstLocaloriginvalues;


        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Fetch Status PickList Value*/
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: Status_Field
    })
    statusPicklistValues({
        error,
        data
    }) {
        if (data && data.values) {

            const lstLocalStatus = [];

            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalStatus.push(objType);

            }
            this.statusDefaultValue = 'Closed';
            this.lstStatus = lstLocalStatus;
            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Fetch Sub Status PickList Value*/
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: SubStatus_Field
    })
    subStatusPicklistValues({
        error,
        data
    }) {
        if (data && data.values) {
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocalSubStatus = [];
            lstLocalSubStatus.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalSubStatus.push(objType);

            }


            this.SubstatusDefaultValue = '';
            this.lstSubStatus = lstLocalSubStatus;

            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Fetch State PickList Value*/
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: State_Field
    })
    statePicklistValues({
        error,
        data
    }) {
        if (data && data.values) {
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocalstate = [];
            lstLocalstate.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalstate.push(objType);

            }
            this.strState = '';
            this.lstState = lstLocalstate;
            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Get Interaction Log Id and Other Paramters*/
    @wire(getRecord, {
        recordId: '$strInteractionLogId',
        fields: [InquirerName_Field, InquirerNameRelationship_Field, RecordTypeFormula_Field, CallType_Field, IVRAuthenticated_Field, ProviderInformationDetails_Field]
    })
    wiredInteractionRecord({
        error,
        data
    }) {
        if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else if (data) {

            if (data.recordTypeInfo !== undefined && data.recordTypeInfo !== null) {
                let strDefaultCaseOrigin = '';
                this.strRecordTypeName = data.recordTypeInfo.name;
                if (data.recordTypeInfo.name === 'Secure Message') {
                    strDefaultCaseOrigin = 'SECURE MESSAGING';
                } else if (data.recordTypeInfo.name === 'Letter') {
                    strDefaultCaseOrigin = 'LETTER';
                } else if (data.recordTypeInfo.name === 'Email') {
                    strDefaultCaseOrigin = 'EMAIL';
                } else if (data.recordTypeInfo.name === 'Chat') {
                    strDefaultCaseOrigin = 'WEB CHAT';
                } else if (data.recordTypeInfo.name === 'Call') {
                    if (data.fields.Call_Type_ACE__c !== undefined && data.fields.Call_Type_ACE__c !== null &&
                        data.fields.Call_Type_ACE__c.value === 'Inbound') {
                        if (data.fields.IVRAuthenticated_ACE__c !== undefined && data.fields.IVRAuthenticated_ACE__c !== null &&
                            data.fields.IVRAuthenticated_ACE__c.value === 'Yes' || data.fields.IVRAuthenticated_ACE__c.value === 'Y') {
                            strDefaultCaseOrigin = 'IVR DEFAULT';
                        } else {
                            strDefaultCaseOrigin = 'TELEPHONE';
                        }
                    } else if (data.fields.Call_Type_ACE__c !== undefined && data.fields.Call_Type_ACE__c !== null &&
                        data.fields.Call_Type_ACE__c.value === 'Outbound') {
                        strDefaultCaseOrigin = 'OUTBOUND CALL';
                    } else {
                        /*Do Nothing*/
                    }
                } else {
                    if (data.recordTypeInfo.name === 'Internal') {
                        strDefaultCaseOrigin = 'TELEPHONE';
                    } else {
                        strDefaultCaseOrigin = data.recordTypeInfo.name.toUpperCase();
                    }
                }
                this.caseOriginDefaultValues = strDefaultCaseOrigin;

            }

            if (data.fields !== undefined && data.fields !== null && data.fields.ProviderInformationDetails_ACE__c.value !== undefined &&
                data.fields.ProviderInformationDetails_ACE__c.value !== null) {
                this.strProviderInfo = JSON.parse(data.fields.ProviderInformationDetails_ACE__c.value);
            }
            if (data.fields !== undefined && data.fields !== null && data.fields.Inquirer_Relationship_ACE__c.value !== undefined &&
                data.fields.Inquirer_Relationship_ACE__c.value !== null) {
                this.strInquirerRelationship = data.fields.Inquirer_Relationship_ACE__c.value.toUpperCase();
            }
            if (data.fields !== undefined && data.fields !== null && data.fields.Inquirer_Relationship_ACE__c.value !== undefined &&
                data.fields.InquirerName_ACE__c.value !== null) {
                this.strInquirerName = data.fields.InquirerName_ACE__c.value;
            }


        } else {
            /*do nothing*/
        }
    }
    /*To Fetch Delivery Method PickList Value*/
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: DeliveryMethod_Field
    })
    deliveryPicklistValues({
        error,
        data
    }) {
        if (data && data.values) {
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocalDeliveryMethodValues = [];
            lstLocalDeliveryMethodValues.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalDeliveryMethodValues.push(objType);

            }
            this.deliveryMethodDefaultValue = 'Mail';
            this.lstDeliveryMethod = lstLocalDeliveryMethodValues;
            this.lstDeliveryMethodBackup = lstLocalDeliveryMethodValues;

            this.isError = false;
            this.showDisableSubmitButton()


        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*Constructor */
    constructor() {
        super();
        this.isLoaded = !this.isLoaded;
        this.showModal = true;
        this.isSubmitResultSuccess = false;

    }

    connectedCallback() {
        this.planSummaryValue();
        this.handleLoad();
    }
    /*To handle Activity After the Load of Picklists */
    handleLoad() {
        /*To get the Available Card Types for the Member */
        getIdCardTypeForMembers({
                strRequestWrapperForCardType: this.objRequestForCardType,
                lstFamilymembers: this.lstFamilyMemberNameOfOrderCard,
                mapOfFamilyMemberAndMemberNumber: this.mapOfFamilyMemberAndMemberNumber,
                boolCheckAvailblity: true,
                strOldFamilyDetails: this.strOldFamilyData,
                boolFEPIndicator :false
            }).then(result => {
                if (result !== undefined && result !== null && result.lstFamilyCardWrapper !== undefined && result.lstFamilyCardWrapper !== null &&
                    result.objFamilyCardHeader !== undefined && result.objFamilyCardHeader !== null) {

                    this.listOfFamilyname = result.lstFamilyCardWrapper;
                    this.objFamilyCardTypeHeader = result.objFamilyCardHeader;
                    this.recipientDefaultValue = 'Member';
                    this.deliveryMethodDefaultValue = 'Mail';
                    this.setStatusForSuppressAndExisting();
                    this.setStatusForSuppressAndExistingLabels();
                    this.strIdCardLevelIndicator = result.strIdCardLevelIndicator;

                    this.isError = false;

                    this.boolIsRecipientAndMail = true;

                    this.boolAddressNotAvailable = false;
                    this.boolAlteranteMailAddress = false;
                    if (this.objCaseData !== undefined && this.objCaseData !== null) {
                        this.strADDRESS = this.objCaseData.Address_ACE__c;
                        this.strCity = this.objCaseData.City_ACE__c;
                        this.strZipCode = this.objCaseData.ZipCode_ACE__c;
                        this.strState = this.objCaseData.State_ACE__c;
                        this.strInCareOf = this.objCaseData.InCareOf_ACE__c;
                        this.caseOriginDefaultValues = this.objCaseData.Origin;
                        this.statusDefaultValue = this.objCaseData.Status;
                        this.SubstatusDefaultValue = this.objCaseData.Sub_Status_ACE__c;
                        this.strUniqueIdentifier = this.objCaseData.UniqueIdentifierIDCard_ACE__c;

                    }
                    this.setStatusForSuppressAndExisting();
                    if (this.strADDRESS != null && this.strCity && this.strState && this.strZipCode) {
                        let strIncareOf = '';
                        if (!this.strInCareOf || this.strInCareOf === '') {
                            strIncareOf = '';
                        } else {
                            strIncareOf = this.strInCareOf;
                        }
                        this.strAddressOfMember = strIncareOf + ' </br>' + this.strADDRESS + ', </br>' + this.strCity + ', ' + this.strState + ', ' + this.strZipCode;
                        this.strAlternateAddressOfMember = this.strAddressOfMember;
                    } else {
                        this.strADDRESS = '';
                        this.strCity = '';
                        this.strZipCode = '';
                        this.strState = '';

                    }
                    if (this.strInteractionLogId !== undefined && this.strInteractionLogId !== null) {
                        if (this.caseOriginDefaultValues === 'TELEPHONE' && this.strRecordTypeName === 'Internal') {
                            this.boolCaseOrigin = true;
                        } else {
                            this.boolCaseOrigin = false;
                        }
                    } else {
                        this.boolCaseOrigin = true;
                    }
                } else {
                    this.isError = true;
                }
                this.isLoaded = !this.isLoaded;
            })
            .catch(() => {

                this.isError = true;
                this.isLoaded = !this.isLoaded;
            });

    }
    /*Method To Set Status For Supressed And Existing Cards */
    setStatusForSuppressAndExisting() {

        try {
            if (this.recipientDefaultValue === 'Member' && this.deliveryMethodDefaultValue === 'Mail') {
                const lstfamilyMemberNew = this.listOfFamilyname;
                let boolIsSupressed = false;
                let boolIsExisting = false;
                for (let i = 0; i < lstfamilyMemberNew.length; i++) {
                    for (let k = 0; k < lstfamilyMemberNew[i].lstCheckBoxWrapper.length; k++) {
                        if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisSupressed) {
                            boolIsSupressed = true;
                        }
                        if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisExisting) {
                            boolIsExisting = true;
                        }
                    }
                }
                if (boolIsSupressed && boolIsExisting) {
                    this.statusDefaultValue = 'Pended';
                    this.SubstatusDefaultValue = 'Suppressed & Existing Request';


                    this.isSubmitEnabled = true;

                } else if (boolIsSupressed && !boolIsExisting) {
                    this.statusDefaultValue = 'Pended';
                    this.SubstatusDefaultValue = 'Suppressed';


                    this.isSubmitEnabled = true;
                } else if (!boolIsSupressed && boolIsExisting) {
                    this.statusDefaultValue = 'Pended';
                    this.SubstatusDefaultValue = 'Existing Request';


                    this.isSubmitEnabled = true;
                } else {
                    this.statusDefaultValue = 'Closed';
                    this.SubstatusDefaultValue = '';
                    this.boolSubstatus = false;
                    this.isSubmitEnabled = false;

                }
            } else {
                this.statusDefaultValue = 'Closed';
                this.SubstatusDefaultValue = '';
                this.boolSubstatus = false;
            }


        } catch (objexception) {
            /*Do Nothing*/
        }
    }
    /*Method To Set Labels For Supressed And Existing Cards */
    setStatusForSuppressAndExistingLabels() {
        const supressedLables = [];
        try {
            if (this.recipientDefaultValue === 'Member' && this.deliveryMethodDefaultValue === 'Mail') {
                const lstfamilyMemberNew = this.listOfFamilyname;
                let boolLabelDentalCardType = false;
                let boolLabelPharmacyCardType =false;
                for (let i = 0; i < lstfamilyMemberNew.length; i++) {
                    for (let k = 0; k < lstfamilyMemberNew[i].lstCheckBoxWrapper.length; k++) {
                        if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType === 'Dental'
                             && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisExisting){
                            boolLabelDentalCardType = true;
                        } else if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType ==='Pharmacy'
                                   && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisExisting) {
                           boolLabelPharmacyCardType = true;
                        } else {
                            //do nothing
                        }
                    }
                }
                for (let i = 0; i < lstfamilyMemberNew.length; i++) {
                    let strLabels = '';
                    for (let k = 0; k < lstfamilyMemberNew[i].lstCheckBoxWrapper.length; k++) {
                        if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisSupressed) {
                            strLabels += lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType + ' (Suppressed); ';
                        }
                        if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolisExisting &&
                            lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType !=='Dental' &&
                            lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType !=='Pharmacy') {
                            strLabels += lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType + ' (Existing Request); ';
                        }
                        if (boolLabelDentalCardType && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType ==='Dental') {
                            strLabels += 'Dental' + ' (Existing Request); ';
                        }
                        if (boolLabelPharmacyCardType && lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardType ==='Pharmacy') {
                           strLabels += 'Pharmacy' + ' (Existing Request); ';
                        }
                    }
                    if (strLabels !== '') {
                        strLabels = lstfamilyMemberNew[i].strMemberNameUI + ': ' + strLabels;
                        if (strLabels != null && strLabels.endsWith('; ')) {
                            strLabels = strLabels.substring(0, strLabels.length - 2);
                        }

                        supressedLables.push(strLabels);
                    }
                }
                if (supressedLables.length > 0) {
                    this.lstsupressedLables = supressedLables;
                    this.boolSupressedLables = true;
                } else {
                    this.boolSupressedLables = false;
                }
            } else {
                this.boolSupressedLables = false;
            }
        } catch (objexception) {
            /*Do Nothing*/
        }


    }
    /*Method To Get The Case Object Details */
    getCaseObject() {
        const objCase = {
            Type: 'Member Management',
            Sub_Type_ACE__c: 'ID Card Request',
            SubscriberID_ACE__c: this.objPlanData.strSubscriberID,
            GroupNumber_ACE__c: this.objPlanData.strGroupNumber,
            GroupName_ACE__c: this.objPlanData.strGroupName,
            SectionNumber_ACE__c: this.objPlanData.strSectionNumber,
            CorporationCode_ACE__c: this.objPlanData.strCorporationCode,
            CMID_ACE__c: this.objPlanData.strCMID,
            GroupCostCenter_ACE__c: this.objPlanData.strGroupCostCenter,
            Policy_ID_ACE__c: this.objPlanData.strPolicyId,
            Plan_Effective_Date_ACE__c: this.objPlanData.strEffectiveDate,
            Plan_Termination_Date_ACE__c: this.objPlanData.strTerminationDate,
            Account_Number_ACE__c: this.objPlanData.strAccountNumber,
            Multiplan_ACE__c: this.objPlanData.strMultiPlan,
            Product_Type_ACE__c: this.objPlanData.strProductType,
            AddonServices_ACE__c: this.objPlanData.strAddOnServices,
            DeliveryMethod_ACE__c: this.deliveryMethodDefaultValue,
            SelfServiceRecipient_ACE__c: this.recipientDefaultValue,
            Status: this.statusDefaultValue,
            Sub_Status_ACE__c: this.SubstatusDefaultValue,
            Address_ACE__c: '',
            City_ACE__c: '',
            State_ACE__c: '',
            RecordTypeId: this.recordTypeId,
            ZipCode_ACE__c: '',
            AccountId: this.strAccountId,
            InquirerName_ACE__c: this.strInquirerName,
            Inquirer_Relationship_ACE__c: this.strInquirerRelationship,
            InCareOf_ACE__c: '',
            CardTypeValues_ACE__c: '',
            IdCardLevelIndicator_ACE__c: '',
            UniqueIdentifierIDCard_ACE__c: '',
            Origin: this.caseOriginDefaultValues,
            Interaction_Log_Id_ACE__c: this.strInteractionLogId


        };
            objCase.IsCbcApiCallAvailable_ACE__c =false;
            objCase.IsAccountsAPICallAvailable_ACE__c =false;
            if(this.objPlanData.boolIsAccountsAPICallAvailable && this.objPlanData.boolIsAccountsAPICallAvailable=== true) {
                objCase.IsAccountsAPICallAvailable_ACE__c = this.objPlanData.boolIsAccountsAPICallAvailable;
            }
            if(this.objPlanData.boolIsCbcApiCallAvailable && this.objPlanData.boolIsCbcApiCallAvailable=== true) {
                objCase.IsCbcApiCallAvailable_ACE__c = this.objPlanData.boolIsCbcApiCallAvailable;
            }
            if( this.objPlanData.strAceLineOfBusiness!==undefined && this.objPlanData.strAceLineOfBusiness !==null && this.objPlanData.strAceLineOfBusiness !=='') {
                            objCase.LineOfBusiness_ACE__c = this.objPlanData.strAceLineOfBusiness.toUpperCase();
                        if(this.objPlanData.strSourceSystemName!==undefined && this.objPlanData.strSourceSystemName !==null && this.objPlanData.strSourceSystemName !=='' && this.objPlanData.strAceLineOfBusiness.toUpperCase()==='RETAIL') {
                                    objCase.Source_System_Name_ACE__c = this.objPlanData.strSourceSystemName;
                                }
                        }


        if (objCase.InquirerName_ACE__c === undefined || objCase.InquirerName_ACE__c === null || objCase.InquirerName_ACE__c === '') {
            objCase.InquirerName_ACE__c = this.strSubscriberName;
        }
        if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
            objCase.Address_ACE__c = this.strADDRESS;
            objCase.City_ACE__c = this.strCity;
            objCase.State_ACE__c = this.strState;
            objCase.ZipCode_ACE__c = this.strZipCode;
            objCase.InCareOf_ACE__c = this.strInCareOf;
        }
        if (this.strInquirerRelationship !==undefined && this.strInquirerRelationship !== null &&
            (this.strInquirerRelationship === 'PROVIDER' || this.strInquirerRelationship === 'Provider') &&
            this.strProviderInfo !== undefined && this.strProviderInfo !== null) {
            objCase.TaxId_ACE__c = this.returnDataValue(this.strProviderInfo.strTaxID);
            objCase.ProviderNPI_ACE__c = this.returnDataValue(this.strProviderInfo.strNPI);
            objCase.ProviderStreet_ACE__c = this.returnDataValue(this.strProviderInfo.straddressLine1) +' '+this.returnDataValue(this.strProviderInfo.straddressLine2);
            objCase.ProviderCity_ACE__c = this.returnDataValue(this.strProviderInfo.strcity);
            objCase.ProviderName_ACE__c = this.returnDataValue(this.strProviderInfo.strFirstName) + ' ' + this.returnDataValue(this.strProviderInfo.strLastName);
            objCase.ProviderNumber_ACE__c = this.returnDataValue(this.strProviderInfo.strProviderNumber);
            objCase.ProviderState_ACE__c = this.returnDataValue(this.strProviderInfo.strstateCode);
            objCase.ProviderZipCode_ACE__c = this.returnDataValue(this.strProviderInfo.strpostalCode);
            objCase.ProviderInfoName_ACE__c = this.returnDataValue(this.strProviderInfo.strInstitutionalName);
            objCase.ProviderFaxNumber_ACE__c = this.returnDataValue(this.strProviderInfo.strFaxNumber);
            if ( !objCase.ProviderInfoName_ACE__c) {
                objCase.ProviderInfoName_ACE__c =objCase.ProviderName_ACE__c;
            }
        }
        return objCase;
    }
    returnDataValue(strData) {
        if (strData) {
            return strData;
        }
        return '';
    }
    /* Method To get the Memeber LIst For Mail DeliveryMethod*/
    getLstMemberSubmitList() {
        this.boolStandAloneCards = false;
        const lstmembers = [];
        let countOfHealth = 0;
        let countOfDrug = 0;
        let countOfDental = 0;
        let countOfCombined = 0;
        let countOfStandAloneDentalForSubscriber = 0;
        let countOfStandAloneDrugForSubscriber = 0;
        let boolSubscriberChecked = false;
        if (this.strIdCardLevelIndicator === 'S') {
            for (let i = 0; i < this.listOfFamilyname.length; i++) {
                for (let k = 0; k < this.listOfFamilyname[i].lstCheckBoxWrapper.length; k++) {
                    const strCardType = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strCardType;
                    const isChecked = this.listOfFamilyname[i].lstCheckBoxWrapper[k].boolCardChecked;
                    if (strCardType === 'Medical' && isChecked) {
                        countOfHealth = countOfHealth + 1;
                    } else if (strCardType === 'Pharmacy' && isChecked) {
                        countOfDrug = countOfDrug + 1;
                    } else if (strCardType === 'Dental' && isChecked) {
                        countOfDental = countOfDental + 1;
                    } else {
                        if (isChecked) {
                            countOfCombined = countOfCombined + 1;
                        }
                    }
                }
            }
            const member = {
                memNbr: '1',
                hlthCardCnt: countOfHealth.toString(),
                dentCardCnt: countOfDental.toString(),
                drugCardCnt: countOfDrug.toString(),
                combCardCnt: countOfCombined.toString()
            }
            lstmembers.push(member);
        } else {
            for (let i = 0; i < this.listOfFamilyname.length; i++) {
                countOfHealth = 0;
                countOfDrug = 0;
                countOfDental = 0;
                countOfCombined = 0;
                for (let k = 0; k < this.listOfFamilyname[i].lstCheckBoxWrapper.length; k++) {
                    const strCardType = this.listOfFamilyname[i].lstCheckBoxWrapper[k].strCardType;
                    const isChecked = this.listOfFamilyname[i].lstCheckBoxWrapper[k].boolCardChecked;
                    if (strCardType === 'Medical' && isChecked) {
                        countOfHealth = countOfHealth + 1;
                    } else if (strCardType === 'Pharmacy' && isChecked) {
                        countOfDrug = countOfDrug + 1;
                    } else if (strCardType === 'Dental' && isChecked) {
                        countOfDental = countOfDental + 1;
                    } else {
                        if (isChecked) {
                            countOfCombined = countOfCombined + 1;
                        }
                    }
                }
                if (countOfHealth !== 0 || countOfDental !== 0 || countOfDrug !== 0 || countOfCombined !== 0) {
                    let member;
                    if (this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName] !== 1) {
                        if (countOfHealth !== 0 || countOfCombined !== 0) {
                            member = {
                                memNbr: this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName],
                                hlthCardCnt: countOfHealth.toString(),
                                dentCardCnt: countOfDental.toString(),
                                drugCardCnt: countOfDrug.toString(),
                                combCardCnt: countOfCombined.toString()
                            };
                            lstmembers.push(member);
                        } else {
                            countOfStandAloneDentalForSubscriber += countOfDental;
                            countOfStandAloneDrugForSubscriber += countOfDrug;
                        }
                    } else {
                        boolSubscriberChecked = true;
                        member = {
                            memNbr: this.MapOfFamilyMemberNameAndMemberId[this.listOfFamilyname[i].strMemberName],
                            hlthCardCnt: countOfHealth.toString(),
                            dentCardCnt: countOfDental.toString(),
                            drugCardCnt: countOfDrug.toString(),
                            combCardCnt: countOfCombined.toString()
                        };
                        lstmembers.push(member);
                    }
                }
            }
        }
        if (this.strIdCardLevelIndicator === 'M') {
            if (lstmembers.length >= 1 && boolSubscriberChecked) {
                this.getCombinedCountForStandAloneCards(lstmembers, countOfStandAloneDentalForSubscriber, countOfStandAloneDrugForSubscriber);
            } else {
                if (countOfStandAloneDentalForSubscriber !== 0 || countOfStandAloneDrugForSubscriber !== 0) {
                    const subMember = {
                        memNbr: 1,
                        hlthCardCnt: '0',
                        dentCardCnt: countOfStandAloneDentalForSubscriber.toString(),
                        drugCardCnt: countOfStandAloneDrugForSubscriber.toString(),
                        combCardCnt: '0'
                    };
                    lstmembers.push(subMember);
                    this.boolStandAloneCards = true;
                }
            }
        }
        return lstmembers;
    }
    /*To get The Wrapper For Combined Count of StandAlone Cards*/
    getCombinedCountForStandAloneCards(lstmembers, countOfStandAloneDentalForSubscriber, countOfStandAloneDrugForSubscriber) {
        for (let i = 0; i < lstmembers.length; i++) {
            if (lstmembers[i].memNbr === 1 && countOfStandAloneDentalForSubscriber !== 0 || countOfStandAloneDrugForSubscriber !== 0) {
                lstmembers[i].dentCardCnt = (parseInt(lstmembers[i].dentCardCnt, 10) + countOfStandAloneDentalForSubscriber).toString();
                lstmembers[i].drugCardCnt = (parseInt(lstmembers[i].drugCardCnt, 10) + countOfStandAloneDrugForSubscriber).toString();
                this.boolStandAloneCards = true;
                break;
            }
        }
    }
    /* Method To Make a Server Call On Submit*/
    handleSubmitClick() {
        this.isLoaded = !this.isLoaded;
        let boolisMailMemberStatusClosed = false;
        const lstmembers = this.getLstMemberSubmitList();
        const objCase = this.getCaseObject();
        if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member' && this.statusDefaultValue === 'Closed') {
            boolisMailMemberStatusClosed = true;
        }
        const objaddressInfo = {
            strAddrLn1: objCase.Address_ACE__c,
            strAddrLn2: '',
            inCareOfLn: objCase.InCareOf_ACE__c,
            ctyNm: objCase.City_ACE__c,
            stCd: objCase.State_ACE__c,
            zipCd: objCase.ZipCode_ACE__c,
            cntryCd: 'US'

        };
        const submitReq = {
            corporateEntityCode: objCase.CorporationCode_ACE__c,
            bluestarAccountNumber: this.strPlanSummaryData.objViewEmployerGroupWrapper.strblueStarAccountNumber,
            subscriberSequenceNumber: this.objPlanData.subscriberSequenceNumber,
            subMemLvlCd: this.strIdCardLevelIndicator,
            members: lstmembers,
            addressInfo: objaddressInfo
        };
        const lstSubmitReq = [];
        lstSubmitReq.push(submitReq);
        const inputzip = this.template.querySelector('.ZIPCODE');
        if (inputzip !== undefined && inputzip !== null) {
            inputzip.setCustomValidity('');
            inputzip.reportValidity();
        }

        const allValidPicklist = [...this.template.querySelectorAll('lightning-combobox')]
            .reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);
        const allValid = [...this.template.querySelectorAll('lightning-input')]
            .reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);
        if (allValid && allValidPicklist) {

            this.boolAlteranteMailAddress = false;
            submitCaseFromIdCard({
                    strCaseData: JSON.stringify(objCase),
                    strFamilyDataChecboxes: JSON.stringify(this.listOfFamilyname),
                    boolBlueStarCallout: boolisMailMemberStatusClosed,
                    lstSubmitReq: lstSubmitReq,
                    mapOfFamilyMemberAndMemberNumber: this.mapOfFamilyMemberAndMemberNumber,
                    strIdCardLevelIndicator: this.strIdCardLevelIndicator,
                    boolcheckAvailblity: true,
                    strUniqueIdentifier: this.strUniqueIdentifier,
                    mapOfFamilyMemberNumberAndMid: this.MapOfFamilyMemberNumberAndMid,
                    mapOfFamilyMemberIdAndCMID: this.MapOfFamilyMemberIdAndCMID,
                    boolFEPIndicator: false,
                    boolStandAloneCards: this.boolStandAloneCards,
                    boolBoeingIndicator: false
                })
                .then((result) => {
                    this.isLoaded = !this.isLoaded;
                    this.isSubmitResultSuccess = true;
                    this.boolzipError = false;
                    const strInputZipCode = this.template.querySelector('.ZIPCODE.slds-has-error');
                    const strInputCity = this.template.querySelector('.CITY.slds-has-error');
                    const strInputAddress = this.template.querySelector('.ADDRESS.slds-has-error');
                    const strInputState = this.template.querySelector('.id-class-state-err.slds-has-error');
                    if(strInputZipCode) {
                      strInputZipCode.classList.remove('slds-has-error');
                    }
                    if(strInputCity) {
                      strInputCity.classList.remove('slds-has-error');
                    }
                    if(strInputAddress) {
                      strInputAddress.classList.remove('slds-has-error');
                    }
                    if(strInputZipCode) {
                      strInputState.classList.remove('slds-has-error');
                    }


                    if (result !== undefined && result !== null && result.boolResponseStatus && result.lstSuccessCases.length > 0) {
                        this.showNotification();
                        this.isError = false;
                        this.boolSubstatus = false;
                        this.boolrefresh = false;
                    } else if (result !== undefined && result !== null && !result.boolResponseStatus && result.strZipCodeError !== null && result.strZipCodeError !== '') {

                        this.isSubmitResultSuccess = false;
                        this.boolIsRecipientAndMail = true;
                        this.boolAlteranteMailAddress = true;
                        this.boolAddressNotAvailable = true;
                        this.boolzipError = true;

                        setTimeout(function(){
                            const inp1 = this.template.querySelector('.ZIPCODE');
                            const inp2 = this.template.querySelector('.CITY');
                            const inp3 = this.template.querySelector('.ADDRESS');
                            const inp4 = this.template.querySelector('.id-class-state-err');
                            inp1.classList.add('slds-has-error');
                            inp2.classList.add('slds-has-error');
                            inp3.classList.add('slds-has-error');
                            inp4.classList.add('slds-has-error');
                        }.bind(this), 500);

                    } else if (result !== undefined && result !== null && !result.boolResponseStatus &&
                        result.lstSuccessCases && result.lstPendedCases.length === 0 && result.strZipCodeError === '') {
                        this.isSubmitResultSuccess = false;
                        this.isErrorOfCheck = true;

                        this.isError = true;
                        this.boolSubstatus = false;
                        this.boolrefresh = false;
                    } else if (result !== undefined && result !== null && !result.boolResponseStatus &&
                        result.lstPendedCases && result.strZipCodeError === '') {
                        this.isSubmitResultSuccess = false;
                        this.isErrorOfCheck = true;

                        this.isError = true;
                        this.boolSubstatus = false;
                        this.boolrefresh = false;
                    } else if (result != null && result.lstSuccessCases.length === 0 && result.lstPendedCases.length === 0) {

                        this.isSubmitResultSuccess = false;
                        this.isErrorOfCheck = true;
                        this.isError = true;
                        if (this.isLoaded) {
                            this.isLoaded = !this.isLoaded;
                        }
                    } else {
                        this.isSubmitResultSuccess = false;
                        this.isErrorOfCheck = true;
                        this.isError = true;
                        if (this.isLoaded) {
                            this.isLoaded = !this.isLoaded;
                        }
                    }
                })
                .catch(() => {
                    this.isError = true;
                    if (this.isLoaded) {
                        this.isLoaded = !this.isLoaded;
                    }


                });
        } else {
            this.isLoaded = !this.isLoaded;
        }



    }
    /*To Show Toast Message*/
    showNotification() {
        this.showModal = false;
        const evt = new ShowToastEvent({
            title: '',
            message: 'Case closed successfully.',
            variant: 'success',
        });
        this.dispatchEvent(evt);
    }
    /*To Handle on Select of Checkbox*/
    handleChange(objEvent) {
        const checkedVal = objEvent.target.checked;
        const attributeKey = objEvent.target.getAttribute('data-membercardtype');
        if (attributeKey.includes('-Medical') || attributeKey.includes('-Dental') || attributeKey.includes('-Pharmacy') ||
            attributeKey.includes('-Medical/Dental') || attributeKey.includes('-Medical/Pharmacy') || attributeKey.includes('-Medical/Pharmacy/Dental')
        ) {
            const MemberName = attributeKey.split('-')[0];
            let lstfamilyMemberNew = [];
            lstfamilyMemberNew = this.listOfFamilyname;

            for (let i = 0; i < lstfamilyMemberNew.length; i++) {
                if (lstfamilyMemberNew[i].strMemberName === MemberName) {
                    for (let k = 0; k < lstfamilyMemberNew[i].lstCheckBoxWrapper.length; k++) {
                        if (lstfamilyMemberNew[i].lstCheckBoxWrapper[k].strCardKey === attributeKey) {
                            lstfamilyMemberNew[i].lstCheckBoxWrapper[k].boolCardChecked = checkedVal;
                        }
                    }
                    this.listOfFamilyname = lstfamilyMemberNew;
                }
            }
        }
        this.checkForCheckBoxSelected();
        this.setStatusForSuppressAndExisting();
    }
    /* Method To Enable Submit Button*/
    checkForCheckBoxSelected() {
        let lstFamilyMemberNamelocal = [];
        lstFamilyMemberNamelocal = this.listOfFamilyname;
        let boolIsCheckBoxesSelected = false;
        for (let i = 0; i < lstFamilyMemberNamelocal.length; i++) {
            for (let k = 0; k < lstFamilyMemberNamelocal[i].lstCheckBoxWrapper.length; k++) {
                if (lstFamilyMemberNamelocal[i].lstCheckBoxWrapper[k].boolCardChecked) {
                    boolIsCheckBoxesSelected = true;
                    break;
                }
            }
        }
        if (boolIsCheckBoxesSelected) {
            this.isSubmitEnabled = false;
        } else {
            this.isSubmitEnabled = true;
        }
    }
    /* Method To Handle On Change of Status*/
    handleChangeStatus(objEvent) {
        this.statusDefaultValue = objEvent.target.value;
        if (this.statusDefaultValue === 'Pended') {
            this.SubstatusDefaultValue = 'Personal Pend';
            this.boolSubstatus = true;
        } else {
            this.SubstatusDefaultValue = '';
            this.boolSubstatus = false;
        }
    }
    /* Method To Handle On Change of SUB Status*/
    handleChangeSubStatus(objEvent) {
        this.SubstatusDefaultValue = objEvent.target.value;
    }
    /* Method To Handle On Change of Origin*/
    handleChangeOrigin(objEvent) {
        this.caseOriginDefaultValues = objEvent.target.value;
    }
    /* Method To Handle On Change of Recipient*/
    handleChangeRecipient(objEvent) {
        this.recipientDefaultValue = objEvent.target.value;
        this.isSubmitResultSuccess = false;

        const lstDeliveryMethodUI = [];
        const objTypeNull = {
            label: '--None--',
            value: ''
        };
        if (this.recipientDefaultValue === 'Provider') {
            this.deliveryMethodDefaultValue = '';
            this.boolIsRecipientAndMail = false;
            lstDeliveryMethodUI.push(objTypeNull);
            lstDeliveryMethodUI.push({
                label: 'Email',
                value: 'Email'
            });
            lstDeliveryMethodUI.push({
                label: 'Fax',
                value: 'Fax'
            });
            this.lstDeliveryMethod = lstDeliveryMethodUI;


        } else {
            this.deliveryMethodDefaultValue = '';
            this.boolIsRecipientAndMail = false;
            this.lstDeliveryMethod = this.lstDeliveryMethodBackup;


        }
        this.showDisableSubmitButton();
        this.setStatusForSuppressAndExisting();
        this.setStatusForSuppressAndExistingLabels();
    }
    /* Method To Show or Disable Submit Button */
    showDisableSubmitButton() {

        if (this.deliveryMethodDefaultValue === '--None--' || this.recipientDefaultValue === '--None--') {
            this.isSubmitEnabled = true;
        } else {
            this.isSubmitEnabled = false;
        }
    }
    /* Method To Handle On Change of Delivery Method*/
    handleChangeDeliveryMethod(objEvent) {
        this.deliveryMethodDefaultValue = objEvent.target.value;
        this.isSubmitResultSuccess = false;
        if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
            this.boolIsRecipientAndMail = true;
        } else {
            this.boolIsRecipientAndMail = false;
        }
        this.showDisableSubmitButton();
        this.setStatusForSuppressAndExisting();
        this.setStatusForSuppressAndExistingLabels();
    }
    /* Method To Handle On Change of Alterante*/
    handleChangeAlternatevalue(objEvent) {

        const className = objEvent.target.className;
        if (className.includes('InCareOf')) {
            this.strInCareOf = objEvent.target.value;
        } else if (className.includes('ADDRESS')) {
            this.strADDRESS = objEvent.target.value;
        } else if (className.includes('CITY')) {
            this.strCity = objEvent.target.value;
        } else if (className.includes('STATE')) {
            this.strState = objEvent.target.value;
        } else if (className.includes('ZIPCODE')) {
            this.strZipCode = objEvent.target.value;
        } else {
            /*Do Nothing*/
        }
        this.strAlternateAddressOfMember = this.strInCareOf + ' ' + '</br>' +
            this.strADDRESS + ', ' + '</br>' +
            this.strCity + ', ' +
            this.strState + ', ' +
            this.strZipCode;

    }
    /* Method To Handle Change oF Main Address */
    handleMainAddress(objEvent) {
        const className = objEvent.target.className;
        if (className.includes('MailAddress')) {
            this.boolMailAddress = true;
            this.boolAlteranteMailAddress = false;
        } else if (className.includes('AlternateAddress')) {
            this.boolMailAddress = false;
            this.boolAlteranteMailAddress = true;

        } else {
            /*Do Nothing*/
        }
    }
    /*Launch a case on Select Sub Tab*/
    openCase(objEvent) {
        if (objEvent !== undefined && objEvent !== null && objEvent.target !== undefined && objEvent.target !== null &&
            objEvent.target.getAttribute('data-caseid') !== undefined && objEvent.target.getAttribute('data-caseid') !== null) {
            const caseId = objEvent.target.getAttribute('data-caseid');
            const caseIdURL = objEvent.target.getAttribute('data-caseurl');
            const strAccountIdOfCase = objEvent.target.getAttribute('data-caseaccid');
            let boolOpenSubtab = false;
            if (this.strAccountId === strAccountIdOfCase) {
                boolOpenSubtab = true;
            }
            const objDispatchEventData = {
                Id: caseId,
                TabId: this.currentTabId,
                CaseUrl: caseIdURL,
                AccountId: strAccountIdOfCase,
                boolOpenSubtab: boolOpenSubtab
            };
            const openSubTab = new CustomEvent('OpenSubTab', {
                detail: JSON.stringify(objDispatchEventData)
            });
            window.dispatchEvent(openSubTab);
        }
    }
    /*Get A value of Selcted Plans*/
    getValueFromPLan(strPLanValue, strSelectedValue, strElseValue) {
        let valueToBeReturned;
        if (strPLanValue !== undefined && strPLanValue !== null) {
            valueToBeReturned = strSelectedValue;
        } else {
            valueToBeReturned = strElseValue;
        }
        return valueToBeReturned;

    }
    /*Get Plan Summary Wrapper*/
    planSummaryValue() {
        if (this.strPlanSummaryData !== undefined && this.strPlanSummaryData !== null) {
            const casePlanParam = {
                strSubscriberID: this.getValueFromPLan(this.strPlanSummaryData.strSubscriberId, this.strPlanSummaryData.strSubscriberId, ''),
                strGroupNumber: this.getValueFromPLan(this.strPlanSummaryData.strGroupNumber, this.strPlanSummaryData.strGroupNumber, ''),
                strGroupName: this.getValueFromPLan(this.strPlanSummaryData.strGroupName, this.strPlanSummaryData.strGroupName, ''),
                strSectionNumber: this.getValueFromPLan(this.strPlanSummaryData.objViewEmployerGroupWrapper.strGroupSectionNumber, this.strPlanSummaryData.objViewEmployerGroupWrapper.strGroupSectionNumber, ''),
                strCorporationCode: this.getValueFromPLan(this.strPlanSummaryData.strCorporationCode, this.strPlanSummaryData.strCorporationCode, ''),
                boolPgIndicator: this.getValueFromPLan(this.strPlanSummaryData.boolPgIndicator, this.strPlanSummaryData.boolPgIndicator, ''),
                strCMID: this.getValueFromPLan(this.strPlanSummaryData.strClientMemberId, this.strPlanSummaryData.strClientMemberId, ''),
                strMid: this.getValueFromPLan(this.strPlanSummaryData.strMemberId, this.strPlanSummaryData.strMemberId, ''),
                strGroupCostCenter: this.getValueFromPLan(this.strPlanSummaryData.strGroupCostCenterNumber, this.strPlanSummaryData.strGroupCostCenterNumber, ''),
                strPolicyId: this.getValueFromPLan(this.strPlanSummaryData.strPolicyId, this.strPlanSummaryData.strPolicyId, ''),
                strEffectiveDate: this.getValueFromPLan(this.strPlanSummaryData.strEffectiveDate, this.strPlanSummaryData.strEffectiveDate, ''),
                strTerminationDate: this.getValueFromPLan(this.strPlanSummaryData.strTerminationDate, this.strPlanSummaryData.strTerminationDate, ''),
                strAccountNumber: this.getValueFromPLan(this.strPlanSummaryData.strAccountNumber, this.strPlanSummaryData.strAccountNumber, ''),
                strMultiPlan: this.getValueFromPLan(this.strPlanSummaryData.strMultiPlan, this.strPlanSummaryData.strMultiPlan, ''),
                strProductType: this.getValueFromPLan(this.strPlanSummaryData.strNetwork, this.strPlanSummaryData.strNetwork, ''),
                strFundingType: this.getValueFromPLan(this.strPlanSummaryData.strFundingTypeCode, this.strPlanSummaryData.strFundingTypeCode, ''),
                addOnServices: this.strPlanSummaryData.lstCoverageCodes,
                strAddOnServices: '',
                Address_ACE__c: '',
                City_ACE__c: '',
                State_ACE__c: '',
                ZipCode_ACE__c: '',
                Email_ACE__c: '',
                lstFamilyName: null,
                boolIsCbcApiCallAvailable: this.getValueFromPLan(this.strPlanSummaryData.boolIsCbcApiCallAvailable, this.strPlanSummaryData.boolIsCbcApiCallAvailable, ''),
                boolIsAccountsAPICallAvailable: this.getValueFromPLan(this.strPlanSummaryData.boolIsAccountsAPICallAvailable, this.strPlanSummaryData.boolIsAccountsAPICallAvailable, ''),
                strAceLineOfBusiness: this.getValueFromPLan(this.strPlanSummaryData.strAceLineOfBusiness, this.strPlanSummaryData.strAceLineOfBusiness, ''),
                strSourceSystemName: this.getValueFromPLan(this.strPlanSummaryData.strSourceSystemName, this.strPlanSummaryData.strSourceSystemName, '')
            };


            const objreq = {
                "subscriberSequenceNumber": this.getValueFromPLan(this.strPlanSummaryData.strSubscriberSequenceNumber, this.strPlanSummaryData.strSubscriberSequenceNumber, ''),
                "corporateEntityCode": this.strPlanSummaryData.strCorporationCode,
                "bluestarAccountNumber": this.strPlanSummaryData.objViewEmployerGroupWrapper.strblueStarAccountNumber

            };
            if(this.isJSONString(this.objCommunicationPreferenceData)){
                this.objCommunicationPreferenceData = JSON.parse(this.objCommunicationPreferenceData);
            }

            const lstOfRequestWrapper = [];
            lstOfRequestWrapper.push(objreq);
            this.objRequestForCardType = lstOfRequestWrapper;
            casePlanParam['subscriberSequenceNumber'] = objreq.subscriberSequenceNumber;
            casePlanParam['memberNumber'] = objreq.memberNumber;
            casePlanParam['bluestarAccountNumber'] = objreq.bluestarAccountNumber;
            const strSenderAddress = this.strPlanSummaryData.strfirstName + ' ' + this.strPlanSummaryData.strlastname;
            if (this.objCommunicationPreferenceData !== null && this.objCommunicationPreferenceData !== undefined) {
                casePlanParam['Address_ACE__c'] = this.objCommunicationPreferenceData.streetAddress;
                casePlanParam['City_ACE__c'] = this.objCommunicationPreferenceData.city;
                casePlanParam['State_ACE__c'] = this.objCommunicationPreferenceData.state;
                casePlanParam['ZipCode_ACE__c'] = this.objCommunicationPreferenceData.zipCode;
                this.strAddressOfMember = strSenderAddress + ' </br>' + this.objCommunicationPreferenceData.streetAddress + ',  </br> ' +
                    this.objCommunicationPreferenceData.city +
                    ', ' + this.objCommunicationPreferenceData.state + ', ' + this.objCommunicationPreferenceData.zipCode;
                this.boolAddressNotAvailable = false;
                this.boolAlteranteMailAddress = false;


            }

            if (this.strAddressOfMember === undefined || this.strAddressOfMember === null || this.strAddressOfMember === '') {
                this.boolAddressNotAvailable = true;
                this.boolAlteranteMailAddress = true;

            }
            if (this.strEmail !== null && this.strEmail !== undefined) {
                casePlanParam['Email_ACE__c'] = this.strEmail;
            }
            if (this.strPlanSummaryData.lstFamilyWrapper !== undefined && this.strPlanSummaryData.lstFamilyWrapper !== null &&
                this.strPlanSummaryData.lstFamilyWrapper.length > 0) {
                const strCurrentPageMemberName = this.strPlanSummaryData.strfirstName + ' ' + this.strPlanSummaryData.strlastname;
                const strCurrentPageMemberNumber = parseInt(this.strPlanSummaryData.strMemberNumber, 10);
                const lstFamilyMemberName = [];
                const MapOfFamilyMemberAndMemberNumberLocal = {};
                const MapOfFamilyMemberNumberAndMidlocal = {};
                const MapOfFamilyMemberNameAndMemberIdLocal = {};
                const MapOfFamilyMemberIdAndCMIDlocal = {};

                for (let j = 0; j < this.strPlanSummaryData.lstFamilyWrapper.length; j++) {
                    const strFamilyName = this.strPlanSummaryData.lstFamilyWrapper[j].strFirstName + ' ' + this.strPlanSummaryData.lstFamilyWrapper[j].strLastName;
                    if (strCurrentPageMemberNumber !== this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber) {
                        lstFamilyMemberName.push(strFamilyName + '_' + this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber.toString());
                        MapOfFamilyMemberAndMemberNumberLocal[this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber] = strFamilyName + '_' + this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber.toString();
                        MapOfFamilyMemberNameAndMemberIdLocal[strFamilyName + '_' + this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber.toString()] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                        MapOfFamilyMemberNumberAndMidlocal[this.strPlanSummaryData.lstFamilyWrapper[j].strMemberId] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                        MapOfFamilyMemberIdAndCMIDlocal[this.strPlanSummaryData.lstFamilyWrapper[j].strClientMemberId] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;

                    } else {
                        MapOfFamilyMemberAndMemberNumberLocal[this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber] = strFamilyName + '_' + this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber.toString();
                        MapOfFamilyMemberNameAndMemberIdLocal[strFamilyName + '_' + this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber.toString()] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                        MapOfFamilyMemberNumberAndMidlocal[this.strPlanSummaryData.lstFamilyWrapper[j].strMemberId] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                        MapOfFamilyMemberIdAndCMIDlocal[this.strPlanSummaryData.lstFamilyWrapper[j].strClientMemberId] = this.strPlanSummaryData.lstFamilyWrapper[j].intMemberNumber;
                    }
                }
                lstFamilyMemberName.sort();
                lstFamilyMemberName.splice(0, 0, strCurrentPageMemberName + '_' + strCurrentPageMemberNumber.toString());
                casePlanParam['lstFamilyName'] = lstFamilyMemberName;

                this.strInCareOf = strCurrentPageMemberName;
                this.strSubscriberName = strCurrentPageMemberName;
                this.lstFamilyMemberNameOfOrderCard = lstFamilyMemberName;
                this.mapOfFamilyMemberAndMemberNumber = MapOfFamilyMemberAndMemberNumberLocal;
                this.MapOfFamilyMemberNameAndMemberId = MapOfFamilyMemberNameAndMemberIdLocal;
                this.MapOfFamilyMemberNumberAndMid = MapOfFamilyMemberNumberAndMidlocal;
                this.MapOfFamilyMemberIdAndCMID = MapOfFamilyMemberIdAndCMIDlocal;
            }
            const lstAddOnServices = casePlanParam.addOnServices;
            let strAddOnServices = '';
            if (lstAddOnServices) {
                for (let intCount = 0; intCount < lstAddOnServices.length; intCount++) {
                    if (lstAddOnServices[intCount].strEffectiveEndDate !== undefined && lstAddOnServices[intCount].strEffectiveEndDate !== null && lstAddOnServices[intCount].strEffectiveEndDate !== "") {
                        const codeDate = new Date(lstAddOnServices[intCount].strEffectiveEndDate);
                        const CurrentDate = new Date();
                        CurrentDate.setHours(0, 0, 0, 0);

                        if (lstAddOnServices[intCount].strCode !== null && codeDate >= CurrentDate) {

                            strAddOnServices = strAddOnServices + lstAddOnServices[intCount].strCode;
                            casePlanParam['strAddOnServices'] = strAddOnServices;
                        }
                    }
                }
            }

            if (casePlanParam.strTerminationDate) {
                const TerminationDate = casePlanParam.strTerminationDate;
                let TerminationDateArray = [];
                TerminationDateArray = TerminationDate.split('/');
                casePlanParam.strTerminationDate = TerminationDateArray[2] + '-' + TerminationDateArray[0] + '-' + TerminationDateArray[1];
            }
            if (casePlanParam.strEffectiveDate) {
                const EffectiveDate = casePlanParam.strEffectiveDate;
                let EffectiveDateArray = [];
                EffectiveDateArray = EffectiveDate.split('/');
                casePlanParam.strEffectiveDate = EffectiveDateArray[2] + '-' + EffectiveDateArray[0] + '-' + EffectiveDateArray[1];
            }
            this.objPlanData = casePlanParam;
        }
    }

    @api
    openModal() {
        this.showModal = true;
    }

    @api
    closeModal() {
        this.showModal = false;
    }
    /*Refresh Modal*/
    refreshModal() {

        this.isSubmitResultSuccess = false;
        this.isSubmitEnabled = false;
        this.isError = false;
        this.isLoaded = !this.isLoaded;
        this.recipientDefaultValue = 'Member';
        this.isError = false;
        this.lstDeliveryMethod = this.lstDeliveryMethodBackup;
        this.deliveryMethodDefaultValue = 'Directed to Self-Service';
        this.statusDefaultValue = 'Closed';
        this.SubstatusDefaultValue = '';
        this.strADDRESS = '';
        this.strAlternateAddressOfMember = '';
        this.strCity = '';
        this.strState = '';

        this.strZipCode = '';
        this.strInCareOf = '';
        this.boolMailAddress = false;
        this.boolAlteranteMailAddress = false;
        this.boolCaseOrigin = false;
        this.boolIsRecipientAndMail = false;
        this.boolSubstatus = false;
        this.boolSupressedLables = false;
        this.planSummaryValue();
        this.handleLoad();
    }

    // Method  to Check if the given parameter is a valid JSON string
    isJSONString=(strJSON)=>{
        try {
            JSON.parse(strJSON);
        }catch(e) {
            if(e){
                return false;
            }
        }
        return true;
    }
}
