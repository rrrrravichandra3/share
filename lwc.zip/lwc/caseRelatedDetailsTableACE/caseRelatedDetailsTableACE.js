import { LightningElement, api, wire} from 'lwc';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF'; 
import { EnclosingTabId, getTabInfo, openSubtab, setTabIcon, setTabLabel } from 'lightning/platformWorkspaceApi';
import fetchCaseRelatedDetailsRecords from '@salesforce/apex/CaseRelatedTableController_ACE.fetchCaseRelatedDetailsRecords';
import fetchStreamlinkGUI from '@salesforce/apex/CaseRelatedTableController_ACE.fetchStreamlinkGUI';
import ClaimMedicalRecordType_ACE from '@salesforce/label/c.ClaimMedicalRecordType_ACE';
import ClaimPharmacyRecordType_ACE from '@salesforce/label/c.ClaimPharmacyRecordType_ACE';
import ClaimDentalRecordType_ACE from '@salesforce/label/c.ClaimDentalRecordType_ACE';
import IDRDisputeRecordType_ACE from '@salesforce/label/c.IDRDisputeRecordType';
import PreServicePreDetECMRecordType_ACE from '@salesforce/label/c.PreServicePreDetECMRecordType_ACE';
import fetchCaseLobDetail from '@salesforce/apex/CaseRelatedTableController_ACE.fetchCaseTypeAndSubType';

export default class CaseRelatedDetailsTableACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    @api strCaseId;
    @api lstRelatedDetails;
    strStreamLineGUILink = null;    
    lstCaseRelatedDetails = null;
    lstCRD = [];

    label = {
        ClaimMedicalRecordType_ACE,
        ClaimPharmacyRecordType_ACE,
        ClaimDentalRecordType_ACE,
        IDRDisputeRecordType_ACE,
        PreServicePreDetECMRecordType_ACE
    };

    lstFEPColumns = [
        { label: 'RECORD TYPE', fieldName: 'RecordTypeName', sortable: false, type: 'text' },
        { label: 'RECORD NUMBER', fieldName: 'RecordLink', sortable: false, boolWrapper: true, type: 'text' },
        { label: 'DATE', fieldName: 'Date_ACE__c', sortable: true, boolInitSort: true, boolAsc: false, type: 'date'},
        { label: 'STATUS', fieldName: 'Status_ACE__c', sortable: false, type: 'text'},
        { label: 'ACTION', fieldName: 'Link', sortable: false, boolWrapper: true, type: 'text' },
        /* CEAS-66674  -  Adding tooltip with info icon */
        { label: '', fieldName: 'HelpText', sortable: false ,boolIsTooltip:true, boolIsInfoIconTooltip: true, type: 'text'},
    ];

    lstColumns = [
        { label: 'RECORD TYPE', fieldName: 'RecordTypeName', sortable: false, type: 'text' },
        { label: 'RECORD NUMBER', fieldName: 'RecordLink', sortable: false, boolWrapper: true, type: 'text' },
        { label: 'DATE', fieldName: 'Date_ACE__c', sortable: true, boolInitSort: true, boolAsc: false, type: 'date'},
        { label: 'STATUS', fieldName: 'Status_ACE__c', sortable: false, type: 'text'},
        /* CEAS-66674  -  Adding tooltip with info icon */
        { label: '', fieldName: 'HelpText', sortable: false ,boolIsTooltip:true, boolIsInfoIconTooltip: true, type: 'text'},
    ];

    get boolRenderDataTable() {
        return this.lstCaseRelatedDetails || false;
    }

    objInitTableSettings = {
        pageSize: 10,
        boolViewMore: true,
        restrictedPageSize: 5,
        columnsData: this.lstColumns,
        boolSecondaryTable: false,
        boolShowFilter: false,
        boolPagination: true,
        boolShowSearch: false,
        filterData: [],
        boolShowCheckbox: false,
        boolShowHeader: false
    };

    objFEPInitTableSettings = {
        pageSize: 10,
        boolViewMore: true,
        restrictedPageSize: 5,
        columnsData: this.lstFEPColumns,
        boolSecondaryTable: false,
        boolShowFilter: false,
        boolPagination: true,
        boolShowSearch: false,
        filterData: [],
        boolShowCheckbox: false,
        boolShowHeader: false
    };
    //Used to store tab Data.
    objTabData = null; 
    objError;
    boolIsFEP = false;
    boolNoRecordFound = false;    

    handleErrors(error) {
        this.objError = error;
    }

    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.fetchTabData();
            this.fetchDataFromServer();
        } catch(error) {
            this.handleErrors(error);
        }
    }

    fetchLobDetail() {
        fetchCaseLobDetail({
            strCaseId: this.strCaseId
        }).then((result)=>{
            if (result) {
                let lstCase = [...result];
                if (BaseLWC.isNotUndefinedOrNull(lstCase) && lstCase.length > 0) {
                    this.boolIsFEP = lstCase[0].FEP_ACE__c;
                } 
            }
          }
        ).catch((error)=>{
            this.handleErrors(error);
        });
    }

    fetchTabData() {  
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objTabData => {
                this.objTabData = objTabData;
                const strBaseCurrentTabUrl = this.objTabData.url;
                const fepParamCheck = BaseLWC.helperBaseGetUrlParameters('isLineOfBusinessFEP', strBaseCurrentTabUrl);
                if(typeof fepParamCheck === 'string' && (fepParamCheck === 'false' || fepParamCheck === 'true')) {
                    this.boolIsFEP = JSON.parse(fepParamCheck);
                }
            }).catch(error => {
                this.handleErrors(error);
            });
        }
    }

    fetchDataFromServer() {
        try {
            if(this.lstRelatedDetails && typeof this.lstRelatedDetails ==='string' && this.lstRelatedDetails === 'no related records') {
                //CEAS-85672 reRender the datatable to reload all methods.
                
                this.boolNoRecordFound = true;
                this.lstCaseRelatedDetails = [];
            } else if (this.lstRelatedDetails && typeof this.lstRelatedDetails) {
                this.lstCRD = JSON.parse(JSON.stringify([...this.lstRelatedDetails]));
                if (this.lstCRD && this.lstCRD.length) {
                    this.addDatatableInfo();
                    if (this.lstCRD[0].Related_Case_ACE__r) {
                        this.boolIsFEP = this.lstCRD[0].Related_Case_ACE__r.FEP_ACE__c;
                    } else {
                        this.fetchLobDetail();
                    }
                } else {
                    //CEAS-85672 reRender the datatable to reload all methods.
                    
                    this.boolNoRecordFound = true;
                    this.lstCaseRelatedDetails = [];
                }
            } else {
                fetchCaseRelatedDetailsRecords({
                    strCaseId: this.strCaseId
                }).then((result) => {
                    if (result) {
                        this.lstCRD = [...result];
                        if (this.lstCRD && this.lstCRD.length > 0) {
                            this.addDatatableInfo();
                        } else {
                            //CEAS-85672 reRender the datatable to reload all methods.
                            this.boolNoRecordFound = true;
                            this.lstCaseRelatedDetails = [];
                            
                        }

                    }
                })
                    .catch(() => {
                        //Do Nothing;
                    });
            }
        } catch (ex) {
            //do nothing
        }
    }
    
     handleRowAction(objEvent) {
       const objEventData = JSON.parse(objEvent.detail);
        if(objEventData.activeColumnData && objEventData.activeColumnData.key === 'RecordLink'){
            const strEncodedParams = objEventData.activeColumnData.value.params;
            const objPageReference = {
                "type": "standard__navItemPage",
                "attributes": {
                    "apiName": objEventData.activeColumnData.value.page
                },
                "state": {
                    
                }
            };
            objPageReference.state[objEventData.activeColumnData.value.paramKey] = strEncodedParams;
            let parentTabId;
            if (this.objTabData.isSubtab) {
                parentTabId = this.objTabData.parentTabId;
            } else {
                parentTabId = this.objTabData.tabId;
            }
            openSubtab(parentTabId, {pageReference: objPageReference, focus: true}).then((response) => {
                setTabLabel(response, objEventData.activeColumnData.value.value);
                setTabIcon(response, 'standard:record');
            });
        }
    }

    addDatatableInfo() {
        fetchStreamlinkGUI({
            strCaseId: this.strCaseId
        }).then(result => {
            this.strStreamLineGUILink = result[0].URL_ACE__c;
            this.lstCRD.forEach(objElement => {
                let strURLParams = null;
                let strFlexipage = null;
                let strTooltipInfo = null;
                let paramKey = 'c__BaseURLParam';
                objElement['RecordTypeName'] = objElement.RecordType.Name;
                //add action link if applicable
                if (objElement.Related_Case_ACE__r.FEP_ACE__c && objElement.RecordType.Name === this.label.ClaimMedicalRecordType_ACE 
                    && ((objElement.Related_Case_ACE__r.Type ==='Claims' && (objElement.Related_Case_ACE__r.Sub_Type_ACE__c === 'Claim Adjustment' || objElement.Related_Case_ACE__r.Sub_Type_ACE__c === 'Claim Status'|| objElement.Related_Case_ACE__r.Sub_Type_ACE__c ==='Refunds / Payments' || objElement.Related_Case_ACE__r.Sub_Type_ACE__c ==='Claim Reconsideration' || objElement.Related_Case_ACE__r.Sub_Type_ACE__c ==='Independent Dispute Resolution'))
                    || (objElement.Related_Case_ACE__r.Type ==='Correspondence' && (objElement.Related_Case_ACE__r.Sub_Type_ACE__c === 'Appeal Correspondence' || objElement.Related_Case_ACE__r.Sub_Type_ACE__c === 'Claim Correspondences' || objElement.Related_Case_ACE__r.Sub_Type_ACE__c ==='Member Correspondence' || objElement.Related_Case_ACE__r.Sub_Type_ACE__c ==='Written Correspondence'))
                    || (objElement.Related_Case_ACE__r.Type ==='Member Management' && (objElement.Related_Case_ACE__r.Sub_Type_ACE__c === 'Adverse Determination' || objElement.Related_Case_ACE__r.Sub_Type_ACE__c === 'Coordination of Benefits' ))
                    || (objElement.Related_Case_ACE__r.Type ==='Special Handling' && (objElement.Related_Case_ACE__r.Sub_Type_ACE__c === 'Fraud' || objElement.Related_Case_ACE__r.Sub_Type_ACE__c === 'Seasons of Life / End of Life')))) {
                    
                    const strCorpCode = objElement.Related_Case_ACE__r.CorporationCode_ACE__c.replace('1','');
                    const strURL = this.strStreamLineGUILink + '/' + strCorpCode + '/' + objElement.Claim_Number_ACE__c;
                    objElement['Link'] = {wrapper: `<a href=` + strURL +  `target="_blank">Adjust Claim (Streamline GUI)</a>`};
                    this.boolIsFEP = true;
                } else if(objElement.Related_Case_ACE__r.FEP_ACE__c) {
                    objElement['Link'] = '';
                    this.boolIsFEP = true;
                } else {
                    //do nothing
                }
                                
                //get URL params and tooltip info for each record type 
                if (objElement.RecordType.Name === 'Appeals' && objElement.GC_Appeal_ACE__c === true) {
                    strFlexipage = 'ViewGCAppealDetails_FlexiPage_ACE';
                    strURLParams = '?' +  window.btoa(unescape(encodeURIComponent('appealId='+objElement.Claim_Number_ACE__c + '&accountId='+objElement.Related_Case_ACE__r.AccountId)));
                    strTooltipInfo = "Patient Name: " + this.validateFieldValue(objElement.Patient_Name_ACE__c) + "<br/>Appeal Completion Date: " + 
                                    this.validateFieldValue(objElement.Completion_Date_ACE__c) + "<br/>Status Reason: " + 
                                    this.validateFieldValue(objElement.Status_Reason_ACE__c) + "<br/>Complaint Class: " + this.validateFieldValue(objElement.ComplaintClass_ACE__c);
                } else if (objElement.RecordType.Name === 'Appeals') {
                    strFlexipage = 'ViewAppealDetails_FlexiPage_ACE';
                    strURLParams = '?'+ window.btoa(unescape(encodeURIComponent('strAppealId='+objElement.Claim_Number_ACE__c+'&mid='+objElement.Related_Case_ACE__r.Account.MID_Surrogate_ACE__c+'&planId=&Cmid=&strPatientName=&strStatusReason='+
                                                        objElement.Status_Reason_ACE__c+'&strCorpCode=' + objElement.Related_Case_ACE__r.CorporationCode_ACE__c + '&strGroupNumber=' +
                                                        objElement.Related_Case_ACE__r.GroupNumber_ACE__c+'&idAccount=' + objElement.Related_Case_ACE__r.AccountId)));
                    strTooltipInfo = "Patient Name: " + this.validateFieldValue(objElement.Patient_Name_ACE__c) + "<br/>Compliance Due Date: " + 
                                    this.validateFieldValue(objElement.Completion_Date_ACE__c) + "<br/>Status Reason: " + 
                                    this.validateFieldValue(objElement.Status_Reason_ACE__c) + "<br/>Sub Category: " + this.validateFieldValue(objElement.Sub_Category_ACE__c);
                } else if (objElement.RecordType.Name === this.label.ClaimPharmacyRecordType_ACE) {
                    strFlexipage = 'Claims_Details_FlexiPage_ACE';
                    strURLParams = '?'+ window.btoa(unescape(encodeURIComponent('claimNumber=' + objElement.Claim_Number_ACE__c +'&mid='+objElement.Related_Case_ACE__r.Account.MID_Surrogate_ACE__c+ '&claimId='+objElement.Claim_Id_ACE__c +'&adjNumber='+objElement.Adjustment_Number_ACE__c+
                                    '&groupNumber=' +objElement.Related_Case_ACE__r.GroupNumber_ACE__c + '&corpCode=' + 
                                    objElement.Related_Case_ACE__r.CorporationCode_ACE__c+'&idAccount='+objElement.Related_Case_ACE__r.AccountId)));
                    strTooltipInfo = "Product Name: " + this.validateFieldValue(objElement.Product_Name_ACE__c) + "<br/>Pharmacy Name: " + 
                                    this.validateFieldValue(objElement.Pharmacy_Name_ACE__c);
                } else if (objElement.RecordType.Name === this.label.IDRDisputeRecordType_ACE) {
                    strFlexipage = 'ViewDisputeDetails_FlexiPage_ACE';
                    strURLParams = '?'+ window.btoa(unescape(encodeURIComponent('claimNumber='+objElement.Idr_Claim_Number_ACE__c+'&mid='+objElement.Related_Case_ACE__r.Account.MID_Surrogate_ACE__c+'&strPatientName='+objElement.Patient_Name_ACE__c+'&strProviderName='+
                                    objElement.Requestor_Name_ACE__c+'&corpCode=' + objElement.Related_Case_ACE__r.CorporationCode_ACE__c + '&groupNumber=' +
                                    objElement.Related_Case_ACE__r.GroupNumber_ACE__c+'&idAccount=' + objElement.Related_Case_ACE__r.AccountId+'&strDisputeId='+
                                    objElement.Claim_Number_ACE__c)));
                    strTooltipInfo = "Requestor Name: " + this.validateFieldValue(objElement.Requestor_Name_ACE__c) + "<br/>Patient Name: " + 
                                    this.validateFieldValue(objElement.Patient_Name_ACE__c) + "<br/>DCN/Claim Number: " + this.validateFieldValue(objElement.Idr_Claim_Number_ACE__c);
                } else if (objElement.RecordType.Name === this.label.ClaimMedicalRecordType_ACE) {
                    if (objElement.Related_Case_ACE__r.FEP_ACE__c) {
                        this.boolIsFEP = true;
                        strFlexipage = 'Claims_History_FlexiPage_ACE';
                        strURLParams = '?' + window.btoa(unescape(encodeURIComponent('strClaimType=FEPClaim'+'&mid=' + 
                                        objElement.Related_Case_ACE__r.Account.MID_Surrogate_ACE__c + '&strClaimStatus=&strGroupNumber=' +
                                        objElement.Related_Case_ACE__r.GroupNumber_ACE__c + '&strCorpCode=' +
                                        objElement.Related_Case_ACE__r.CorporationCode_ACE__c+ '&idAccount=' +objElement.Related_Case_ACE__r.AccountId)));
                        strTooltipInfo = "Total Billed: " + this.validateFieldValue(objElement.Total_Billed_ACE__c) + "<br/>Provider Name: " + 
                                        this.validateFieldValue(objElement.Billing_Provider_Name_Medical_Claim_ACE__c);
                    } else {
                        strFlexipage = 'ViewMedicalClaimDetailsFlexiPage_ACE';
                        strURLParams = '?' + window.btoa(unescape(encodeURIComponent('claimNumber='+ objElement.Claim_Number_ACE__c +'&mid='+
                                            objElement.Related_Case_ACE__r.Account.MID_Surrogate_ACE__c+ '&claimId='+objElement.Claim_Id_ACE__c +
                                            '&adjNumber='+objElement.Adjustment_Number_ACE__c+ '&groupNumber=' +objElement.Related_Case_ACE__r.GroupNumber_ACE__c +
                                            '&corpCode=' + objElement.Related_Case_ACE__r.CorporationCode_ACE__c+'&idAccount='+objElement.Related_Case_ACE__r.AccountId)));
                        strTooltipInfo = "SCCF Number: " + this.validateFieldValue(objElement.SCCF_Number_ACE__c) + "<br/>Total Billed: " + this.validateFieldValue(objElement.Total_Billed_ACE__c) 
                                        + "<br/>Provider Name: " + this.validateFieldValue(objElement.Billing_Provider_Name_Medical_Claim_ACE__c);
                    }
                } else if (objElement.RecordType.Name === this.label.ClaimDentalRecordType_ACE) {
                    strURLParams = '?' + window.btoa(unescape(encodeURIComponent('claimNumber='+ objElement.Claim_Number_ACE__c +'&mid='+
                                objElement.Related_Case_ACE__r.Account.MID_Surrogate_ACE__c+ '&claimId='+objElement.Claim_Id_ACE__c +
                                '&adjNumber='+objElement.Adjustment_Number_ACE__c+ '&groupNumber=' +objElement.Related_Case_ACE__r.GroupNumber_ACE__c +
                                '&corpCode=' + objElement.Related_Case_ACE__r.CorporationCode_ACE__c+'&idAccount='+objElement.Related_Case_ACE__r.AccountId)));
                    strFlexipage = 'ViewDentalClaimDetailsFlexiPage_ACE';
                    strTooltipInfo = "Total Billed: " + this.validateFieldValue(objElement.Total_Billed_ACE__c) + "<br/>Provider Name: " + 
                                    this.validateFieldValue(objElement.Billing_Provider_Name_Medical_Claim_ACE__c);
                } else if (objElement.RecordType.Name === 'Preauth') {
                    paramKey = 'c__strAuthAndTabDetails';
                    strFlexipage = 'PriorAuthReferralDetailsFlexiPage_ACE';
                    strURLParams = '?' + window.btoa(unescape(encodeURIComponent('strAuthorizationNumber='+objElement.Claim_Number_ACE__c+'&strTabName=PreAuthorization')));
                    strTooltipInfo = "Name: " + this.validateFieldValue(objElement.Patient_Name_ACE__c) + "<br/>Date of Birth: " + 
                                    this.validateFieldValue(objElement.BirthDate_ACE__c) + "<br/>Facility: " + this.validateFieldValue(objElement.Facility_ACE__c) + 
                                    "<br/>Requested Dates of Service: " + this.validateFieldValue(objElement.Requested_Date_Range_ACE__c);
                } else if (objElement.RecordType.Name === 'Predetermination') {
                    paramKey = 'c__strAuthAndTabDetails';
                    strFlexipage = 'PredeterminationDetailsFlexiPage_ACE';
                    strURLParams = '?' + window.btoa(unescape(encodeURIComponent('strAuthorizationNumber='+objElement.Claim_Number_ACE__c+'&strTabName=PreDetermination')));
                    strTooltipInfo = "Name: " + this.validateFieldValue(objElement.Patient_Name_ACE__c) + "<br/>Date of Birth: " + this.validateFieldValue(objElement.BirthDate_ACE__c) + 
                                    "<br/>Facility: " + this.validateFieldValue(objElement.Facility_ACE__c) + "<br/>Requested Dates of Service: " + 
                                    this.validateFieldValue(objElement.Requested_Date_Range_ACE__c);
                } else if (objElement.RecordType.Name === 'Referrals') {
                    paramKey = 'c__strAuthAndTabDetails';
                    strFlexipage = 'ReferralDetailFlexiPage_ACE';
                    strURLParams = window.btoa(unescape(encodeURIComponent('strAuthorizationNumber='+objElement.Claim_Number_ACE__c+'&strTabName=Referral')));
                    strTooltipInfo = "Name: " + this.validateFieldValue(objElement.Patient_Name_ACE__c) + "<br/>Date of Birth: " + this.validateFieldValue(objElement.BirthDate_ACE__c) + 
                                    "<br/>Facility: " + this.validateFieldValue(objElement.Facility_ACE__c) + "<br/>Requested Dates of Service: " + 
                                    this.validateFieldValue(objElement.Requested_Date_Range_ACE__c);
                } else if (objElement.RecordType.Name === this.label.PreServicePreDetECMRecordType_ACE) {
                    strFlexipage = 'ViewPreserviceDetailsFlexiPage_ACE';
                    strURLParams = window.btoa(unescape(encodeURIComponent('?c__BaseURLParam=strFocusId=PreDeterminations' + '&mid='+objElement.Related_Case_ACE__r.Account.MID_Surrogate_ACE__c+'&strname=' +
                                    objElement.Related_Case_ACE__r.AccountName_ACE__c+'&strECM=show&strObjectId=' + objElement.ObjectId_ACE__c + 
                                    '&strDescription=' + objElement.Description_ACE__c)));
                    strTooltipInfo = "Folder ID: " + this.validateFieldValue(objElement.Folder_Id_ACE__c) + "<br/>Date Received: " + this.validateFieldValue(objElement.DateReceived_ACE__c) + 
                                    "<br/>Document Types: " + this.validateFieldValue(objElement.DocumentTypes_ACE__c) + "<br/>Number of Pages: " + this.validateFieldValue(objElement.NumberOfPages_ACE__c);
                } else {
                    strFlexipage = 'PredeterminationDetailsFlexiPage_ACE';
                    strURLParams = window.btoa(unescape(encodeURIComponent('strAuthorizationNumber='+objElement.Claim_Number_ACE__c+'&strTabName=ECM_Image')));
                    strTooltipInfo = "Date Received: " + this.validateFieldValue(objElement.DateReceived_ACE__c) + 
                                    "<br/>Document Types: " + this.validateFieldValue(objElement.DocumentTypes_ACE__c) + "<br/>Number of Pages: " + 
                                    this.validateFieldValue(objElement.NumberOfPages_ACE__c);
                }
                const objLink = `<a data-masterLabel=${objElement.Claim_Number_ACE__c} href='javascript:void(0);'>${objElement.Claim_Number_ACE__c}</a>`
                objElement['RecordLink'] = {
                    value: objElement.Claim_Number_ACE__c,
                    wrapper: objLink,
                    page: strFlexipage,
                    params: strURLParams,
                    paramKey: paramKey
                };
                objElement['HelpText'] = {};
                objElement['HelpText'].strCellValue = strTooltipInfo;
                objElement['HelpText'].strTextTooltipContent = strTooltipInfo;
            });
            this.lstCaseRelatedDetails = [...this.lstCRD];
        });
    }

    validateFieldValue(strFieldValue) {
        if (BaseLWC.isUndefinedOrNullOrBlank(strFieldValue)){
            return '';
        } else {
            return strFieldValue;
        }
    }
}