import { LightningElement, api, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';
import BaseLWC from 'c/baseLWCFunctions_CF';

import {getRecordNotifyChange } from 'lightning/uiRecordApi';

import checkCaseStatus from '@salesforce/apex/CreateChildCaseController_ACE.checkCaseStatus';
import updateCase from '@salesforce/apex/CreateChildCaseController_ACE.updateCase';

import CreateChildCase_CardBody_ErrorStatus_ACE from '@salesforce/label/c.CreateChildCase_CardBody_ErrorStatus_ACE';
import CreateChildCase_CardHeader_ChangePlan_ACE from '@salesforce/label/c.CreateChildCase_CardHeader_ChangePlan_ACE';
import CreateChildCase_CardHeader_SubscriberID_ACE from '@salesforce/label/c.CreateChildCase_CardHeader_SubscriberID_ACE';
import CreateChildCase_CardHeader_Corporation_ACE from '@salesforce/label/c.MemberSearch_CorporationLabel_ACE';
import CreateChildCase_CardHeader_GroupNumber_ACE from '@salesforce/label/c.GroupNumber_ACE';
import CreateChildCase_CardHeader_Status_ACE from '@salesforce/label/c.SRSummary_Status_ACE';
import ViewPlanSummary_Select_ACE from '@salesforce/label/c.ViewPlanSummary_Select_ACE';
import CreateChildCase_CardBody_DataIssue_ACE from '@salesforce/label/c.CreateChildCase_CardBody_DataIssue_ACE';
import CreateChildCase_CardBody_UpdateSuccess_ACE from '@salesforce/label/c.CreateChildCase_CardBody_UpdateSuccess_ACE';
import CreateChildCase_CardBody_UpdateError_ACE from '@salesforce/label/c.CreateChildCase_CardBody_UpdateError_ACE';
import Message_error_ACE from '@salesforce/label/c.Message_error_ACE';


export default class CreateChangePlanLightningComponentLwc extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;

    @api recordId;
    @api boolOpenPlanModal;
    @api planSummaryDetail;

    boolIsError;
    strErrorMessage;
    lstAllPlanDetails;
    planDetails;
    strLineOfBusiness;
    objTabData;
    casestatus;

    label = {  
        CreateChildCase_CardBody_ErrorStatus_ACE,
        CreateChildCase_CardHeader_ChangePlan_ACE,
        CreateChildCase_CardHeader_SubscriberID_ACE,
        CreateChildCase_CardHeader_Corporation_ACE,
        CreateChildCase_CardHeader_GroupNumber_ACE,
        CreateChildCase_CardHeader_Status_ACE,
        ViewPlanSummary_Select_ACE,
        CreateChildCase_CardBody_DataIssue_ACE,
        CreateChildCase_CardBody_UpdateSuccess_ACE,
        CreateChildCase_CardBody_UpdateError_ACE,
        Message_error_ACE
    };

    connectedCallback() {
        this.callbackMethod();
    }

    callbackMethod() {
        try {

            checkCaseStatus({ idCase: this.recordId })
            .then((result) => {
                this.casestatus = result; 
                 if (this.casestatus === "Withdrawn" || this.casestatus === "Closed") {
                    this.boolIsError = true;
                    this.strErrorMessage = this.label.CreateChildCase_CardBody_ErrorStatus_ACE ;
                }
                else {
                    this.fetchTabData();
                }
                
            })
            .catch(() => {
                this.handleErrors();
                this.boolIsError = true;
            });
          
        } catch (error) {
            //Handle Error
            this.handleErrors();
        }
    }

    fetchTabData() {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId)
            .then((objTabData) => {
                this.objTabData = objTabData;                
                this.capturePlanSummaryListener();
            })
            .catch(() => {
                this.handleErrors();
            });
        }
    }
  capturePlanSummaryListener () {
    const planSummaryDataEvent = JSON.stringify(this.planSummaryDetail);
      if (BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent)) {
            const objListenerResponse = JSON.parse(planSummaryDataEvent);
            this.boolIsError = false;
            this.planDetails = objListenerResponse.objParameters.objMessage.objSelectedPlanDetails;
            const arrPlanDetails = [];
            let objPlanDetails;
                            if (this.planDetails !== undefined && this.planDetails !== null) {
                                if (objListenerResponse.objParameters.objMessage.strMoreThanOnePlan === false ||
                                    objListenerResponse.objParameters.objMessage.strMoreThanOnePlan === 'false') {
                                    const strAddOnServices = this.getAddOnService(objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.lstCoverageCodes, objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strEnrollmentStatus);
                                    let strSource= '';
                                    this.strLineOfBusiness = objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strAceLineOfBusiness;

                                    if (this.strLineOfBusiness !== undefined && this.strLineOfBusiness !== null && this.strLineOfBusiness !== '' && this.strLineOfBusiness === 'Retail') {
                                        strSource = objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strSourceSystemName;
                                    }

                                    objPlanDetails = {
                                       strSubscriberId: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strSubscriberId,
                                       strCorpCode: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strCorpCode,
                                       strGroupNumber: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strGroupNumber,
                                       strEnrollmentStatus: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strEnrollmentStatus,
                                       strAccountNumber: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strAccountNumber,
                                       boolPgIndicator: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.boolPgIndicator,
                                       strGroupSectionNumber: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.objViewEmployerGroupWrapper.strGroupSectionNumber,
                                       strPolicyId: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strPolicyId,
                                       strEffectiveDate: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strEffectiveDate,
                                       strTerminationDate: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strTerminationDate,
                                       strNetwork: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strNetwork,
                                       strClientMemberId: objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strClientMemberId,
                                       strFundingTypeCode :objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strFundingTypeCode,
                                       strGroupName:objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strGroupName,
                                       strAddOnServices: strAddOnServices,
                                       strLob:this.strLineOfBusiness,
                                       strSourceSystem:strSource,
                                       strGroupCostCenter:objListenerResponse.objParameters.objMessage.objSelectedPlanDetails.strGroupCostCenterNumber
                                    };
                                    arrPlanDetails.push(objPlanDetails);
                                } else {
                                try {
                                   for (const obj in objListenerResponse.objParameters.objMessage.objHistoryPlanDetails) {
                                        const strAddOnServices = this.getAddOnService(objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].lstCoverageCodes, objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strEnrollmentStatus);
                                        this.strLineOfBusiness = objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strAceLineOfBusiness;
                                        let strSource= '';
                                        if(this.strLineOfBusiness !== undefined && this.strLineOfBusiness!==null && this.strLineOfBusiness!== '' && this.strLineOfBusiness==='Retail') {
                                            strSource = objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strSourceSystemName;
                                        }
                                        objPlanDetails = {
                                            strSubscriberId: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strSubscriberId,
                                            strCorpCode: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strCorpCode,
                                            strGroupNumber: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strGroupNumber,
                                            strEnrollmentStatus: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strEnrollmentStatus,
                                            strAccountNumber: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strAccountNumber,
                                            boolPgIndicator: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].boolPgIndicator,
                                            strGroupSectionNumber: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].objViewEmployerGroupWrapper.strGroupSectionNumber,
                                            strPolicyId: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strPolicyId,
                                            strEffectiveDate: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strEffectiveDate,
                                            strTerminationDate: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strTerminationDate,
                                            strNetwork: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strNetwork,
                                            strClientMemberId: objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strClientMemberId,
                                            strFundingTypeCode :objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strFundingTypeCode,
                                            strGroupName:objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strGroupName,
                                            strAddOnServices: strAddOnServices,
                                            strLob:this.strLineOfBusiness,
                                            strSourceSystem:strSource,
                                            strGroupCostCenter:objListenerResponse.objParameters.objMessage.objHistoryPlanDetails[obj].strGroupCostCenterNumber
                                        };
                                        arrPlanDetails.push(objPlanDetails);
                                    }

                                } catch(exception){
                                    //do nothing
                                }
                                }
                                if (arrPlanDetails === undefined || arrPlanDetails ===null || arrPlanDetails.length === 0) {
                                    this.boolShowSpinner = true;
                                     this.boolIsError=true;
                                    this.strErrorMessage = this.label.CreateChildCase_CardBody_DataIssue_ACE;
                                } else {
                                    this.boolIsError=false;   
                                    this.boolShowSpinner = true;
                                    this.lstAllPlanDetails = arrPlanDetails;
                                    this.objPlanSummaryListener = null;
                                }
                            }
        }
    }

    getAddOnService(lstAddOnServices, strEnrollmentStatus) {
        let strAddOnServices = '';
        try {
        if (lstAddOnServices !== undefined && lstAddOnServices !== null && lstAddOnServices !== '' && lstAddOnServices) {
            for (let intCount = 0; intCount < lstAddOnServices.length; intCount++) {
                if (strEnrollmentStatus !== undefined && strEnrollmentStatus !== null && strEnrollmentStatus !== '' &&
                    strEnrollmentStatus.toUpperCase() !== 'INACTIVE' && lstAddOnServices[intCount].strEffectiveEndDate !== undefined &&
                    lstAddOnServices[intCount].strEffectiveEndDate !== null && lstAddOnServices[intCount].strEffectiveEndDate !== "") {
                    const codeDate = new Date(lstAddOnServices[intCount].strEffectiveEndDate);
                    const CurrentDate = new Date();
                    CurrentDate.setHours(0, 0, 0, 0);
                    if (lstAddOnServices[intCount].strCode !== null && codeDate >= CurrentDate) {
                        if (strAddOnServices === '') {
                            strAddOnServices = lstAddOnServices[intCount].strCode;
                        } else {
                            strAddOnServices = strAddOnServices + ',' + lstAddOnServices[intCount].strCode;
                        }
                    }
                } else if (strEnrollmentStatus !== undefined && strEnrollmentStatus !== null && strEnrollmentStatus !== '' &&
                    strEnrollmentStatus.toUpperCase() === 'INACTIVE') {
                    if (lstAddOnServices[intCount].strCode !== null) {
                        if (strAddOnServices === '') {
                            strAddOnServices = lstAddOnServices[intCount].strCode;
                        } else {
                            strAddOnServices = strAddOnServices + ',' + lstAddOnServices[intCount].strCode;
                        }
                    }
                } else {
                    /*Do Nothing*/
                }
            }
        }
    } catch(exception){
       //do nothing
    }
        return strAddOnServices;
    }

     //Handle the error occurances
     handleErrors() {
        //Do nothing
    }

    showAddtoCase() {
        this.boolOpenPlanModal = true;
    }

    closeModel() {  
        this.closeModalEvent();
        this.boolOpenPlanModal =  false;
    }

    selectPlan(event) {
        //Bind the data to aura attributes to display the data on UI.
        try{
        const strPolicyDetails1 = JSON.parse(JSON.stringify(event.target.name));

        if(strPolicyDetails1.strGroupNumber  !== null && strPolicyDetails1.strGroupNumber  !== undefined && strPolicyDetails1.strGroupNumber  !== '' &&
         strPolicyDetails1.strCorpCode !== null && strPolicyDetails1.strCorpCode !== undefined && strPolicyDetails1.strCorpCode !== '' && 
         strPolicyDetails1.strSubscriberId !== null && strPolicyDetails1.strSubscriberId !== undefined && strPolicyDetails1.strSubscriberId !== '') {
            const objResponseCTI = {
                strIdDestination: "postingMessageFromCasePlan",
                objParameters: {
                    strGroup : strPolicyDetails1.strGroupNumber,
                    strCorp : strPolicyDetails1.strCorpCode,
                    strSub :strPolicyDetails1.strSubscriberId
                }
            }
        let objElementId;
        setTimeout((function () {
          try {

                // First we check if the iframe with same id exists in the dom. If yes then we just post a message to the contentWindow of the iFrame.
                objElementId = document.getElementById('iframe');
                if (objElementId !== undefined && objElementId !== null && objElementId.contentWindow !== undefined && objElementId.contentWindow !== null) {
                    
                        objElementId.contentWindow.postMessage({
                            key: 'IVRParamsFromPlanChange',
                            value: JSON.stringify(objResponseCTI),
                            boolIsLocalStorageEvent: true
                        }, '*');
                   
                } else {

                    // If the iframe does not exists, then we just create a new iFrame and post a message.
                    objElementId = document.createElement("iframe");
                    objElementId.src = '/apex/' + 'SetlocalstoragePage_ACE';
                    objElementId.id = 'iframe';
                    objElementId.width = 0;
                    objElementId.height = 0;
                    objElementId.style.display = "none";
                    document.body.appendChild(objElementId);
                    objElementId.onload = function () {
                      
                            objElementId.contentWindow.postMessage({
                                key: 'IVRParamsFromPlanChange',
                                value: JSON.stringify(objResponseCTI),
                                boolIsLocalStorageEvent: true
                            }, '*');
                        
                    }
                }
            } catch (exception) {
                // Do nothing.
            }
        }), 2000);


        }
        updateCase({ idCase: this.recordId ,
            strPolicyId: strPolicyDetails1.strPolicyId,
            strEffectiveDate : strPolicyDetails1.strEffectiveDate,
            strTerminationDate : strPolicyDetails1.strTerminationDate,
            strSubscriberId : strPolicyDetails1.strSubscriberId,
            strGroupNumber :strPolicyDetails1.strGroupNumber ,
            strGroupSectionNumber : strPolicyDetails1.strGroupSectionNumber,
            strCorpCode : strPolicyDetails1.strCorpCode,
            strAccountNumber : strPolicyDetails1.strAccountNumber,
            strNetwork : strPolicyDetails1.strNetwork,
            strCmid :strPolicyDetails1.strClientMemberId ,
            strAddOnServices : strPolicyDetails1.strAddOnServices,
            strFundingTypeCode : strPolicyDetails1.strFundingTypeCode,
            strGroupName : strPolicyDetails1.strGroupName,
            boolPgIndicator : strPolicyDetails1.boolPgIndicator,
            strLOB : strPolicyDetails1.strLob,
            strSource : strPolicyDetails1.strSourceSystem,
            strGroupCostCenter : strPolicyDetails1.strGroupCostCenter,
        })
        .then((result) => {
                const boolIsUpdate = result;
                this.boolOpenPlanModal = false;
                if (boolIsUpdate) {
                    const evt = new ShowToastEvent({
                        title: this.label.CreateChildCase_CardBody_UpdateSuccess_ACE,
                        message: ' ',
                        messageTemplate: ' ',
                        duration: ' 5000',
                        key: 'info_alt',
                        type: 'success',
                        mode: 'pester',
                        variant: 'success',
                        });
                        this.dispatchEvent(evt);
                        localStorage.strBypassCustomRefreshLogic = "true";
                       getRecordNotifyChange([{recordId: this.recordId}]);
                } else {
                   const errorEvt = new ShowToastEvent({
                    title: 'Error Message',
                    message: this.label.CreateChildCase_CardBody_UpdateError_ACE,
                    messageTemplate: this.label.CreateChildCase_CardBody_UpdateError_ACE,
                    duration: ' 5000',
                    key: 'info_alt',
                    type: 'error',
                    mode: 'pester',
                    variant: 'error',
                    });
                    this.dispatchEvent(errorEvt);
                }
           
        })
        .catch(() => {
            this.handleErrors();
        }); 
        } catch(e){
            this.handleErrors();
        }
         
    }

    closeModalEvent() {
        const casecloseModal = new CustomEvent('changeplanclosemodal', {
            detail: { boolOpenPlanModal: false }
        });
        // Fire the custom event
        this.dispatchEvent(casecloseModal);
    }

   disconnectedCallback() {
    //Do Nothing
   }
    
}