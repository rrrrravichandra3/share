import { LightningElement, api } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import fetchClinicalDispositionFromCaseAndAccount from '@salesforce/apex/ClinicalDispositionController_ACE.getClinicalDispositionFromCaseAndAccount';
import fetchClinicalDispositionValues from '@salesforce/apex/ClinicalDispositionController_ACE.fetchClinicalDispositionValues';
import createCaseRecord from '@salesforce/apex/ClinicalDispositionController_ACE.createCaseRecord';
import updateCaseRecord from '@salesforce/apex/ClinicalDispositionController_ACE.updateCaseRecord';

export default class ClinicalSelectLWCACE extends LightningElement {
    showText = false;
    @api objTabData;
    strBaseCurrentTabId;
    strBaseCurrentParentTabId;
    strBaseCurrentTabUrl;
    boolSpinner = false;
    objError;
    boolBaseIsItSubTab;
    boolVPSTabSpecificEvents;
    objPlanSummaryListener;
    @api objSelectedPlanDetails;
    localStorageListener;
    @api accountRecordId;
    isButtonDisable = false;
    boolInActiveCall = false;
    strInteractionIdPlanSummary;
    strInteractionId;
    strClinicalDispositionChecked = '';
    lstClinicalInCase = [];
    lstClinicalValues = [];
    lstTableData = [];
    boolCaseCreated = false;
    mapClinicalValues;
    label = {
        EnableVPSTabSpecificEvents_ACE
    };
    handleClinicalAction(event) {
        this.constructTable();
        this.showTable = !this.showTable;
    }
    get clinicalVariant() {
        if (this.showTable) {
            return 'brand';
        }
        return '';
    }
    get displayTable() {
        return this.showTable && BaseLWC.arrayIsNotEmpty(this.lstTableData);
    }
    get clinicalActionButtonName() {
        if (this.strClinicalDispositionChecked && this.strClinicalDispositionChecked.split(',').length) {
            return `Clinical Action (${this.strClinicalDispositionChecked.split(',').length})`;
        } return 'Clinical Action';
    }
    
    columns = [ 
        { label: 'Clinical Disposition', fieldName: 'clinicalDisposition', sortable: true, type: '', boolInitSort:true, boolAsc:true },
        { label: 'SELECT', fieldName: 'selector', sortable: true, type: '' }          
    ];
    showTable = false;
    objInitTableSettings = {
        pageSize: 100,
        restrictedPageSize:100,
        boolViewMore: false,
        columnsData: this.columns,
        boolShowFilter: false,
        boolSecondaryTable: false,
        boolShowSearch: false,
        boolShowSearchLabel:false,
        boolShowRecordCount:false
    };
    connectedCallback() {
        this.mapClinicalValues = new Map();
        if (this.objTabData) {
            this.processTabData();
        }
    }
    boolProvider = false;

    handleErrors = (error) => {
        this.objError = error;
    };
    strProfileName;

    processTabData = () => {
        try {
            this.strBaseCurrentTabId = this.objTabData.tabId;
            this.strBaseCurrentTabUrl = this.objTabData.url;
            this.boolBaseIsItSubTab = this.objTabData.isSubtab;
            
            if (this.boolBaseIsItSubTab === true) {
                this.strBaseCurrentParentTabId = this.objTabData.parentTabId;
            } else {
                this.strBaseCurrentParentTabId = this.objTabData.tabId;
            }
            if (BaseLWC.stringIsNotBlank(this.label.EnableVPSTabSpecificEvents_ACE) && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                this.boolVPSTabSpecificEvents = true;
            }
            //CEAS-73247 - Get Profile Name from URL.
            const strProfileParam = BaseLWC.helperBaseGetUrlParameters('pfn', this.strBaseCurrentTabUrl);
            if(strProfileParam) {
                this.strProfileName = strProfileParam;
            }
            if (this.strProfileName) {
                if (this.label.Read_Only_Profile && 
                    this.label.split(',').includes(this.strProfileName)) { 
                    this.isButtonDisable = true;
                } else {
                    this.isButtonDisable = false;
                }
            }
            const strDecodedURL = BaseLWC.helperBaseDecodeUrl(this.strBaseCurrentTabUrl);
            const objUrl = new URL(strDecodedURL);
            const strProviderSearch = objUrl.searchParams.get('ProviderSearch');
            if (BaseLWC.isNotUndefinedOrNull(strProviderSearch) && (strProviderSearch === 'true' || strProviderSearch === true)) {
                this.boolProvider = true;
            } else {
                this.boolProvider = false;
            }
            this.executeInitialFunctionality();
        } catch (error) {
            this.handleErrors(error);
        }
    };
    executeInitialFunctionality() {
        const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + this.accountRecordId;
        this.strInteractionId = BaseLWC.helperBaseGetItem(localStorageKey);
        this.handleLocalStorageListener();
        this.fetchClinicalData();
    }
    processPlanData = (planData) => {
        
    }
    async fetchClinicalData() {
        try {
            if (this.strInteractionId && this.accountRecordId) {
                const objResult = await  fetchClinicalDispositionFromCaseAndAccount({'strInteractionLogId': this.strInteractionId, 'strIdAccount': this.accountRecordId});
                if (objResult && objResult.length) {
                    this.lstClinicalInCase = objResult;
                    this.strClinicalDispositionChecked = this.lstClinicalInCase.toString();
                    this.lstClinicalInCase.forEach(el => {
                        const strId =el.replaceAll(/ /g, '');
                        this.mapClinicalValues.set(strId, el.Label);
                    })
                }
            }
            const apexResult = await fetchClinicalDispositionValues();
            if (apexResult && apexResult.length) {
                this.lstClinicalValues = apexResult;
            }
            this.constructTable();
        } catch(error) {
            this.handlErrors(error);
        }
    }
    constructTable() {
        this.lstTableData = [];
        this.lstClinicalValues.forEach(el => {
            const objectClinical = {};
            let boolPresent = false;;
            if (this.strClinicalDispositionChecked.includes(el.Label)) {
                boolPresent = true;
            }
            objectClinical.clinicalDisposition = el.Label;
            const strId = el.Label ? el.Label.replaceAll(/ /g, '') : el.Label;
            if (boolPresent) {
                this.mapClinicalValues.set(strId, el.Label);
                if (this.strInteractionId) {
                    objectClinical.selector = {
                        value : el.Label,
                        wrapper:`<input type="checkbox" name="select" style="display: inline-block; position: relative;outline: none;width: 1rem;height: 1rem;vertical-align: middle;" id="selectCheckBox" checked/>`
                    }
                } else {
                    objectClinical.selector = {
                        value : el.Label,
                        wrapper:`<input type="checkbox" name="select" style="display: inline-block; position: relative;outline: none;width: 1rem;height: 1rem;vertical-align: middle;" id="selectCheckBox" disabled checked/>`
                    }
                }
            } else {
                if (this.strInteractionId) {
                    objectClinical.selector = {
                        value : el.Label,
                        wrapper:`<input type="checkbox" name="select" style="display: inline-block; position: relative;outline: none;width: 1rem;height: 1rem;vertical-align: middle;" id="selectCheckBox"/>`
                    }
                } else {
                    objectClinical.selector = {
                        value : el.Label,
                        wrapper:`<input type="checkbox" name="select" style="display: inline-block; position: relative;outline: none;width: 1rem;height: 1rem;vertical-align: middle;" id="selectCheckBox" disabled/>`
                    }
                }
            }
            objectClinical.selector.strId = strId;
            this.lstTableData.push(objectClinical);
        })
        this.setClinicalString();
    }
    async createCase() {
        try {
            if (this.boolCaseCreated) {
                const objResult = await updateCaseRecord({'caseId' : this.strCaseId, 'strIdAccount' : this.accountRecordId, 'strInteractionLogId' : this.strInteractionId, 'strClinicalDispositionChecked': this.strClinicalDispositionChecked});
                if (objResult) {
                    this.hideSpinner();
                }
            } else {
                let strAddOnServices = '';
                if(this.objSelectedPlanDetails.addOnServices !== 'undefined' && this.objSelectedPlanDetails.addOnServices !== null) {
                    let lstAddOnServices = this.objSelectedPlanDetails.addOnServices;
                    const strPolicyStatus = this.objSelectedPlanDetails.strEnrollmentStatus;
                    if (lstAddOnServices) {
                        strAddOnServices = "";
                        for (let intCount = 0; intCount < lstAddOnServices.length; intCount++) {
                            let codeDate = new Date(lstAddOnServices[intCount].strEffectiveEndDate);
                            let CurrentDate = new Date();
                            CurrentDate.setHours(0, 0, 0, 0);
                            if (lstAddOnServices[intCount].strCode !== null &&  strPolicyStatus!==undefined && strPolicyStatus!== null
                                && strPolicyStatus!=='' && strPolicyStatus.toUpperCase() !=='INACTIVE' &&  codeDate >= CurrentDate ) {
                                if (intCount ==0) {
                                    strAddOnServices = lstAddOnServices[intCount].strCode;
                                } else {
                                    strAddOnServices = strAddOnServices +',' + lstAddOnServices[intCount].strCode;
                                }				
                            }
                            else if(strPolicyStatus!==undefined && strPolicyStatus!== null
                                && strPolicyStatus!=='' && strPolicyStatus.toUpperCase() ==='INACTIVE' && lstAddOnServices[intCount].strCode !== null){
                                if (intCount ==0) {
                                    strAddOnServices = lstAddOnServices[intCount].strCode;
                                } else {
                                    strAddOnServices = strAddOnServices +',' + lstAddOnServices[intCount].strCode;
                                }
                            }
                        }
                    }
                }
                const boolCbcApiCallAvailable = this.objSelectedPlanDetails.boolCbcApiCallAvailable || false;
                const boolAccountsAPICallAvailable = this.objSelectedPlanDetails.boolAccountsAPICallAvailable || false;
                const objParameters =
                {
                    "mid" : this.objSelectedPlanDetails.strMemberId,
                    "strGroupNum" : this.objSelectedPlanDetails.strGroupNumber,
                    'groupName' : this.objSelectedPlanDetails.groupName,
                    "strPolicyId" : this.objSelectedPlanDetails.strPolicyId,
                    "strSubscriberId" : this.objSelectedPlanDetails.strSubscriberId,
                    "strCorpCode" : this.objSelectedPlanDetails.strCorporationCode,
                    "strAccountNumber" : this.objSelectedPlanDetails.strAccountNumber,
                    "strInteractionId" : this.strInteractionId,
                    "strSecureGroupRole" : '',
                    "strSectionNumber" : this.objSelectedPlanDetails.strGroupSectionNumber,
                    "strQuickLinksLabel" : " ",
                    "strGroupCostCenter" : this.objSelectedPlanDetails.strGroupCostCenterNumber,
                    "strGroupName" : this.objSelectedPlanDetails.groupName,
                    "strCMID" : this.objSelectedPlanDetails.strCMID,
                    "strProductType" : this.objSelectedPlanDetails.strNetwork,
                    "strMultiPlan" : this.objSelectedPlanDetails.strMultiPlan,
                    "boolPgIndicator" : this.objSelectedPlanDetails.boolPgIndicator,
                    "strEffectiveDate" : this.objSelectedPlanDetails.strEffectiveDate,
                    "strTerminationDate" : this.objSelectedPlanDetails.strTerminationDate,
                    "strCoverageCodes" : strAddOnServices,
                    "boolAccountsAPICallAvailable" : boolAccountsAPICallAvailable.toString(),
                    "boolCbcApiCallAvailable" : boolCbcApiCallAvailable.toString(),
                    "strCaseType" : "Reporting",
                    "strCaseSubType" : "Reporting",
                    "strLineOfBusiness" : this.objSelectedPlanDetails.strAceLineOfBusiness,
                    //CEAS-62221
                    "boolIsProvider": this.boolProvider.toString(),
                    'strClinicalDispositionChecked': this.strClinicalDispositionChecked
                };
                const objResult = await createCaseRecord(objParameters);
                if (objResult && objResult.Id) {
                    this.boolCaseCreated = true;
                    this.strInteractionId = objResult.EarliestInteractionLog_ACE__c;
                    this.strCaseId = objResult.Id;
                    this.hideSpinner();
                }
            }
            
        } catch(error) {
            this.handlErrors(error);
        }
    }
    hideSpinner() {
        this.boolSpinner = false;
    }
    objError;
    handlErrors(error) {
        this.objError = error;
    }
    setClinicalString() {
        if (this.mapClinicalValues && this.mapClinicalValues.size) {
            this.strClinicalDispositionChecked = Array.from(this.mapClinicalValues.values()).toString();
        } else {
            this.strClinicalDispositionChecked = '';
        }
    }
    handleRowAction(event) {
        if (!this.strInteractionId) {
            return;
        }
        this.boolSpinner = true;
        if (event.detail) {
            const column = JSON.parse(event.detail).activeColFieldName;
            const rowData = JSON.parse(event.detail);
            if (column === 'selector'){ 
                const strId = rowData.activeColumnData.value.strId;
                if (this.mapClinicalValues.has(strId)) {
                    this.mapClinicalValues.delete(strId);
                } else {
                    this.mapClinicalValues.set(strId, rowData.activeColumnData.value.value);
                }
            }
            this.setClinicalString();
            this.createCase();
        }
    }
    handleLocalStorageListener = () => {
        if(!this.localStorageListener) {
        const objGenericListener = (objListenerEvent) => {
            if (this.localStorageListener === null) {
                window.removeEventListener('message', objGenericListener, false)
            }

            let objLocalStorageData;
            if (objListenerEvent !== undefined && objListenerEvent !== null && typeof objListenerEvent.data === 'string') {
                try {
                    objLocalStorageData = JSON.parse(objListenerEvent.data);
                } catch (objException) {
                    // Do nothing
                }

                if (objLocalStorageData !== undefined && objLocalStorageData !== null && objLocalStorageData.strIdDestination === 'LocalStorageEvent' && objLocalStorageData.objParameters !== undefined && objLocalStorageData.objParameters !== null &&
                    objLocalStorageData.objParameters.objMessage !== undefined && objLocalStorageData.objParameters.objMessage !== null) {
                    const newValue = objLocalStorageData.objParameters.objMessage.newValue;
                    const key = objLocalStorageData.objParameters.objMessage.key;
                    const strAccountIdForCTI = this.accountRecordId;
                    if (strAccountIdForCTI !== undefined && strAccountIdForCTI !== null && key !== undefined && key !== null && key.indexOf('_') > -1 && key.startsWith('strInteractionLogIdForPlanSummaryStamp_')) {
                        if (key.split('_')[1] === strAccountIdForCTI) {
                            const strInteractionLogIdForPlanSummary = newValue;
                            this.boolInActiveCall = false;
                            if (strInteractionLogIdForPlanSummary !== undefined && strInteractionLogIdForPlanSummary !== null) {
                                this.boolInActiveCall = true;
                                this.strInteractionId = strInteractionLogIdForPlanSummary;
                                this.constructTable();
                            } else {
                                this.boolInActiveCall = false;
                                this.strInteractionId = '';
                                this.constructTable();
                            }
                        }
                    } else if (strAccountIdForCTI !== undefined && strAccountIdForCTI !== null && key !== undefined && key !== null && key === 'strInteractionLogIdForPlanSummary' && newValue !== undefined && newValue !== null) {
                        const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + strAccountIdForCTI;
                        const interactionId = BaseLWC.helperBaseGetItem(localStorageKey);
                                this.boolInActiveCall = true;
                                this.strInteractionId = interactionId;
                                this.constructTable();
                    } else {
                        //Do Nothing
                    }
                }
            }

        };
        this.localStorageListener = objGenericListener;
        window.addEventListener('message', objGenericListener, false);
        }

    }
}
