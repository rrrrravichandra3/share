import { LightningElement, track,wire,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


import getPDFData from '@salesforce/apex/PreviewLetterController_ACE.sendLetterRequest'; 
import createLetterRecord from '@salesforce/apex/PreviewLetterController_ACE.createLetterRecord';


export default class LwcPreviewLetterACE extends LightningElement {
    @track pdfData ;
    @track memberPDFData;
    @track providerPDFData;
    @track boolMember = false;
    @track boolProvider = false;


    @api recordId;
    @api boolOpenModal;
    @api selectedTemplate;
    @api boolTemplate1 = false;
    @api boolTemplate2 = false;
    @api boolInitModal = false;

    @api strLetterName;
    @api strCaseId;
    @api strRecepientName;

    @api strMemberName;
    @api strProviderName;

    @track correspondence_id='';  
    

    @api templateJsonData;

    boolClicked = false;
    showPdf = false;
    showSpinner = true;
    boolError = false;
    boolDisableSendLetter = true;
    boolDisableDownloadLetter = true ;
    boolDisableEditLetter = false;

    boolPrevieRequest = true;

    @track clsShowPDF = 'slds-hide';


    strErrorMessage = 'There was an error completing your request. Please address as much of the inquiry as possible using supporting systems and then submit a help desk ticket.';
    newLocation='';

    strModalBodyClass ="slds-modal__content modal-body slds-p-around_medium slds-align_absolute-center slds-grid slds-wrap";
   

    async fetchData(requestType) {

        let boolMemberProvider = false;
        let boolApiResult = false;

              
        try{
            this.templateJsonData = JSON.parse(JSON.stringify(this.templateJsonData , (k,v) => v === 'undefined' ? null : v));
            this.templateJsonData.documentVersion =requestType; 

            if(this.templateJsonData.documentData.hcm_output.correspondence 
                && this.templateJsonData.documentData.hcm_output.correspondence.length >1){
                    boolMemberProvider = true;
            }
            
            let result = await getPDFData({ strRequestBody: JSON.stringify(this.templateJsonData) });
            this.boolDisableEditLetter = false;
            if(result){
                result = JSON.parse(result); 
            }

            let respBody;
            let tempPDFData;
            
            if(result && result.strResponseBody) {
                respBody = JSON.parse(result.strResponseBody);
            }

            if(boolMemberProvider){
                if( respBody && respBody.memberResponse && respBody.memberResponse.status=='SUCCESS' &&  respBody.providerResponse && respBody.providerResponse.status=='SUCCESS' ){
                    boolApiResult = true;
                } else {
                    boolApiResult = false;
                }
            } else if( (respBody.memberResponse && respBody.memberResponse.status=='SUCCESS') || ( respBody.providerResponse && respBody.providerResponse.status=='SUCCESS' )){
                boolApiResult = true;
            } else {
                boolApiResult = false;
            }

            if(result && result.strResponseStatusCode && result.strResponseStatusCode === '200'  && respBody && boolApiResult) {
                
                    // Storing PDF Data
                    
                    if(respBody.providerResponse) { //remove
                        this.providerPDFData = respBody.providerResponse.base64Template;
                        tempPDFData = this.providerPDFData;
                        this.boolProvider = true;
                        this.strRecepientName = this.strProviderName;
                        if(respBody.providerResponse.correspondenceIds && respBody.providerResponse.correspondenceIds.length>0) {
                            this.correspondence_id = respBody.providerResponse.correspondenceIds[0];
                        }
                    }

                    if(respBody.memberResponse) {
                        this.memberPDFData = respBody.memberResponse.base64Template;
                        tempPDFData = this.memberPDFData;
                        this.boolMember = true;
                        this.strRecepientName = this.strMemberName;
                        if(respBody.memberResponse.correspondenceIds && respBody.memberResponse.correspondenceIds.length>0) {
                            this.correspondence_id = respBody.memberResponse.correspondenceIds[0];
                        }
                    }

                    

                    if(respBody.memberResponse && respBody.providerResponse) { 
                        if(respBody.providerResponse.correspondenceIds && respBody.providerResponse.correspondenceIds.length>0 
                            && respBody.memberResponse.correspondenceIds && respBody.memberResponse.correspondenceIds.length>0 ) {
                                this.correspondence_id = respBody.memberResponse.correspondenceIds[0] + ','+respBody.providerResponse.correspondenceIds[0];
                        }                        
                        tempPDFData = this.memberPDFData;
                    }

                    if(this.template.querySelector('.modal-body')) {
                        this.template.querySelector('.modal-body').classList.remove('slds-align_absolute-center');
                    }
                    
                    if(requestType == 'DRAFT') {
                        this.pdfData = tempPDFData;
                        this.showPdf = true;                        
                    } 

                    this.clsShowPDF = 'slds-show';                                     
                    
                    this.showSpinner = false;
                    if(requestType =='PRINT') {
                        this.showToast('Success','Letter request sent successfully','success');
                        this.createLetRecord();
                        this.handleClose();
                    }  
                    this.boolDisableSendLetter = false;
                    this.boolDisableDownloadLetter = false;    
                         

            } else {
                this.showSpinner = false;
                this.boolError = true;
                this.boolDisableSendLetter = true;
                if(requestType =='DRAFT') {
                    this.boolDisableDownloadLetter = true;
                } else {
                    this.boolDisableDownloadLetter = false;
                }

            }   

        } catch( error) {
            this.showSpinner = false;
            this.boolError = true;
            this.boolDisableEditLetter = false;
            this.boolDisableSendLetter = true;
            if(requestType =='DRAFT') {
                this.boolDisableDownloadLetter = true;
            } else {
                this.boolDisableDownloadLetter = false;
            }
        }
        
    }

    createLetRecord() {
        createLetterRecord({ corespId : this.correspondence_id , strCaseId: this.strCaseId , strLetterName : this.strLetterName, strRecepientName: this.strRecepientName })
            .then(result => {
                
            })
            .catch(error => {
                
            });
    }

    showToast(messageTitle, message, variant) {
        const event = new ShowToastEvent({
            title: messageTitle,
            message: message,
            variant: variant,
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }

    handleEditLetter(){
        
        let createlettersubmitEvent = new CustomEvent('editletter', {
			detail: {
				
				template1: this.boolTemplate1,
				template2: this.boolTemplate2,
                initialModal: this.boolInitModal
			}
		});
		this.dispatchEvent(createlettersubmitEvent);
   
    }
    connectedCallback() {
        
        this.boolOpenModal = true;
        this.fetchData('DRAFT');
    }


    handleClose() {
        this.boolOpenModal = false;
        let closeModal = new CustomEvent('cancelorclosemodal', {
			detail: {
				boolopencreateletter: false
			}
		});
		this.dispatchEvent(closeModal);
    }

    handleSendPostal() {
        
        this.showSpinner = true;
        this.boolError = false;
        this.boolDisableEditLetter = true;
        this.clsShowPDF = 'slds-hide';
        if(this.template.querySelector('.modal-body')){
            this.template.querySelector('.modal-body').classList.add('slds-align_absolute-center');
        }
        this.fetchData('PRINT');
    }

    

    handleDownload(){
        try{
            this.showSpinner = true;
            this.boolError = false;
            this.clsShowPDF = 'slds-hide';
            this.boolDisableEditLetter = true;
            if(this.template.querySelector('.modal-body')){
                this.template.querySelector('.modal-body').classList.add('slds-align_absolute-center');
            }
            
            if(this.boolProvider){
                this.fetchData('ELECTRONIC');
                let element = document.createElement('a');
                element.setAttribute('href', 'data:application/pdf;base64,' + this.pdfData);
                let fileName = this.strProviderName+'_'+this.strLetterName+'.pdf';
                element.setAttribute('download', fileName);
                element.style.display = 'none'; 
                document.body.appendChild(element);
                element.click();
                document.body.removeChild(element);

            }
            if(this.boolMember){
                this.fetchData('ELECTRONIC');
                let element = document.createElement('a');
                element.setAttribute('href', 'data:application/pdf;base64,' + this.pdfData);
                let fileName = this.strMemberName+'_'+this.strLetterName+'.pdf';
                element.setAttribute('download', fileName);
                element.style.display = 'none'; 
                document.body.appendChild(element);
                element.click();
                document.body.removeChild(element);
            }
        }catch(error){
            //Do nothing
        }
    }

    handleShow(){
        try{
            this.boolOpenModal = true;
            let base64Encode = this.pdfData;
                
            base64Encode = base64Encode.replace(/=+$/, "");
            const linkSource = 'data:application/octet-stream;base64,' + base64Encode; //Del
            let srcBase64EncodeForIframe = 'data:application/octet-stream;base64,' + base64Encode;        
            srcBase64EncodeForIframe = 'data:application/pdf;base64,' + base64Encode;           
            
            const objResponse = {
                strIdDestination: 'FiredFromDownLoadBase64Attachment',
                objParameters: {
                    contentType: 'pdf',
                    srcContentData: srcBase64EncodeForIframe,
                }
            };
            if(this.template.querySelector('.pdfFrame')){
                this.template.querySelector('.pdfFrame').contentWindow.postMessage(JSON.stringify(objResponse), '*');
            }
        }catch(error){
            
        }

    }    
    
}