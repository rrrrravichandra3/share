import { LightningElement, api, track, wire } from "lwc";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


//Base LWC functions.
import BaseLWC from "c/baseLWCFunctions_CF";

//CEAS-82941 Changes
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';

//Import Labels
import DeactivateLightning_Title_ACE from "@salesforce/label/c.DeactivateLightning_Title_ACE";
import HIPAAAuthParty_CloseLabel_ACE from "@salesforce/label/c.HIPAAAuthParty_CloseLabel_ACE";
import DeactivateLightning_Message_ACE from "@salesforce/label/c.DeactivateLightning_Message_ACE";
import HIPAAAuthParty_CancelLabel_ACE from "@salesforce/label/c.HIPAAAuthParty_CancelLabel_ACE";
import HIPAAAuthParty_DeactivateLabel_ACE from "@salesforce/label/c.HIPAAAuthParty_DeactivateLabel_ACE";
import FacetsNMCCAPISuccessMessage_ACE from "@salesforce/label/c.FacetsNMCCAPISuccessMessage_ACE";
import UpdateHIPAARestrictions_CCRFHeaderName_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_CCRFHeaderName_ACE";
import ViewStandardAuthorization_Header_ACE from "@salesforce/label/c.ViewStandardAuthorization_Header_ACE";
import FacetsNotesAPIErrorMessage_ACE from "@salesforce/label/c.FacetsNotesAPIErrorMessage_ACE";
import HIPAAAuthParty_Active_ACE from "@salesforce/label/c.HIPAAAuthParty_Active_ACE";
import HIPAAAuthParty_Deactivated_ACE from "@salesforce/label/c.HIPAAAuthParty_Deactivated_ACE";
import UpdateHIPAARestrictions_RRFHeaderName_ACE from "@salesforce/label/c.UpdateHIPAARestrictions_RRFHeaderName_ACE";
import HIPAAAuthParty_AuthorizedPartyHeader_ACE from "@salesforce/label/c.HIPAAAuthParty_AuthorizedPartyHeader_ACE";

//Import Apex Methods
import getAuthorizationById from '@salesforce/apexContinuation/HIPAA_CCRF_RRF_DetailController_ACE.getAuthorizationById';
import getAddressInfo from '@salesforce/apexContinuation/HIPAA_CCRF_RRF_DetailController_ACE.getAddressInfo';
import submitToFacets from '@salesforce/apexContinuation/HIPAA_CCRF_RRF_DetailController_ACE.submitToFacets';
import processDeactivationRequest from '@salesforce/apexContinuation/HIPAA_CCRF_RRF_DetailController_ACE.processDeactivationRequest';
import submitToFacetsHIPAARestriction from '@salesforce/apexContinuation/HIPAA_CCRF_RRF_DetailController_ACE.submitToFacetsHIPAARestriction';
import createInteractionAndCaseForAutoDocHelper from '@salesforce/apex/HIPAA_CCRF_RRF_DetailController_ACE.createInteractionAndCaseForAutoDocHelper';


export default class LwcDeactivate_ACE extends LightningElement {
    //CEAS-82941 Changes
    @wire(EnclosingTabId) enclosingTabId;

    label = {
        DeactivateLightning_Title_ACE,
        HIPAAAuthParty_CloseLabel_ACE,
        DeactivateLightning_Message_ACE,
        HIPAAAuthParty_CancelLabel_ACE,
        HIPAAAuthParty_DeactivateLabel_ACE,
        FacetsNMCCAPISuccessMessage_ACE,
        UpdateHIPAARestrictions_CCRFHeaderName_ACE,
        ViewStandardAuthorization_Header_ACE,
        FacetsNotesAPIErrorMessage_ACE,
        HIPAAAuthParty_Active_ACE,
        HIPAAAuthParty_Deactivated_ACE,
        UpdateHIPAARestrictions_RRFHeaderName_ACE,
        HIPAAAuthParty_AuthorizedPartyHeader_ACE
    }
    strIntialNotes ='';
    strErrorMessage;

    //Variables passed in from parent component  
    @api boolModalOpen;
    @api strPageName;
    @api strSelectRecordStatus = "";
    @api strCreatedRecordId;
    @api strMid;
    @api strClientMemberId;
    @api strObjectAPIName;
    @api strPlanDetails;
    @api strAccountId;
    @api strInteractionLogId;
    @api strModalHeader = "Deactivate Authorization";
    @api objRecord;
    @api boolIsNMCC;
    @api datDeactivation;
    @api strCreatedInteractionHolder;

    //Attributes
    @api boolError = false;
    @track showSpinner = false;
    


    //Boolean variables

    //Global Variables
    strHIPAAObjectAPIName = 'HIPAA_Restrictions_ACE__c';
    strStandardObjectAPIName = 'Authorized_Parties_ACE__c';
    objAuthorizedParty = {};
    strFacetsGroupId;
    objAddressInfo;
    objMemberName;
    objVoicePhone;
    objDeactivationData;//Useless???
    strFacetsDeactivateError = 'Please confirm you would like to deactivate this record. This action will also deactivate the record in Facets.';
    facetsHIPAAResReq = "";
    objTabData;

    //Initial method
    connectedCallback() {
        this.showSpinner = true;
        try {
            this.doInitHelper();
            this.setPlanData();
        } catch (error) {
            this.handleErrors(error);
        }
    }

    fetchTabData() {
            //CEAS-82941 Changes 
            if (this.enclosingTabId) {
                getTabInfo(this.enclosingTabId).then((tabInfo) => {
                    this.objTabData = tabInfo;
                }).catch((error) => {
                    this.handleErrors();
                });
           }
    }


    closeModal(){
            this.boolModalOpen = false;
            //Post Event to PArent Component
            const eventCloseModal = new CustomEvent("closedeactivatemodal");
              this.dispatchEvent(eventCloseModal);
    }

    saveRecordController() {
        this.handleSaveRecord();
        //NT:CEAS-71625
        if (this.boolIsNMCC && this.strObjectAPIName === 'Authorized_Parties_ACE__c') {
            this.submitToFacets();
        }
    }

    doInitHelper() {
        
        this.boolModalOpen = true;


        //NT:CEAS-71625
        this.objAuthorizedParty = {}
        const idRecord = this.strCreatedRecordId;
        if (typeof idRecord !== "undefined" && idRecord !== "null" && idRecord !== null) {


            getAuthorizationById({
                idRecord: idRecord
            }).then(objResult => {
                objAuthorizedParty = objResult; 
            }).catch(error => {
                //No handling Needed.
            });
        }
    }

    setPlanData() {
        //CEAS-74763 Moving PlanSummary Listner Methods Here
        if(this.strPlanDetails && this.isJsonString(this.strPlanDetails)) {
            const objPlanDetails = JSON.parse(this.strPlanDetails);
            //CEAS-66246
            if (objPlanDetails.strAceLineOfBusiness === 'Government-Medicaid') {
                this.boolIsNMCC = true;
                this.strFacetsGroupId = objPlanDetails.strFacetsGroupId;
                this.fetchAddressInfo();
            } 
        }
    }

    fetchAddressInfo() {
        if (this.objAddressInfo != undefined && this.objAddressInfo != null) {
            this.fetchTabData();
            const strURL = this.objTabData.url;
            BaseLWC.helperBaseGetUrlParameters('subscriberId', strURL);
            const strMid = BaseLWC.helperBaseGetUrlParameters('mid', strURL);
            const strGroupNumber = BaseLWC.helperBaseGetUrlParameters('groupNumber', strURL);
            const strCorpCode = BaseLWC.helperBaseGetUrlParameters('corpCode', strURL);
            getAddressInfo({
                strMemberId: idRecord,
                strGroupNumber: idRecord,
                strCorpCode: idRecord,
            }).then(objResult => {
                const objResponse = JSON.parse(objResult);
                if (!BaseLWC.isUndefinedOrNullOrBlank(objResponse) && !BaseLWC.isUndefinedOrNullOrBlank(objResponse.enrollmentAddress)) {
                    this.objAddressInfo = objResponse.enrollmentAddress;
                    this.objMemberName = objResponse.name;
                    this.objVoicePhone = objResponse.voicePhone;
                }
            }).catch(error => {
                //No handling Needed.
            });
        }
    }

    submitToFacets() {

        let intCounter = 0;
        const intBreakAway = 10;
        const intTimeoutPause = 500;      

        const innerFunction = function() {
            const objAddressInfo = JSON.parse(JSON.stringify(this.objAddressInfo));
            if ((objAddressInfo == null || objAddressInfo == undefined) && intCounter < intBreakAway) {
                setTimeout(function() {
                    intCounter++;
                    innerFunction();
                }, intTimeoutPause);
            } else {
                if (objAddressInfo != null && objAddressInfo != undefined) {
                    const objMemberName = this.objMemberName;
                    const objVoicePhone = this.objVoicePhone;
                    let strPhoneNumber;
                    if (objVoicePhone != null && objVoicePhone != undefined) { //objVoicePhone
                        strPhoneNumber = objVoicePhone.phoneNumber;
                    }
                    const strSubscriberId = BaseLWC.helperBaseGetUrlParameters('subscriberId', false, null, null);
                    const strSubId = strSubscriberId.substring(3);
                    const strExpirationDate = (new Date()).toLocaleDateString('en-us');
                    let strEffectiveDate;
                    if (this.objAuthorizedParty.Authorized_Party_Type_ACE__c === 'Responsible Party') {
                        strEffectiveDate = (new Date(this.objAuthorizedParty.Signature_Date_ACE__c)).toLocaleDateString('en-us', {timeZone: 'UTC'});
                    } else {
                        strEffectiveDate = (new Date(this.objAuthorizedParty.Effective_Date_ACE__c)).toLocaleDateString('en-us', {timeZone: 'UTC'});
                    }
                    const objRequestBody = {
                        "personalRepresentativeCategory": this.formatData(this.objAuthorizedParty.Authorized_Party_Type_ACE__c),
                        "groupId": this.formatData(this.strFacetsGroupId),
                        "subscriberId": this.formatData(strSubId),
                        "lastName": this.formatData(this.objAuthorizedParty.Authorized_Person_ACE__c),
                        "firstName": "",
                        "address1": this.formatData(objAddressInfo.streetAddress),
                        "city": this.formatData(objAddressInfo.city),
                        "state": this.formatData(objAddressInfo.state),
                        "zipCode": this.formatData(objAddressInfo.zipCode.substring(0,5)),
                        "effectiveDate": this.formatData(strEffectiveDate),
                        "terminationDate": this.formatData(strExpirationDate),
                        "phone": this.formatData(strPhoneNumber),
                        "relationshipDescription": this.formatData(this.objAuthorizedParty.Relationship_ACE__c),
                        "terminationReason": this.formatData('MREQ'),
                        "personalRepresentativeId": this.formatData(this.objAuthorizedParty.AuthorizedPersonID_ACE__c)
                    };

                    submitToFacets({
                        strRequestBody: strRequestBody
                    }).then(objResult => {
                        const objResponse = JSON.parse(objResult);
                        this.facetsSubmitToastHelper(objResponse);
                    }).catch(error => {
                        //No handling Needed.
                    });
                }
            }
        }
        return innerFunction();
    }

    facetsSubmitToastHelper(objResponse) {
        let strToastMessage, strToastType, strToastKey;
        if (!BaseLWC.isUndefinedOrNullOrBlank(objResponse) && objResponse.strResponseStatusCode === '200') {
            strToastType = 'success';
            strToastKey = 'utility:success';
            strToastMessage = this.label.FacetsNMCCAPISuccessMessage_ACE;
        } else {
            strToastType = 'error';
            strToastKey = 'utility:error';
            strToastMessage = this.label.FacetsNotesAPIErrorMessage_ACE;
        }

        const objToastEvent = new ShowToastEvent({
            title: strToastMessage,
            message: strToastMessage,
            duration: '5000',
            variant: strToastType,
            mode: 'pester'
        });
        this.dispatchEvent(objToastEvent);
    }

    formatData(strInput) {
        if (BaseLWC.isUndefinedOrNullOrBlank(strInput) || strInput === '') {
            return '';
        } else {
            return strInput;
        }
    }

    handleSaveRecord() {
        let objUpdatedData;
        const strObjAPIName = this.strObjectAPIName;
        let strFunctionality;
        let datDeactivateDate;
        if (strObjAPIName === this.strHIPAAObjectAPIName) {
            objUpdatedData = {
                Id: this.strCreatedRecordId,
                Active_ACE__c: 'Deactivated'
            }
            strFunctionality = this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE;
        } else if (strObjAPIName === this.strStandardObjectAPIName) {
            strFunctionality = this.label.ViewStandardAuthorization_Header_ACE;
            const datDeactivationDate = this.datDeactivation;
            const datToday = new Intl.DateTimeFormat("en-US", {year: "numeric", month: "2-digit", day: "2-digit"}).format(new Date())
            if (datDeactivationDate) {
                const datToday = new Intl.DateTimeFormat("en-US", {year: "numeric", month: "2-digit", day: "2-digit"}).format(datDeactivationDate)
            }

            //If Deactivation Attribute is not passed, then set to today
            if (datDeactivateDate === null || datDeactivateDate === undefined) {
                datDeactivateDate = datToday;
            }

            objUpdatedData = {
                Id: this.strCreatedRecordId,
                Deactivation_Date_ACE__c: datDeactivateDate
            }
        } else {
            //No handling needed.
        }
        this.objDeactivationData = objUpdatedData;

        processDeactivationRequest({
            strHIPAAAuthPartyInfo: JSON.stringify(objUpdatedData),
            strObjectAPIName: strObjAPIName
        }).then(() => {
            try {
                this.boolError = false;
                this.showSpinner = true;
                const objDeactiveAndRecordStatus = {
                    boolDeactivationIdentifier: true,
                    strSelectRecordStatus: this.strSelectRecordStatus
                };
                if(this.boolIsNMCC === true) {
                    const removedUndefinedAndNull = function(filterData) {
                        if (BaseLWC.isUndefinedOrNullOrBlank(filterData)) {
                            return '';
                        } else {
                            return filterData;
                        }
                    }
                    const objPlanSummary = JSON.parse(this.strPlanDetails);
                    const dateFacetsTerminationDate = new Intl.DateTimeFormat("en-US", {year: "numeric", month: "2-digit", day: "2-digit"}).format(new Date())
                    const objRecord = this.objRecord;
                    let subscriberId = objPlanSummary.strSubscriberId;
                    subscriberId = subscriberId.replace(/^0+/, '');
                    let strRequestReasonCode = 'CCRF';
                    if(objRecord && objRecord !== "{}") {
                        if(objRecord.RecordType.DeveloperName === 'HIPAA_RRF_ACE') {
                            strRequestReasonCode = 'RRF'
                        }
                        const facetsHIPAAResReq = {
                            "groupId": removedUndefinedAndNull(objPlanSummary.strFacetsGroupId),
                            "subscriberId": subscriberId,
                            "addressLine1": removedUndefinedAndNull(objRecord.Address1_ACE__c),
                            "city": removedUndefinedAndNull(objRecord.City_ACE__c),
                            "state": removedUndefinedAndNull(objRecord.State_ACE__c),
                            "zipCode": removedUndefinedAndNull(objRecord.ZipCode_ACE__c),
                            "effectiveDate": removedUndefinedAndNull(objRecord.Date_Signed_ACE__c),
                            "requestReasonCode":strRequestReasonCode,
                            "addressLine2": removedUndefinedAndNull(objRecord.Address2_ACE__c),
                            "notes": removedUndefinedAndNull(objRecord.Notes_ACE__c),
                            "originalEndDate": "12/31/9999",
                            "terminationReasonCode" : "MREQ",
                            "terminationDate" : removedUndefinedAndNull(dateFacetsTerminationDate),
                        };
                        this.facetsHIPAAResReq = facetsHIPAAResReq;
                }
                }
                this.updateInteractionAndCaseForAutoDocHelper(null, null, false, strFunctionality, objDeactiveAndRecordStatus);
            } catch (exception) {
                this.boolError = true;
            }
        }).catch(error => {
            //No handling Needed.
        });
    }

    

    postMessageToAuthorizeParent(objComponent, strApiName, strMid, strPageName) {
        if (strApiName === "HIPAA_Restrictions_ACE__c") {
            const strActionName = 'RefreshUpdatedHIPAARestrictions';
            const objResponse = {
                strIdDestination: "HIPAA_SuccessNotification_To_VFPage" + strMid,
                objParameters: {
                    strAction: strActionName
                }
            };
            const strIframeId = 'idHIPPARestrictionsFrame' + strMid;
            const objVf = document.getElementById(strIframeId).contentWindow;
            objVf.postMessage(objResponse, '*');
            window.postMessage(JSON.stringify(objResponse), '*');
        } else {
            if (strPageName === 'ViewStandardAuthorizationPage_ACE') {
                const strIframeId = 'idViewStandardAuthorization' + strMid;
                const idStandardAuthFrame = document.getElementById(strIframeId).contentWindow;
                const strParameterToBeSent = 'Refresh_StandardAuthPage_' + strMid;
                const objResponse = {
                    strIdDestination: strParameterToBeSent
                };
                idStandardAuthFrame.postMessage(JSON.stringify(objResponse), '*');
                window.postMessage(JSON.stringify(objResponse), '*');
            } else {
                const strIframeId = 'idviewAuthorizedParty' + strMid;
                const idAuthorizedPartyFrame = document.getElementById(strIframeId).contentWindow;
                const idAuthorizedPartyDestinationId = 'Refresh_AuthorizedPartyPage_' + strMid;
                const objResponseToAuthorizeParty = {
                    strIdDestination: idAuthorizedPartyDestinationId
                };
                idAuthorizedPartyFrame.postMessage(JSON.stringify(objResponseToAuthorizeParty), '*');
                window.postMessage(JSON.stringify(objResponseToAuthorizeParty), '*');
            }
        }
    }

    isJsonString(strJson) {
        try {
            JSON.parse(strJson);
        } catch (e) {
            return false;
        }
        return true;
    }

    handleErrors(error) {
        this.boolError = error;
    }

    /**
     * Auto doc functions below
     */

    
    /**
     * Method to create Interaction log and case.
     *
     * @param lstFetchFieldsToCompare Hold's list of fields to compare.
     * @param mapFetchFieldLabel Hold's FIelds labels for respective Field API name.
     * @param boolIsEdit Boolean to confirm edit action.
     * @param strFunctionality Hold's functionality name.
     * @param boolDeactivationIdentifier boolean to identify deactivation.
     * @param strSelectRecordStatus Hold's the record active status.
     */
    updateInteractionAndCaseForAutoDocHelper(lstFetchFieldsToCompare, mapFetchFieldLabel, boolIsEdit,strFunctionality, objDeactiveAndRecordStatus) {

        try {
            let strRecordId;
            if (boolIsEdit) {
                if (strFunctionality.includes('&&')) {
                    const strFunctionalityName = strFunctionality.split('&&')[0];
                    if (strFunctionalityName === 'STANDARD AUTHORIZATION' || strFunctionalityName === 'AUTHORIZED PARTIES') {
                        const listOfAuth = [];
                        listOfAuth.push(this.strRecordId);
                        strRecordId = JSON.stringify(listOfAuth);
                    }
                } else {
                    strRecordId = this.strRecordId;
                }
            } else {
                strRecordId = this.strCreatedRecordId;
            }
            let strInteractionLogIdForAutoDoc = this.strInteractionLogId;
            if (strInteractionLogIdForAutoDoc === null || strInteractionLogIdForAutoDoc === 'null' || strInteractionLogIdForAutoDoc === '') {
                strInteractionLogIdForAutoDoc = '';
            }
            const boolDeactivationIdentifier = objDeactiveAndRecordStatus['boolDeactivationIdentifier'];
            const strSelectRecordStatus = objDeactiveAndRecordStatus['strSelectRecordStatus'];
            let boolIsNMCC = false;
            let facetsHIPAAResReq = '';
            if(this.boolIsNMCC) {
                boolIsNMCC = this.boolIsNMCC;
            }
            if (this.facetsHIPAAResReq) {
                facetsHIPAAResReq = this.facetsHIPAAResReq;
            }
            let formatted_date = BaseLWC.currentDateFormat();
            this.strIntialNotes = 'Created on '+formatted_date+'\n\n'+'PHI AUTHORIZATION/RESTRICTION'+'\n\n';
            let strFunctionalitycheck;
            if (strFunctionality.includes('&&')) {
                strFunctionalitycheck = strFunctionality.split('&&')[0];
            } else {
                strFunctionalitycheck = strFunctionality;
            }
            let boolisNotChanged = true;
            const lstFieldsChangesInfo = this.compareFieldsValueChangesHelper(lstFetchFieldsToCompare, mapFetchFieldLabel, boolIsEdit,strFunctionalitycheck, boolDeactivationIdentifier, strSelectRecordStatus,true);
            if (lstFieldsChangesInfo) {
                lstFieldsChangesInfo.forEach((objValue, strKey) => {
                    //Set old and new values to be displayed.
                    if((strKey.toUpperCase() === 'AUTHORIZED PERSON/ENTITY' || strKey.toUpperCase() === 'RELATIONSHIP'  || strKey.toUpperCase() === 'REPRESENTATIVE') && objValue.oldValue===objValue.newValue ) {
                        this.strIntialNotes = this.strIntialNotes +'\t\t'+ strKey.toUpperCase()+': \t\t'+objValue.newValue+'\n\n';
                    } else{
                        boolisNotChanged =false;
                        this.strIntialNotes = this.strIntialNotes +'\t\t'+ strKey.toUpperCase()+'\n'+'\t\t\t'+'OLD VALUE : '+objValue.oldValue+'\n'+'\t\t\t'+'NEW VALUE : '+objValue.newValue+'\n\n';
                    }
                });
            }
            if(boolisNotChanged){
                this.strIntialNotes ='';
            }
            const objParameters = {
                "strRecordId": strRecordId,
                "strInteractionId": strInteractionLogIdForAutoDoc,
                "strPlanDetails": this.strPlanDetails,
                "strAccountId": this.strAccountId,
                "strFunctionality": strFunctionality,
                "strIntialNotes": this.strIntialNotes
            };

            try {
                let objCreateInteractionAndCaseAutodoc = createInteractionAndCaseForAutoDocHelper(objParameters)
                const promiseArray = [];
                promiseArray.push(objCreateInteractionAndCaseAutodoc);
                if (boolIsNMCC) {
                    let submitRestrictionToFacets = submitToFacetsHIPAARestriction({'strRequestBody' : JSON.stringify(facetsHIPAAResReq)})
                    promiseArray.push(submitRestrictionToFacets);
                }
                Promise.all(promiseArray).then(objResult => {
                    const strResultOfAutodocInteraction = objResult[0];
                    const facetsResult = objResult[1];
                    let strInteractionLogId = this.strInteractionLogId;
                    if (strResultOfAutodocInteraction && strResultOfAutodocInteraction.includes('_')) {
                        const strCheckRecordType = strResultOfAutodocInteraction.split('_');
                        this.strCreatedInteractionHolder = strCheckRecordType[0];
                        if (strCheckRecordType[1].toUpperCase() === 'LETTER') {
                            strInteractionLogId = null;
                        } 
                    }
                    if (!BaseLWC.isUndefinedOrNullOrBlank(facetsResult) && facetsResult === true) {
                        this.facetsCalloutRestrictionSuccess = true;
                    }
                    if (!BaseLWC.isUndefinedOrNullOrBlank(facetsResult) && facetsResult === false) {
                        this.facetsCalloutRestrictionSuccess = false;
                    }
                    this.strInteractionLogId = strInteractionLogId;
                    let strFunctionalityfinal;
                    if (strFunctionality.includes('&&')) {
                        strFunctionalityfinal = strFunctionality.split('&&')[0];
                    } else {
                        strFunctionalityfinal = strFunctionality;
                    }
                    this.createJSONForAutoDocHelper(lstFetchFieldsToCompare, mapFetchFieldLabel, boolIsEdit, strFunctionalityfinal,
                        boolDeactivationIdentifier, strSelectRecordStatus, null, null, this.strCreatedInteractionHolder);
    
                }).catch(error => {
                    //No handling Needed.
                });
            } catch (e) {
                // deal with any errors
            }

        } catch (objException) {
            this.strErrorMessage = this.label.UpdateHIPPARestrictions_SaveUnsuccessfull_ACE;
        }
        


    }


        /**
     * Function to create JSON to show field value changes on Auto Doc card.
     *
     * @param lstFetchFieldsToCompare Hold's list of fields to compare.
     * @param mapFetchFieldLabel Hold's FIelds labels for respective Field API name.
     * @param boolIsEdit Boolean to confirm edit action.
     * @param strFunctionality Hold's functionality name.
     * @param boolDeactivationIdentifier boolean to identify deactivation.
     * @param strSelectRecordStatus Hold's the record active status.
     */
    
    createJSONForAutoDocHelper(lstFetchFieldsToCompare, mapFetchFieldLabel, boolIsEdit,
        strFunctionality, boolDeactivationIdentifier, strSelectRecordStatus,oldValueStr,newValueStr,strCreatedInteractionHolder) {

        //Get field value changes
        
        const lstFieldsChangesInfo = this.compareFieldsValueChangesHelper(lstFetchFieldsToCompare, mapFetchFieldLabel, boolIsEdit,strFunctionality, boolDeactivationIdentifier, strSelectRecordStatus,false);

        //Build JSON to stamp in Local storage.
        let lstAutoDocJson = [];
        let objAutoDocJson;
        
        if (lstFieldsChangesInfo) {
            lstFieldsChangesInfo.forEach(function(objValue, strKey) {
                const lstSections = [];
                const lstValues = [];
                //Set old and new values to be displayed.
                lstValues.push({
                    strFieldLabel:  "OLD VALUE",
                    strFieldValue: objValue.oldValue
                });
                lstValues.push({
                    strFieldLabel:  "NEW VALUE",
                    strFieldValue: objValue.newValue
                });

                let strIconName;
                let strIconFamilyType;
                if (strFunctionality ===  "Restrictions" || strFunctionality ===  "Confidential Communication Requests") {
                    strIconName = "error";
                    strIconFamilyType = "utility";
                } else {
                    strIconName = "custom91";
                    strIconFamilyType = "custom";
                }
                //Set Auto Doc Header.
                lstSections.push({
                    strLabel:  "PHI AUTHORIZATION/RESTRICTION",
                    strIcon: strIconName,
                    strIconFamily: strIconFamilyType,
                    strIconColor: "#fff;background-color: rgba(27, 82, 151, 1);width: 20px;height: 20px;"
                });

                //Set Section Header.
                lstSections.push({
                    strLabel: strKey.toUpperCase(),
                    strIcon: "",
                    strIconFamily: "",
                    strIconColor: ""
                });
                //Construct JSON.
                objAutoDocJson = {
                    strInteractionLogId: strCreatedInteractionHolder,
                    lstValues: lstValues,
                    lstSections: lstSections
                }
                lstAutoDocJson.push(objAutoDocJson);
            });

            //Send DML acknowledgement and close modal.
            this.triggerAcknowledgementsAndCloseHelper(lstAutoDocJson, strFunctionality, boolDeactivationIdentifier);
        }
    }

    /**
     * Method to create JSON to show field value changes on Auto Doc card.
     *
     * @param lstFetchFieldsToCompare Hold's list of fields to compare.
     * @param mapFetchFieldLabel Hold's FIelds labels for respective Field API name.
     * @param boolIsEdit Boolean to confirm edit action.
     * @param strFunctionality Hold's functionality name.
     * @param boolDeactivationIdentifier boolean to identify deactivation.
     * @param strSelectRecordStatus Hold's the record active status.
     */
    compareFieldsValueChangesHelper(lstFetchFieldsToCompare, mapFetchFieldLabel,boolIsEdit, strFunctionality, boolDeactivationIdentifier, strSelectRecordStatus,boolNotes) {
        const lstFieldsChangesInfo = new Map();
        let strStoredDataCopy;
        let objStoredDataCopy;
        let objModifiedData;

        //Fields To compare.
        const lstFieldsToCompare = lstFetchFieldsToCompare;

        //Construct field labels for respective fields.
        const mapGetFieldLabel = mapFetchFieldLabel;

        //Get Modified and Unmodified data.
        if (BaseLWC.isUndefinedOrNullOrBlank(boolDeactivationIdentifier) && !boolDeactivationIdentifier) {
            if (strFunctionality === this.label.UpdateHIPAARestrictions_RRFHeaderName_ACE || strFunctionality === this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE) {
                strStoredDataCopy = this.objHIPPARestrictionCopy;
                objModifiedData = this.objHIPPARestriction;
            } else {
                if (strFunctionality === this.label.ViewStandardAuthorization_Header_ACE) {
                    if (!BaseLWC.isUndefinedOrNullOrBlank(this.strAuthorizedPartyCopy) && !BaseLWC.isUndefinedOrNullOrBlank(this.strAuthorizedPartyCopy)) {
                        objComponent.set(this.objAuthorizedPartyCopy, JSON.parse(this.strAuthorizedPartyCopy));
                        this.processDatesFormat(this.objAuthorizedPartyCopy);
                        strStoredDataCopy = JSON.stringify(this.objAuthorizedPartyCopy);
                    }
                    this.processDatesFormat(objAuthorizedParty);
                } else {
                    strStoredDataCopy = this.objAuthorizedPartyCopy;
                }

                objModifiedData = JSON.parse(JSON.stringify(this.objAuthorizedParty));
            }
        } else {

            //Check for Deactivation action.
            const objOldNewValues = {};
            if (!BaseLWC.isUndefinedOrNullOrBlank(strSelectRecordStatus) && !BaseLWC.isUndefinedOrNullOrBlank(strSelectRecordStatus)) {
                objOldNewValues.oldValue = strSelectRecordStatus;
            } else {
                objOldNewValues.oldValue = this.label.HIPAAAuthParty_Active_ACE;
            }
            objOldNewValues.newValue = this.label.HIPAAAuthParty_Deactivated_ACE;
            if(boolNotes && this.objRecord && this.objRecord.Person_Restricted_ACE__c) {
                const objOldNew = {};
                objOldNew.oldValue =this.objRecord.Person_Restricted_ACE__c;
                objOldNew.newValue =this.objRecord.Person_Restricted_ACE__c;
                lstFieldsChangesInfo.set('REPRESENTATIVE',objOldNew);
            }
            lstFieldsChangesInfo.set('Status', objOldNewValues);
            return lstFieldsChangesInfo;
        }

        if (BaseLWC.isUndefinedOrNullOrBlank(strStoredDataCopy) || BaseLWC.isUndefinedOrNullOrBlank(strStoredDataCopy)) {
            objStoredDataCopy = {};
        } else {
            objStoredDataCopy = JSON.parse(strStoredDataCopy);
        }

        if (!boolIsEdit) {
            const objOldNewValues = {
                oldValue: '-'
            }
            if (strFunctionality === this.label.UpdateHIPAARestrictions_RRFHeaderName_ACE) {
                objOldNewValues.newValue = this.label.UpdateHIPAARestrictions_RRFHeaderName_ACE;
                lstFieldsChangesInfo.set('Type', objOldNewValues);
            } else if (strFunctionality === this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE) {
                objOldNewValues.newValue = this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE;
                lstFieldsChangesInfo.set('Type', objOldNewValues);
            } else if (strFunctionality === this.label.ViewStandardAuthorization_Header_ACE) {
                objOldNewValues.newValue = this.label.ViewStandardAuthorization_Header_ACE;
                lstFieldsChangesInfo.set('Type', objOldNewValues);
            } else if (strFunctionality === this.label.HIPAAAuthParty_AuthorizedPartyHeader_ACE) {
                objOldNewValues.newValue = this.label.HIPAAAuthParty_AuthorizedPartyHeader_ACE;
                lstFieldsChangesInfo.set('Type', objOldNewValues);
            } else {
                //No handling needed.
            }
        }

        //Check for changes in field values.
        for (const strKey in lstFieldsToCompare) {
            if (boolIsEdit) {
                const boolAdditionalCheck = (BaseLWC.isUndefinedOrNullOrBlank(objStoredDataCopy[lstFieldsToCompare[strKey]]) &&
                        BaseLWC.isUndefinedOrNullOrBlank(objModifiedData[lstFieldsToCompare[strKey]])) ||
                    (BaseLWC.isUndefinedOrNullOrBlank(objModifiedData[lstFieldsToCompare[strKey]]) &&
                        BaseLWC.isUndefinedOrNullOrBlank(objStoredDataCopy[lstFieldsToCompare[strKey]]))

                if (!boolAdditionalCheck && ((!boolNotes && objStoredDataCopy[lstFieldsToCompare[strKey]] !== objModifiedData[lstFieldsToCompare[strKey]]) || (boolNotes && (objStoredDataCopy[lstFieldsToCompare[strKey]] !== objModifiedData[lstFieldsToCompare[strKey]] || lstFieldsToCompare[strKey].toUpperCase() ==='AUTHORIZED_PERSON_ACE__C' || lstFieldsToCompare[strKey].toUpperCase() ==='RELATIONSHIP_ACE__C' || lstFieldsToCompare[strKey].toUpperCase() ==='PERSON_RESTRICTED_ACE__C')))) {
                    const objOldNewValues = {
                        oldValue: '-'
                    };
                    if (lstFieldsToCompare[strKey].toLowerCase().includes('date')) {
                        if (!BaseLWC.isUndefinedOrNullOrBlank(objStoredDataCopy[lstFieldsToCompare[strKey]])) {
                            objOldNewValues.oldValue = this.formatDateValues(objStoredDataCopy[lstFieldsToCompare[strKey]]);//$A.localizationService.formatDate(objStoredDataCopy[lstFieldsToCompare[strKey]], "MM/DD/YYYY");
                        }
                        objOldNewValues.newValue = this.formatDateValues(objModifiedData[lstFieldsToCompare[strKey]]);//$A.localizationService.formatDate(objModifiedData[lstFieldsToCompare[strKey]], "MM/DD/YYYY");
                    } else {
                        if (!BaseLWC.isUndefinedOrNullOrBlank(objStoredDataCopy[lstFieldsToCompare[strKey]])) {
                            objOldNewValues.oldValue = objStoredDataCopy[lstFieldsToCompare[strKey]];
                        }
                        objOldNewValues.newValue = objModifiedData[lstFieldsToCompare[strKey]];
                    }
                    lstFieldsChangesInfo.set(mapGetFieldLabel[lstFieldsToCompare[strKey]], objOldNewValues);
                }
            } else {
                if (!BaseLWC.isUndefinedOrNullOrBlank(objModifiedData[lstFieldsToCompare[strKey]]) && !BaseLWC.isUndefinedOrNullOrBlank(objModifiedData[lstFieldsToCompare[strKey]])) {
                    const objOldNewValues = {
                        oldValue: '-'
                    }

                    if (lstFieldsToCompare[strKey].toLowerCase().includes('date')) {
                        objOldNewValues.newValue = this.formatDateValues(objModifiedData[lstFieldsToCompare[strKey]]);//$A.localizationService.formatDate(objModifiedData[lstFieldsToCompare[strKey]], "MM/DD/YYYY");
                    } else {
                        objOldNewValues.newValue = objModifiedData[lstFieldsToCompare[strKey]];
                    }

                    lstFieldsChangesInfo.set(mapGetFieldLabel[lstFieldsToCompare[strKey]], objOldNewValues);
                }
            }
        }

        return lstFieldsChangesInfo;
    }

    processDatesFormat(objAuthParty) {
        if (objAuthParty.Health_Plan_From_ACE__c) {
            objAuthParty.Health_Plan_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Health_Plan_From_ACE__c));
        }

        if (objAuthParty.Health_Plan_To_ACE__c) {
            objAuthParty.Health_Plan_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Health_Plan_To_ACE__c));
        }

        if (objAuthParty.Effective_Date_ACE__c) {
            objAuthParty.Effective_Date_ACE__c = this.formatDateValues(new Date(objAuthParty.Effective_Date_ACE__c));
        }

        if (objAuthParty.Other_Disclosure_To_ACE__c) {
            objAuthParty.Other_Disclosure_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Other_Disclosure_To_ACE__c));
        }

        if (objAuthParty.Other_Disclosure_From_ACE__c) {
            objAuthParty.Other_Disclosure_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Other_Disclosure_From_ACE__c));
        }

        if (objAuthParty.Premium_To_ACE__c) {
            objAuthParty.Premium_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Premium_To_ACE__c));
        }

        if (objAuthParty.Premium_From_ACE__c) {
            objAuthParty.Premium_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Premium_From_ACE__c));
        }

        if (objAuthParty.Service_Info_From_ACE__c) {
            objAuthParty.Service_Info_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Service_Info_From_ACE__c));
        }

        if (objAuthParty.Service_Info_To_ACE__c) {
            objAuthParty.Service_Info_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Service_Info_To_ACE__c));
        }

        if (objAuthParty.Provider_Supplier_To_ACE__c) {
            objAuthParty.Provider_Supplier_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Provider_Supplier_To_ACE__c));
        }

        if (objAuthParty.Provider_Supplier_From_ACE__c) {
            objAuthParty.Provider_Supplier_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Provider_Supplier_From_ACE__c));
        }

        if (objAuthParty.Claims_From_ACE__c) {
            objAuthParty.Claims_From_ACE__c = this.formatDateValues(new Date(objAuthParty.Claims_From_ACE__c));
        }

        if (objAuthParty.Claims_To_ACE__c) {
            objAuthParty.Claims_To_ACE__c = this.formatDateValues(new Date(objAuthParty.Claims_To_ACE__c));
        }
    }
    

    formatDateValues(dateToFormat){
        const dtf = new Intl.DateTimeFormat('en', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        })
        let formattedDate = dtf.format(new Date(dateToFormat.replace(/-/g, '\/'))); 
        return formattedDate;
    }

     /**
     * Method to access VF page to refresh and fire Application event to patient card.
     *
     * @param objComponent to hold the instance of component and access the attributes.
     * @param lstAutoDocJson Hold's Auto doc JSON.
     * @param strFunctionality Hold's functionality name.
     * @param boolDeactivationIdentifier boolean to identify deactivation.
     */
    
     triggerAcknowledgementsAndCloseHelper(lstAutoDocJson, strFunctionality, boolDeactivationIdentifier) {
        try {

            const objHIPAAEvent = new CustomEvent('lwchipaaauthpartysuccessappevent', {
                detail: {
                    "strClientMemberId": this.strClientMemberId,
                    "objAutodoc": lstAutoDocJson,
                    "boolRefresh": true
                }
            });

            //dispatching the custom event
            this.dispatchEvent(objHIPAAEvent);

            if (BaseLWC.isUndefinedOrNullOrBlank(boolDeactivationIdentifier) && !boolDeactivationIdentifier) {
                if (strFunctionality === this.label.UpdateHIPAARestrictions_RRFHeaderName_ACE || strFunctionality === this.label.UpdateHIPAARestrictions_CCRFHeaderName_ACE) {
                    this.boolDMLStatus = true;
                } else if (strFunctionality === this.label.ViewStandardAuthorization_Header_ACE ||
                           strFunctionality === this.label.HIPAAAuthParty_AuthorizedPartyHeader_ACE) {
                            boolDMLSuccess = true;
                    this.boolIsOpen = false;
                } else {
                    //No handling needed.
                }

                this.showSpinner = false;
            } else {
                //Post Message
                this.postMessageToAuthorizeParent(this.strObjectAPIName,
                this.strMid, this.strPageName,
                this.strClientMemberId);
                this.showSpinner = false;
            }

            return true;
        } catch (objException) {
            return false;
        }

    }

}