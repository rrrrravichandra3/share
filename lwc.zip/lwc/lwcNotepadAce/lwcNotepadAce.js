import { LightningElement, wire } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import { APPLICATION_SCOPE, MessageContext, publish, subscribe, unsubscribe } from 'lightning/messageService';
import NotepadTransmissionChannel_ACE from '@salesforce/messageChannel/NotepadTransmissionChannel__c';
import { loadStyle } from 'lightning/platformResourceLoader';
import PopOutRemoveWhiteSpace from '@salesforce/resourceUrl/PopOutRemoveWhiteSpace_ACE';
import { CurrentPageReference } from 'lightning/navigation';
import NotesModal from 'c/uploadToCaseNotepadAce';
import { refreshTab, setTabLabel, setTabIcon, getFocusedTabInfo, getTabInfo } from 'lightning/platformWorkspaceApi';
import { open, EnclosingUtilityId, getInfo} from 'lightning/platformUtilityBarApi';

export default class NotepadCmp extends LightningElement {
    enclosingTabId;
    @wire(CurrentPageReference)
    currentPageReference;
    boolIsOpenModal = false;
    accountId;
    NotepadTransmissionChannel = NotepadTransmissionChannel_ACE;
    renderedVal = false;
    notesEntered = '';
    isPoppedOut = false;
    @wire(MessageContext)
    messageContext;
    subscription = null;
    @wire(EnclosingUtilityId) utilityId;
    /**
     * The `connectedCallback` method is called when the component is being added to the DOM.
     * It checks if the component is in a popout tab and subscribes to the specified message channel.
     * It also publishes a message to the message channel with the source as 'lwcNotepadAce' and the method as 'GET'.
     *
     * @method connectedCallback
     * @returns {void}
     */
    connectedCallback() {
        if (this.currentPageReference && this.currentPageReference.type === 'standard__popout') {
            this.isPoppedOut = true;
        }
        this.subscribeToMessageChannel();
        const payload = { method: 'GET', reqSource: 'lwcNotepadAce' };
        publish(this.messageContext, this.NotepadTransmissionChannel, payload);
    }

    notesEntered;
    get disableReset() {
        return !BaseLWC.stringIsNotBlank(this.notesEntered);
    }
    get disableUpload() {
        return !BaseLWC.stringIsNotBlank(this.notesEntered);
    }
    /**
     * Handles the input event for the textarea where the user enters their notes.
     *
     * @method handleNotes
     * @param {Event} event - The input event triggered by the user typing in the textarea.
     * @returns {void}
     */
    handleNotes(event) {
        this.notesEntered = event.target.value;
    }
    /**
     * Handles the reset event for the textarea where the user enters their notes.
     *
     * @method handleReset
     * @returns {void}
     */
    handleReset() {
        this.notesEntered = '';
        this.template.querySelector('textarea[name="Notepad"]').value = '';
    }
    /**
     * Handles the upload event for the textarea where the user enters their notes.
     *
     * @method handleUpload
     */
    handleUpload() {
        if (this.isPoppedOut) {
            this.unsubscribeToMessageChannel();
            this.boolIsOpenModal = true;
            const payload = { method: 'POST', reqSource: 'HCSCOAuthCmp', notes: this.notesEntered, boolOpenModal: this.boolIsOpenModal };
            publish(this.messageContext, this.NotepadTransmissionChannel, payload);
            window.close();
        } else {
            this.initiateUpload();
        }
    }
    /**
     * Initializes the upload process.
     *
     * @method initiateUpload
     * @returns {void}
     */
    initiateUpload() {
        getFocusedTabInfo()
            .then((focusedTabInfo) => {
                if (focusedTabInfo.isSubtab) {
                    getTabInfo(focusedTabInfo.parentTabId)
                        .then((tabInfo) => {
                            this.accountId = tabInfo.recordId || '';
                            this.enclosingTabId = focusedTabInfo.parentTabId;
                            this.proceedUpload();
                        })
                        .catch((error) => {
                        });
                } else {
                    this.accountId = focusedTabInfo.recordId || '';
                    this.enclosingTabId = focusedTabInfo.tabId;
                    this.proceedUpload();
                }
            })
            .catch((error) => {
            });
    }
    /**
     * Proceeds with the upload process.
     *
     * @method proceedUpload
     * @returns {Promise<void>} A promise that resolves when the upload process is completed.
     */
    proceedUpload() {
        this.boolIsOpen = true;
        NotesModal.open({
            // `label` is not included here in this example.
            // it is set on lightning-modal-header instead
            size: 'large',
            label: "Upload to Existing Case",
            description: "Upload to Existing Case",
            accountId: this.accountId,
            enclosingTabId: this.enclosingTabId,
            strNotes: this.notesEntered
        })
            .then((result) => {
                //do nothing
            })
            .catch((_error) => {
                //do nothing
            });
    }
    /**
     * Subscribes the component to the specified message channel.
     *
     * @method subscribeToMessageChannel
     * @returns {void}
     */

    subscribeToMessageChannel() {
        if (!this.subscription) {
            this.subscription = subscribe(this.messageContext, this.NotepadTransmissionChannel, (message) => this.handleMessage(message), { scope: APPLICATION_SCOPE });
        }
    }
    /**
     * Handler for message received by component.
     *
     * @method handleMessage
     * @param {object} message - The message containing the new notes.
     * @returns {void}
     */
    // Handler for message received by component
    handleMessage(message) {
        const { method, reqSource, clear, mid } = message;
        if (!method && !reqSource) {
            return;
        }
        if (method === 'GET') {
            this.publishMessage(reqSource, mid);
        } else if (method === 'POST' && reqSource === 'lwcNotepadAce') {
            if (clear) {
                this.notesEntered = '';
                this.template.querySelector('textarea[name="Notepad"]').value = '';
                this.openNotepadUtility();
            } else {
                this.updateNotes(message);
            }
        }
    }
    /**
     * Updates the notes with the new content received from the message.
     *
     * @method updateNotes
     * @param {object} message - The message containing the new notes.
     * @returns {void}
     */
    async updateNotes(message) {
        const { method, reqSource, boolIsFromAutdoc, notes, boolOpenModal } = message;
        if (boolIsFromAutdoc) {
            if (!this.notesEntered) {
                this.notesEntered = notes;
            } else {
                this.notesEntered += '\n\n';
                this.notesEntered += notes;
            }
            this.template.querySelector('textarea[name="Notepad"]').value = this.notesEntered;
            this.openNotepadUtility();
        } else {
            this.notesEntered = notes;
            this.boolIsOpen = boolOpenModal;
            if (this.boolIsOpen) {
                this.initiateUpload();
            }
        }
    }
    /**
     * Publishes a message to the specified message channel with the provided payload.
     *
     * @method publishMessage
     * @param {string} reqSource - The source of the request.
     * @param {string} mid - The message ID.
     * @returns {void}
     */
    publishMessage(reqSource, mid) {
        const payload = { method: 'POST', reqSource: reqSource, notes: this.notesEntered, mid: mid };
        publish(this.messageContext, this.NotepadTransmissionChannel, payload);
    }
    /**
     * The disconnectedCallback method is called when the component is being removed from the DOM.
     * It unsubscribes the component from the specified message channel and dispatches a custom event with the source and notes.
     *
     * @method disconnectedCallback
     * @returns {void}
     */
    disconnectedCallback() {
        this.unsubscribeToMessageChannel();
        const objSubTabEvents = new CustomEvent('NotePadNotesEvent_ACE', { detail: { source: 'HCSCOAuthCmp', notes: this.notesEntered, boolOpenModal: this.boolIsOpenModal } });
        window.dispatchEvent(objSubTabEvents);
    }
    /**
     * Unsubscribes the component from the specified message channel.
     *
     * @method unsubscribeToMessageChannel
     * @returns {void}
     */
    unsubscribeToMessageChannel() {
        unsubscribe(this.subscription);
        this.subscription = null;
    }
    resourceLoaded = false;
    /**
     * The `renderedCallback` method is called when the component's DOM has been updated and is ready to be used.
     * It checks if the component has already been rendered and if not, it sets the `renderedVal` flag to true and loads the CSS file using `Promise.all`.
     *
     * @method renderedCallback
     * @returns {void}
     */
    renderedCallback() {
        if (this.renderedVal) {
            return;
        }
        if (this.isPoppedOut && !this.resourceLoaded) {
            this.resourceLoaded = true;
            Promise.all([loadStyle(this, PopOutRemoveWhiteSpace + '/PopOutRemoveWhiteSpace.css')]);
        }
        if (this.refs.notepadFooter) {
            const dimensions = this.refs.notepadFooter.getBoundingClientRect();
            if (dimensions.height) {
                this.template.host.style.setProperty('--footerHeight', `${dimensions.height + 6}px`);
                this.renderedVal = true;
            }
        }
    }

    
    /**
     * Opens the notepad utility.
     * @returns {Promise<void>} A promise that resolves when the notepad utility is opened.
     */
    async openNotepadUtility() {
        const utilityInfo = await getInfo(this.utilityId);
        if (!utilityInfo.utilityVisible) {
            open(this.utilityId, { autoFocus: true });
        }
    }
}
