import { LightningElement, api } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';

export default class MemberContactDetailsModalLightningWebComponentACE extends LightningElement {
    @api showModal;
    @api objDataForCaseCreationPage;
    @api strMidLwc;

    closeModal() {
        this.showModal = false;
        const objCloseEvent = new CustomEvent('close');
        this.dispatchEvent(objCloseEvent);
    }

    handleClick(event) {
        const strLabel = event.target.label;
        const objResponse = JSON.parse(this.objDataForCaseCreationPage);
        delete objResponse.strEventName;
        const strCaseDefaults = JSON.parse(objResponse.objParameters.strCaseRuleDetails);
        strCaseDefaults['Address_to_Change_ACE__c'] = strLabel;
        objResponse.objParameters.strCaseRuleDetails = JSON.stringify(strCaseDefaults);
        const strEventName = 'opencasepagefrommodel';
        const objParameterToSend = JSON.stringify(objResponse);
        this.dispatchEvent(
            new CustomEvent(strEventName, {
              detail: objParameterToSend,
              bubbles : true
            })
        );
        this.showModal = false; 
    }   
}