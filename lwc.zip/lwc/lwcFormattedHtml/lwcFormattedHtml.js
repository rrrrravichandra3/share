import { LightningElement,api,track } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';

export default class LwcFormattedHtml extends LightningElement {
    @track compValue='';
    @track boolRefresh=false;    
    @api trackevents;
    @api
    get value() {
        return this.compValue;
    }

    set value(val) {
        if (typeof val === 'object') {
            this.compValue = '';
            if(!BaseLWC.isUndefinedOrNullOrBlank(val) && val.strMessage){
                this.compValue = val.strMessage;
            }            
        } else {
            this.compValue = '<span></span>';
            if(val){
                this.compValue = val;
            }            
        }  
        this.boolRefresh=!this.boolRefresh;        
    }
    boolInline=true;
    
    lstBlockElemets=['div','p','section'];
    lstLocalTrackEvents = [];

    async connectedCallback(){        
        this.trackevents=this.trackevents;
        if(this.trackevents && typeof this.trackevents==='string'){
            this.lstLocalTrackEvents=this.trackevents.split(',');
        }

    }
    renderedCallback(){        
        this.loadHtml();
    }
    loadHtml(){
        if(!BaseLWC.stringIsNotBlank(this.compValue)){        
            this.boolInline=true;
            return;
        }else{
            const objWrapper=document.createElement('div');
            objWrapper.innerHTML=this.compValue;
            const objChildNodes=objWrapper.childNodes;
            this.boolInline=!objWrapper.querySelector(this.lstBlockElemets.join(','));
            let domWrapperName='div';
            if(this.boolInline){
                domWrapperName='span';
            }
            [...objChildNodes].forEach(el=>{
                if(this.template.querySelector(domWrapperName)) {
                    this.template.querySelector(domWrapperName).appendChild(el);
                }

            });
        }

        //Add Event Listeners
        if(this.lstLocalTrackEvents.length){
            this.lstLocalTrackEvents.forEach(el=>{
                this.template.querySelector('.root').addEventListener(el,this.handleEvent,false);
            })
        }
        
    }
    handleEvent=(ev)=>{
        const objParams={
            eventType:ev.type,
            eventTarget:ev.target.outerHTML,
            originalValue:this.value,
            textContent: ev.target.textContent
        }

        const eventParams = new CustomEvent("eventhandler", {
            detail: objParams
        });
        this.dispatchEvent(eventParams);
        ev.stopImmediatePropagation();
    }
}