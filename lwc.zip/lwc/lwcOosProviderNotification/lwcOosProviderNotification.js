import { api, LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import CreateAlerts_RequiredChk_ACE from '@salesforce/label/c.CreateAlerts_RequiredChk_ACE';
import createProviderAlert from "@salesforce/apex/ManageAGSAlertsController_ACE.createPNTAPAlert";

export default class LwcOosProviderNotification extends NavigationMixin(LightningElement) {

    @api strRecordTypeID;
    @api strProviderNPI;
    @api strTitle;
    @api datStartDate;
    @api datEndDate;
    @api strCorpCodeToSearch;
    @api strDescription;
    @api strProviderNumber;
    @api strProviderName;
    @api strProviderStreet;
    @api strProviderCity;
    @api strProviderState;
    @api strProviderZip;

    objProviderDetail = [{}]
    pntapRecord;

    label = {
        CreateAlerts_RequiredChk_ACE
    }

    handleSuccess(alertDetails) {

        this.pntapRecord = alertDetails;

        if (this.pntapRecord !== undefined && this.pntapRecord !== null) {
            this.template.querySelector(".toastPNTAP").classList.remove("slds-hide");
            const PntapRecordEvent = new CustomEvent('pntapsuccess', {
                detail: { strRecordId: this.pntapRecord }
            });
            // Fire the custom event
            this.dispatchEvent(PntapRecordEvent);
        }
    }

    closeModal() {
        const PntapcloseModal = new CustomEvent('pntapclosemodal', {
            detail: { modalClose: false }
        });
        // Fire the custom event
        this.dispatchEvent(PntapcloseModal);
    }

    handleFieldChange(event) {

        const dataValue = event.currentTarget.dataset.field;

        switch (dataValue) {
            case 'ProviderNPI':
                event.target.value = (event.target.value).replace(/[^0-9]/g, '');
                this.strProviderNPI = event.target.value;
                this.objProviderDetail[0].NPI_ACE__c = this.strProviderNPI;
                break;
            case 'ProviderName':
                this.strProviderName = (event.target.value).replace(/\B\s+|\s+\B/g, '');
                event.target.value = this.strProviderName;
                this.objProviderDetail[0].ProviderName_ACE__c = this.strProviderName;
                break;
            case 'ProviderNumber':
                this.strProviderNumber = event.target.value;
                this.objProviderDetail[0].ProviderNumber_ACE__c = this.strProviderNumber;
                break;
            case 'ProviderStreet':
                this.strProviderStreet = (event.target.value).replace(/\B\s+|\s+\B/g, '');
                event.target.value = this.strProviderStreet;
                this.objProviderDetail[0].ProviderStreet_ACE__c = this.strProviderStreet;
                break;
            case 'ProviderCity':
                this.strProviderCity = (event.target.value).replace(/\B\s+|\s+\B/g, '');
                event.target.value = this.strProviderCity;
                this.objProviderDetail[0].ProviderCity_ACE__c = this.strProviderCity;
                break;
            case 'ProviderState':
                this.strProviderState = event.target.value;
                this.objProviderDetail[0].ProviderState_ACE__c = this.strProviderState;
                break;
            case 'ProviderZip':
                this.strProviderZip = (event.target.value).replace(/\B\s+|\s+\B/g, '');
                event.target.value = this.strProviderZip;
                this.objProviderDetail[0].ProviderZip_ACE__c = this.strProviderZip;
                break;
            default : break;
        }
    }

    handleSubmit(event) {

        let boolError = false;

        boolError = this.validateFormFields();

        if (boolError) {
            event.preventDefault();
        } else {
            event.preventDefault();
            this.objProviderDetail[0].Id = null;
            this.objProviderDetail[0].NPI_ACE__c = this.strProviderNPI;
            this.objProviderDetail[0].ProviderAddress_ACE__c = this.objProviderDetail[0].ProviderStreet_ACE__c + " " +
                                                               this.objProviderDetail[0].ProviderCity_ACE__c +  " " +
                                                               this.objProviderDetail[0].ProviderState_ACE__c + " " +
                                                               this.objProviderDetail[0].ProviderZip_ACE__c;
            this.createPntapAlert();
            
        }

    }

    createPntapAlert() {
        createProviderAlert({
            strTitle : this.strTitle,
            strDescription: this.strDescription,
            strStartDate: this.datStartDate,
            strEndDate: this.datEndDate,
            strNPI: this.strProviderNPI,
            strCorpCode: this.strCorpCodeToSearch,
            strAlertId :null,
            lstSelectedProviders: this.objProviderDetail
        }).then((objResult) => {
            this.handleSuccess(objResult);
        });
    }


    validateFormFields() {

        let boolHasNPIError = false;
        let boolHasPNameError = false;
        let boolHasPStreetError = false;
        let boolHasPCityError = false;
        let boolHasPStateError = false;
        let boolHasPZipCodeError = false;

        //validation for NPI Field
        if (this.strProviderNPI === undefined || this.strProviderNPI === "") {
            boolHasNPIError = true;
            if (!this.template.querySelector(".NPIDigitError").classList.contains("slds-hide")) {
                this.template.querySelector(".NPIDigitError").classList.add("slds-hide")
            }
            this.template.querySelector(".NPIErrorText").classList.remove("slds-hide");
        } else if ((this.strProviderNPI).length !== 10) {
            boolHasNPIError = true;
            if (!this.template.querySelector(".NPIErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".NPIErrorText").classList.add("slds-hide")
            }
            this.template.querySelector(".NPIDigitError").classList.remove("slds-hide");
        } else {
            boolHasNPIError = false;
            if (!this.template.querySelector(".NPIErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".NPIErrorText").classList.add("slds-hide")
            }
            if (!this.template.querySelector(".NPIDigitError").classList.contains("slds-hide")) {
                this.template.querySelector(".NPIDigitError").classList.add("slds-hide")
            }
        }

        //validation for Provider Name Field
        if (this.strProviderName === undefined || this.strProviderName === "" || this.strProviderName === null) {
            boolHasPNameError = true;
            if (!this.template.querySelector(".pNameDoubleQuoteError").classList.contains("slds-hide")) {
                this.template.querySelector(".pNameDoubleQuoteError").classList.add("slds-hide")
            }
            this.template.querySelector(".pNameErrorText").classList.remove("slds-hide");
        } else if ((this.strProviderName).indexOf('"') > -1) {
            boolHasPNameError = true;
            if (!this.template.querySelector(".pNameErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".pNameErrorText").classList.add("slds-hide")
            }
            this.template.querySelector(".pNameDoubleQuoteError").classList.remove("slds-hide");
        } else {
            boolHasPNameError = false;
            if (!this.template.querySelector(".pNameErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".pNameErrorText").classList.add("slds-hide")
            }
            if (!this.template.querySelector(".pNameDoubleQuoteError").classList.contains("slds-hide")) {
                this.template.querySelector(".pNameDoubleQuoteError").classList.add("slds-hide")
            }
        }

        //validation for Provider Street
        if (this.strProviderStreet === undefined || this.strProviderStreet === "") {
            boolHasPStreetError = true;
            if (!this.template.querySelector(".pStreetDoubleQuoteError").classList.contains("slds-hide")) {
                this.template.querySelector(".pStreetDoubleQuoteError").classList.add("slds-hide")
            }
            this.template.querySelector(".pStreetErrorText").classList.remove("slds-hide");
        } else if ((this.strProviderStreet).indexOf('"') > -1) {
            boolHasPStreetError = true;
            if (!this.template.querySelector(".pStreetErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".pStreetErrorText").classList.add("slds-hide")
            }
            this.template.querySelector(".pStreetDoubleQuoteError").classList.remove("slds-hide");
        } else {
            boolHasPStreetError = false;
            if (!this.template.querySelector(".pStreetErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".pStreetErrorText").classList.add("slds-hide")
            }
            if (!this.template.querySelector(".pStreetDoubleQuoteError").classList.contains("slds-hide")) {
                this.template.querySelector(".pStreetDoubleQuoteError").classList.add("slds-hide")
            }
        }

        //validation for Provider City
        if (this.strProviderCity === undefined || this.strProviderCity === "") {
            boolHasPCityError = true;
            if (!this.template.querySelector(".pCityDoubleQuoteError").classList.contains("slds-hide")) {
                this.template.querySelector(".pCityDoubleQuoteError").classList.add("slds-hide")
            }
            this.template.querySelector(".pCityErrorText").classList.remove("slds-hide");
        } else if ((this.strProviderCity).indexOf('"') > -1) {
            boolHasPCityError = true;
            if (!this.template.querySelector(".pCityErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".pCityErrorText").classList.add("slds-hide")
            }
            this.template.querySelector(".pCityDoubleQuoteError").classList.remove("slds-hide");
        } else {
            boolHasPCityError = false;
            if (!this.template.querySelector(".pCityErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".pCityErrorText").classList.add("slds-hide")
            }
            if (!this.template.querySelector(".pCityDoubleQuoteError").classList.contains("slds-hide")) {
                this.template.querySelector(".pCityDoubleQuoteError").classList.add("slds-hide")
            }
        }

        //validation for Provider State
        if (this.strProviderState === undefined || this.strProviderState === "") {
            boolHasPStateError = true;
            if (this.template.querySelector(".pStateErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".pStateErrorText").classList.remove("slds-hide");
            }

        } else {
            boolHasPStateError = false;
            if (!this.template.querySelector(".pStateErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".pStateErrorText").classList.add("slds-hide")
            }
        }

        //validation for Provider Zip
        if (this.strProviderZip === undefined || this.strProviderZip === "") {
            boolHasPZipCodeError = true;
            if (!this.template.querySelector(".pZipDoubleQuoteError").classList.contains("slds-hide")) {
                this.template.querySelector(".pZipDoubleQuoteError").classList.add("slds-hide")
            }
            this.template.querySelector(".pZipErrorText").classList.remove("slds-hide");
        } else if ((this.strProviderZip).indexOf('"') > -1) {
            boolHasPZipCodeError = true;
            if (!this.template.querySelector(".pZipErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".pZipErrorText").classList.add("slds-hide")
            }
            this.template.querySelector(".pZipDoubleQuoteError").classList.remove("slds-hide");
        } else {
            boolHasPZipCodeError = false;
            if (!this.template.querySelector(".pZipErrorText").classList.contains("slds-hide")) {
                this.template.querySelector(".pZipErrorText").classList.add("slds-hide")
            }
            if (!this.template.querySelector(".pZipDoubleQuoteError").classList.contains("slds-hide")) {
                this.template.querySelector(".pZipDoubleQuoteError").classList.add("slds-hide")
            }
        }

        if (boolHasNPIError || boolHasPNameError || boolHasPStreetError
            || boolHasPCityError || boolHasPStateError || boolHasPZipCodeError) {
            return true;
        } else {
            return false;
        }

    }
}