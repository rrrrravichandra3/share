//CEAS-64928, CEAS-65583

import { LightningElement, api } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import Alerts_ModelHeader_ACE from '@salesforce/label/c.Alerts_ModelHeader_ACE';


export default class LwcLegacyAlertsAce extends LightningElement {

    label = {
        Alerts_ModelHeader_ACE
    };
    @api lstLegacyMemberAlerts;
    @api boolShowHideModal;
    @api strTabId;
    objError = {};
    objTabData;

    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.setHTML(this.lstLegacyMemberAlerts);            
        } catch(error) {
            this.handleErrors(error);
        }
    }

    handleErrors(error) {
        this.objError = error;
    }

    closeModal() {
        const objParameterData = {};         
        BaseLWC.fireCustomEvent('CloseLegacyModalEvent', objParameterData, 'AlertSummaryLightningCloseLegacyModal', true, this.strTabId);
    }

    setHTML(lstResult){
        this.lstResult.array.forEach(objLegacyAlerts => {
            if(objLegacyAlerts.strDescription === undefined || objLegacyAlerts.strDescription === null) {
                objLegacyAlerts.strDescription = "N/A";
            }
            if(objLegacyAlerts.strStartDate === undefined || objLegacyAlerts.strStartDate === null) {
                objLegacyAlerts.strStartDate = "N/A";
            }
            if(objLegacyAlerts.strEndDate === undefined || objLegacyAlerts.strEndDate === null) {
                objLegacyAlerts.strEndDate = "N/A";
            }
        });
    }


    legacyAlertsTableObj = {
        pageSize: 10,
        showPagination : true,
        boolViewMore: false,
        columnsData: [
            { label: 'NOTIFICATION DESCRIPTION', fieldName: 'strDescription', sortable: false, type: 'text' },
            { label: 'EFFECTIVE DATE', fieldName: 'strStartDate', sortable: false, type: 'date' },
            { label: 'EXPIRATION DATE', fieldName: 'strEndDate', sortable: false, type: 'date' }
        ],
        boolShowFilter: false,
        boolPagination: true,
        boolShowSearch: false,
        boolShowCheckbox: false,
        boolShowHeader: false,
        boolShowSearchLabel: false,
        boolSecondaryTable: false,
        restrictedPageSize: false,
        boolPaginationwithSize: true
    };
}