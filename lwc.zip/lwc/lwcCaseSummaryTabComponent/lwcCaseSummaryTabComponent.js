import { LightningElement, wire, api } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';
import { openSubtab, setTabIcon } from 'lightning/platformWorkspaceApi';
import { publish, MessageContext } from 'lightning/messageService';
import bridgeHelper from '@salesforce/messageChannel/LWCAuraVFBridgeHelper__c';

import getCaseSummaryData from '@salesforce/apex/CaseHybridController_ACE.getCaseSummary'
import GroupNumber from '@salesforce/label/c.ViewCaseSummary_GroupNumber_ACE';
import TypeAndSubType from '@salesforce/label/c.ViewCaseSummary_TypeAndSubType_ACE';
import Status from '@salesforce/label/c.ViewCaseSummary_Status_ACE';
import InquirerRelationship from '@salesforce/label/c.ViewCaseSummary_InquirerRelationship_ACE';
import Origin from '@salesforce/label/c.ViewCaseSummary_Origin_ACE';
import SMSTextMessage_Title_ACE from '@salesforce/label/c.SMSTextMessage_Title_ACE';
import CaseSummary_Title_ACE from '@salesforce/label/c.CaseSummary_Title_ACE';

import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import InteractionHistoryPage_NoRecordFound_ACE from '@salesforce/label/c.InteractionHistoryPage_NoRecordFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
//CEAS-79890 
import fetchProfile from '@salesforce/apex/CreateChildCaseController_ACE.fetchProfile';
import ReportingAdministrator_Profile_ACE from '@salesforce/label/c.ReportingAdministrator_Profile_ACE';
export default class LwcCaseSummaryTabComponent extends LightningElement {

    label = {
        GroupNumber,
        TypeAndSubType,
        Status,
        InquirerRelationship,
        Origin,
        SMSTextMessage_Title_ACE,
        CaseSummary_Title_ACE,
        SafeMode_ToastMessage_ACE,
        IntegrationFailMessage_ACE,
        InteractionHistoryPage_NoRecordFound_ACE,
        ReportingAdministrator_Profile_ACE
    }

    @api tabData;
    @api globalData;
    @api boolSafeMode;

    //CEAS-84895
    boolShowArchived = true;

    boolDisplayData = false;
    boolSpinner = false;
    boolShowNoRecorsFound = false;
    boolAPIError = false;

    //CEAS-79890
    strBaseCurrentTabUrl;
    hideNewButton = true;
    objCatchError = {};

    @wire(MessageContext)
    messageContext

    boolShowNotesModal = false;
    notesModal = {};
    lstTableData = [];
    lstCaseId = [];
    columns = [
        { label: 'CASE NUMBER', fieldName: 'CaseNumber', sortable: true, type: '' },
        { label: 'DATE/TIME OPENED', fieldName: 'CreatedDate', sortable: true, type: 'date', boolInitSort: true, boolAsc: false, boolIsTooltip: true },
        { label: 'INQUIRER NAME', fieldName: 'InquirerName_ACE__c', sortable: true, type: '', boolIsTooltip: true },
        { label: 'SUBSCRIBER ID', fieldName: 'SubscriberID_ACE__c', sortable: true, type: '' },
        { label: this.label.GroupNumber, fieldName: 'GroupNumber_ACE__c', sortable: true, type: '' },
        { label: this.label.TypeAndSubType, fieldName: 'TypeAndSubType_ACE__c', sortable: true, type: '' },
        { label: this.label.Status, fieldName: 'Status', sortable: true, type: '' },
        { label: 'ORIGIN', fieldName: 'Origin', sortable: true, boolHidden: false, type: '' },
        { label: 'CASE OWNER', fieldName: 'OwnerName', sortable: true, type: '' },
        { label: 'ACTION', fieldName: 'actionLink', sortable: false, type: '' },
        { label: 'SUBJECT', fieldName: 'Subject', sortable: false, boolHidden: true, type: '' },
        { label: 'INQUIRER RELATIONSHIP', fieldName: 'InquirerRelationship_ACE__c', sortable: false, type: '', boolHidden: true },
        { label: 'Account Name', fieldName: 'AccountName_ACE__c', sortable: true, type: '', boolHidden: true },
        { label: 'TYPE', fieldName: 'Type', sortable: false, type: '', boolHidden: true },
        { label: 'SUB-TYPE', fieldName: 'Sub_Type_ACE__c', sortable: false, type: '', boolHidden: true },
        { label: 'CORP CODE', fieldName: 'CorporationCode_ACE__c', sortable: false, type: '', boolHidden: true },
        { label: 'CASE AGE', fieldName: 'CaseAge_ACE__c', sortable: false, type: '', boolHidden: true },
        { label: 'Counter', fieldName: 'counter', sortable: false, type: '', boolHidden: true }

    ];

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: false,
        boolShowSearch: true,
        boolShowSearchLabel: true,
        filterData: [
            { strType: 'picklist', intCol: 6, strFilterName: this.label.TypeAndSubType },
            { strType: 'picklist', intCol: 7, strFilterName: this.label.Status },
            { strType: 'picklist', intCol: 13, strFilterName: this.label.InquirerRelationship },
            { strType: 'picklist', intCol: 8, strFilterName: this.label.Origin }
        ],
    };

    connectedCallback() {
        if (!(typeof this.tabData === 'object' && typeof this.globalData === 'object')) {
            return;
        }
        if (!(this.globalData.boolProducer || this.globalData.boolAccount)) {
            const filter = { strType: 'text', intCol: 5, strFilterName: this.label.GroupNumber };
            this.objInitTableSettings.filterData = [filter, ...this.objInitTableSettings.filterData];
        }
        if (this.globalData.boolProducer || this.globalData.boolAccount || this.globalData.boolProspectAccount) {
            const columns1 = { ...this.columns[3], boolHidden: true };
            const columns2 = { ...this.columns[4], boolHidden: true };
            this.columns[3] = columns1;
            this.columns[4] = columns2;
            this.objInitTableSettings.columnsData = [...this.columns];
        }
        this.listenForCaseCardRefresh();
        this.fetchData();
        window.addEventListener(`FilterCaseSummary_${this.tabData.recordId}`, this.filterTableListener, false);
        //CEAS-72530
        window.addEventListener('message', this.messageListener, false);
        //CEAS-79890
        this.hideCaseCreation();
         //CEAS-84895
         this.hideArchivedButton();
    }

    messageListener = (objEvent) => {
        //Handles opening of case details subtab for other cards
        if (objEvent && objEvent.data && typeof objEvent.data === 'string') {
            try {
                const objEventData = JSON.parse(objEvent.data);
                if (objEventData && objEventData.strIdDestination && objEventData.strIdDestination === 'CaseSummaryCallOpenSubtab_ACE') {
                    const strCaseId = objEventData.objParameters.strCaseId;
                    const strCaseNumber = objEventData.objParameters.strCaseNumber;
                    if (this.lstCaseId.includes(strCaseId)) {
                        this.openCaseDetails(strCaseId, strCaseNumber);
                    } else {
                        //Do nothing
                    }
                }

                //Refresh from Manual Case
                if (objEventData && objEventData.key && objEventData.key === "strCaseSummaryRefreshFromManualCase" &&
                    objEventData.newValue && JSON.parse(objEventData.newValue).strRecordId === this.globalData.strUrlMemberId) {
                    this.refreshData();
                }

            } catch (e) {
                //Do nothing
            }

        }
    }

    fetchData = () => {
                this.boolDisplayData = false;
        this.boolSpinner = true;
        this.boolShowNoRecorsFound = false;
        this.boolAPIError = false;
        //Fetch Data from Controller
        getCaseSummaryData({ idAccount: this.tabData.recordId }).then(result => {
            if (result) {
                const data = [...result];

                //Loop through Data to modify for Table
                this.lstTableData = data.map((el) => {

                    const obj = { ...el };
                    this.lstCaseId.push(el['Id']);
                    obj.OwnerName = el.Owner.Name;
                    obj['CaseNumber'] = {
                        value: el['CaseNumber'],
                        strCaseId: el['Id'],
                        wrapper: `<a data-casenumber="${el.CaseNumber}">${el.CaseNumber}</a>`
                    };

                    //CEAS-69441
                    obj['Sub_Type_ACE__c'] = this.convertAPIToLabelForSubtype(obj['Sub_Type_ACE__c']);
                    obj['TypeAndSubType_ACE__c'] = this.convertAPIToLabelForTypeAndSubtype(obj['TypeAndSubType_ACE__c']);
                    let strFacetstaskId = '';
                    if (el['Facets_Task_ID_ACE__c']) {
                        strFacetstaskId = el['Facets_Task_ID_ACE__c'];
                    }
                    obj['actionLink'] = {
                        value: el['CaseNumber'],
                        strCaseId: el['Id'],
                        strType: el['Type'],
                        strSubType: el['Sub_Type_ACE__c'],
                        strFacetsTaskId: strFacetstaskId,
                        wrapper: `<a data-casenumber="${el.CaseNumber}">View Notes</a>`
                    }

                    let datDateToShow = '';
                    if (BaseLWC.dtDateTimeISOtoLocal(obj.CreatedDate) !== 'Invalid Date') {
                        datDateToShow = BaseLWC.dtDateTimeISOtoLocal(obj.CreatedDate)
                    }
                    obj['CreatedDate'] = {
                        value: obj.CreatedDate,
                        wrapper: datDateToShow,
                        strCellValue: `<p>Case Age:<br/>${obj.CaseAge_ACE__c} Days</p>`,
                        strTextTooltipContent: `<p>Case Age:<br/>${obj.CaseAge_ACE__c} Days</p>`
                    }
                    const strInquirer = obj.InquirerName_ACE__c;
                    if (strInquirer) {
                        obj['InquirerName_ACE__c'] = {
                            value: strInquirer,
                            wrapper: strInquirer,
                            strCellValue: `<p>Inquirer Relationship:<br/>${obj.InquirerRelationship_ACE__c}</p>`,
                            strTextTooltipContent: `<p>Inquirer Relationship:<br/>${obj.InquirerRelationship_ACE__c}</p>`
                        }
                    } else {
                        obj['InquirerName_ACE__c'] = {
                            value: '',
                            wrapper: '',
                            strCellValue: '',
                            strTextTooltipContent: ''
                        }
                    }

                    return obj;
                })


                if (!this.lstTableData.length) {
                    this.boolShowNoRecorsFound = true;
                }
                this.boolDisplayData = true;
                this.boolSpinner = false;

            }
        }).catch(() => {
            this.boolSpinner = false;
            this.boolAPIError = true;
        });
    }

    handleRowAction(event) {
        const rowData = JSON.parse(event.detail);
        if (rowData.activeColumnName === 'ACTION') {
            this.notesModal.strCaseNumber = rowData.activeColumnData.value.value;
            this.notesModal.strCaseId = rowData.activeColumnData.value.strCaseId;
            this.notesModal.strCaseType = rowData.activeColumnData.value.strType;
            this.notesModal.strCaseSubType = rowData.activeColumnData.value.strSubType;
            this.notesModal.strFacetsTaskId = rowData.activeColumnData.value.strFacetsTaskId;
            this.boolShowNotesModal = true;
        } else if (rowData.activeColumnName === 'CASE NUMBER') {
            this.openCaseDetails(rowData.activeColumnData.value.strCaseId, rowData.activeColumnData.value.value)
        } else {
            //Do nothing
        }
    }

    closeModal() {
        this.boolShowNotesModal = false;
    }

    refreshData = () => {
        this.fetchData();

        setTimeout(function () {
            this.objInitTableSettings.lstDefaultFilter = []
        }.bind(this), 2000)
    }

     //CEAS-84895
     hideArchivedButton(){
        const objAcc = this.globalData.objAccRecords;
        const strRecordType = objAcc.RecordType.value.fields.DeveloperName.value;
        if(strRecordType !== 'PersonAccount') {
            this.boolShowArchived = false ;
        } 
     }
    

    openArchivedRecordsInSubtab = () => {
        const strParams = '?mid=' + this.globalData.strUrlMemberId + '&corpCode=' + this.globalData.strCorpCode + '&groupNumber=' + this.globalData.strGroupName;
        const strUrl = '/lightning/n/Archived_Records' + BaseLWC.helperBaseEncodeUrl(strParams);
        openSubtab(this.tabData.tabId, {url: strUrl, focus: true})
            .then(objresponse => {
                setTabIcon(objresponse, 'custom:custom13', '').then(() => {
                    //Do nothing
                }).catch(() => {
                    //Do nothing
                })
            }).catch(() => {
                //Do nothing
            })
    }

    openCaseDetails = (strCaseId, strCaseNumber) => {
        if (!this.tabData) {
            return;
        }
        try {
            const objParsedTabData = JSON.parse(JSON.stringify(this.tabData));
            if (objParsedTabData.url) {
                const strDecodedURL = BaseLWC.helperBaseDecodeUrl(objParsedTabData.url);
                if (!BaseLWC.isValidUrl(strDecodedURL)) {
                    return
                }

                const objUrl = new URL(strDecodedURL);
                const strProducerId = objUrl.searchParams.get("producerId");
                let strParams = '?mid=' + this.globalData.strUrlMemberId + '&caseNumber=' + strCaseNumber;
                if (this.globalData.boolProspectMember) {
                    strParams += '&boolProspectMember=true&boolProducer=false&boolURLFormed=true'
                } else {
                    if (this.globalData.objAccRecords.RecordType.value.fields.DeveloperName.value === 'Producer_ACE') {
                        strParams += '&boolProducer=true&producerId=' + strProducerId
                    } else {
                        strParams += '&boolProducer=false'
                    }
                }

                const strUrl = '/lightning/r/Case/' + strCaseId + '/view' + BaseLWC.helperBaseEncodeUrl(strParams);
                if (objParsedTabData.isSubtab && this.tabData.tabId === objParsedTabData.parentTabId ||
                    (!objParsedTabData.isSubtab && this.tabData.tabId === objParsedTabData.tabId)) {
                    openSubtab(this.tabData.tabId, {url: strUrl, focus: true})
                        .then(() => {
                            //Do nothing
                        }).catch((error) => {
                            //Do nothing
                            console.log('print error ' + JSON.stringify(error.body.message));
                        })
                } else {
                    return;
                }
            }
        } catch(error) {
            //do nothing
        }
    }

    openCreateCaseSubTab = () => {
        if (!this.tabData) {
            return;
        }
        try {
            const objParsedTabData = JSON.parse(JSON.stringify(this.tabData));
            if (objParsedTabData.url) {
                const strDecodedURL = BaseLWC.helperBaseDecodeUrl(objParsedTabData.url);
                if (!BaseLWC.isValidUrl(strDecodedURL)) {
                    return
                }
                const objAcc = this.globalData.objAccRecords;
                const strcallBack = objAcc.Phone.value;
                const strRecordType = objAcc.RecordType.value.fields.DeveloperName.value;
                const strSubscriber = objAcc.SubscriberId_ACE__c.value;
                const strTempMemberLOB = objAcc.TempMemberLOB_ACE__c.value; // CEAS-45893
                const strBillingState = objAcc.BillingState.value;

                const objUrl = new URL(strDecodedURL);
                const strProducerId = objUrl.searchParams.get("producerId");
                let strEncodedParams = '';
                let strFlexiPageURL;

                if (strRecordType === 'Producer_ACE') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now() + '&boolProducer=true&producerId=' + strProducerId);
                    strFlexiPageURL = '/lightning/n/ManualCaseCreate_Producer_ACE' + strEncodedParams;
                } else if (strRecordType === 'ProspectMember_ACE') {
                    if (strSubscriber !== null) {
                        //CEAS-63769
                        if (strTempMemberLOB && (strTempMemberLOB.toUpperCase() === 'GOVERNMENT-MEDICARE' || strTempMemberLOB.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL')) {
                            const strCorpCode = this.assignCorpCodeFromBillingState(strBillingState);
                            strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now() + '&tempMemberLOB=' + strTempMemberLOB + '&corpCode=' + strCorpCode);
                            strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectMember_ACE' + strEncodedParams + '&boolProspectMember=true';
                        } else {
                            strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now());
                            strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectMember_ACE' + strEncodedParams + '&boolProspectMember=true';
                        }

                    } else {
                        strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now() + '&tempMemberLOB=' + strTempMemberLOB);
                        strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectMemberNoSub_ACE' + strEncodedParams + '&boolProspectMember=true';
                    }
                } else if (strRecordType === 'Out_of_State_FEP_Member' || strRecordType === 'BlueCard_Member_ACE') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now());
                    strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectMemberNoSub_ACE' + strEncodedParams + '&boolProspectMember=true';
                } else if (strRecordType === 'Retail_Applicant_ACE') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now() + '&isRetailApplicant=true&strCallBackNumber=' + strcallBack);
                    strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectMemberNoSub_ACE' + strEncodedParams + '&boolProspectMember=true';
                } else if (strRecordType === 'Account_ACE') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now());
                    strFlexiPageURL = '/lightning/n/ManualCaseCreate_AccountServicing_ACE' + strEncodedParams;
                } else if (strRecordType === 'ProspectAccount_ACE') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now());
                    strFlexiPageURL = '/lightning/n/ManualCaseCreate_ProspectAccount_ACE' + strEncodedParams;
                    // CEAS-57152 Design for NMCC
                } else if (strRecordType === 'PersonAccount') {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now() + '&boolLoadAfterPlanEvent=true');
                    strFlexiPageURL = '/lightning/n/Manual_Case_Create_ACE' + strEncodedParams;
                } else {
                    strEncodedParams = BaseLWC.helperBaseEncodeUrl('?timeInMillis=' + Date.now());
                    strFlexiPageURL = '/lightning/n/Manual_Case_Create_ACE' + strEncodedParams;
                }

                openSubtab(this.tabData.tabId, {url: strFlexiPageURL, focus : true})
                    .then(() => {
                        //Do nothing
                    }).catch(() => {
                        //Do nothing
                    })

                const objRequestFromNewButton = {
                    boolFromNewButton: true
                };
                const objData = {
                    key: 'requestFromNewButton_' + objAcc.Id.value,
                    value: JSON.stringify(objRequestFromNewButton)
                }
                this.postMessageHelper(objData, true, false, 'setLocalStorageViaIframe');

            }
        } catch(error) {
            
        }
    }

    postMessageHelper(objDataToBeSent, boolLocalStorage, boolPostMessage, strDestinationId) {
        try {
            const objParameterData = {
                strDestinationId: strDestinationId,
                objMessage: objDataToBeSent
            };
            const objPayload = {
                bridgeMessageData: objParameterData
            };
            if (this.messageContext !== undefined && this.messageContext !== null) {
                publish(this.messageContext, bridgeHelper, objPayload);
            }
        } catch (exception) {
            //No handling Needed.
        }

    }

    assignCorpCodeFromBillingState = (strBillingState) => {
        let strCorpCode = '';
        if (strBillingState) {
            if (strBillingState === 'New Mexico') {
                strCorpCode = 'NM1';
            } else if (strBillingState === 'Illinois') {
                strCorpCode = 'IL1';
            } else if (strBillingState === 'Texas') {
                strCorpCode = 'TX1';
            } else if (strBillingState === 'Oklahoma') {
                strCorpCode = 'OK1';
            } else if (strBillingState === 'Montana') {
                strCorpCode = 'MT1';
            } else {
                //Do nothing
            }
        }
        return strCorpCode;
    }

    callRereshMethod = () => {
        this.refreshData();
    }

    listenForCaseCardRefresh = () => {
        window.addEventListener(`RefreshCaseSummary_${this.tabData.recordId}`, this.callRereshMethod, false)
    }

    disconnectedCallback() {
        window.removeEventListener(`RefreshCaseSummary_${this.tabData.recordId}`, this.callRereshMethod, false)
        window.removeEventListener(`FilterCaseSummary_${this.tabData.recordId}`, this.filterTableListener, false);
    }

    //CEAS-69441 start
    convertAPIToLabelForSubtype(strSubType) {
        let strNewSubtype = strSubType;
        if (strNewSubtype === 'Grievance / Complaint') {
            strNewSubtype = 'Grievance / Member Complaint';
        } else if (strNewSubtype === 'Member Portal (BAM)') {
            strNewSubtype = 'Member Portal';
        } else if (strNewSubtype === 'PCP Update') {
            strNewSubtype = 'MG / PCP Update';
        } else if (strNewSubtype === 'Prior Authorization') {
            strNewSubtype = 'Preauth';
        } else if (strNewSubtype === 'Prospective Member') {
            strNewSubtype = 'Temporary Member';
        } else {
            //Do nothing
        }
        return strNewSubtype;
    }

    convertAPIToLabelForTypeAndSubtype(strTypeSubtype) {
        let strNewTypeSubtype = strTypeSubtype;

        const strGMC = 'Grievance / Complaint';
        if (strNewTypeSubtype.includes(strGMC)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strGMC, 'Grievance / Member Complaint');
        }
        const strMemberPortal = 'Member Portal (BAM)';
        if (strNewTypeSubtype.includes(strMemberPortal)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMemberPortal, 'Member Portal');
        }
        const strMGPCP = 'PCP Update';
        if (strNewTypeSubtype.includes(strMGPCP)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strMGPCP, 'MG / PCP Update');
        }
        const strPreAuth = 'Prior Authorization';
        if (strNewTypeSubtype.includes(strPreAuth)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strPreAuth, 'Preauth');
        }
        const strProspectiveMember = 'Prospective Member';
        if (strNewTypeSubtype.includes(strProspectiveMember)) {
            strNewTypeSubtype = strNewTypeSubtype.replace(strProspectiveMember, 'Temporary Member');
        }
        return strNewTypeSubtype;
    }
    //CEAS-69441 end

    filterTableListener = (objEvent) => {
        if (objEvent.detail && JSON.parse(objEvent.detail)) {
            if (JSON.parse(objEvent.detail).filter) {
                this.objInitTableSettings.lstDefaultFilter = [
                    {
                        strFilterName: this.label.Status,
                        lstValues: ['Open', 'Pended']
                    },
                    {
                        strFilterName: this.label.Origin,
                        lstValues: ['OUTBOUND CALL']
                    }
                ]
                this.refreshData();
            }
        }
    }
    //CEAS-79890
    hideCaseCreation = () =>  {
        try {
            this.strBaseCurrentTabUrl = this.tabData.url;
            const strProfileParam = BaseLWC.helperBaseGetUrlParameters('pfn', this.strBaseCurrentTabUrl);
            if(strProfileParam) {
                if(strProfileParam === this.label.ReportingAdministrator_Profile_ACE) {
                    this.hideNewButton = false;
                } 
            } else {
                fetchProfile({}).then(result => {
                    if(result === this.label.ReportingAdministrator_Profile_ACE) {
                        this.hideNewButton = false;
                    } else {
                        this.hideNewButton = true;
                    }
                }).catch(() => {
                     //Do Nothing;
                });
            }
        } catch(error) {
            this.handleErrors(error);
        }
    };

    handleErrors = (error) => {
        this.objCatchError = error;
    };
}
