import { LightningElement,api } from 'lwc';

export default class LwcExportData extends LightningElement {
    @api boolShowExport;
    @api headersExport;
    @api lstFilteredData;
    @api boolExportButtonDisabled;
    @api fileName;
    @api buttonTitle; 

    handleExport() {
        try {
        let csv = '';
        let selectedRowsList = [];
        const rowEnd = '\n';
        let headers = '';
        //Fetch Headers in String format seperated by comma
        for (let key in this.headersExport) {
            if(this.headersExport[key].boolExport) {
                headers += this.headersExport[key].label + ','; 
            } 
        }
        csv += headers;
        csv += rowEnd;
        //Fetch the Row Table Records as List of Maps List<Map<String, String>>
        // Map(11) {'CaseNumber' => '12569569', 'Case_Pend_Age_ACE__c' => 39, 'SubscriberID_ACE__c' => '000905342320', 'GroupNumber_ACE__c' => 'N72100', 'TypeAndSubType_ACE__c' => 'Pre-Service Reviews - Preauth Initiation',"Status" => "Open","Account_Number_ACE__c" => "-","CorporationCode_ACE__c" => "NM1","AppealID_ACE__c" => "-","OwnerName" => "Renuka katiyar","FollowUpDate" => "06/02/2023"}
        for(let a in this.lstFilteredData) {
            for (let [key, value] of this.lstFilteredData[a]) {
                let currRow = '';
                currRow = value;
                currRow += ',';
                csv += currRow;
            }
            csv += rowEnd;
            
        }
            const downloadElement = document.createElement('a');
            downloadElement.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
            downloadElement.target = '_self';
            downloadElement.download = this.fileName;
            downloadElement.click();
    } catch (error) {}
    }
    
}