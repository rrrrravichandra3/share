import { LightningElement, track, wire,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import MemberContactDetails_FepSuccessMessage_ACE from '@salesforce/label/c.MemberContactDetails_FepSuccessMessage_ACE';
import CreateCasePage_MemberManagement_ACE from '@salesforce/label/c.CreateCasePage_MemberManagement_ACE';
import MemberContactDetails_PreferredPhone_Message_ACE from '@salesforce/label/c.MemberContactDetails_PreferredPhone_Message_ACE';
import CreateCasePage_Telephone_ACE from '@salesforce/label/c.CreateCasePage_Telephone_ACE';
import CommunicationPreferencesLabel_ACE from '@salesforce/label/c.CommunicationPreferencesLabel_ACE';
import MemberContactDetails_EmailAlreadyMessage_ACE from '@salesforce/label/c.MemberContactDetails_EmailAlreadyMessage_ACE';
import MemberContactDetails_SuccessMessage_ACE from '@salesforce/label/c.MemberContactDetails_SuccessMessage_ACE';
import MemberContactDetails_SourceSystem_ACE from '@salesforce/label/c.MemberContactDetails_SourceSystem_ACE';
import MemberContactDetails_SYSTEM80_SUB_Email_Message_ACE from '@salesforce/label/c.MemberContactDetails_SYSTEM80_SUB_Email_Message_ACE';
import MemberContactDetails_SYSTEM80_SUB_PhoneNumber_Message_ACE from '@salesforce/label/c.MemberContactDetails_SYSTEM80_SUB_PhoneNumber_Message_ACE';
import MemberContactDetails_DocumentEmailAddressButton_ACE from '@salesforce/label/c.MemberContactDetails_DocumentEmailAddressButton_ACE';
import MemberContactDetails_DocumentPhoneNumberButton_ACE from '@salesforce/label/c.MemberContactDetails_DocumentPhoneNumberButton_ACE';
import MemberContactDetails_SUB_PhoneNumber_Message_ACE from '@salesforce/label/c.MemberContactDetails_SUB_PhoneNumber_Message_ACE';
import MemberContactDetails_SUB_Email_Message_ACE from '@salesforce/label/c.MemberContactDetails_SUB_Email_Message_ACE';
import MemberContactDetails_OnExchange_SUB_PhoneNumber_Message_ACE from '@salesforce/label/c.MemberContactDetails_OnExchange_SUB_PhoneNumber_Message_ACE';
import MemberContactDetails_OnExchange_SUB_Email_Message_ACE from '@salesforce/label/c.MemberContactDetails_OnExchange_SUB_Email_Message_ACE';
import HideComponentsByLOB_ACE from '@salesforce/label/c.HideComponentsByLOB_ACE';
import MemberContactDetails_ACE from '@salesforce/label/c.MemberContactDetails_ACE';
import MemberContactDetails_NoMatchFound_ACE from '@salesforce/label/c.MemberContactDetails_NoMatchFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import MemberContactDetails_PhoneAlreadyMessage_ACE from '@salesforce/label/c.MemberContactDetails_PhoneAlreadyMessage_ACE';
import MemberContactDetails_PreferredMailingAddress_ACE from '@salesforce/label/c.MemberContactDetails_PreferredMailingAddress_ACE';
import MemberContactDetails_PreferredPhoneNumber_ACE from '@salesforce/label/c.MemberContactDetails_PreferredPhoneNumber_ACE';
import MemberContactDetails_PreferredTextPhoneNumber_ACE from '@salesforce/label/c.MemberContactDetails_PreferredTextPhoneNumber_ACE';
import MemberContactDetails_EmailAddress_ACE from '@salesforce/label/c.MemberContactDetails_EmailAddress_ACE';
import MemberContactDetails_RequestAddressButton_ACE from '@salesforce/label/c.MemberContactDetails_RequestAddressButton_ACE';
import Read_Only_Profile from '@salesforce/label/c.Read_Only_Profile';
import MemberContactDetails_AEPMessageUI_ACE from '@salesforce/label/c.MemberContactDetails_AEPMessageUI_ACE';
import MemberContactDetails_OfficialMailingAddress_ACE from '@salesforce/label/c.MemberContactDetails_OfficialMailingAddress_ACE';
import MemberContactDetails_PhysicalAddress_ACE from '@salesforce/label/c.MemberContactDetails_PhysicalAddress_ACE';
import MemberContactDetails_ViewAllPhone_ACE from '@salesforce/label/c.MemberContactDetails_ViewAllPhone_ACE';
import MemberContactDetails_ViewAllEmail_ACE from '@salesforce/label/c.MemberContactDetails_ViewAllEmail_ACE';
import MemberContactDetails_PermissionToVoicemail_ACE from '@salesforce/label/c.MemberContactDetails_PermissionToVoicemail_ACE';
import MemberContactDetails_WrittenLanguage_ACE from '@salesforce/label/c.MemberContactDetails_WrittenLanguage_ACE';
import MemberContactDetails_SpokenLanguage_ACE from '@salesforce/label/c.MemberContactDetails_SpokenLanguage_ACE';
import MemberContactDetails_PreferredDays_ACE from '@salesforce/label/c.MemberContactDetails_PreferredDays_ACE';
import Retail_SpokenLanguage_Message_ACE from '@salesforce/label/c.Retail_SpokenLanguage_Message_ACE';
import MemberContactDetail_AEPSubject_ACE from '@salesforce/label/c.MemberContactDetail_AEPSubject_ACE';
import CreateCasePage_Closed_ACE from '@salesforce/label/c.CreateCasePage_Closed_ACE';
import MemberContactDetails_PreferredTime_ACE from '@salesforce/label/c.MemberContactDetails_PreferredTime_ACE';
import General_Timezone_ACE from '@salesforce/label/c.General_Timezone_ACE';
import MemberContactDetails_PreferredMethod_ACE from '@salesforce/label/c.MemberContactDetails_PreferredMethod_ACE';
import General_M_ACE from '@salesforce/label/c.General_M_ACE';
import General_T_ACE from '@salesforce/label/c.General_T_ACE';
import General_W_ACE from '@salesforce/label/c.General_W_ACE';
import Email_ACE from '@salesforce/label/c.Email_ACE';
import MemberContactDetails_Preferred_ACE from '@salesforce/label/c.MemberContactDetails_Preferred_ACE';
import General_F_ACE from '@salesforce/label/c.General_F_ACE';
import EO_SaveLabel_ACE from '@salesforce/label/c.EO_SaveLabel_ACE';
import VIewMedical_NUMBER_ACE from '@salesforce/label/c.VIewMedical_NUMBER_ACE';
import MemberContactDetails_PreferredText_ACE from '@salesforce/label/c.MemberContactDetails_PreferredText_ACE';
import MemberContactDetails_PreferredVoice_ACE from '@salesforce/label/c.MemberContactDetails_PreferredVoice_ACE';
import MemberContactDetails_GovMedicaidPhoneNumberBanner_ACE from '@salesforce/label/c.MemberContactDetails_GovMedicaidPhoneNumberBanner_ACE';
import MemberContactDetails_RequestPhoneNumberButton_ACE from '@salesforce/label/c.MemberContactDetails_RequestPhoneNumberButton_ACE';
import MemberContactDetails_GovMedicaidTXMPhoneNumBanner_ACE from '@salesforce/label/c.MemberContactDetails_GovMedicaidTXMPhoneNumBanner_ACE';
import MemberContactDetails_RequestEmailAddressButton_ACE from '@salesforce/label/c.MemberContactDetails_RequestEmailAddressButton_ACE';
import MemberContactDetails_PhoneInvalidMessage_ACE from '@salesforce/label/c.MemberContactDetails_PhoneInvalidMessage_ACE';
import MemberContactDetails_EmailInvalidMessage_ACE from '@salesforce/label/c.MemberContactDetails_EmailInvalidMessage_ACE';
import getUserProfile from '@salesforce/apex/CommunicationPreferSummaryController_ACE.profileDetails';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import Government_Medicare_Label_ACE from '@salesforce/label/c.Government_Medicare_Label_ACE'
import getPreferredContactTimes from '@salesforce/apex/NotificationPrefLWCController_ACE.getPreferredContactTimes';
import getContactTimeZones from '@salesforce/apex/NotificationPrefLWCController_ACE.getContactTimeZones';
import getPermissionToLeaveVoiceMailOptions from '@salesforce/apex/NotificationPrefLWCController_ACE.getPermissionToLeaveVoiceMailOptions';
import getPreferedContactMethods from '@salesforce/apex/NotificationPrefLWCController_ACE.getPreferedContactMethods';
import lstSpokenLanguageApex from '@salesforce/apex/NotificationPrefLWCController_ACE.lstSpokenLanguage';
import lstWrittenLanguageApex from '@salesforce/apex/NotificationPrefLWCController_ACE.lstWrittenLanguage';
import lstAlternativeFormatApex from '@salesforce/apex/NotificationPrefLWCController_ACE.lstAlternativeFormat'
import fetchCaseRuleForPhoneAndEmail from '@salesforce/apex/NotificationPrefLWCController_ACE.fetchCaseRuleForPhoneAndEmail';
import fetchCaseRuleForAddressApex from '@salesforce/apex/NotificationPrefLWCController_ACE.fetchCaseRuleForAddress';
import getMemberContactDetails from "@salesforce/apexContinuation/NotificationPrefLWCController_ACE.getMemberContactDetails";
import saveMemberContactDetails from "@salesforce/apexContinuation/NotificationPrefLWCController_ACE.saveMemberContactDetails";
import createCaseforAutodoc from "@salesforce/apex/NotificationPrefLWCController_ACE.createCaseforAutodoc";
import BaseLWC from 'c/baseLWCFunctions_CF';
import { setTabIcon,EnclosingTabId,getTabInfo,openSubtab} from 'lightning/platformWorkspaceApi';

export default class MemberContactDetailsComponent_ACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;
    labels = {
        MemberContactDetails_FepSuccessMessage_ACE,
        MemberContactDetails_PreferredPhone_Message_ACE,
        MemberContactDetails_PhoneAlreadyMessage_ACE,
        MemberContactDetails_NoMatchFound_ACE,
        MemberContactDetails_SuccessMessage_ACE,
        MemberContactDetails_SYSTEM80_SUB_Email_Message_ACE,
        MemberContactDetails_SYSTEM80_SUB_PhoneNumber_Message_ACE,
        MemberContactDetails_SUB_PhoneNumber_Message_ACE,
        MemberContactDetails_SUB_Email_Message_ACE,
        MemberContactDetails_DocumentPhoneNumberButton_ACE,
        MemberContactDetails_DocumentEmailAddressButton_ACE,
        MemberContactDetails_OnExchange_SUB_Email_Message_ACE,
        MemberContactDetails_OnExchange_SUB_PhoneNumber_Message_ACE,
        Government_Medicare_Label_ACE,
        MemberContactDetail_AEPSubject_ACE,
        CreateCasePage_Closed_ACE,
        HideComponentsByLOB_ACE,
        MemberContactDetails_SourceSystem_ACE,
        EnableVPSTabSpecificEvents_ACE,
        MemberContactDetails_ACE,
        CreateCasePage_MemberManagement_ACE,
        CreateCasePage_Telephone_ACE,
        CommunicationPreferencesLabel_ACE,
        IntegrationFailMessage_ACE,
        MemberContactDetails_PreferredMailingAddress_ACE,
        MemberContactDetails_PreferredPhoneNumber_ACE,
        MemberContactDetails_PreferredTextPhoneNumber_ACE,
        MemberContactDetails_EmailAddress_ACE,
        MemberContactDetails_RequestAddressButton_ACE,
        Read_Only_Profile,
        MemberContactDetails_AEPMessageUI_ACE,
        MemberContactDetails_OfficialMailingAddress_ACE,
        MemberContactDetails_PhysicalAddress_ACE,
        MemberContactDetails_ViewAllPhone_ACE,
        MemberContactDetails_ViewAllEmail_ACE,
        MemberContactDetails_PermissionToVoicemail_ACE,
        MemberContactDetails_WrittenLanguage_ACE,
        MemberContactDetails_SpokenLanguage_ACE,
        MemberContactDetails_PreferredDays_ACE,
        General_M_ACE,
        General_T_ACE,
        General_W_ACE,
        General_F_ACE,
        Email_ACE,
        MemberContactDetails_Preferred_ACE,
        Retail_SpokenLanguage_Message_ACE,
        MemberContactDetails_PreferredTime_ACE,
        General_Timezone_ACE,
        MemberContactDetails_PreferredMethod_ACE,
        EO_SaveLabel_ACE,
        MemberContactDetails_EmailAlreadyMessage_ACE,
        VIewMedical_NUMBER_ACE,
        MemberContactDetails_PreferredVoice_ACE,
        MemberContactDetails_PreferredText_ACE,
        MemberContactDetails_GovMedicaidTXMPhoneNumBanner_ACE,
        MemberContactDetails_GovMedicaidPhoneNumberBanner_ACE,
        MemberContactDetails_RequestPhoneNumberButton_ACE,
        MemberContactDetails_RequestEmailAddressButton_ACE,
        MemberContactDetails_PhoneInvalidMessage_ACE,
        MemberContactDetails_EmailInvalidMessage_ACE
    };
    constants = {
        STRING_MEMBER_CONTACT_DETAILS_SEPARATOR_AFTER_SPACE: ', '
    };
    strCaseNumber;
    strCaseId;
    strAlternateFormat='';
    strRelationshipTypeCode='';
    strMarketType = '';
    strSource='';
    boolSaveSpinner = false;
    updatePhoneError = false;
    updateEmailError = false;
    boolAccountsAPICallAvailable = false;
    boolCbcApiCallAvailable = false;
    phoneButtonText = this.labels.MemberContactDetails_RequestPhoneNumberButton_ACE;
    emailButtonText = this.labels.MemberContactDetails_RequestEmailAddressButton_ACE;
    objPlanDetails;
    openLWCModel;
    lwcControllerData;
    strClientMemberId;
    strLineOfBusiness;
    parentTabId;
    strMID;
    strCorpCode;
    strSectionNumber;
    boolPerfGurantee;
    securedGroupNecessaryRole;
    strFamilyCaseNumber;
    strGroupNumber;
    strAccountId;
    strSubId;
    objTabData;
    boolAEP = false;
    boolPreferredText = true;
    boolNMCCAddressChangeModal = false;
    boolVPSTabSpecificEvents = false;
    boolShowSpinner = true;
    boolErrorFromIntegration = false;
    apiMemberData={};
    strPhoneInfoMessage;
    strEmailInfoMessage;
    strAddressFirstLine='';
    strAddressSecondLine='';
    strPhysicalAddressFirstLine='';
    strPhysicalAddressSecondLine='';
    strPreferredPhone='';
    strPreferredTextPhone='';
    strPreferredEmail='';
    strCaseDefaultValues='';
    strPolicyId='';
    strGroupCostCenter='';
    strAccInformation;
    strAddOnServices='';
    strTerminationDatel='';
    strEffectiveDate='';
    lstFamilyMembers=[];
    isGovermentMedicade = false;
    showPhoneEmailButton = false;
    govtMedicaidPhNo = false;
    userProfileIsReadOnly=false;
    writtenLanguageDisabled=false;
    preferedContactMethodDisabled=false;
    isSpokenLanguageVisible = true;
    retailSpokenLanguageMessage = false;
    isAlterNateFormatAvailable = false;
    @track allPhoneActiveSections = [];
    @track allEmailActiveSections = [];
    @track lstPhone = [];
    @track lstEmail = [];
    @track objContact = {};
    @track objContactDay = {};
    @track objContactAutoDoc = {};
    @track objContactDayAutoDoc = {};
    lstAlternativeFormat = [];
    lstWrittenLanguage = [];
    lstSpokenLanguage = [];
    contactTimeZones = [];
    preferredContactTime = [];
    permissionToLeaveVoiceMailOptions = [];
    preferedContactMethods = [];
    strInteractionId;
    sortPhoneAscending = false;
    sortEmailAscending = false;
    barPhoneColor = 'barColor';
    barEmailColor = 'barColor';
    objCatchError;
    strIntialNotes ='';
	//CEAS-85501
	boolIsFEP = false;

    @wire(getPermissionToLeaveVoiceMailOptions)
    getPermissionToLeaveVoiceMailOptions({ data, error }) {
        if (data) {
            this.permissionToLeaveVoiceMailOptions = data;
        } else if (error) {
            this.permissionToLeaveVoiceMailOptions = [];
        }
    }

    @wire(getPreferedContactMethods)
    getPreferedContactMethods({ data, error }) {
        if (data) {
            this.preferedContactMethods = data;
        } else if (error) {
            this.preferedContactMethods = [];
        }
    }

    @wire(getPreferredContactTimes)
    getPreferredContactTimes({ data, error }) {
        if (data) {
            this.preferredContactTime = data;
        } else if (error) {
            this.preferredContactTime = [];
        }
    }

    @wire(getContactTimeZones)
    getContactTimeZones({ data, error }) {
        if (data) {
            this.contactTimeZones = data;
        } else if (error) {
            this.contactTimeZones = [];
        }
    }

    @wire(lstSpokenLanguageApex)
    lstSpokenLanguag({ data, error }) {
        if (data) {
            this.lstSpokenLanguage = data;
        } else if (error) {
            this.lstSpokenLanguage = [];
        }
    }

    @wire(lstWrittenLanguageApex)
    lstWrittenLanguage({ data, error }) {
        if (data) {
            this.lstWrittenLanguage = data;
        } else if (error) {
            this.lstWrittenLanguage = [];
        }
    }

    @wire(lstAlternativeFormatApex)
    lstAlternativeFormat({ data, error }) {
        if (data) {
            this.lstAlternativeFormat = data;
        } else if (error) {
            this.lstAlternativeFormat = [];
        }
    }

    get isMemberGoverment(){
        let isGoverment = false;
        if(this.strLineOfBusiness && this.labels.HideComponentsByLOB_ACE.toUpperCase().includes(this.strLineOfBusiness.toUpperCase())){
            isGoverment = true;
        }
        return isGoverment;
    }

    get isMemberGovermentMedicare() {
        let memberMedicare = false;
        if(this.strLineOfBusiness && this.strLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE'){
            memberMedicare = true;
        }
        return memberMedicare;
    }

    //RL: CEAS-74578
    writtenLanguageTexas() {
        const excludeWrittenLanguages = ["Chambri", "Fataleka", "Haida", "Hiri Motu", "Modern Greek", "Other", "Persian", "Serrano", "Unknown"];
        this.lstWrittenLanguage = this.lstWrittenLanguage.filter((element) => {return !excludeWrittenLanguages.includes(element.value);});
    }

    handleWrittenLanguageChange(event) {
        this.objContact.Written_Language__c = event.detail;
    }

    handleAlterNateFormate(event) {
        this.strAlternateFormat = event.detail;
        this.objContact.Alternative_Format_ACE__c = event.detail;
    }

    handleSpokenLanguage(event) {
        this.objContact.Spoken_Language__c = event.detail;
    }

    /**
     * Connected Call back function.
     */
    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.fetchAllData();
        } catch(error) {
            this.handleErrors(error);
        }
    }

    closeAddressChangeModal() {
        this.boolNMCCAddressChangeModal = false;
    }

    //EVENT ARCHITECTURE
    disconnectedCallback() {
        if (this.parentTabId) {
            if (this.boolVPSTabSpecificEvents) {
                window.removeEventListener(
                    'PlanSummaryEvent_' + this.parentTabId,
                    this.capturePlanSummaryListener
                );
            } else {
                window.removeEventListener(
                    'PlanSummaryEvent',
                    this.capturePlanSummaryListener
                );
            }
            const strPlanSummaryEvent = 'PlanSummaryInteractionEvent_' + this.parentTabId;
            window.removeEventListener(strPlanSummaryEvent, this.planSummaryInteractionEventListnerProcess);
        }
    }

    fetchAllData() {
        this.fetchProfileName();
        if(this.enclosingTabId) {
        getTabInfo(this.enclosingTabId).then(objTabData => {
            if (BaseLWC.stringIsNotBlank(this.labels.EnableVPSTabSpecificEvents_ACE) && this.labels.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                this.boolVPSTabSpecificEvents = true;
            }
            this.objTabData = objTabData;
            let strBaseCurrentTabUrl = objTabData.url;
            let tabId = objTabData.tabId;
            setTabIcon(tabId, 'standard:messaging_conversation');
            this.strMID = BaseLWC.helperBaseGetUrlParameters('mid', strBaseCurrentTabUrl);
            this.strCorpCode = BaseLWC.helperBaseGetUrlParameters('corpCode', strBaseCurrentTabUrl);
            this.strGroupNumber = BaseLWC.helperBaseGetUrlParameters('groupNumber', strBaseCurrentTabUrl);
            //CEAS-85501
            let strIsFEP = BaseLWC.helperBaseGetUrlParameters('isLineOfBusinessFEP', strBaseCurrentTabUrl);
            if(strIsFEP && strIsFEP === 'true') {
                //Making View All Accordians Open
                this.allPhoneActiveSections = this.labels.MemberContactDetails_ViewAllPhone_ACE;
                this.allEmailActiveSections = this.labels.MemberContactDetails_ViewAllEmail_ACE;
            }

            let ws = BaseLWC.helperBaseGetUrlParameters('ws', strBaseCurrentTabUrl);
            if(ws && ws.includes('/')) {
                let allElements = ws.split("/");
                if(allElements && Array.isArray(allElements) && allElements.length > 4){
                    this.strAccountId = allElements[4];
                }
            }
            const localStorageKey = 'strInteractionLogIdForPlanSummaryStamp_' + this.strAccountId;
            this.strInteractionId = BaseLWC.helperBaseGetItem(localStorageKey);
            this.strSubId = BaseLWC.helperBaseGetUrlParameters("subscriberId", strBaseCurrentTabUrl);
            this.parentTabId = objTabData.parentTabId;
            this.planSummaryListener();
        }).catch((error) => {
            this.handleErrors(error);
            this.boolShowSpinner = false;
            this.boolSaveSpinner = false;
        });
        }
    }

    planSummaryListener() {
        if (this.parentTabId) {
            if (this.boolVPSTabSpecificEvents) {
                window.addEventListener(
                    'PlanSummaryEvent_' + this.parentTabId,
                    this.capturePlanSummaryListener
                );
            } else {
                window.addEventListener(
                    'PlanSummaryEvent',
                    this.capturePlanSummaryListener
                );
            }
            const strPlanSummaryEvent = 'PlanSummaryInteractionEvent_' + this.parentTabId;
            window.addEventListener(strPlanSummaryEvent, this.planSummaryInteractionEventListnerProcess);
        }
    }

    /**
     * Helps to Capture event and process it.
     */
    planSummaryInteractionEventListnerProcess = (objCommEvent) => {
        if (BaseLWC.isNotUndefinedOrNull(objCommEvent.detail) && typeof objCommEvent.detail === 'string') {
            const objLocalStorageData = JSON.parse(objCommEvent.detail);

            if (objLocalStorageData && objLocalStorageData.objParameters && objLocalStorageData.objParameters.objMessage) {
                let response = objLocalStorageData.objParameters.objMessage;
                const interactionId = response.interactionId;
                const strAccountIdFromEvent = response.strAccountIdForCTI;
                const strAccountIdForCTI = this.strAccountId;
                if (strAccountIdFromEvent === strAccountIdForCTI) {
                    if (interactionId) {
                        this.strInteractionId = interactionId;
                    }
                }
            }
        }
    }

     /**
      * Capture plan summary Information from Event.
      */
     capturePlanSummaryListener = (planSummaryDataEvent) => {
        try {

            if (
                BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail) &&
                typeof planSummaryDataEvent.detail === "string"
            ) {
                const planSummaryData = JSON.parse(planSummaryDataEvent.detail);
                //Check if the response in not null and if we are listening to event fired from Family Card and also if the message is not null.
                if (planSummaryData && planSummaryData.strIdDestination === "PlanCardDetails_ACE" && planSummaryData.objParameters 
                    && planSummaryData.objParameters.objMessage.objSelectedPlanDetails.strMemberId === this.strMID &&
                    planSummaryData.objParameters.strParentTabId === this.parentTabId){
                    const familyDetails = planSummaryData.objParameters.objMessage.lstFamilyDetails;
                        if(familyDetails && Array.isArray(familyDetails)){
                            for(let intFamilyMember = 0; intFamilyMember < familyDetails.length; ++intFamilyMember) {
                                this.lstFamilyMembers.push({
                                    label: familyDetails[intFamilyMember].strFirstName + ' ' +
                                        familyDetails[intFamilyMember].strLastName,
                                    value: familyDetails[intFamilyMember].strFirstName + ' ' +
                                        familyDetails[intFamilyMember].strLastName,
                                    title: familyDetails[intFamilyMember].strFirstName + ' ' +
                                        familyDetails[intFamilyMember].strLastName,
                                    selected: false
                                });
                            }
                        }
                         
                        this.objPlanDetails = planSummaryData.objParameters.objMessage.objSelectedPlanDetails;
                        if(this.objPlanDetails.boolIsAccountsAPICallAvailable) {
                            this.boolAccountsAPICallAvailable = this.objPlanDetails.boolIsAccountsAPICallAvailable;
                        }
                        if(this.objPlanDetails.boolIsCbcApiCallAvailable) {
                            this.boolCbcApiCallAvailable = this.objPlanDetails.boolIsCbcApiCallAvailable;
                        }
                        if(this.objPlanDetails) {
                            this.strClientMemberId = this.objPlanDetails.strClientMemberId;
                            this.strLineOfBusiness = this.objPlanDetails.strAceLineOfBusiness;
                            if(typeof this.strLineOfBusiness === 'string' && this.strLineOfBusiness.toUpperCase() === 'FEP') {
                                this.boolIsFEP = true;
                            }
                            this.boolAEP = this.objPlanDetails.boolGroupAEP;
                            this.strPolicyId = this.objPlanDetails.strPolicyId;
                            this.strSource = this.objPlanDetails.strSourceSystemName;
                            this.strMarketType = this.objPlanDetails.strMarketType;
                            this.strRelationshipTypeCode = this.objPlanDetails.strRelationshipTypeCode;
                            this.strEffectiveDate = this.objPlanDetails.strEffectiveDate;
                            this.strTerminationDate = this.objPlanDetails.strTerminationDate;
                            this.strGroupCostCenter = this.objPlanDetails.strGroupCostCenterNumber;
                            this.boolPerfGurantee = this.objPlanDetails.boolPgIndicator;
                            this.strAccInformation = this.objPlanDetails.strAccountNumber;
                            this.securedGroupNecessaryRole = this.objPlanDetails.securedGroupNecessaryRole;
                            this.strFamilyCaseNumber = this.objPlanDetails.strFamilyCaseNumber;
                            if(this.objPlanDetails.objViewEmployerGroupWrapper) {
                                this.strSectionNumber = this.objPlanDetails.objViewEmployerGroupWrapper.strGroupSectionNumber;
                            }
                            if(this.objPlanDetails.lstCoverageCodes) {
                                let lstAddOnServices = this.objPlanDetails.lstCoverageCodes;
                                const strPolicyStatus = this.objPlanDetails.strEnrollmentStatus;
                                if (lstAddOnServices) {
                                    this.strAddOnServices = "";
                                    for (let intCount = 0; intCount < lstAddOnServices.length; intCount++) {
                                        let codeDate = new Date(lstAddOnServices[intCount].strEffectiveEndDate);
                                        let CurrentDate = new Date();
                                        CurrentDate.setHours(0, 0, 0, 0);
                                        if (lstAddOnServices[intCount].strCode !== null && strPolicyStatus &&
                                            strPolicyStatus !== '' && strPolicyStatus.toUpperCase() !== 'INACTIVE' && codeDate >= CurrentDate) {
                                            if (this.strAddOnServices === "") {
                                                this.strAddOnServices = lstAddOnServices[intCount].strCode;
                                            } else {
                                                this.strAddOnServices = this.strAddOnServices + ',' + lstAddOnServices[intCount].strCode;
                                            }
                                        } else if (lstAddOnServices[intCount].strCode !== null && strPolicyStatus &&
                                            strPolicyStatus !== '' && strPolicyStatus.toUpperCase() === 'INACTIVE') {
                                            if (this.strAddOnServices === "") {
                                                this.strAddOnServices = lstAddOnServices[intCount].strCode;
                                            } else {
                                                this.strAddOnServices = this.strAddOnServices + ',' + lstAddOnServices[intCount].strCode;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                if (BaseLWC.isNotUndefinedOrNull(planSummaryData)) {
                    if (this.boolVPSTabSpecificEvents) {
                        window.removeEventListener(
                            'PlanSummaryEvent_' + this.parentTabId,
                            this.capturePlanSummaryListener
                        );
                    } else {
                        window.removeEventListener(
                            'PlanSummaryEvent',
                            this.capturePlanSummaryListener
                        );
                    }
                }
                this.fetchMemberContactDetails();
                
            }              
            }
        } catch(error) {
            this.handleErrors(error);
            this.boolShowSpinner = false;
            this.boolSaveSpinner = false;
        }

    };

    handleErrors = (error) => {
        this.objCatchError = error;
    };

    enableDisableButtons(){    
        if (this.strLineOfBusiness && this.strLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICAID') {
            this.boolPreferredText = false;
            this.isGovermentMedicade = true;
            // CEAS-74560 removed condition strCorpCode equals 'NM'
            this.isAlterNateFormatAvailable = true;
            if (this.strCorpCode && this.strCorpCode.startsWith('TX')) {
                this.govtMedicaidPhNo = false;
            } else {
                this.govtMedicaidPhNo = true;
            }
            this.writtenLanguageTexas();
        }

        if (this.strLineOfBusiness && this.strLineOfBusiness.toUpperCase() === 'RETAIL') {
            this.isSpokenLanguageVisible = false;
            this.retailSpokenLanguageMessage = true;
            if(this.strRelationshipTypeCode === 'SUB') {
                if (this.strSource === 'SYSTEM 80') {
                    //CEAS-52750
                    this.showPhoneEmailButton = true;
                    this.phoneButtonText = this.labels.MemberContactDetails_DocumentPhoneNumberButton_ACE;
                    this.emailButtonText = this.labels.MemberContactDetails_DocumentEmailAddressButton_ACE;
                    this.strPhoneInfoMessage = this.labels.MemberContactDetails_SYSTEM80_SUB_PhoneNumber_Message_ACE;
                    this.strEmailInfoMessage = this.labels.MemberContactDetails_SYSTEM80_SUB_Email_Message_ACE;
                }
                if (this.strMarketType === 'On-Exchange') {
                    //CEAS-52750
                    this.showPhoneEmailButton = true;
                    this.phoneButtonText = this.labels.MemberContactDetails_DocumentPhoneNumberButton_ACE;
                    this.emailButtonText = this.labels.MemberContactDetails_DocumentEmailAddressButton_ACE;
                    this.strPhoneInfoMessage = this.labels.MemberContactDetails_OnExchange_SUB_PhoneNumber_Message_ACE;
                    this.strEmailInfoMessage = this.labels.MemberContactDetails_OnExchange_SUB_Email_Message_ACE;
                }
                if (this.strMarketType === 'Off-Exchange') {
                    this.showPhoneEmailButton = true;
                }
            } else {
                this.showPhoneEmailButton = false;
                this.strPhoneInfoMessage = this.labels.MemberContactDetails_SUB_PhoneNumber_Message_ACE;
                this.strEmailInfoMessage = this.labels.MemberContactDetails_SUB_Email_Message_ACE;
            }
        } else {
            this.isRetailSpokenLanguageVisible = true;
        }

        if(this.strLineOfBusiness && this.strLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL'){
            this.writtenLanguageDisabled = true;
            this.preferedContactMethodDisabled = true;
        }
    }

    enableDisablePhoneEmailButton(objData){
        objData.updateError = '';
        objData.showEditInput = false;
        if(!this.userProfileIsReadOnly) {
            if(this.strLineOfBusiness && (this.strLineOfBusiness.toUpperCase() === this.labels.Government_Medicare_Label_ACE.toUpperCase() || this.strLineOfBusiness.toUpperCase() === 'GMS' || this.strLineOfBusiness.toUpperCase() === 'FEP')) {
                objData.showButton = true;
            } else if(this.strLineOfBusiness && this.strLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICAID' && this.strCorpCode) {
                objData.showButton = true;
            } else {
                objData.showButton = false;
            }
        } else {
            objData.showButton = false;
        }
    }

    fetchProfileName() {
        getUserProfile().then((strProfileData) => {
            if (strProfileData && this.labels.Read_Only_Profile.split(',').includes(strProfileData)) {
                this.userProfileIsReadOnly = true;
            } else {
                this.userProfileIsReadOnly = false;
            }
        }).catch((error) => {
            this.handleErrors(error);
            this.userProfileIsReadOnly = false;
        });
    }    

    fetchMemberContactDetails(){
        getMemberContactDetails({
            strMid: this.strMID,
            strGroupNumber:this.strGroupNumber,
            strCorpCode: this.strCorpCode,
            strLineOfBusiness: this.strLineOfBusiness})
        .then((memberContactData) => {
            this.apiMemberData = memberContactData;
            if(memberContactData) {
                this.populateDataFromResponse(memberContactData);
                this.enableDisableButtons();
                this.boolErrorFromIntegration = false;
            } else {
                this.boolErrorFromIntegration = true;
            }
            this.boolShowSpinner = false;
            this.boolSaveSpinner = false;
            })
        .catch((error) => {
            this.handleErrors(error);
            this.boolShowSpinner = false;
            this.boolSaveSpinner = false;
            this.boolErrorFromIntegration = true;
          });
    }

    populateDataFromResponse(objMemberContactDetailsWrapper) {
        if(objMemberContactDetailsWrapper) {
            if(this.strLineOfBusiness) {
                this.strLineOfBusiness = this.strLineOfBusiness.toUpperCase();
            }
            let mailingAddressDetails = objMemberContactDetailsWrapper.mailingAddress;
            if(mailingAddressDetails) {
                if(mailingAddressDetails.streetAddress) {
                    this.strAddressFirstLine = mailingAddressDetails.streetAddress;
                }
                this.strAddressSecondLine = '';
                if(mailingAddressDetails.city) {
                    this.strAddressSecondLine += mailingAddressDetails.city +
                        this.constants.STRING_MEMBER_CONTACT_DETAILS_SEPARATOR_AFTER_SPACE;
                }
                if(mailingAddressDetails.state) {
                    this.strAddressSecondLine += mailingAddressDetails.state +
                        this.constants.STRING_MEMBER_CONTACT_DETAILS_SEPARATOR_AFTER_SPACE;
                }
                if(mailingAddressDetails.zipCode) {
                    this.strAddressSecondLine += mailingAddressDetails.zipCode;
                }                    
            }
            let strPhysicalAddress = objMemberContactDetailsWrapper.physicalAddress;
            if(strPhysicalAddress) {
                if(strPhysicalAddress.streetAddress) {
                    this.strPhysicalAddressFirstLine = strPhysicalAddress.streetAddress;
                }
                this.strPhysicalAddressSecondLine = '';
                if(strPhysicalAddress.city) {
                    this.strPhysicalAddressSecondLine += strPhysicalAddress.city +
                        this.constants.STRING_MEMBER_CONTACT_DETAILS_SEPARATOR_AFTER_SPACE;
                }
                if(strPhysicalAddress.state) {
                    this.strPhysicalAddressSecondLine += strPhysicalAddress.state +
                        this.constants.STRING_MEMBER_CONTACT_DETAILS_SEPARATOR_AFTER_SPACE;
                }
                if(strPhysicalAddress.zipCode) {
                    this.strPhysicalAddressSecondLine += strPhysicalAddress.zipCode;
                }
            }
            if(objMemberContactDetailsWrapper.lstPhone) {
                this.lstPhone = objMemberContactDetailsWrapper.lstPhone;
                if(this.lstPhone && Array.isArray(this.lstPhone)){
                    this.sortPhoneAscending = false;
                    this.sortPhoneData();
                    for (let i = 0; i < this.lstPhone.length; i++) {
                        this.lstPhone[i].index = i;
                        this.enableDisablePhoneEmailButton(this.lstPhone[i]);
                        if(!(this.lstPhone[i].strPhone === '' && this.lstPhone[i].boolPreferredVoicemail)) {
                            this.lstPhone[i].hasPreferredVoicemailAndPhone = true;
                        } else {
                            this.lstPhone[i].hasPreferredVoicemailAndPhone = false;
                        }
                        if(!(this.lstPhone[i].strPhone === '' && this.lstPhone[i].boolPreferredPhone)) {
                            this.lstPhone[i].hasPreferredPhoneNum = true;
                        } else {
                            this.lstPhone[i].hasPreferredPhoneNum = false;
                        }
                      }
                }
            }
            if(objMemberContactDetailsWrapper.lstEmail) {
                this.lstEmail = objMemberContactDetailsWrapper.lstEmail;
                if(this.lstEmail && Array.isArray(this.lstEmail)){
                    this.sortEmailAscending = false;
                    this.sortEmailData();
                    for (let i = 0; i < this.lstEmail.length; i++) {
                        this.lstEmail[i].index = i;
                        this.enableDisablePhoneEmailButton(this.lstEmail[i]);
                        if(this.lstEmail[i].strEmail !== '') {
                            this.lstEmail[i].hasEmail = true;
                        } else {
                            this.lstEmail[i].hasEmail = false;
                        }
                      }
                }
            }
            if(objMemberContactDetailsWrapper.objContactDay) {
                this.objContactDay = objMemberContactDetailsWrapper.objContactDay;
                this.objContactDayAutoDoc = JSON.stringify(this.objContactDay);
            }
            if(objMemberContactDetailsWrapper.objContact) {
                this.objContact = objMemberContactDetailsWrapper.objContact;
                this.objContactAutoDoc = JSON.stringify(this.objContact);
                if(this.objContact.Timezone__c){
                    this.objContact.Timezone__c = this.objContact.Timezone__c.toUpperCase();
                }
            }
            if(objMemberContactDetailsWrapper.strPreferredPhone) {
                this.strPreferredPhone = objMemberContactDetailsWrapper.strPreferredPhone;
            }
            if(objMemberContactDetailsWrapper.strPreferredTextPhone) {
                this.strPreferredTextPhone = objMemberContactDetailsWrapper.strPreferredTextPhone;
            }
            if(objMemberContactDetailsWrapper.strPreferredEmail) {
                this.strPreferredEmail = objMemberContactDetailsWrapper.strPreferredEmail;
            }
            if(objMemberContactDetailsWrapper.strAlternateFormat) {
                this.strAlternateFormat = objMemberContactDetailsWrapper.strAlternateFormat;
            }
            if(objMemberContactDetailsWrapper.strCaseFieldsValue) {
                this.strCaseDefaultValues = objMemberContactDetailsWrapper.strCaseFieldsValue;
            }
        }
    }

    showEditPhonebox(event) {
        let phoneData = this.respectivePhoneData(event.target.getAttribute('data-id'));
        if(phoneData) {
            phoneData.showButton = false;
            phoneData.showEditInput = true;
        }
    }

    showEditEmailbox(event){
        let emailData = this.respectiveEmailData(event.target.getAttribute('data-id'));
        if(emailData) {
            emailData.showButton = false;
            emailData.showEditInput = true;
        }
    }

    respectiveEmailData(index) {
        if(index){
            index = Number(index);
        }
        for (let i = 0; i < this.lstEmail.length; i++) {
            if(this.lstEmail[i].index === index){
                return this.lstEmail[i];
            }
        }
        return null;
    }

    respectivePhoneData(index) {
        if(index){
            index = Number(index);
        }
        for (let i = 0; i < this.lstPhone.length; i++) {
            if(this.lstPhone[i].index === index) {
                return this.lstPhone[i];
            }
        }
        return null;
    }

    selectContactDay(event) {
        let selectedElement = event.target.getAttribute("data-id");
        if(selectedElement === 'idMonDay') {
            this.objContactDay = {
                boolMonday: event.detail.checked,
                boolTuesday: false,
                boolWednesday: false,
                boolThursday: false,
                boolFriday: false
            };
        } else if(selectedElement === 'idTuesDay') {
            this.objContactDay = {
                boolMonday: false,
                boolTuesday: event.detail.checked,
                boolWednesday: false,
                boolThursday: false,
                boolFriday: false
            };
        } else if(selectedElement === 'idWednesDay') {
            this.objContactDay = {
                boolMonday: false,
                boolTuesday: false,
                boolWednesday: event.detail.checked,
                boolThursday: false,
                boolFriday: false
            };
        } else if(selectedElement === 'idThursDay') {
            this.objContactDay = {
                boolMonday: false,
                boolTuesday: false,
                boolWednesday: false,
                boolThursday: event.detail.checked,
                boolFriday: false
            };
        } else if(selectedElement === 'idFriDay') {
            this.objContactDay = {
                boolMonday: false,
                boolTuesday: false,
                boolWednesday: false,
                boolThursday: false,
                boolFriday: event.detail.checked
            };
        }
    }

    updatePhone(event) {
        fetchCaseRuleForPhoneAndEmail({strLob: 'RETAIL'}).then((caseRuleValue)=>{
            this.openCaseCreationSubtabForPhone(caseRuleValue);
        }).catch((error)=>{
            this.handleErrors(error);
            this.updatePhoneError = true;
            this.strPhoneInfoMessage = error;
        });
    }

    updateEmail(event) {
        fetchCaseRuleForPhoneAndEmail({strLob: 'RETAIL'}).then((caseRuleValue)=>{
            this.openCaseCreationSubtabForEmail(caseRuleValue);
        }).catch((error)=>{
            this.handleErrors(error);
            this.updateEmailError = true;
            this.strEmailInfoMessage = error;
        });
    }

    MCPUpdatePhone(event) {
        let strPhone = event.target.value;
        let phoneData = this.respectivePhoneData(event.target.getAttribute('data-id'));
        const boolValidPhone = this.validatePhoneNumber(strPhone);
    
        if (boolValidPhone) {
            let oldPhone = phoneData.strPhone;
            let boolVoice1; 
            let boolText1;
    
            if(phoneData) {
                boolVoice1 = phoneData.boolPreferredVoicemail;
                boolText1 = phoneData.boolPreferredPhone;
            } else {
                boolVoice1 = true;
                boolText1 = true;
            }
            phoneData.strPhone = strPhone;
            phoneData.updateError = '';
            phoneData.showButton = true;
            phoneData.showEditInput = false;
            //showToast(2000, $Label.MemberContactDetails_SuccessMessage_ACE, intAlertTypeSuccess, strAlertPositionCustom, 'right: 10%; bottom: 60%; z-index: 999;');
            const phoneSMSJSONStr = this.createPhoneSMSJSON(this.objContact.Permission_to_Leave_Voicemail__c, strPhone, boolVoice1, boolText1);
            if (boolVoice1 === true && phoneSMSJSONStr !== '') {
                this.savePhoneData(phoneSMSJSONStr, '', phoneData);
            }
            if (boolText1 === true && phoneSMSJSONStr !== '') {
                this.savePhoneData('', phoneSMSJSONStr, phoneData);
            }
            this.callAutoDocFromPhone(oldPhone, boolVoice1, boolText1, strPhone);
        } else {
            if(phoneData){
                phoneData.strPhone = strPhone;
                phoneData.updateError = this.labels.MemberContactDetails_PhoneInvalidMessage_ACE;
                event.target.style.borderColor = "red";
            }
        }
    }

    MCPUpdateEmail(event) {
        const strEmail = event.target.value;
        let emailData = this.respectiveEmailData(event.target.getAttribute('data-id'));
        const boolValidEmail = this.validateEmail(strEmail);
        if (boolValidEmail) {
            let oldEmail = emailData.strEmail;
            emailData.strEmail = strEmail;
            emailData.updateError = '';
            emailData.showButton = true;
            emailData.showEditInput = false;
            const strEmailJson = this.createEmailJSON(strEmail);
            this.saveEmailData(strEmailJson, emailData);
            this.callAutoDocFromEmail(oldEmail,  emailData.boolPreferred, strEmail);
        } else {
            if(emailData){
                emailData.updateError = this.labels.MemberContactDetails_EmailInvalidMessage_ACE;
                emailData.strEmail = strEmail;
                event.target.style.borderColor = "red";
            }
        }
    }


    sortPhoneData() {
        if(!this.userProfileIsReadOnly && Array.isArray(this.lstPhone) && this.lstPhone.length > 1) {
            this.sortPhoneAscending = !this.sortPhoneAscending;
            this.lstPhone = this.lstPhone.sort(
                (p1, p2) => (p1.strPhone < p2.strPhone) ? (this.sortPhoneAscending ? -1 : 1) : (p1.strPhone > p2.strPhone) ? (this.sortPhoneAscending ? 1 : -1) : 0);
            this.barPhoneColor = this.sortPhoneAscending ? 'barColor' : 'barColor mirrorImage';
        }    
    }

    sortEmailData() {
        if(!this.userProfileIsReadOnly && Array.isArray(this.lstEmail) && this.lstEmail.length > 1) {
            this.sortEmailAscending = !this.sortEmailAscending;
            this.lstEmail = this.lstEmail.sort(
                (p1, p2) => (p1.strEmail < p2.strEmail) ? (this.sortEmailAscending ? -1 : 1) : (p1.strEmail > p2.strEmail) ? (this.sortEmailAscending ? 1 : -1) : 0);
            this.barEmailColor = this.sortEmailAscending ? 'barColor' : 'barColor mirrorImage';
        }
    }

    // To validate Email format
    validateEmail(email) {
        let re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    createEmailJSON(emailVal) {
        let jsonEmailStr = '';
        if (emailVal) {
            jsonEmailStr = '"email": { "emailAddress": "' + emailVal + '",' + '"sourceSystem": "' + this.labels.MemberContactDetails_SourceSystem_ACE + '"}';
        }
        return jsonEmailStr;
    }

    saveEmailData(strEmailJson, emailData) {
        this.boolSaveSpinner = true;
        saveMemberContactDetails({
            strMid: this.strMID, 
            strGroupNumber:this.strGroupNumber, 
            strCorpCode: this.strCorpCode, 
            strLineOfBusiness: this.strLineOfBusiness,
            strListPhone: '',
            strListPhoneText: '',
            strListEmail: strEmailJson,
            strContactDays: '',
            strAlternateFormat: this.strAlternateFormat,
            strContactObj: JSON.stringify(this.objContact),
            apiMemberData: JSON.stringify(this.apiMemberData),
            boolNumberUpdate: true
        })
        .then((success) => {
            this.handleRefresh();
            if(!this.strInteractionId){
            this.showToast();
            }
          })
        .catch((error) => {
            this.handleErrors(error);
            emailData.updateError = error;
            this.boolSaveSpinner = false;
        });
    }

    savePhoneData(strListPhone, strListPhoneText, phoneData) {
        this.boolSaveSpinner = true;
        saveMemberContactDetails({
            strMid: this.strMID, 
            strGroupNumber:this.strGroupNumber, 
            strCorpCode: this.strCorpCode, 
            strLineOfBusiness: this.strLineOfBusiness,
            strListPhone: strListPhone,
            strListPhoneText: strListPhoneText,
            strListEmail: '',
            strContactDays: '',
            strAlternateFormat: this.strAlternateFormat,
            strContactObj: JSON.stringify(this.objContact),
            apiMemberData: JSON.stringify(this.apiMemberData),
            boolNumberUpdate: true
        })
        .then((success) => {
            this.handleRefresh();
            if(!this.strInteractionId){
            this.showToast();
            }
          })
        .catch((error) => {
            this.handleErrors(error);
            phoneData.updateError = error;
            this.boolSaveSpinner = false;
        });
    }
    
    createPhoneSMSJSON(strPermissionToLeaveVoiceMails, strPhone1, boolVoice, boolText) {
        let phoneSMSJSON;
        let boolPermission;
        if (strPermissionToLeaveVoiceMails === "Yes") {
            boolPermission = true;
        } else {
            boolPermission = false;
        }
        
        if (strPhone1 !== '') {
            strPhone1 = strPhone1.replace(/[)(-\s]/g, '');
        }
   
        if (boolVoice === true && strPhone1 !== '') {
            phoneSMSJSON = '"phone": {"number": "' + strPhone1 + '",' + '"sourceSystem": "' + this.labels.MemberContactDetails_SourceSystem_ACE + '",' +
                '"boolPreferredVoicemail": ' + boolVoice + ',' + '"leaveMessage": ' + boolPermission + '}';
        }
        if (boolText === true && strPhone1 !== '') {
            phoneSMSJSON = '"sms": {"number": "' + strPhone1 + '",' + '"sourceSystem": "' + this.labels.MemberContactDetails_SourceSystem_ACE + '",' +
                '"verificationStatus" : "CONFIRMED_CELL"}';
        }
        return phoneSMSJSON;
    }

    validatePhoneNumber(phoneNumber) {
        let phoneNumberPattern = /^\(?(\d{3})\)?[\s]?(\d{3})[- ]?(\d{4})$/;
        return phoneNumberPattern.test(phoneNumber);
    }

    handleContactMethod(event) {
        this.objContact.Prefered_Contact_Method__c = event.detail.value;
    }

    handleTimeZone(event) {
        this.objContact.Timezone__c = event.detail.value;
    }

    handlePreferredContactTime(event) {
        this.objContact.Preferred_Contact_Time__c = event.detail.value;
    }

    handlePermissionToLeaveVoiceMailOptions(event) {
        this.objContact.Permission_to_Leave_Voicemail__c = event.detail.value;
    }

    handlePhoneSectionToggle(event) {
        this.allPhoneActiveSections = event.detail.openSections;
    }

    handleEmailSectionToggle(event) {
        this.allEmailActiveSections = event.detail.openSections;
    }

    handleRefresh(event) {
        this.saveAPIError = '';
        this.boolSaveSpinner = true;
        this.boolErrorFromIntegration = false;
        this.updatePhoneError = false;
        this.updateEmailError = false;
        //CEAS-85501
        if(this.boolIsFEP) {
            this.allPhoneActiveSections = this.labels.MemberContactDetails_ViewAllPhone_ACE;
            this.allEmailActiveSections = this.labels.MemberContactDetails_ViewAllEmail_ACE;
        } else {
        this.allPhoneActiveSections = [];
        this.allEmailActiveSections = [];
        }
        this.fetchMemberContactDetails();
    }

    updateAddress(event) {
        let strLob = this.strLineOfBusiness.toUpperCase();
        if (strLob === 'GOVERNMENT' || strLob === 'GMS' || strLob === 'RETAIL' || strLob === 'GOVERNMENT-MEDICARE') {
            this.fetchCaseRuleForAddress(strLob);
        } else if (strLob === 'GOVERNMENT-MEDICAID' || strLob === 'GOVERNMENT-MEDICARE SUPPLEMENTAL') {//CEAS-71052
            this.strLineOfBusiness = strLob;
            this.boolNMCCAddressChangeModal = true;
        } else {
            // Do Nothing
        }
    }

    fetchCaseRuleForAddress(strLob){
        fetchCaseRuleForAddressApex({strLob: strLob}).then((caseRuleValue)=>{
            this.openCaseCreationSubtabForAddress(caseRuleValue);
        }).catch((error)=>{
            this.handleErrors(error);
        });
    }

    openCaseCreationSubtabForEmail(caseRuleValue) {
        if (this.strCaseDefaultValues) {
            let objCaseDefault = JSON.parse(this.strCaseDefaultValues);
            objCaseDefault.ApplicableTo_ACE__c = this.lstFamilyMembers;
            objCaseDefault.AEPIndicator_ACE__c = this.boolAEP;
            objCaseDefault.Subject = this.labels.MemberContactDetail_AEPSubject_ACE;
            objCaseDefault.RedirectedtoEmployer_ACE__c = true;
            objCaseDefault.Status = this.labels.CreateCasePage_Closed_ACE;
        }
        if (caseRuleValue) {
            let objCaseRuleDefault = JSON.parse(caseRuleValue);
            objCaseRuleDefault.ApplicableTo_ACE__c = this.lstFamilyMembers;
            objCaseRuleDefault.AEPIndicator_ACE__c = this.boolAEP;
            objCaseRuleDefault.Subject = 'Member Management - Communication Preferences';
            objCaseRuleDefault.RedirectedtoEmployer_ACE__c = true;
            objCaseRuleDefault.Status = this.labels.CreateCasePage_Closed_ACE;
            objCaseRuleDefault.New_Phone_Number_ACE__c = this.strPreferredPhone;
            this.strCaseDefaultValues = JSON.stringify(objCaseRuleDefault);
        }
        let strAction = this.emailButtonText;
        let objResponse = {
            strIdDestination: 'OpenCaseCreatePage_' + this.strMID,
            objParameters: {
                strCaseRuleDetails: this.strCaseDefaultValues,
                strPolicyId: this.strPolicyId,
                strEffectiveDate: this.strEffectiveDate,
                strTerminationDate: this.strTerminationDate,
                strCodes: this.strAddOnServices,
                strGroupCostCenter: this.strGroupCostCenter,
                strAction: strAction
            }
        };
        this.openCaseModel(objResponse);
    }

    openCaseCreationSubtabForPhone(caseRuleValue) {
        if (this.strCaseDefaultValues) {
            let objCaseDefault = JSON.parse(this.strCaseDefaultValues);
            objCaseDefault.ApplicableTo_ACE__c = this.lstFamilyMembers;
            objCaseDefault.AEPIndicator_ACE__c = this.boolAEP;
            objCaseDefault.Subject = this.labels.MemberContactDetail_AEPSubject_ACE;
            objCaseDefault.RedirectedtoEmployer_ACE__c = true;
            objCaseDefault.Status = this.labels.CreateCasePage_Closed_ACE;   
        }
        if (caseRuleValue) {
            let objCaseRuleDefault = JSON.parse(caseRuleValue);
            objCaseRuleDefault.ApplicableTo_ACE__c = this.lstFamilyMembers;
            objCaseRuleDefault.AEPIndicator_ACE__c = this.boolAEP;
            objCaseRuleDefault.Subject = 'Member Management - Communication Preferences';
            objCaseRuleDefault.RedirectedtoEmployer_ACE__c = true;
            objCaseRuleDefault.Status = this.labels.CreateCasePage_Closed_ACE;
            this.strCaseDefaultValues = JSON.stringify(objCaseRuleDefault);
        }
        //ceas-52750
        let strAction = this.phoneButtonText;
        let objResponse = {
            strIdDestination: 'OpenCaseCreatePage_' + this.strMID,
            objParameters: {
                strCaseRuleDetails: this.strCaseDefaultValues,
                strPolicyId: this.strPolicyId,
                strEffectiveDate: this.strEffectiveDate,
                strTerminationDate: this.strTerminationDate,
                strCodes: this.strAddOnServices,
                strGroupCostCenter: this.strGroupCostCenter,
                strAction: strAction
            }
        };
        this.openCaseModel(objResponse);
    }

    openCaseCreationSubtabForAddress(caseRuleValue) {
        let strLob = this.strLineOfBusiness.toUpperCase();
        if (this.strCaseDefaultValues) {
            let objCaseDefault = JSON.parse(this.strCaseDefaultValues);
            objCaseDefault.ApplicableTo_ACE__c = this.lstFamilyMembers;
            if (this.boolAEP) {
                objCaseDefault.AEPIndicator_ACE__c = this.boolAEP;
                objCaseDefault.Subject = this.labels.MemberContactDetail_AEPSubject_ACE;
                objCaseDefault.RedirectedtoEmployer_ACE__c = true;
                objCaseDefault.Status = this.labels.CreateCasePage_Closed_ACE;
            } else {
                objCaseDefault.AEPIndicator_ACE__c = this.boolAEP;
            }
            if (caseRuleValue) {
                let objCaseRuleDefault = JSON.parse(caseRuleValue);
                objCaseRuleDefault.ApplicableTo_ACE__c = this.lstFamilyMembers;
                objCaseRuleDefault.AEPIndicator_ACE__c = this.boolAEP;
                objCaseRuleDefault.Sub_Status_ACE__c = objCaseDefault.Sub_Status_ACE__c;
                objCaseRuleDefault.Origin = objCaseDefault.Origin;
                if (!this.boolAEP && strLob !== 'GOVERNMENT-MEDICARE') { //CEAS-62197
                    objCaseRuleDefault.CurrentAddress_ACE__c = objCaseDefault.CurrentAddress_ACE__c;
                    objCaseRuleDefault.CurrentCity_ACE__c = objCaseDefault.CurrentCity_ACE__c;
                    objCaseRuleDefault.CurrentState_ACE__c = objCaseDefault.CurrentState_ACE__c;
                    objCaseRuleDefault.CurrentZipCode_ACE__c = objCaseDefault.CurrentZipCode_ACE__c;
                }
                if(strLob === 'GOVERNMENT-MEDICARE') {//CEAS-62197
                    objCaseRuleDefault.Address_to_Change_ACE__c = '';
                    objCaseRuleDefault.Current_Mailing_Address_ACE__c = objCaseDefault.CurrentAddress_ACE__c;
                    objCaseRuleDefault.CurrentCity_ACE__c = objCaseDefault.CurrentCity_ACE__c;
                    objCaseRuleDefault.CurrentState_ACE__c = objCaseDefault.CurrentState_ACE__c;
                    objCaseRuleDefault.CurrentZipCode_ACE__c = objCaseDefault.CurrentZipCode_ACE__c;
                }
   
               //  CEAS-69293 code starts
               if(strLob === 'GOVERNMENT-MEDICAID') {
                   objCaseRuleDefault.ActionTaken_ACE__c = 'Update';
                   objCaseRuleDefault.Address_to_Change_ACE__c = 'Physical and Mailing';
                   objCaseRuleDefault.CurrentCity_ACE__c = objCaseDefault.CurrentCity_ACE__c;
                   objCaseRuleDefault.CurrentState_ACE__c = objCaseDefault.CurrentState_ACE__c;
                   objCaseRuleDefault.CurrentZipCode_ACE__c = objCaseDefault.CurrentZipCode_ACE__c;
               }
               //  CEAS-69293 code end
                
                objCaseRuleDefault.Subject = 'Member Management - Address Change';
                objCaseRuleDefault.RedirectedtoEmployer_ACE__c = true;
                objCaseRuleDefault.Status = this.labels.CreateCasePage_Closed_ACE;
                objCaseRuleDefault.Line_of_business_ACE__c = strLob;
                this.strCaseDefaultValues = JSON.stringify(objCaseRuleDefault);
            }
        }
        let objResponse = {
            strIdDestination: 'OpenCaseCreatePage_' + this.strMID,
            objParameters: {
                strCaseRuleDetails: this.strCaseDefaultValues,
                strPolicyId: this.strPolicyId,
                strEffectiveDate: this.strEffectiveDate,
                strTerminationDate: this.strTerminationDate,
                strCodes: this.strAddOnServices,
                strGroupCostCenter: this.strGroupCostCenter
            }
        };
        // CEAS-69293: Updated condition to support for NMCC
        if (!this.boolAEP && strLob !== 'GOVERNMENT' && strLob !== 'GOVERNMENT-MEDICARE' && strLob !== 'GOVERNMENT-MEDICAID') {
            objResponse['strEventName'] = 'OpenLWCModal_' + this.strMID;
        }
        this.openCaseModel(objResponse);
    }

    openCaseModel(objResponse){
        if (objResponse.strEventName === undefined) {
            let strCaseDefaults = JSON.parse(objResponse.objParameters.strCaseRuleDetails);
            strCaseDefaults['SubscriberID_ACE__c'] = this.strSubId;
            strCaseDefaults['GroupNumber_ACE__c'] = this.strGroupNumber;
            strCaseDefaults['CorporationCode_ACE__c'] = this.strCorpCode;
            strCaseDefaults['Policy_ID_ACE__c'] = objResponse.objParameters.strPolicyId;
            strCaseDefaults['Plan_Effective_Date_ACE__c'] = objResponse.objParameters.strEffectiveDate;
            strCaseDefaults['Plan_Termination_Date_ACE__c'] = objResponse.objParameters.strTerminationDate;
            strCaseDefaults['CMID_ACE__c'] = this.strClientMemberId;
            strCaseDefaults['AddonServices_ACE__c'] = objResponse.objParameters.strCodes;
            strCaseDefaults['GroupCostCenter_ACE__c'] = objResponse.objParameters.strGroupCostCenter;
            strCaseDefaults['strAction'] = objResponse.objParameters.strAction;//CEAS-52750
            strCaseDefaults = JSON.stringify(strCaseDefaults);
            const objMidPlanId = {
                strPlanId: objResponse.objParameters.strPolicyId,
                strMid: this.strAccountId
            };
            this.postMessageToDynamicCasePage(objMidPlanId, strCaseDefaults, null, 'CaseDefaultsOnDynamicCaseCreation');
        } else if(objResponse.strEventName) {
            this.lwcControllerData = JSON.stringify(objResponse);
            this.openLWCModel = true;
        } else {
            //Do Nothing
        }
    }

    closeLWCModel() {
        this.openLWCModel = false;
    }

    openCasePageFromModel(event){
        this.openLWCModel = false;
        if(event.detail) {
            const objControllerResult = JSON.parse(event.detail)
            let strCaseDefaults = JSON.parse(objControllerResult.objParameters.strCaseRuleDetails);
            strCaseDefaults['SubscriberID_ACE__c'] = this.strSubId;
            strCaseDefaults['GroupNumber_ACE__c'] = this.strGroupNumber;
            strCaseDefaults['CorporationCode_ACE__c'] = this.strCorpCode;
            strCaseDefaults['Policy_ID_ACE__c'] = objControllerResult.objParameters.strPolicyId;
            strCaseDefaults['Plan_Effective_Date_ACE__c'] = objControllerResult.objParameters.strEffectiveDate;
            strCaseDefaults['Plan_Termination_Date_ACE__c'] = objControllerResult.objParameters.strTerminationDate;
            strCaseDefaults['CMID_ACE__c'] = this.strClientMemberId;
            strCaseDefaults['AddonServices_ACE__c'] = objControllerResult.objParameters.strCodes;
            strCaseDefaults['GroupCostCenter_ACE__c'] = objControllerResult.objParameters.strGroupCostCenter;
            strCaseDefaults['strAction'] = objControllerResult.objParameters.strAction;//CEAS-52750
            strCaseDefaults = JSON.stringify(strCaseDefaults);
            const objMidPlanId = {
                strPlanId: objControllerResult.objParameters.strPolicyId,
                strMid: this.strAccountId
            };
            this.postMessageToDynamicCasePage(objMidPlanId, strCaseDefaults,null,'CaseDefaultsOnDynamicCaseCreation');
        }
    }
    
    postMessageToDynamicCasePage(objMidPlanId, strCaseDefaultsJSON, objParametersToBeSent, strDestinationId) {
        const encodedURLParams = BaseLWC.helperBaseEncodeUrl('?Dynamic=true' + '&timeInMillis=' + Date.now());
        const strURL = '/lightning/n/Manual_Case_Create_ACE' + encodedURLParams;
        const strMemberId = objMidPlanId.strMid;
        openSubtab(this.objTabData.parentTabId,{ url: strURL, focus: true })
            .then((subTabId) => {
                getTabInfo(subTabId)
                    .then(function (objEnclosedTabInfo) {
                        if (objEnclosedTabInfo !== undefined && objEnclosedTabInfo !== null && objEnclosedTabInfo !== false) {

                            const strWsUrl = BaseLWC.helperBaseGetUrlParameters('ws', objEnclosedTabInfo.url);
                            let strAccountId = null;
                            if (strWsUrl !== undefined && strWsUrl !== null) {
                                try {
                                    strAccountId = strWsUrl.split('/')[4];
                                } catch(objError) {
                                    this.handleErrors(objError);
                                }
                            }
                            if (strAccountId === undefined || strAccountId === null || strAccountId === '') {
                                try {
                                    const checkURL = new URL(decodeURIComponent(objEnclosedTabInfo.url));
                                    strAccountId = checkURL.searchParams.get('ws').split('/')[4];
                                } catch(error) {
                                    this.handleErrors(error);
                                }
                            }

                            // Account id if the tab is not focused.
                            if (strAccountId === undefined || strAccountId === null || strAccountId === '') {
                                try {
                                    const checkURLAgain = new URL(decodeURIComponent(objEnclosedTabInfo.url));
                                    strAccountId = checkURLAgain.href.split('/')[6];
                                } catch(error) {
                                    this.handleErrors(error);
                                }
                            }
                            let intCaseIntervalCounter = 0;
                            const objErrorData = {};
                            objErrorData.strComponentName = 'BaseLightningComponent_ACE';
                            objErrorData.strMessage = 'SetIntervals';
                            objErrorData.strFunctionName = 'helperBasePostMessage';
                            objErrorData.strStackTrace = 'MaxIntervalReached;\nClearedInterval;\n';
                            objErrorData.strError = 'IframeId Not Found: ' + 'idCreateNewCaseLightningComponent_' + strAccountId;
                            //Check DOM's dataIsLoaded attribute in Interval of 1 second
                            const postMessageFunction = setInterval(function () {
                                try {
                                    intCaseIntervalCounter++;
                                    const strDynamicCasePage = document.getElementById('idCreateNewCaseLightningComponent_' + strAccountId);
                                    if (strDynamicCasePage !== undefined && strDynamicCasePage !== null && strDynamicCasePage.dataIsLoaded === 1) {
                                        clearInterval(postMessageFunction);
                                        postDataToCasePage(strMemberId);
                                    }
                                    const intMultiplier = 1;
                                    //objHelper.clearLoopedIntervalsInBase(objComponent, objHelper, intCaseIntervalCounter, intMultiplier ,
                                    //postMessageFunction, objErrorData);
                                } catch(objException) {
                                    clearInterval(postMessageFunction);
                                    this.handleErrors(objException);
                                }
                            }, 1000);

                            //Function to POst the message.
                            function postDataToCasePage(strMemId) {
                                const objCaseCreateFrame = document.getElementById('idCreateNewCaseLightningComponent_' + strAccountId).contentWindow;
                                if (strCaseDefaultsJSON) {
                                    const objResponse = {
                                        strIdDestination: strDestinationId,
                                        objParameters: {
                                            caseRuleId: JSON.parse(strCaseDefaultsJSON).Id,
                                            strMid: strMemId,
                                            strPlanId: objMidPlanId.strPlanId,
                                            caseObject: JSON.parse(strCaseDefaultsJSON)
                                        }
                                    };
                                    objCaseCreateFrame.postMessage(JSON.stringify(objResponse), '*');
                                } else {
                                    objCaseCreateFrame.postMessage(JSON.stringify(objParametersToBeSent), '*');
                                }
                            }
                        }
                    })
                    .catch(function (error) {
                        // Do nothing
                        this.handleErrors(error);
                    });
            })
            .catch(function (error) {
                // Do nothing
                this.handleErrors(error);
            });
    }
    postMemberContactDetails(event) {
        //Check Phone and Email Validations
        let strPhoneValidation = this.phoneValidation();
        let strEmailValidation = this.emailValidation();
        this.saveAPIError = '';
        if(strPhoneValidation !== '' || strEmailValidation !== '') {
            const event = new ShowToastEvent({
                variant: 'error',
                message: strPhoneValidation + ' ' + strEmailValidation,
                title: ''
            });
            this.dispatchEvent(event);
        } else {
            this.boolSaveSpinner = true;
            let strContactDays = '';

            if(this.objContactDay.boolMonday) {
                strContactDays = "MONDAY";
            }
            if(this.objContactDay.boolTuesday) {
                if(strContactDays !== '') {
                    strContactDays = strContactDays + "," + "TUESDAY";
                } else {
                    strContactDays = "TUESDAY";
                }
            }
            if(this.objContactDay.boolWednesday) {
                if (strContactDays !== '') {
                     strContactDays = strContactDays + "," + "WEDNESDAY";
                } else {
                     strContactDays = "WEDNESDAY";
                }
            }
            if (this.objContactDay.boolThursday) {
                if (strContactDays !== '') {
                    strContactDays = strContactDays + "," + "THURSDAY";
                } else {
                    strContactDays = "THURSDAY";
                }
             }
            if (this.objContactDay.boolFriday) {
                if (strContactDays !== '') {
                    strContactDays = strContactDays + "," + "FRIDAY";
                } else {
                    strContactDays = "FRIDAY";
                }
            }

            saveMemberContactDetails({
                strMid: this.strMID, 
                strGroupNumber:this.strGroupNumber, 
                strCorpCode: this.strCorpCode, 
                strLineOfBusiness: this.strLineOfBusiness,
                strListPhone: '',
                strListPhoneText: '',
                strListEmail: '',
                strContactDays: strContactDays,
                strAlternateFormat: this.strAlternateFormat,
                strContactObj: JSON.stringify(this.objContact),
                apiMemberData: JSON.stringify(this.apiMemberData),
                boolNumberUpdate: false
            }).then((success) => {
                this.handleRefresh();
                if(!this.strInteractionId){
                this.showToast();
                }
            })
            .catch((error) => {
                this.handleErrors(error);
                this.boolSaveSpinner = false;
                this.saveAPIError = error.body.message;
            });

            this.callAutoDocFromSave();
        }
    }

    callAutoDocFromPhone(oldPhone, boolVoice, boolText, newPhone) {
        let lstPhoneValues = '';
        let lstValuesPhoneAry = [];
        let boolPhoneVoiceAutodoc = false;
        let boolPhoneTextAutodoc = false;
        if(oldPhone) {
            oldPhone = oldPhone.replace(/[)(-\s]/g, '');
        }
        if(newPhone) {
            newPhone = newPhone.replace(/[)(-\s]/g, '');
        }
        let formatted_date = BaseLWC.currentDateFormat(); 
        this.strIntialNotes = 'Created on '+formatted_date+'\n\n'+'COMMUNICATION PREFERENCES'+'\n\n'+'\tMember Contacts'+'\n\n' +'\t\t Phone Number'+'\n\t\t\t'
        if(boolVoice) {
            if(oldPhone) {
                lstPhoneValues = '{' + '"strFieldLabel":' + '"PREFERRED PHONE VOICE OLD"' + ',' + '"strFieldValue":' + '"' + oldPhone + '"' + '},' +
                    '{' + '"strFieldLabel":' + '"PREFERRED PHONE VOICE NEW"' + ',' + '"strFieldValue":' + '"' + newPhone + '"' + '}';
                this.strIntialNotes = this.strIntialNotes + 'PREFERRED PHONE VOICE OLD: '+'\t\t'+oldPhone+'\n\t\t\t'+'PREFERRED PHONE VOICE NEW: '+'\t\t'+newPhone;
            } else {
                lstPhoneValues = '{' + '"strFieldLabel":' + '"PREFERRED PHONE VOICE NEW"' + ',' + '"strFieldValue":' + '"' + newPhone + '"' + '}';
                this.strIntialNotes = this.strIntialNotes +'PREFERRED PHONE VOICE NEW: '+'\t\t'+newPhone;
            }
            lstValuesPhoneAry.push(lstPhoneValues);
            boolPhoneVoiceAutodoc = true;
        } else if(boolText) {
            if(oldPhone) {
                lstPhoneValues = '{' + '"strFieldLabel":' + '"PREFERRED PHONE TEXT OLD"' + ',' + '"strFieldValue":' + '"' + oldPhone + '"' + '},' +
                     '{' + '"strFieldLabel":' + '"PREFERRED PHONE TEXT NEW"' + ',' + '"strFieldValue":' + '"' + newPhone + '"' + '}';
                this.strIntialNotes = this.strIntialNotes + 'PREFERRED PHONE TEXT OLD: '+'\t\t'+oldPhone+'\n\t\t\t'+'PREFERRED PHONE TEXT NEW: '+'\t\t'+newPhone;
            } else {
                lstPhoneValues = '{' + '"strFieldLabel":' + '"PREFERRED PHONE TEXT NEW"' + ',' + '"strFieldValue":' + '"' + newPhone + '"' + '}';
                this.strIntialNotes = this.strIntialNotes + 'PREFERRED PHONE TEXT NEW: '+'\t\t'+newPhone;
            }
            lstValuesPhoneAry.push(lstPhoneValues);
            boolPhoneTextAutodoc = true;
        }
        let sectionPhoneVoice = '';
        let autodocPhVoiceLog = '';
        if(boolPhoneTextAutodoc || boolPhoneVoiceAutodoc) {
            sectionPhoneVoice = '],"lstSections":[' + '{' + '"strLabel":' + '"Member Contacts",' + '"strIcon":' + '"person_account",' + '"strIconFamily":' + '"standard",' + '"strIconColor":' + '"#62b7ed","strVisibleFor":"default"' + '},' +
             '{' + '"strLabel":' + '"Phone Number",' + '"strIcon":' + '"person_account",' + '"strIconFamily":' + '"standard",' + '"strIconColor":' + '"#62b7ed","strVisibleFor":"default"' + '}]';
            autodocPhVoiceLog = '[' + lstValuesPhoneAry + sectionPhoneVoice;
            this.callAutoDocFunction(true, autodocPhVoiceLog);
        }
    }

    callAutoDocFromEmail(oldEmail, boolPreferred, newEmail) {
        let lstEmailValues;
        let lstValuesAry = [];
        let sectionEmail = '';
        let autodocEmailLog = '';
        let formatted_date = BaseLWC.currentDateFormat(); 
        this.strIntialNotes = 'Created on '+formatted_date+'\n\n'+'COMMUNICATION PREFERENCES'+'\n\n'+'\tMember Contacts'+'\n\n' +'\t\t EMAIL'+'\n\t\t\t'
         if (boolPreferred) {
            if(oldEmail) {
                lstEmailValues = '{' + '"strFieldLabel":' + '"PREFERRED EMAIL OLD"' + ',' + '"strFieldValue":' + '"' + oldEmail + '"' + '},' +
                '{' + '"strFieldLabel":' + '"PREFERRED EMAIL NEW"' + ',' + '"strFieldValue":' + '"' + newEmail + '"' + '}';
                this.strIntialNotes = this.strIntialNotes + 'PREFERRED EMAIL OLD: '+'\t\t'+oldEmail+'\n\t\t\t'+'PREFERRED EMAIL NEW: '+'\t\t'+newEmail;
            } else {
                lstEmailValues = '{' + '"strFieldLabel":' + '"PREFERRED EMAIL NEW"' + ',' + '"strFieldValue":' + '"' + newEmail + '"' + '}';
                this.strIntialNotes = this.strIntialNotes +'PREFERRED EMAIL NEW: '+'\t\t'+newEmail;
            }
            lstValuesAry.push(lstEmailValues);
            sectionEmail = '],"lstSections":[' + '{' + '"strLabel":' + '"Member Contacts",' + '"strIcon":' + '"person_account",' + '"strIconFamily":' + '"standard",' + '"strIconColor":' + '"#62b7ed","strVisibleFor":"default"' + '},' +
             '{' + '"strLabel":' + '"EMAIL",' + '"strIcon":' + '"person_account",' + '"strIconFamily":' + '"standard",' + '"strIconColor":' + '"#62b7ed","strVisibleFor":"default"' + '}]';
            autodocEmailLog = '[' + lstValuesAry + sectionEmail;
            this.callAutoDocFunction(true, autodocEmailLog);
        }
    }
    
    callAutoDocFromSave() {
        let parseObjcontact = JSON.parse(this.objContactAutoDoc);
        let strPermToLeaveVoice = this.objContact.Permission_to_Leave_Voicemail__c;
        let strWrittenLang = this.objContact.Written_Language__c;
        let strSpokenLang = this.objContact.Spoken_Language__c;
        let strPrefContTime = this.objContact.Preferred_Contact_Time__c;
        let strTimeZone = this.objContact.Timezone__c;
        let strPrefContMethod = this.objContact.Prefered_Contact_Method__c;
        let contactpref = '';
        let sectionContPref = '';
        let autodocContPrefLog = '';
        let boolContPrefChanged = false;
        let contactprefAry = [];
        let formatted_date = BaseLWC.currentDateFormat(); 
        this.strIntialNotes = 'Created on '+formatted_date+'\n\n'+'COMMUNICATION PREFERENCES'+'\n\n'+'\tMember Contacts'+'\n\n' +'\t\t Preferred Contact'+'\n\t\t\t'
        if (parseObjcontact['Permission_to_Leave_Voicemail__c'] !== strPermToLeaveVoice && strPermToLeaveVoice !== null && strPermToLeaveVoice !== '') {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Permission to Leave Voicemail Old"' + ',' + '"strFieldValue":' + '"' + parseObjcontact['Permission_to_Leave_Voicemail__c'] + '"' + '},' +
                '{' + '"strFieldLabel":' + '"Permission to Leave Voicemail New"' + ',' + '"strFieldValue":' + '"' + strPermToLeaveVoice + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Permission to Leave Voicemail Old: '+'\t\t'+parseObjcontact['Permission_to_Leave_Voicemail__c']+'\n\t\t\t'+'Permission to Leave Voicemail New: '+'\t\t'+strPermToLeaveVoice+'\n\n\t\t\t';
        }
        if (parseObjcontact['Written_Language__c'] !== strWrittenLang && strWrittenLang !== null && strWrittenLang !== '') {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Written Language Old"' + ',' + '"strFieldValue":' + '"' + parseObjcontact['Written_Language__c'] + '"' + '},' +
                '{' + '"strFieldLabel":' + '"Written Language New"' + ',' + '"strFieldValue":' + '"' + strWrittenLang + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Written Language Old: '+'\t\t'+parseObjcontact['Written_Language__c']+'\n\t\t\t'+'Written Language New: '+'\t\t'+strWrittenLang+'\n\n\t\t\t';
        }
        if (parseObjcontact['Spoken_Language__c'] !== strSpokenLang && strSpokenLang !== null && strSpokenLang !== '') {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Spoken Language Old"' + ',' + '"strFieldValue":' + '"' + parseObjcontact['Spoken_Language__c'] + '"' + '},' +
                '{' + '"strFieldLabel":' + '"Spoken Language New"' + ',' + '"strFieldValue":' + '"' + strSpokenLang + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Spoken Language Old: '+'\t\t'+parseObjcontact['Spoken_Language__c']+'\n\t\t\t'+'Spoken Language New: '+'\t\t'+strSpokenLang+'\n\n\t\t\t';
        }
        if (parseObjcontact['Preferred_Contact_Time__c'] !== strPrefContTime && strPrefContTime !== null && strPrefContTime !== '') {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Preferred Contact Time Old"' + ',' + '"strFieldValue":' + '"' + parseObjcontact['Preferred_Contact_Time__c'] + '"' + '},' +
                '{' + '"strFieldLabel":' + '"Preferred Contact Time New"' + ',' + '"strFieldValue":' + '"' + strPrefContTime + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Preferred Contact Time Old: '+'\t\t'+parseObjcontact['Preferred_Contact_Time__c']+'\n\t\t\t'+'Preferred Contact Time New: '+'\t\t'+strPrefContTime+'\n\n\t\t\t';
        }
        if (strTimeZone !== null && strTimeZone !== '' && parseObjcontact['Timezone__c'].toUpperCase() !== strTimeZone.toUpperCase()) {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Timezone Old"' + ',' + '"strFieldValue":' + '"' + parseObjcontact['Timezone__c'].toUpperCase() + '"' + '},' +
                '{' + '"strFieldLabel":' + '"Timezone New"' + ',' + '"strFieldValue":' + '"' + strTimeZone.toUpperCase() + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Timezone Old: '+'\t\t'+parseObjcontact['Timezone__c']+'\n\t\t\t'+'Timezone New: '+'\t\t'+strTimeZone.toUpperCase()+'\n\n\t\t\t';
        }
        if (strPrefContMethod !== null && strPrefContMethod !== '' && parseObjcontact['Prefered_Contact_Method__c'].toUpperCase() !== strPrefContMethod.toUpperCase()) {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Preferred Contact Method Old"' + ',' + '"strFieldValue":' + '"' + parseObjcontact['Prefered_Contact_Method__c'] + '"' + '},' +
                '{' + '"strFieldLabel":' + '"Preferred Contact Method New"' + ',' + '"strFieldValue":' + '"' + strPrefContMethod + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Preferred Contact Method Old: '+'\t\t'+parseObjcontact['Prefered_Contact_Method__c']+'\n\t\t\t'+'Preferred Contact Method New: '+'\t\t'+strPrefContMethod+'\n\n\t\t\t';
        }
        // Preferred Contact Days
        let strContactDays = '';
        let parseObjcontactDay = JSON.parse(this.objContactDayAutoDoc);

        if(this.objContactDay.boolMonday) {
            strContactDays = "MONDAY";
        }
        if(this.objContactDay.boolTuesday) {
            strContactDays = "TUESDAY";
        }
        if(this.objContactDay.boolWednesday) {
            strContactDays = "WEDNESDAY";
        }
        if (this.objContactDay.boolThursday) {
            strContactDays = "THURSDAY";
        }
        if (this.objContactDay.boolFriday) {
            strContactDays = "FRIDAY";
        }
        if (parseObjcontactDay['boolMonday'] && strContactDays !== 'MONDAY' && strContactDays !== null && strContactDays !== '') {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Contact Day Old"' + ',' + '"strFieldValue":' + '"MONDAY"' + '},' +
                '{' + '"strFieldLabel":' + '"Contact Day New"' + ',' + '"strFieldValue":' + '"' + strContactDays + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Contact Day Old: '+'\t\t'+'MONDAY'+'\n\t\t\t'+'Contact Day New: '+'\t\t'+strContactDays;
        }
        if (parseObjcontactDay['boolTuesday'] && strContactDays !== 'TUESDAY' && strContactDays !== null && strContactDays !== '') {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Contact Day Old"' + ',' + '"strFieldValue":' + '"TUESDAY"' + '},' +
                '{' + '"strFieldLabel":' + '"Contact Day New"' + ',' + '"strFieldValue":' + '"' + strContactDays + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Contact Day Old: '+'\t\t'+'TUESDAY'+'\n\t\t\t'+'Contact Day New: '+'\t\t'+strContactDays;
        }
        if (parseObjcontactDay['boolWednesday'] && strContactDays !== 'WEDNESDAY' && strContactDays !== null && strContactDays !== '') {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Contact Day Old"' + ',' + '"strFieldValue":' + '"WEDNESDAY"' + '},' +
                '{' + '"strFieldLabel":' + '"Contact Day New"' + ',' + '"strFieldValue":' + '"' + strContactDays + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Contact Day Old: '+'\t\t'+'WEDNESDAY'+'\n\t\t\t'+'Contact Day New: '+'\t\t'+strContactDays;
        }
        if (parseObjcontactDay['boolThursday'] && strContactDays !== 'THURSDAY' && strContactDays !== null && strContactDays !== '') {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Contact Day Old"' + ',' + '"strFieldValue":' + '"THURSDAY"' + '},' +
                '{' + '"strFieldLabel":' + '"Contact Day New"' + ',' + '"strFieldValue":' + '"' + strContactDays + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Contact Day Old: '+'\t\t'+'THURSDAY'+'\n\t\t\t'+'Contact Day New: '+'\t\t'+strContactDays;
        }
        if (parseObjcontactDay['boolFriday'] && strContactDays !== 'FRIDAY' && strContactDays !== null && strContactDays !== '') {
            contactpref = contactpref + '{' + '"strFieldLabel":' + '"Contact Day Old"' + ',' + '"strFieldValue":' + '"FRIDAY"' + '},' +
                '{' + '"strFieldLabel":' + '"Contact Day New"' + ',' + '"strFieldValue":' + '"' + strContactDays + '"' + '}';
            contactprefAry.push(contactpref);
            contactpref = '';
            boolContPrefChanged = true;
            this.strIntialNotes = this.strIntialNotes + 'Contact Day Old: '+'\t\t'+'FRIDAY'+'\n\t\t\t'+'Contact Day New: '+'\t\t'+strContactDays;
        }
        let commaContactpref = '';
        for (let i = 0; i < contactprefAry.length; i++) {
            if (i === 0 && i < contactprefAry.length) {
                commaContactpref = commaContactpref + contactprefAry[i];
            } else if (i < contactprefAry.length) {
                commaContactpref = commaContactpref + ',' + contactprefAry[i];
            }
        }
        contactprefAry = [];
        if (boolContPrefChanged) {
            sectionContPref = '],"lstSections":[' + '{' + '"strLabel":' + '"Member Contacts",' + '"strIcon":' + '"person_account",' + '"strIconFamily":' + '"standard",' + '"strIconColor":' + '"#62b7ed","strVisibleFor":"default"' + '},' +
                '{' + '"strLabel":' + '"Preferred Contact",' + '"strIcon":' + '"person_account",' + '"strIconFamily":' + '"standard",' + '"strIconColor":' + '"#62b7ed","strVisibleFor":"default"' + '}]';
            autodocContPrefLog = commaContactpref + sectionContPref;
        }
        this.callAutoDocFunction(true, autodocContPrefLog);
    }
    

    callAutoDocFunction(boolSaveButton, autoDocResponse) {
        // check if the Interaction is on then processed with autodoc population
        if (this.strInteractionId && this.strInteractionId !== '') {
            let interactionId = BaseLWC.helperBaseGetItem('strInteractionLogIdForPlanSummaryStamp_' + this.strAccountId);
            if(interactionId === undefined || interactionId === null || interactionId === '') {
                interactionId = BaseLWC.helperBaseGetItem('strInteractionLogId');
            }
            if (interactionId === undefined || interactionId === null || interactionId === '') {
                interactionId = BaseLWC.helperBaseGetUrlParameters('strInteractionLogId',this.objTabData.url);
            }
            if(interactionId) {
                this.setAutodocDetails(interactionId, boolSaveButton, autoDocResponse);
            }
        }
    }

    //Capture the changes made during intercation and post it to Autodoc
    setAutodocDetails(strInteractionIdCase, boolSaveButton, autoDocResponse) {
        // declare JSON for Autodoc
        let objResponses = [];
        let objResponse = {
            strInteractionLogId: '',
            lstValues: []
        };
        if (strInteractionIdCase !== null && strInteractionIdCase !== '') {
            objResponse.strInteractionLogId = strInteractionIdCase;
        }
        objResponse.lstValues = autoDocResponse;
        objResponses.push(objResponse);

        let strResponses = JSON.stringify(objResponses).replace(/\\/g, '');
        strResponses = strResponses.replace('"lstValues":"[{', '"lstValues":[{');
        strResponses = strResponses.replace('"lstValues":"{', '"lstValues":[{');
        strResponses = strResponses.replace('}]"}]', '}]}]');
        strResponses = strResponses.replace('"default"}]"}', '"default"}]}');
        strResponses = strResponses.replace('"default"}]"}', '"default"}]}');
        strResponses = strResponses.replace('"lstValues":"{', '"lstValues":[{');
        strResponses = strResponses.replace('"lstValues":"[]', '"lstValues":[]');
        // post the final response JSON to autodoc Iframe
        if (strInteractionIdCase !== null && strInteractionIdCase !== '') {
            this.postMessageToAutoDoc(strResponses);
            //objSecureLS.set('strAutodoc', strResponses);
            // Get Provider details from local storage
            let strProviderInfoMemContact = window.localStorage.getItem('MemberSearchProviderData_ACE');
            if (strProviderInfoMemContact === undefined || strProviderInfoMemContact === null) {
                strProviderInfoMemContact = '';
            }
            if(boolSaveButton) {
                // create closed case once response posted to autodoc
                /*
                if (strInteractionIdWebChat !== null && strInteractionIdWebChat !== '') {
                    createCase(strInteractionIdWebChat, this.labels.CreateCasePage_MemberManagement_ACE, $Label.CommunicationPreferencesLabel_ACE, $Label.CreateCaseWebChat_ACE, $Label.CreateCasePage_Closed_ACE, strMid, strSubscriberId, strGroupNumber, strCaseCmid,
                            strSectionNumber, strCorpCode, boolPerfGurantee, strGroupCostCenter, strAccInformation, strPolicyId, strEffectiveDate, strTerminationDate, strAddOnServices, strProviderInfoMemContact, boolAccountsAPICallAvailable, boolCbcApiCallAvailable, strLob, strSource,securedGroupNecessaryRole,strFamilyCaseNumber);
                        //window.localStorage.setItem('strKeepAutodocActive','false');
                } else
                */
                if (strInteractionIdCase !== null && strInteractionIdCase !== '') {
                    this.createCase(
                        strInteractionIdCase, 
                        this.labels.CreateCasePage_MemberManagement_ACE, 
                        this.labels.CommunicationPreferencesLabel_ACE, 
                        this.labels.CreateCasePage_Telephone_ACE, 
                        this.labels.CreateCasePage_Closed_ACE, 
                        this.strMID, 
                        this.strSubId, 
                        this.strGroupNumber, 
                        this.strClientMemberId,
                        this.strSectionNumber, 
                        this.strCorpCode, 
                        this.boolPerfGurantee, 
                        this.strGroupCostCenter, 
                        this.strAccInformation, 
                        this.strPolicyId, 
                        this.strEffectiveDate, 
                        this.strTerminationDate, 
                        this.strAddOnServices, 
                        strProviderInfoMemContact, 
                        this.boolAccountsAPICallAvailable, 
                        this.boolCbcApiCallAvailable,
                        this.strLineOfBusiness, 
                        this.strSource,
                        this.securedGroupNecessaryRole, 
                        this.strFamilyCaseNumber
                    );
                }
            }
        }
    }

    postMessageToAutoDoc(dataResponse) {
        let localIframe = document.getElementById('proxy');
        if (!localIframe) {
            let iframe = document.createElement("iframe");
            iframe.src = '/apex/SetlocalstoragePage_ACE';
            iframe.id = "proxy";
            document.body.appendChild(iframe);
            iframe.onload = function() {
                iframe.contentWindow.postMessage({
                    key: 'strAutodoc',
                    value: dataResponse,
                    boolIsFromMemberDetails: true
                }, '*');
                iframe.contentWindow.postMessage({
                    key: 'strKeepAutodocActive',
                    value: 'true',
                    boolIsFromMemberDetails: true
                }, '*');
            }
        } else {
            localIframe.contentWindow.postMessage({
                key: 'strKeepAutodocActive',
                value: 'true',
                boolIsFromMemberDetails: true
            }, '*');
            localIframe.contentWindow.postMessage({
                key: 'strAutodoc',
                value: dataResponse,
                boolIsFromMemberDetails: true
            }, '*');
        }
    }

    createCase(
        strInteractionLogParm, 
        strCaseTypeParm, 
        strCaseSubTypeParm, 
        strCaseOrignParm, 
        strCaseStatusParm, 
        strCaseMidParm, 
        strCaseSubscriberIdParm, 
        strCaseGroupNumberParm, 
        strCaseCmidParm,
        strCaseSectionNumberParm, 
        strCaseCorpCodeParm, 
        boolCasePrefGuranteeParm, 
        strCaseCostCenterParm, 
        strCaseAccInfoParm, 
        strPolicyId, 
        strEffectiveDate,
        strTerminationDate, 
        strCodes, 
        strProviderInfo, 
        boolIsAccountsAPICallAvailable, 
        boolIsCbcApiCallAvailable, 
        strLOB, 
        strSourceSystem,
        securedGroupNecessaryRole, 
        strFamilyCaseNumber) {
            createCaseforAutodoc({
                strInteractionLogAutodoc: strInteractionLogParm,
                strCaseTypeAutodoc: strCaseTypeParm,
                strCaseSubTypeAutodoc: strCaseSubTypeParm,
                strCaseOriginAutodoc: strCaseOrignParm,
                strCaseStatusAutodoc: strCaseStatusParm,
                strCaseMidAutodoc: strCaseMidParm,
                strCaseSubscriberIdAutodoc: strCaseSubscriberIdParm,
                strCaseGroupNumberAutodoc: strCaseGroupNumberParm,
                strCaseCmidAutodoc: strCaseCmidParm,
                strCaseSectionNumberAutodoc: strCaseSectionNumberParm,
                strCaseCorpCodeAutodoc: strCaseCorpCodeParm,
                boolPerfGuranteeAutodoc: boolCasePrefGuranteeParm,
                strCaseGroupCostCenterAutodoc: strCaseCostCenterParm,
                strCaseAccInformationAutodoc: strCaseAccInfoParm,
                strPolicyId: strPolicyId,
                strEffectiveDate: strEffectiveDate,
                strTerminationDate: strTerminationDate,
                strCodes: strCodes,
                strProviderInfo: strProviderInfo,
                boolIsAccountsAPICallAvailable: boolIsAccountsAPICallAvailable,
                boolIsCbcApiCallAvailable: boolIsCbcApiCallAvailable,
                strLOB: strLOB,
                strSourceSystem: strSourceSystem,
                securedGroupNecessaryRole: securedGroupNecessaryRole,
                strFamilyCaseNumber: strFamilyCaseNumber,
                strIntialNotes: this.strIntialNotes
            }
            ).then((data) => {
                    if(data && data.Id){
                        this.strCaseNumber = data.CaseNumber;
                        this.strCaseId = data.Id;
                        const strParams = '?mid=' + this.strMID+ '&caseNumber=' + this.strCaseNumber;
                        const strUrl =  BaseLWC.helperBaseEncodeUrl(strParams);
                        if (this.strInteractionIdCase !== null && this.strInteractionIdCase !== '') {
                            if (this.boolIsFEP) {
                                const showToast = new ShowToastEvent({
                                "title" : '',
                                "message": this.labels.MemberContactDetails_SuccessMessage_ACE +' '+ "Case {0} successfully created." +' '+ this.labels.MemberContactDetails_FepSuccessMessage_ACE,
                                "messageData": [
                                    {
                                        url : '/lightning/r/Case/' + this.strCaseId + '/view' + strUrl,
                                        label : this.strCaseNumber
                                    },  
                                ],
                                "variant": 'success'
                            });
                            this.dispatchEvent(showToast);
                        } else {
                            const event = new ShowToastEvent({
                            variant: 'success',
                            message: this.labels.MemberContactDetails_SuccessMessage_ACE,
                            });
                        this.dispatchEvent(event);
                        }
                    } else {
                        this.showToast();
                    }
                } else {
                    this.showToast();
                }
            }).catch((error)=> {
                if(error){
                    this.handleErrors(error);
                }
            });
    }

    // To check Duplicate Email and Email format
    emailValidation() {
        let emails = [];
        let strError = '';
        for (let i = 0; i < this.lstEmail.length; i++) {
            if(this.lstEmail[i].updateError && this.lstEmail[i].updateError !== '') {
                strError += this.lstEmail[i].updateError;
            } else {
                if(emails.includes(this.lstEmail[i].strEmail)) {
                    strError += this.labels.MemberContactDetails_EmailAlreadyMessage_ACE
                } else {
                    emails.push(this.lstEmail[i].strEmail);
                }
            }
        }
        return strError;
    }

    // To check Duplicate Phone and Phone format
    phoneValidation() {
        let phoneNumberVoicemail = [];
        let phoneNumberPhone = [];
        let strError = '';
        for (let i = 0; i < this.lstPhone.length; i++) {
            if(this.lstPhone[i].updateError && this.lstPhone[i].updateError !== '') {
                strError += this.lstPhone[i].updateError;
            } else {
                if((this.lstPhone[i].boolPreferredPhone && phoneNumberPhone.includes(this.lstPhone[i].strPhone)) ||
                 (this.lstPhone[i].boolPreferredVoicemail &&phoneNumberVoicemail.includes(this.lstPhone[i].strPhone))) {
                    strError += this.labels.MemberContactDetails_PhoneAlreadyMessage_ACE
                } else {
                    if(this.lstPhone[i].boolPreferredPhone) {
                        phoneNumberPhone.push(this.lstPhone[i].strPhone);
                    } else if(this.lstPhone[i].boolPreferredVoicemail) {
                        phoneNumberVoicemail.push(this.lstPhone[i].strPhone);
                    }
                }
            }
        }
        return strError;
    }

    showToast() {
        if (!this.boolIsFEP) {
            const event = new ShowToastEvent({
                variant: 'success',
                message: this.labels.MemberContactDetails_SuccessMessage_ACE,
                title: ''
            });
            this.dispatchEvent(event);
        } else {
            const event = new ShowToastEvent({
                variant: 'success',
                message:  this.labels.MemberContactDetails_SuccessMessage_ACE +' '+ this.labels.MemberContactDetails_FepSuccessMessage_ACE,
            });
            this.dispatchEvent(event);
        }
}

}