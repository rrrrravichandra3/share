import { LightningElement ,api,wire,track} from 'lwc';

export default class LwcCreateLetterTemplateModalACE extends LightningElement {
    @api recordid;
    @api boolopenmodal;
    @api selectedtemplate;
    deductibleCopay;
    paymentLevel;
    outOfPocketMax;
    maxBenefitAmount;
    visitMaxAmount;
    maxLifetimeLimit;
    selectedLimit;
    isShowOutOfCountryInsurance= false;
    isShowOutOfCountryBenefit = false;
    isShowCOCC = false;
    isShowMaxLifetimeLimit = false;
    isShowPTCMaintain = false;
    inNetworkdeductible;
    inNetworkBenefitLevel;
    emergencyRoom;
    lifetimeMax;
    HCABalance;
    selectedRange;
    selectedPlanType;
    selectedCobra;
    isEnablePreviewBtn=true;
    inputFields = [];
    boolShowSpinner = false;
    previousTempName='';
    reason_codes_section= [];
    tempJson;

    get rangeOptions(){
        return [
            { label: '48 Hours', value: '48' },
            { label: '72 Hours', value: '72' }
        ]
    }
    get planTypeOptions(){
        return [
            { label: 'Group', value: 'Group' },
            { label: 'Individual & Family Markets', value: 'Individual&FamilyMarkets' }
        ]
    }

    get cobraOptions(){
        return [
            { label: 'Yes', value: 'yes' },
            { label: 'No', value: 'no' }
        ]
    }

    @api get isShowOutOfCountryInsurance(){
        if(typeof this.selectedtemplate === 'string'){
            const selectedtemp = this.selectedtemplate.toUpperCase();
            if(selectedtemp === 'OUT OF COUNTRY PROOF OF INSURANCE'){
                return true;
            }else{
                return false;
            }
        }
    }

    @api get isShowOutOfCountryBenefit(){
        if(typeof this.selectedtemplate === 'string'){
            const selectedtemp = this.selectedtemplate.toUpperCase();
            if(selectedtemp === 'OUT OF COUNTRY SUMMARY OF BENEFITS'){
                return true;
            }else{
                return false;
            }
        }
    }

    @api get isShowCOCC(){
        if(typeof this.selectedtemplate === 'string'){
            const selectedtemp = this.selectedtemplate.toUpperCase();
            if(selectedtemp === 'CERTIFICATE OF CREDIBLE COVERAGE (COCC)'){
                return true;
            }else{
                return false;
            }
        }
    }

    @api get inputFields(){
        if(this.isShowOutOfCountryInsurance){
            return [
                    { id: "DEDUCTIBLE/COPAY", label: "DEDUCTIBLE/COPAY" },
                    { id: "PAYMENTLEVEL", label: "PAYMENT LEVEL" },
                    { id: "OUTOFPOCKETMAXIMUM", label: "OUT OF POCKET MAXIMUM" },
                    { id: "MAXIMUMBENEFITAMOUNT", label: "MAXIMUM BENEFIT AMOUNT" },
                    { id: "VISITMAXIMUMAMOUNT", label: "VISIT MAXIMUM AMOUNT" }
                    ];
        }else if(this.isShowOutOfCountryBenefit){
            return [
                    { id: "IN-NETWORKDEDUCTIBLE", label: "IN-NETWORK DEDUCTIBLE" },
                    { id: "IN-NETWORKBENEFITLEVEL", label: "IN-NETWORK BENEFIT LEVEL %" },
                    { id: "EMERGENCYROOMCOPAY", label: "EMERGENCY ROOM COPAY" },
                    { id: "LIFETIMEMAXIMUM", label: "LIFETIME MAXIMUM" },
                    { id: "HCABALANCE", label: "HCA BALANCE" }    
                    ];
        }
    }
    

    
    renderedCallback(){        
        if(this.previousTempName && this.previousTempName!= '' && this.previousTempName != this.selectedtemplate){
            this.deductibleCopay = '';
            this.paymentLevel= '';
            this.outOfPocketMax = '';
            this.maxBenefitAmount = '';
            this.visitMaxAmount = '';
            this.onRadioOne = '';
            this.onRadioThree ='';
            this.onRadioTwo = '';
            this.maxLifetimeLimit = '';

            this.inNetworkdeductible = '';
            this.inNetworkBenefitLevel = '' ;
            this.emergencyRoom ='';
            this.lifetimeMax = '' ;
            this.HCABalance ='';
            this.selectedRange = '';

            this.selectedPlanType = '';
            this.selectedCobra = '';

            this.previousTempName= '';
    
        }
        this.checkEnablePreviewButton();
    }
    

    checkEnablePreviewButton(){
    
        try{
            if(this.isShowOutOfCountryInsurance){
                if(this.deductibleCopay && this.paymentLevel && this.outOfPocketMax && this.maxBenefitAmount && this.visitMaxAmount && (this.onRadioOne ||  this.onRadioThree || this.onRadioTwo) ){
                    if(this.onRadioOne){
                        this.tempJson ={
                            reason_code : "001"
                        }  
                        this.isEnablePreviewBtn = false;
                    }else if(this.onRadioThree){
                        this.tempJson ={
                            reason_code : "003"
                        }
                        this.isEnablePreviewBtn = false;
                    }else if(this.onRadioTwo && this.maxLifetimeLimit){
                        this.tempJson ={
                            reason_code : "002"
                        }
                        this.isEnablePreviewBtn = false;
                    }else {
                        this.isEnablePreviewBtn = true;
                    }
                }else{
                        this.isEnablePreviewBtn = true;
                }
                this. reason_codes_section= [];
            } else if(this.isShowOutOfCountryBenefit){
                if(this.inNetworkdeductible && this.inNetworkBenefitLevel && this.emergencyRoom && this.lifetimeMax && this.HCABalance && this.selectedRange ){
                    this.isEnablePreviewBtn = false;
                }else{
                    this.isEnablePreviewBtn = true;
                }
            } else if(this.isShowCOCC){
                if(this.selectedPlanType && this.selectedCobra){
                    this.isEnablePreviewBtn = false;
                }else{
                    this.isEnablePreviewBtn = true;
                }
            } else {
                    //do nothing
            }
        }catch (error) {
                //Handle Error
                this.handleErrors();
        }        
    }
    
    handlePrevious(event){
        this.previousTempName = this.selectedtemplate;
        const PreviousModal = new CustomEvent('previousbutton',{
             detail: { isOpenCreateLetter: true }
         });
         this.dispatchEvent(PreviousModal);
    }
    handlePreviewButton(){
        let strLifeindicator ='';
        let strPolicyType ='';
        let strCobra =''; 
        let strbusSeg = ''; 
        let letterOutputData ={}; 
        let maxLifeTime ='';
        if(this.isShowOutOfCountryInsurance){  
            if(this.onRadioTwo){
                strLifeindicator = 'Y';
                maxLifeTime = this.maxLifetimeLimit;
            } else {
                strLifeindicator = 'N';
            }
            this.reason_codes_section.push(this.tempJson);
            letterOutputData ={
                deductible_copay_amt : this.deductibleCopay,
                payment_level : this.paymentLevel,
                oop_max : this.outOfPocketMax,
                max_benefit_amt : this.maxBenefitAmount,
                max_visit_amt : this.visitMaxAmount,
                lifetime_limit_ind : strLifeindicator,
                max_lifetime_limit_amt : maxLifeTime,
                reason_codes_section : this.reason_codes_section
            }

        }else if(this.isShowOutOfCountryBenefit){
            letterOutputData ={
                inn_deductible_amt : this.inNetworkdeductible,
                inn_benefit_level : this.inNetworkBenefitLevel,
                em_room_copay_amt : this.emergencyRoom,
                max_lifetime_limit_amt : this.lifetimeMax,
                hca_balance : this.HCABalance,
                no_of_hours : this.selectedRange
            }

        }else if(this.isShowCOCC){
            if(this.selectedPlanType.toLocaleLowerCase() == 'group'){
                strPolicyType = 'N';
                strbusSeg = 'GMS';
            } else {
                strPolicyType = 'Y';
                strbusSeg = 'RETAIL';
            }

            if(this.selectedCobra.toLocaleLowerCase() == 'yes'){
                strCobra = 'Y';
            } else {
                strCobra = 'N';
            }



            letterOutputData ={
                select : strPolicyType,
                cobra : strCobra,
                bus_segment : strbusSeg
            }


        }
        
        
        const PreviousModal = new CustomEvent('previewbutton',{
            detail: { booPreviewLetter: true , letterOutputData : letterOutputData , selectedTemplate : this.selectedtemplate}
        });
        this.dispatchEvent(PreviousModal);
    }
    closeModalEvent() {
        const closeModal = new CustomEvent('cancelorclosemodal', {
            detail: { boolopenmodal: false }
        });
        // Fire the custom event
        this.dispatchEvent(closeModal);
    }
    handleChangeInsuranceValue(event){
        if(event.target.label == "DEDUCTIBLE/COPAY"){
            this.deductibleCopay = event.target.value;
        }else if(event.target.label == "PAYMENT LEVEL"){
            this.paymentLevel = event.target.value;
        }else if(event.target.label == "OUT OF POCKET MAXIMUM"){
            this.outOfPocketMax = event.target.value;
        }else if(event.target.label == "MAXIMUM BENEFIT AMOUNT"){
            this.maxBenefitAmount = event.target.value;
        }else if(event.target.label == "VISIT MAXIMUM AMOUNT"){
            this.visitMaxAmount = event.target.value;
        }
         this.checkEnablePreviewButton();
        
    }
    handleChangeBenefitsValue(event){
    try{    
        if(event.target.label == "IN-NETWORK DEDUCTIBLE"){
            this.inNetworkdeductible = event.target.value;
        }else if(event.target.label == "IN-NETWORK BENEFIT LEVEL %"){
            this.inNetworkBenefitLevel = event.target.value;
        }else if(event.target.label == "EMERGENCY ROOM COPAY"){
            this.emergencyRoom = event.target.value;
        }else if(event.target.label == "LIFETIME MAXIMUM"){
            this.lifetimeMax = event.target.value;
        }else if(event.target.label == "HCA BALANCE"){
            this.HCABalance = event.target.value;
        }      
        this.checkEnablePreviewButton();
       }catch (error) {
            //Handle Error
            this.handleErrors();
        }
    }    
    handleChangeMaxLifetimeLimit(event){
        try{
        this.maxLifetimeLimit = event.target.value;
        this.checkEnablePreviewButton();
        }catch (error) {
        //Handle Error
        this.handleErrors();
        }
    }

    handleChangeonRadioOne(event){
        try{
        this.onRadioOne = event.target.checked;
        this.onRadioTwo = false;
        this.onRadioThree = false;
        this.isShowMaxLifetimeLimit = false;
        this.checkEnablePreviewButton();
    }catch (error) {
        //Handle Error
        this.handleErrors();
    }
    }
    handleChangeonRadioTwo(event){
        try{
        this.onRadioTwo = event.target.checked;
        this.onRadioOne = false;
        this.onRadioThree = false;
        this.isShowMaxLifetimeLimit = true;
        this.checkEnablePreviewButton();
    }catch (error) {
        //Handle Error
        this.handleErrors();
    }
    }
    handleChangeonRadioThree(event){
        try{
        this.onRadioThree = event.target.checked;
        this.onRadioTwo = false;
        this.onRadioOne = false;
        this.isShowMaxLifetimeLimit = false;
        this.checkEnablePreviewButton();
    }catch (error) {
        //Handle Error
        this.handleErrors();
    }
    }
    handleChangeRange(event){
        try{
        this.selectedRange = event.target.value;
        this.checkEnablePreviewButton();
    }catch (error) {
        //Handle Error
        this.handleErrors();
    }
    }
    handleChangePlanType(event){
        try{
        this.selectedPlanType = event.target.value;
        this.checkEnablePreviewButton();
    }catch (error) {
        //Handle Error
        this.handleErrors();
    }
    }
    handleChangeCobra(event){
        try{
        this.selectedCobra = event.target.value;
        this.checkEnablePreviewButton();
    }catch (error) {
        //Handle Error
        this.handleErrors();
    }
    }
    
    handleErrors(){
        //Do nothing
    }
}