import { LightningElement, api, track, wire } from 'lwc';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
//import platformWorkspaceApi
import { EnclosingTabId, getTabInfo } from 'lightning/platformWorkspaceApi';

import removeLegacyRecord from '@salesforce/apex/LegacyModalController_ACE.removeLegacyRecord';
import updatePreferredNameOfLegacy from '@salesforce/apexContinuation/LegacyModalController_ACE.updatePreferredNameOfLegacy';
import AlternativeText_Close_ACE from '@salesforce/label/c.AlternativeText_Close_ACE';
import UpdatePreferredNameModal_Description_ACE from '@salesforce/label/c.RemoveLegacyModal_Description_ACE';
import UpdatePreferredNameModal_EffectiveDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_EffectiveDate_ACE';
import UpdatePreferredNameModal_ExpirationDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_ExpirationDate_ACE';
import IntegrationFailMessageForLegacy_ACE from '@salesforce/label/c.IntegrationFailMessageForLegacy_ACE';
import UpdatePreferredNameModal_PreferredName_ACE from '@salesforce/label/c.UpdatePreferredNameModal_PreferredName_ACE';
import UpdatePreferredNameModal_BlankFieldMessageLabel_ACE from '@salesforce/label/c.CreateCasePage_ErrorFieldInfo_ACE';
import ViewStandardAuthorization_Success_ACE from '@salesforce/label/c.ViewStandardAuthorization_Success_ACE';
import UpdatePreferredNameModal_SuccessMessage_ACE from '@salesforce/label/c.RemoveLegacyModal_SuccessMessage_ACE';
import RemoveLegacyModal_Description_ACE from '@salesforce/label/c.RemoveLegacyModal_Description_ACE';
import RemoveLegacyModal_EffectiveDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_EffectiveDate_ACE';
import RemoveLegacyModal_ExpirationDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_ExpirationDate_ACE';
import RemoveLegacyModal_SuccessMessage_ACE from '@salesforce/label/c.RemoveLegacyModal_SuccessMessage_ACE';
import RemoveLegacyModal_RemoveNotificationTitle_ACE from '@salesforce/label/c.RemoveLegacyModal_RemoveNotificationTitle_ACE';
import RemoveLegacyModal_NotificationHeader_ACE from '@salesforce/label/c.RemoveLegacyModal_NotificationHeader_ACE';
import UpdatePreferredNameModal_NotificationHeader_ACE from '@salesforce/label/c.UpdatePreferredNameModal_NotificationHeader_ACE';


export default class LwcPreferredNameUpdateACE extends LightningElement {
    
    label={
        AlternativeText_Close_ACE,
        UpdatePreferredNameModal_Description_ACE,
        UpdatePreferredNameModal_EffectiveDate_ACE,
        UpdatePreferredNameModal_ExpirationDate_ACE,
        IntegrationFailMessageForLegacy_ACE,
        UpdatePreferredNameModal_PreferredName_ACE,
        UpdatePreferredNameModal_BlankFieldMessageLabel_ACE,
        ViewStandardAuthorization_Success_ACE,
        UpdatePreferredNameModal_SuccessMessage_ACE,
        RemoveLegacyModal_Description_ACE,
        RemoveLegacyModal_EffectiveDate_ACE,
        RemoveLegacyModal_ExpirationDate_ACE,
        RemoveLegacyModal_SuccessMessage_ACE,
        RemoveLegacyModal_RemoveNotificationTitle_ACE,
        RemoveLegacyModal_NotificationHeader_ACE,
        UpdatePreferredNameModal_NotificationHeader_ACE
    }
    @api boolSaveModal = false;
    @api boolModalIsOpen = false;
    boolIsValidated = true;
    boolModalIsOpenAPIFAILURE = false;
    boolShowToastMessage = false;
    @api boolRefreshIframe = false;
    @api boolShowNtfType = false;
    boolSaveRemoveModal = false;
    boolConfirmRemove = false;
    //type="Object" description="Preferred Legacy Listener"
    objPreferredLegacyListener;
    objCatch;

    //String Attributes
    //description="Used to store client Member ID from URL after decoded in doInit"
    @api strClientMemberId;
    //description="Used to store Member ID"
    @api strMemberId;
    //type="Object" description="Used to store record Data.
    @api objRecordData= {};
    //type="String" description="Used to show Header message.
    strHeaderData = this.label.UpdatePreferredNameModal_NotificationHeader_ACE;
    //type="String" description="Used to show Header message.
    strHeaderDataRemoveLegacy = this.label.RemoveLegacyModal_NotificationHeader_ACE;
    //type="String" description="Used to Show Preferred Name"
    @track strPreferredName= "";
    //type="Map" description="Used to Show List of Family Members
    lstApplicableTo;
    //type="String" description="Used to show Title Message.
    strTitleMessage = this.label.RemoveLegacyModal_RemoveNotificationTitle_ACE
    //type="String" description="Used to Show Confirm/Remove"
    strConfirmRemoveButton = "Remove"
    //type="String" description="Used to show success message"
    strSuccessMessage= this.label.RemoveLegacyModal_SuccessMessage_ACE;
    //type="String" description="Used to store the value of Applicable field for back button"
    strTempApplicableTo;
    //type="Map" default=""
    mapFamilyMembers;
    //type="Object"
    @api objSelectedPlan;
    objTabData;
    strBaseCurrentTabId;
    strBaseCurrentTabUrl;
    boolBaseIsItSubTab;
    strBaseCurrentParentTabId;
    boolRendered = true;

    //wire function
    @wire(EnclosingTabId) enclosingTabId;

    connectedCallback() {
        this.fetchTabData();
    }

    disconnectedCallback() {
        const strPreferredLegacyEvent = 'PreferredNameLegacyEvent' + this.strMemberId;
        window.removeEventListener(strPreferredLegacyEvent, this.objPreferredLegacyListener, false);
    }

    /**
     * To select applicable to field based on Subscriber account open in HCD
     */
    renderedCallback() {
        if(this.boolRendered && this.template.querySelector(`[data-id='idTitle'] option[value='${this.strTempApplicableTo}']`)) {
            this.template.querySelector(`[data-id='idTitle'] option[value='${this.strTempApplicableTo}']`).setAttribute("selected",true);
            this.boolRendered = false
        }
    }

    /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     * All components should have this code.
     */
    fetchTabData = () => {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
                this.processTabData(objTabData);
            })
            .catch((error) => {
                this.handleErrors(error);
             });
            }          
    };

    processTabData = (objTabData) => {
        try {
            this.objTabData = objTabData;
            this.strBaseCurrentTabId = this.objTabData.tabId;
            this.strBaseCurrentTabUrl = this.objTabData.url;
            this.boolBaseIsItSubTab = this.objTabData.isSubtab;
            if (this.boolBaseIsItSubTab === true) {
                this.strBaseCurrentParentTabId = this.objTabData.parentTabId;
            } else {
                this.strBaseCurrentParentTabId = this.objTabData.tabId;
            }
            this.executeInitialFunctionality();
        } catch (error) {
            this.handleErrors(error);
        }
    };

    /**
     * Method to Initialize unique token value & Tab message custom event.
     *
     */
    executeInitialFunctionality() {
        this.fetchPreferredNameFromPatientCard();
        this.fetchDataFromPatientCard(true);
        this.formFamilyMembers();
    }

    /**
     * This method is used to fetch Preferred Name from Patient Card.
     *
     */
    fetchPreferredNameFromPatientCard() {
        try {
            const strPreferredLegacyEvent = 'PreferredNameLegacyEvent' + this.strMemberId;
            const objPreferredLegacyDestinationId = 'PreferredNameLegacyEvent_ACE' + this.strMemberId;
            if (this.objPreferredLegacyListener === undefined || this.objPreferredLegacyListener === null ||
                this.objPreferredLegacyListener === '') {
                const objPreferredLegacyListener = (objEventData) => {
                    if (objEventData && objEventData.detail && typeof objEventData.detail === 'string') {
                        const strParsedData = JSON.parse(objEventData.detail);
                        if (strParsedData.strIdDestination && strParsedData.strIdDestination === objPreferredLegacyDestinationId) {
                            if (strParsedData.objParameters && strParsedData.objParameters.objMessage && strParsedData.objParameters.objMessage.strPreferredName) {
                                this.strPreferredName = strParsedData.objParameters.objMessage.strPreferredName;
                            }
                        }
                        window.removeEventListener(strPreferredLegacyEvent, objPreferredLegacyListener, false);
                    }
                };

                this.objPreferredLegacyListener =  objPreferredLegacyListener;
                window.addEventListener(strPreferredLegacyEvent, objPreferredLegacyListener, false);
            }
        } catch (objException) {
            //Do Nothing.
        }
    }

    /**
     * This method is used to fetch data from Patient Card.
     */

    fetchDataFromPatientCard(boolFetchData) {
        const objParameter = {
            'boolFetchData': boolFetchData,
            'strPreferredName': this.strPreferredName
        };
        const strPreferredLegacyEvent = 'PreferredLegacyEvent' + this.strMemberId;
        const strPreferredLegacyDestinationId = 'PreferredLegacyEvent_ACE' + this.strMemberId;
        BaseLWC.helperBasePostTabIdMessageCustomEvents(strPreferredLegacyEvent, null, objParameter, strPreferredLegacyDestinationId, this.strBaseCurrentTabId).catch(() => {
            /*Do nothing*/
        });
    }

    /**
     * This method is to get Preferred Name from patient card.
     *
     */
    formFamilyMembers() {
        if (BaseLWC.isNotUndefinedOrNull(this.objSelectedPlan)) {
            const objFamilyPlan = JSON.parse(JSON.stringify(this.objSelectedPlan));
            const objFamilyDetailsFromFamilyCard = objFamilyPlan.lstFamilyWrapper;
            const mapFamilyMember = [];
            let strSelectedPerson = "";
            if (objFamilyDetailsFromFamilyCard) {
                for (let intCount = 0; intCount < objFamilyDetailsFromFamilyCard.length; intCount++) {
                    const objFamilyWithId = {};
                    objFamilyWithId.strFullName = objFamilyDetailsFromFamilyCard[intCount].strFirstName + ' ' +
                        objFamilyDetailsFromFamilyCard[intCount].strLastName;
                    mapFamilyMember.push({
                        value: objFamilyDetailsFromFamilyCard[intCount].strMemberId,
                        key: objFamilyWithId.strFullName
                    });
                    const strMid = this.strMemberId;
                    if (strMid === objFamilyDetailsFromFamilyCard[intCount].strMemberId) {
                        strSelectedPerson = objFamilyDetailsFromFamilyCard[intCount].strMemberId;
                    }
                }
            }
            this.lstApplicableTo = mapFamilyMember;
            this.strTempApplicableTo =  strSelectedPerson;
        }

    }


    handleErrors(error) {
        this.objCatch = error;
    }

    /**
     * This method is to close the Modal popup.
     *
     */
    closeModal() {
        this.boolModalIsOpen =  false;
        const PreferredNameUpdateCloseModal = new CustomEvent("close",{}, this);
        this.dispatchEvent(PreferredNameUpdateCloseModal);
    }

    /**
     * This method is to hide the API error message.
     */
    hideAPIError() {
        this.boolModalIsOpenAPIFAILURE = false;
    }

    /**
     * This method is to take the user back to Notification Type screen.
     *
     */
    back(){
        this.boolSaveModal =  true;
        this.boolSaveRemoveModal = false;
    }


    /**
     * This method is to Show Confirm Remove Legacy Modal.
     *
     */
    saveRemoveLegacy() {
        this.validateForm();
        if (this.boolIsValidated === false) {
            return;
        }
        this.confirmPreferredNameRemoveLegacyHelper();
    }


    /**
     * This method is to Update Preferred Name.
     *
     */
    saveNew() {
        this.validateForm();
        if (this.boolIsValidated === false) {
            return;
        }
        this.boolConfirmRemove = false;
        this.updatePreferredNameHelper();
    }

    /**
     * This method is to Update Preferred Name & Remove Legacy Alert .
     *
     */
    confirmRemoveButton() {
        this.boolConfirmRemove = true;
        this.updatePreferredNameHelper();
    }

    /**
     * This method is to show the Toast Message content.
     *
     */
    fireToastMessageContent() {
        this.boolRefreshIframe = true;
        this.boolShowToastMessage = true;
        const refreshIframePreferredNameUpdate = new CustomEvent("refreshiframefrompreferredname",{}, this);
        this.dispatchEvent(refreshIframePreferredNameUpdate);
    }

    /**
     * This method is used to Show Confirm Remove Legacy Modal.
     *
     */
    confirmPreferredNameRemoveLegacyHelper() {
        this.boolSaveModal = false;
        this.boolSaveRemoveModal = true;
    }

     /**
     * Method to Remove Legacy Record.
     *
     */
    confirmRemoveButtonHelper () {
        const idRecordId = this.objRecordData.Id;
        removeLegacyRecord({
            'idRecord': idRecordId,
            'boolNotification': true,
            'boolAuthorization': false
        }).then(() => {
            try {
                if (this.boolConfirmRemove === true) {
                    this.fireToastMessageContent();
                }
            } catch (exception) {
                //No handling Needed.
                this.handleErrors(exception);
            }
        }).catch((error)=> {
            this.handleErrors(error);
        });
        
    }

    /**
     * This method is used to Save Preferred Name Update.
     *
     */
    updatePreferredNameHelper() {
        const strMemberId = this.strTempApplicableTo;
        const strPrefName = this.strPreferredName;
        const objparams = {
            'strPrefName': strPrefName,
            'strMemberId': strMemberId
        }

        updatePreferredNameOfLegacy({
            'strPreferredNameInfo': JSON.stringify(objparams)
        }).then(objResult => {
                try {
                    const strStateValue = JSON.parse(objResult).strResponseStatusCode;
                    if (strStateValue === '200' || strStateValue === '201' || strStateValue === '204') {
                        this.boolModalIsOpenAPIFAILURE = false;
                        try {
                            const strApplicableMemberId = this.strTempApplicableTo;
                            const strParentMemberId = this.strMemberId;
                            if (strParentMemberId === strApplicableMemberId) {
                                this.fetchDataFromPatientCard(false);
                            }
                            if (this.boolConfirmRemove === true) {
                                this.confirmRemoveButtonHelper();
                            }
                            if (this.boolConfirmRemove === false) {
                                this.fireToastMessageContent();
                            }
                        } catch (exception) {
                            //No handling Needed.
                            this.handleErrors(exception);
                        }
                    }
                } catch (exception) {
                    //No handling Needed.
                    this.handleErrors(exception);
                }
        }).catch((error)=> {
           this.boolModalIsOpenAPIFAILURE = true;
           this.handleErrors(error);
        });
    }

    /**
     * Validate all required fields are populated.
     *
     */
    validateForm() {
        const objElements = this.template.querySelector("[data-id=idPreferredNameModalPrefName]");
        let boolCheckValid = true;
        let strVal = objElements.querySelector('.clsValidateInput').querySelector('input').value;
        const strKey = objElements.querySelector('.clsValidateInput').querySelector('input').getAttribute('data-keys');
        strVal = strVal.trim();
        if (!strVal) {
            objElements.querySelector('.clsValidateInput').classList.add('slds-has-error');
            objElements.querySelector('.clsValidateInput').querySelector('div').classList.remove('slds-hide');
            boolCheckValid = false;
        } else {
            objElements.querySelector('.clsValidateInput').classList.remove("slds-has-error");
            objElements.querySelector('.clsValidateInput').querySelector('div').classList.add('slds-hide');
        }
        if(strKey === 'strPreferredName') {
            this.strPreferredName = strVal;
        }
        this.boolIsValidated = boolCheckValid;
    }

    handleApplicableToChange(objEvent) {
        const objTarget = objEvent.currentTarget;
        if(objTarget) {
            const value = objEvent.currentTarget.value;
            this.strTempApplicableTo = value;
        }

    }
}