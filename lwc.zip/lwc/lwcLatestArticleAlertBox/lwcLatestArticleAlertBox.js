//Importing required Decorators.
import { LightningElement, track, api,wire } from "lwc";

//CEAS-82979 Platform Workspace API
import { EnclosingTabId, getTabInfo, openSubtab} from 'lightning/platformWorkspaceApi';

//Import Labels
import latestArticlemsgDescriptionline1 from '@salesforce/label/c.KnowledgeArticle_LatestArticle_AlertMessage_Line1';
import latestArticlemsgDescriptionline2 from '@salesforce/label/c.KnowledgeArticle_LatestArticle_AlertMessage_Line2';

//Import Apex Methods.
import fetchLatestArticleId from "@salesforce/apex/KnowledgeArticlesController_ACE.fetchLatestArticleVersion";

export default class LwcLatestArticleAlertBox extends LightningElement {
    

      //Variable Declarations:
      //Used to Store Latest Article ID.
      @track latestArticleData = null;
      //Used to Store if Close if pressed.
      @track isAlertVisible;
      //Used to Store if any error as occured
      boolError = false;
      label = {
        latestArticlemsgDescriptionline1,
        latestArticlemsgDescriptionline2

      }
      //Used to Store hyperlink label.
      hyperlinkLabel = "here.";
      //Used to Store base URL.
      url = null;                     
      //Used to store tab Data.
      objTabData = null;
      //Used to Store RecordID of the opened record.               
      @api recordId;                 
      @wire(EnclosingTabId) enclosingTabId;              

      /**
     * Connected Call back function.
     */
      connectedCallback() {
        this.isAlertVisible = true;
            try {
                  this.fetchTabData();
                  this.url = window.location.origin + "/lightning/r/Knowledge__kav/";
                  fetchLatestArticleId({
                        strArticleID: this.recordId,
                  })
                        .then((objResult) => {
                              this.latestArticleData = objResult;
                        })
                        .catch(() => {
                              this.handleErrors();
                        });
            } catch (error) {
                  this.handleErrors();
            }
      }
     /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     * All components should have this code.
     */
      fetchTabData() {        
            if(this.enclosingTabId) {
                  getTabInfo(this.enclosingTabId).then(objTabData => {
                  this.objTabData = objTabData;          
            }).catch(error => {
                                    this.handleErrors(error);
                              });
                  }
      }

      /**
     * Open SubTab on Hyperlink Click.
     * Of the Latest Knowledge Article.
     */
      openLatestArticleLink() {
            const subTabURL = this.url + this.latestArticleData + "/view";
            openSubtab(this.objTabData.parentTabId, { url: subTabURL,focus: true});
      }

      /**
      * To handle Close.
      * Removes the alert off the screen.
      */
      closeNotification() {
        this.isAlertVisible= false;
      }  

      /**
      * To handle Errors.
      * Helps to show case errors.
      * All components should have this code.
      */
      handleErrors(error) {
            if(error !== undefined) {
                  this.boolError = true;
            }
      }
}