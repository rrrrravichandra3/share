import { LightningElement, api } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
import ViewFSUPhoneNumberDetails_ACE from '@salesforce/label/c.ViewFSUPhoneNumberDetails_ACE';
import ViewFSUPhoneNumberAPIError_ACE from '@salesforce/label/c.ViewFSUPhoneNumberAPIError_ACE';
import ViewEmployerGroup_Close_ACE from '@salesforce/label/c.ViewEmployerGroup_Close_ACE';
import Message_error_ACE from '@salesforce/label/c.Message_error_ACE';
import getContactDetails from '@salesforce/apexContinuation/ViewPlanSummaryController_ACE.fetchContactInfo';

export default class FsuPhoneNumberModalACE extends LightningElement {
    @api strMemberId;
    @api strPolicyId;
    @api boolIsOpen = false;
    boolSpinner = true;
    boolError = false;
    strPhoneNumber;
    label = {
        ViewFSUPhoneNumberDetails_ACE,
        ViewFSUPhoneNumberAPIError_ACE,
        ViewEmployerGroup_Close_ACE,
        Message_error_ACE
    };

    connectedCallback() {
        this.fetchContactDetails();
    }
    closeModal() {
        this.boolIsOpen = false;
        const objCloseEvent = new CustomEvent('close', { 
            detail: { boolIsOpen: this.boolIsOpen }
        });
        this.dispatchEvent(objCloseEvent);
    }

    fetchContactDetails = () => {
        getContactDetails({
            strMid: this.strMemberId,
            strPolicyId: encodeURIComponent(this.strPolicyId)
        }).then((objResult) => {
            if (BaseLWC.isNotUndefinedOrNull(objResult)) {
                if (objResult.boolIsSuccess && BaseLWC.isNotUndefinedOrNull(objResult.objResponse)) {
                    const objResponse = objResult.objResponse;
                    if (BaseLWC.isNotUndefinedOrNull(objResponse.policies[0]) && 
                        BaseLWC.isNotUndefinedOrNull(objResponse.policies[0].phoneNumbers) &&
                        BaseLWC.isNotUndefinedOrNull(objResponse.policies[0].phoneNumbers.phoneNumbers)) {
                        const lstPhoneNumbers = objResponse.policies[0].phoneNumbers.phoneNumbers;
                        this.getFSUPhoneNumber(lstPhoneNumbers);
                    } else {
                        this.boolError = true;
                    }
                    this.boolSpinner = false;
                } else {
                    this.boolError = true;
                    this.boolSpinner = false;
                }
            }
        });
    }
    getFSUPhoneNumber(lstPhoneNumbers) {
        for (let i=0; i<lstPhoneNumbers.length; i++) {
            if (BaseLWC.isNotUndefinedOrNull(lstPhoneNumbers[i].fsuName)) {
                this.strPhoneNumber = lstPhoneNumbers[i].phoneNumber;
            }
        }
    }
}