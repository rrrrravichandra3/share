import { LightningElement,api,wire } from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF';
//CEAS-82979 Platform Workspace API
import { EnclosingTabId, getTabInfo} from 'lightning/platformWorkspaceApi';
//importing the custom labels
import SearchForProvider_VitalsSSOEndpoint_ACE from '@salesforce/label/c.SearchForProvider_VitalsSSOEndpoint_ACE';
import MyPrime_ACE from '@salesforce/label/c.MyPrime_ACE';
import createCaseRecord from '@salesforce/apex/RelatedLinksController_ACE.createCaseRecord';

export default class LwcMyPrimeACE extends LightningElement {
Label={
    SearchForProvider_VitalsSSOEndpoint_ACE,
    MyPrime_ACE
}
/*
   parameters from parent component
*/
@api strMemberId;
@api strPrimeURL;
@api strSMPortalState;
@api strSubscriberId;
@api strEmail;
@api strBirthDate;
@api strGender;
@api strFirstName;
@api objPatientCardResponseWrapper;
@api objPlanDetails;
@api strRecordId;
boolShowMyPrime = true;

@wire(EnclosingTabId) enclosingTabId;

LoaclstrInteractionIdForPlanSummaryStamp;
/*
   Getter and Setter to change strInteractionIdForPlanSummaryStamp's value
*/
@api
get strInteractionIdForPlanSummaryStamp() {
return this.LoaclstrInteractionIdForPlanSummaryStamp;
}

set strInteractionIdForPlanSummaryStamp(value) {
    if(value) {
    this.LoaclstrInteractionIdForPlanSummaryStamp=value;
    }
}

objTabData;
objError = {};
strFormId;
strBaseCurrentTabUrl;
objUrl;
strRelatedLinkLabel;
strFocusedTabUrl;
strAccountRecId;
boolError=false;
boolMyPrimeforGMS = false;

//function called on click on MyPime Related link
    navigateToVitals(event) {
        try {
            event.preventDefault();
            event.stopImmediatePropagation();
            event.stopPropagation();
            this.template.querySelector(`form.${this.strFormId}`).submit();
            this.fetchAccountIdFromURL(event);
        } catch (exception) {
            //Do Nothing.
        }
    }

    fetchAccountIdFromURL(event) {
        const strRelatedLinkLabel = event.currentTarget.textContent;
        const strCurrentTabUrl = this.strBaseCurrentTabUrl;
        const strDecodedURL = BaseLWC.helperBaseDecodeUrl(strCurrentTabUrl);
        const objUrl = new URL(strDecodedURL);
        let strAccountId = objUrl.searchParams.get('ws');
        if (strAccountId !== undefined && strAccountId !== null) {
            strAccountId = strAccountId.split('/lightning/r/Account/');
            if (strAccountId !== undefined && strAccountId !== null && strAccountId.length > 0) {
                strAccountId = strAccountId[1].split('/view')[0];
                if (strAccountId.startsWith('001')) {
                    const strActiveInteractionLogId = BaseLWC.helperBaseGetItem('strInteractionLogIdForPlanSummaryStamp_' + strAccountId);
                    this.strInteractionIdForPlanSummaryStamp=strActiveInteractionLogId;
                    this.generateReportingCase(strRelatedLinkLabel,strCurrentTabUrl,strAccountId);
                }
            }
        }
    }
    generateReportingCase(strRelatedLinkLabel,strFocusedTabUrl,strAccountRecId) {
        const secureGroupFromLocalStorage = BaseLWC.helperBaseGetItem('SecureGroupNameLocalStorage_ACE');
        let selectedSecureGroupRole = '';
        if (secureGroupFromLocalStorage !== undefined && secureGroupFromLocalStorage !== "" && typeof secureGroupFromLocalStorage === "string") {
            const objSecureGroupLocalStorage = JSON.parse(secureGroupFromLocalStorage);
            for (let i = 0; i < objSecureGroupLocalStorage.length; i++) {
                if (objSecureGroupLocalStorage[i].accountId === strAccountRecId) {
                    selectedSecureGroupRole = objSecureGroupLocalStorage[i].selectedSecureGroupRole;
                }
            }
        }
        let strPlanDetails = JSON.parse(JSON.stringify(this.objPlanDetails));
        let boolIsCbcApiCallAvailable = false;
        let boolIsAccountsAPICallAvailable = false;
        if(strPlanDetails) {
         if(strPlanDetails.boolIsAccountsAPICallAvailable && strPlanDetails.boolIsAccountsAPICallAvailable=== true) {
            boolIsAccountsAPICallAvailable = strPlanDetails.boolIsAccountsAPICallAvailable;
        }
        if(strPlanDetails.boolIsCbcApiCallAvailable && strPlanDetails.boolIsCbcApiCallAvailable=== true) {
            boolIsCbcApiCallAvailable = strPlanDetails.boolIsCbcApiCallAvailable;
        }
        }
        if (!strPlanDetails) {
            const strDecodedURL = BaseLWC.helperBaseDecodeUrl(strFocusedTabUrl);
            let strMultiPlanFromUrl = 'false';
            const objUrl = new URL(strDecodedURL);
            if (objUrl.searchParams.get("multiPlan") && objUrl.searchParams.get("multiPlan") === true) {
                strMultiPlanFromUrl = 'true';
            }
            strPlanDetails = {
                strMemberId: objUrl.searchParams.get("mid") || '',
                strGroupNumber: objUrl.searchParams.get("groupName") || '',
                strPolicyId: objUrl.searchParams.get("planId") || '',
                strSubscriberId: objUrl.searchParams.get("subscriberId") || '',
                strCorpCode: objUrl.searchParams.get("corpCode") || '',
                strAccountNumber: '',
                objViewEmployerGroupWrapper: {
                    strGroupSectionNumber: ''
                },
                strGroupCostCenterNumber: '',
                strGroupName: '',
                strClientMemberId: objUrl.searchParams.get("Cmid") || '',
                strNetwork: '',
                strMultiPlan: strMultiPlanFromUrl,
                boolPgIndicator: objUrl.searchParams.get("boolProspectMember") || '',
                strEffectiveDate: objUrl.searchParams.get("planEffDt") || '',
                strTerminationDate: objUrl.searchParams.get("planTermDt") || ''
            }
        }
        //parameters for apex method
        const objParameters = {
            mid: strPlanDetails.strMemberId,
            strGroupNum: strPlanDetails.strGroupNumber,
            strPolicyId: strPlanDetails.strPolicyId,
            strSubscriberId: strPlanDetails.strSubscriberId,
            strCorpCode: strPlanDetails.strCorpCode,
            strAccountNumber: strPlanDetails.strAccountNumber,
            strInteractionId: this.strInteractionIdForPlanSummaryStamp,
            strSecureGroupRole: selectedSecureGroupRole,
            strSectionNumber: strPlanDetails.objViewEmployerGroupWrapper.strGroupSectionNumber,
            strQuickLinksLabel: strRelatedLinkLabel,
            strGroupCostCenter: strPlanDetails.strGroupCostCenterNumber,
            strGroupName: strPlanDetails.strGroupName,
            strCMID: strPlanDetails.strClientMemberId,
            strProductType: strPlanDetails.strNetwork,
            strMultiPlan: strPlanDetails.strMultiPlan,
            boolPgIndicator: strPlanDetails.boolPgIndicator,
            strEffectiveDate: strPlanDetails.strEffectiveDate,
            strTerminationDate: strPlanDetails.strTerminationDate,
            boolAccountsAPICallAvailable : boolIsAccountsAPICallAvailable,
            boolCbcApiCallAvailable : boolIsCbcApiCallAvailable
        };
        createCaseRecord(objParameters).then(() => {
            // Do nothing
        })
        .catch(error => {
            this.handleErrors(error);
        });

    }

    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.strFormId='myPrime'+this.strMemberId;
            this.fetchTabData();
            //CEAS-84840
            this.showHideMyPrime();
        } catch (exception) {
            //Do Nothing
        }
    }
    /**
     * To Fetch tab Data from WorkspaceAPI.
     * Helps to determine the Tab info..
     * All components should have this code.
     */
     fetchTabData = () => {
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
                this.processTabData(objTabData);
            })
                }
    };

    processTabData = (objTabData) => {
        try {
            this.objTabData = objTabData;
            this.strBaseCurrentTabUrl = this.objTabData.url;
        } catch (error) {
            this.handleErrors(error);
        }
    };

    // method to handle errors
    handleErrors(error) {
        this.objError = error;
        this.boolError = true;
    }

    showHideMyPrime = () => {
        let objPlanDetail = JSON.parse(JSON.stringify(this.objPlanDetails));
        let boolMyPrimeforGMS = false;
        if(objPlanDetail && objPlanDetail.coverageCodesList) {
            let lstCovrgCodesList = objPlanDetail.coverageCodesList;
            lstCovrgCodesList.forEach(function(objEachCovrgCode) {
                if (objEachCovrgCode.strCode === 'DRUG') {
                    //CEAS-84840
                    const lstVendorList = objEachCovrgCode.lstAllCoverageCodes;
                    lstVendorList.forEach(function(objEachCodeDesc) {
                        if (objEachCodeDesc.vendorCode === 'PRIM' || objEachCodeDesc.vendorCode === 'PRIM1') {
                            boolMyPrimeforGMS = true;
                        }
                    });
                }
            });
        }
        if(objPlanDetail.strAceLineOfBusiness === 'GMS' && !boolMyPrimeforGMS) {
            this.boolShowMyPrime = false;
        }
    }
}