import { LightningElement, wire,api,track } from 'lwc';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
//CEAS-82979 Platform Workspace API
import { EnclosingTabId, getTabInfo} from 'lightning/platformWorkspaceApi';
import Message_error_ACE from "@salesforce/label/c.Message_error_ACE";
import HCSCClaimsStaticResource_ACE from "@salesforce/resourceUrl/HCSCClaimsStaticResource_ACE";
import fetchMedicalRecordStatus from "@salesforce/apexContinuation/ViewMedicalRecordStatus_ACE.fetchMedicalRecordStatus";
import MemberSearch_Reset_Button_ACE from "@salesforce/label/c.MemberSearch_Reset_Button_ACE";
import ViewMedicalRecordStatus_ACE from "@salesforce/label/c.ViewMedicalRecordStatus_ACE";
import ViewClaimHistory_AddtoCaseButton_ACE from "@salesforce/label/c.ViewClaimHistory_AddtoCaseButton_ACE";
import ViewClaimHistory_NewCaseButton_ACE from "@salesforce/label/c.ViewClaimHistory_NewCaseButton_ACE";
import ReadOnlyToolTipMessage_ACE from "@salesforce/label/c.ReadOnlyToolTipMessage_ACE";
import Read_Only_Profile from "@salesforce/label/c.Read_Only_Profile";
import AMS_profile_ACE from "@salesforce/label/c.AMS_profile_ACE";
import SFDC_IT_Read_Only_profile_ACE from '@salesforce/label/c.SFDC_IT_Read_Only_profile_ACE';
import MemberSearch_SearchCriteriaErrorMessage_ACE from "@salesforce/label/c.MemberSearch_SearchCriteriaErrorMessage_ACE";

import PROFILE_NAME from '@salesforce/schema/User.Profile.Name';
import USER_ID from '@salesforce/user/Id';
import {getRecord} from 'lightning/uiRecordApi';
import fetchCaseRecords from '@salesforce/apex/ViewMedicalRecordStatus_ACE.fetchcases';
import fetchCaseRuleId from '@salesforce/apex/NewCaseCheckClass_ACE.sendCaseRuleId';
import CLAIMSRecType from '@salesforce/label/c.ViewAppealSummary_Claim_ACE';
import PreServiceRecType from '@salesforce/label/c.PreServiceReviews_Value_ACE';
import AddToCaseHoverMedicalRecords_ACE from '@salesforce/label/c.AddToCaseHoverMedicalRecords_ACE';
import NewCaseForMedicalRecordPage_ACE from '@salesforce/label/c.NewCaseForMedicalRecordPage_ACE';
import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';
import lblEnableTimeout_ACE from '@salesforce/label/c.EnableTimeout_ACE';

export default class LwcMedicalReportACE extends LightningElement {
    strUserID = USER_ID;
    profileName;
    boolShowButtons = false;
    boolReadOnly = false;
    boolshowTooltiponAddtoCase = true;
    disableSubmit = true;
    claimNumberText;
    certificationNumberText;
    npiNumber;
    boolApiError = false;
    disableReset = true;
    strSubscriberIdPassed;
    imageSource =
        HCSCClaimsStaticResource_ACE + "/Images/Rendering_Provider_Information.svg";
    infoImageURL = HCSCClaimsStaticResource_ACE + "/Images/info.png";
    planSummaryListened = false;
    boolBaseIsItSubTab;
    strBaseCurrentParentTabId;

    label = {
        MemberSearch_Reset_Button_ACE,
        ViewMedicalRecordStatus_ACE,
        ViewClaimHistory_AddtoCaseButton_ACE,
        ViewClaimHistory_NewCaseButton_ACE,
        ReadOnlyToolTipMessage_ACE,
        Read_Only_Profile,
        AMS_profile_ACE,
        CLAIMSRecType,
        PreServiceRecType,
        Message_error_ACE,
        MemberSearch_SearchCriteriaErrorMessage_ACE,
        AddToCaseHoverMedicalRecords_ACE,
        NewCaseForMedicalRecordPage_ACE,
        SFDC_IT_Read_Only_profile_ACE,
        EnableVPSTabSpecificEvents_ACE
    };

    get options() {
        return [{ label: 'Claim', value: 'Claim' }, { label: 'Prior Authorization', value: 'Prior Authorization' }];
    }
    get disableMedicalButton() {
        return this.disableSubmit || !this.planSummaryListened;
    }
    columns = [
        { label: 'Received', fieldName: 'medicalRecordsFound' , sortable: false,type: 'text' },
        { label: 'Date Received', fieldName: 'dateReceived' , sortable: false,type: 'date' },
        { label: 'Number of Pages', fieldName: 'pageCount' , sortable: false,type: 'integer'},
        { label: 'NPI', fieldName: 'npi' , sortable: false, type: 'text'},
        { label: 'Claim Number', fieldName: 'claimNumber' , sortable: false, type: 'text'},
        { label: 'Subscriber ID', fieldName: 'subscriberId' , sortable: false, type: 'text' },
        { label: 'Group Number', fieldName: 'groupNumber' , sortable: false, type: 'text' }
    ];

    columnsPriorAuth = [
        { label: 'Received', fieldName: 'priorAuthFound' , sortable: false,type: 'text' },
        { label: 'Date Received', fieldName: 'dateReceived' , sortable: false,type: 'date' },
        { label: 'Number of Pages', fieldName: 'pageCount' , sortable: false,type: 'integer'},
        { label: 'NPI', fieldName: 'npi' , sortable: false, type: 'text'},
        { label: 'Certification Number', fieldName: 'certificationNumber' , sortable: false, type: 'text'},
        { label: 'Subscriber ID', fieldName: 'subscriberId' , sortable: false, type: 'text' },
        { label: 'Group Number', fieldName: 'groupNumber' , sortable: false, type: 'text' }
    ];

    objInitTableSettings = {
        pageSize: 4,
        boolViewMore: false,
        columnsData: this.columns,
        boolSecondaryTable: false,
        boolShowFilter: false,
        boolPagination: false,
        boolShowSearch: true,
        filterData: [],
        boolShowCheckbox: false,
        boolShowHeader: true
    };

    objPriorAuthInitTableSettings = {
        pageSize: 4,
        boolViewMore: false,
        columnsData: this.columnsPriorAuth,
        boolSecondaryTable: false,
        boolShowFilter: false,
        boolPagination: false,
        boolShowSearch: true,
        filterData: [],
        boolShowCheckbox: false,
        boolShowHeader: true
    };

    @api boolIsMedicalRecordStatus = false;
    medicalResponse = [];
    @track medicalReportData = [];
    medicalReportObject = { 'medicalRecordsFound':'','priorAuthFound' : '', 'npi' : '', 'claimNumber' : '','subscriberId' : '', 'certificationNumber' : ''};
	strGroupNumber;
    strMemberId;
    strCorporationCode;
    strClientMemberId;
    boolDisableNewCaseButton = true;
    boolDisableAddCaseButton = true;
    caseRecords = [];
    strSubscriberId;
    strLineOfBusiness;
    strProviderCorpEntity;
    boolshowTooltiponNewCase = false;
    strCaseRuleId;
    caseStrNotes;
    strPlanId;
    dummy;
    @api showmodal = false;
    boolShowSpinner = false;
    strMedicalRecordsFound;
    strPriorAuthFound;
    boolRerender=false;

    @wire(EnclosingTabId) enclosingTabId;

    @wire(getRecord, {recordId : USER_ID, fields: [PROFILE_NAME] })
    userDetails({data, error}) {
        if(data) {
            this.profileName= data.fields.Profile.value.fields.Name.value;
        } else if (error) {
            this.handleErrors(error);
        } else {
            //do nothing
        }
    }

    connectedCallback() {
        //Always run this below function in Connected Callback.
        try {
            this.fetchTabData();
        } catch (error) {
            //Handle Error
        }
    }

    planSummaryListener() {
        //CEAS-75949
        if(this.label.EnableVPSTabSpecificEvents_ACE && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === "true")  {
            window.addEventListener('PlanSummaryEvent_' + this.strBaseCurrentParentTabId, this.capturePlanSummaryListener, false);
        } else {
            window.addEventListener('PlanSummaryEvent', this.capturePlanSummaryListener);
        }
    
        if (!this.planSummaryListened) {
            if (this.label.EnableVPSTabSpecificEvents_ACE && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === "true") {
                BaseLWC.helperBasePostTabIdMessageCustomEvents('TriggerPlanSummaryData_' + this.strBaseCurrentParentTabId, null, null, 'PlanCardDetails_ACE', this.strBaseCurrentParentTabId).catch(() => {});
            } else {
                BaseLWC.helperBasePostTabIdMessageCustomEvents('TriggerPlanSummaryData', null, null, 'PlanCardDetails_ACE', this.strBaseCurrentParentTabId).catch(() => {});
            }
        }
        //CEAS-75949
    }

    capturePlanSummaryListener = (planSummaryDataEvent) => {
        if (BaseLWC.isNotUndefinedOrNull(planSummaryDataEvent.detail)) {
            const planSummaryData = JSON.parse(planSummaryDataEvent.detail);

            if ((planSummaryData.strIdDestination === 'PlanCardDetails_ACE') & (planSummaryData.objParameters.strParentTabId === this.objTabData.parentTabId)) {
                //CEAS-75949
                if(this.label.EnableVPSTabSpecificEvents_ACE && this.label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === "true") {
                    window.removeEventListener('PlanSummaryEvent_' + this.strBaseCurrentParentTabId, this.capturePlanSummaryListener);
                } else {
                    window.removeEventListener('PlanSummaryEvent', this.capturePlanSummaryListener);
                }
                //CEAS-75949
                this.planSummaryListened = true;
                this.strClientMemberId = planSummaryData.objParameters.objMessage.objSelectedPlanDetails.strClientMemberId;
                this.strGroupNumber = planSummaryData.objParameters.objMessage.objSelectedPlanDetails.strGroupNumber;
                this.strMemberId = planSummaryData.objParameters.objMessage.objSelectedPlanDetails.strMemberId;
                this.strCorporationCode = planSummaryData.objParameters.objMessage.objSelectedPlanDetails.strCorporationCode;
                this.strLineOfBusiness = planSummaryData.objParameters.objMessage.objSelectedPlanDetails.strAceLineOfBusiness;
                this.strPlanId = planSummaryData.objParameters.objMessage.objSelectedPlanDetails.strPolicyId;

            }
        }
    };

    fetchTabData() {
        if(this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then((objTabData) => {
                this.objTabData = objTabData;
                // CEAS-75949
                this.boolBaseIsItSubTab = this.objTabData.isSubtab;
                if (this.boolBaseIsItSubTab === true) {
                    this.strBaseCurrentParentTabId = this.objTabData.parentTabId;
                } else {
                    this.strBaseCurrentParentTabId = this.objTabData.tabId;
                }
                // CEAS-75949
                const strURL = this.objTabData.url;
                const strMid = BaseLWC.helperBaseGetUrlParameters('mid', strURL);
                this.strProviderCorpEntity = BaseLWC.helperBaseGetUrlParameters('corpCode', strURL);
                this.strSubscriberId = BaseLWC.helperBaseGetUrlParameters('subscriberId', strURL);
                const strProviderData = window.localStorage.getItem('lstProviderData_ACE');

                if (strProviderData !== null && strProviderData !== '') {
                    const lstProviderStorage = JSON.parse(strProviderData);
                    lstProviderStorage.forEach((element) => {
                        if (element.mid === strMid) {
                            this.npiNumber = element.strNpid;
                        }
                    });
                }
                this.planSummaryListener();
                this.validateSubmit();
            })
            .catch(() => {
                this.handleErrors();
            });
    }
    }
    executeInitialFunctionality() {
        if (this.objTabData.isSubtab === true) {
            //Always segregate the Main tab and Sub tab functions.
            this.executeSubTabFunctionality();
        } else if (this.objTabData.isSubtab === false) {
            //Always segregate the Main tab and Sub tab functions.
            this.executeMainTabFunctionality();
        } else {
            //Do nothing
        }
    }
    handleErrors(error) {
        this.boolError = error;
    }
    executeMainTabFunctionality() {
        this.boolPrimaryTab = true;
    }

    executeSubTabFunctionality() {
        this.boolPrimaryTab = false;
    }

    get addToCaseStyle() {
        if (this.boolReadOnly || this.boolDisableAddCaseButton) {
            return `slds-button slds-button_neutral addtoCasestyle addnewCase`;
        } else {
            return `slds-button slds-button_neutral addtoCasestyle`;
        }
    }
    set addToCaseStyle(value) {
        this.dummy = value;
    }
    get newCaseStyle() {
        if (this.boolReadOnly || this.boolDisableNewCaseButton) {
            return `slds-button slds-button_neutral newCasestyle addnewCase`;
        } else {
            return `slds-button slds-button_neutral newCasestyle`;
        }
    }
    set newCaseStyle(value) {
        this.dummy = value;
    }
    medicalClaims = true;
    medicalPriorAuth = false;
    strRecordTypeSelected = 'Claim';
    certificationNumberText;

    handleRecordTypeChange(event) {
        this.strRecordTypeSelected = event.target.value;
        if (this.strRecordTypeSelected === 'Claim') {
            this.medicalClaims = true;
            this.medicalPriorAuth = false;
        } else if (this.strRecordTypeSelected === 'Prior Authorization') {
            this.medicalPriorAuth = true;
            this.medicalClaims = false;
        } else {
            //do nothing
        }
        this.boolShowButtons = false;
        this.medicalReportData = [];
        this.boolApiError = false;
        this.boolIsMedicalRecordStatus = false;
        this.showmodal = false;
        this.boolDisableAddCaseButton = true;
        this.boolDisableNewCaseButton = true;
    }
    handleClick() {
        if (this.strSubscriberId.startsWith('0')) {
            this.strSubscriberIdPassed = this.strSubscriberId.slice(3);
        }
        this.boolShowSpinner = true;
        this.medicalReportData = [];
        setTimeout(function () {
            this.boolIsMedicalRecordStatus = false;
        }.bind(this), 0.0001);
        fetchMedicalRecordStatus({
            strNPi: this.npiNumber,
            strClaimNumber: this.claimNumberText,
            strCertificationNumber: this.certificationNumberText,
            strSubscriberId: this.strSubscriberIdPassed,
            strCorpCode: this.strProviderCorpEntity,
            strRecordTypeSelected: this.strRecordTypeSelected
        })
            .then((objResult) => {
                try {
                    this.boolApiError = false;
                    this.boolShowSpinner = false;
                    if (this.profileName && (this.label.Read_Only_Profile.split(',').includes(this.profileName) || this.profileName === this.label.AMS_profile_ACE)) {
                        this.boolReadOnly = true;
                        this.boolDisableAddCaseButton = true;
                        this.boolDisableNewCaseButton = true;
                    }
                    this.medicalResponse = JSON.parse(objResult);

                    if (this.medicalResponse.images.length > 4) {
                        this.medicalResponse.images = this.medicalResponse.images.slice(0, 4);
                    }
                    if (this.medicalClaims) {
                        this.medicalReportObject.medicalRecordsFound = this.medicalResponse.medicalRecordsFound;
                        this.medicalReportObject.claimNumber = this.medicalResponse.claimNumber;
                    } else {
                        this.medicalReportObject.priorAuthFound = this.medicalResponse.priorAuthFound;
                        this.medicalReportObject.certificationNumber = this.medicalResponse.certificationNumber;
                    }

                    this.medicalReportObject.subscriberId = this.medicalResponse.subscriberId;
                    this.medicalReportObject.npi = this.medicalResponse.npi;
                    this.caseStrNotes = '';

                    if (this.medicalResponse.images.length > 0) {
                        this.medicalResponse.images.map((itrRow, intIndex) => {
                            const [year, month, day] = itrRow['dateReceived'].split('-');
                            if (this.medicalClaims) {
                                if (this.medicalReportObject.medicalRecordsFound) {
                                    this.strMedicalRecordsFound = 'Yes';
                                } else {
                                    this.strMedicalRecordsFound = 'No';
                                }

                                this.medicalReportData[intIndex] = {
                                    medicalRecordsFound: this.strMedicalRecordsFound,
                                    npi: this.medicalReportObject.npi,
                                    claimNumber: this.medicalReportObject.claimNumber,
                                    subscriberId: this.medicalReportObject.subscriberId,
                                    pageCount: itrRow['pageCount'],
                                    dateReceived: itrRow['dateReceived'],
                                    groupNumber: itrRow['groupNumber']
                                };
                                this.caseStrNotes += `Received: ${this.strMedicalRecordsFound} Date Received: ${[month, day, year].join('/')} Claim #: ${this.medicalReportObject.claimNumber}\n`;
                            } else {
                                if (this.medicalReportObject.priorAuthFound) {
                                    this.strPriorAuthFound = 'Yes';
                                } else {
                                    this.strPriorAuthFound = 'No';
                                }
                                this.medicalReportData[intIndex] = {
                                    priorAuthFound: this.strPriorAuthFound,
                                    npi: this.medicalReportObject.npi,
                                    certificationNumber: this.medicalReportObject.certificationNumber,
                                    subscriberId: this.medicalReportObject.subscriberId,
                                    pageCount: itrRow['pageCount'],
                                    dateReceived: itrRow['dateReceived'],
                                    groupNumber: itrRow['groupNumber']
                                };
                                this.caseStrNotes += `Received: ${this.strPriorAuthFound} Date Received: ${[month, day, year].join('/')} Certification #: ${
                                    this.medicalReportObject.certificationNumber
                                }\n`;
                            }
                        });
                    }
                    if  (!this.medicalReportObject.medicalRecordsFound) {
                        this.strMedicalRecordsFound = 'No';
                    }
                    if (!this.medicalReportObject.priorAuthFound) {
                        this.strPriorAuthFound = 'No';
                    }

                    if (this.medicalResponse.images.length === 0) {
                        if (this.strRecordTypeSelected === 'Claim') {
                            this.medicalReportData[0] = {
                                medicalRecordsFound: this.strMedicalRecordsFound,
                                npi: this.medicalReportObject.npi,
                                claimNumber: this.medicalReportObject.claimNumber,
                                subscriberId: this.medicalReportObject.subscriberId,
                                pageCount: '-',
                                dateReceived: '-',
                                groupNumber: '-'
                            };
                            this.caseStrNotes += `Received: No Date Received: Claim #: ${this.medicalReportObject.claimNumber}\n`;
                        } else if (this.strRecordTypeSelected === 'Prior Authorization') {
                            this.medicalReportData[0] = {
                                priorAuthFound: this.strPriorAuthFound,
                                npi: this.medicalReportObject.npi,
                                certificationNumber: this.medicalReportObject.certificationNumber,
                                subscriberId: this.medicalReportObject.subscriberId,
                                pageCount: '-',
                                dateReceived: '-',
                                groupNumber: '-'
                            };
                            this.caseStrNotes += `Received: No Date Received: Certification #: ${this.medicalReportObject.certificationNumber}\n`;
                        } else {
                            //do nothing
                        }
                    }
                } catch (error) {
                    this.handleErrors(error);
                }
            
                this.caseStrNotes = this.caseStrNotes.trim();
                if (this.medicalReportData.length <= 4) {
                    this.boolIsMedicalRecordStatus = true;
                }
                this.enableDisableAddToCaseNewCase();
            })
            .catch((error) => {
                this.boolApiError = true;
                this.boolShowSpinner = false;
                this.boolDisableAddCaseButton = true;
                this.boolDisableNewCaseButton = true;
                this.boolShowButtons = false;
                this.handleErrors(error);
            });
    }

    handleReset() {
        this.boolRerender=true;
        setTimeout(function () {
            this.boolRerender = false;
        }.bind(this), 200);
        this.claimNumberText = '';
        this.certificationNumberText = '';
        this.boolShowButtons = false;
        this.medicalReportData = [];
        this.boolApiError = false;
        this.boolIsMedicalRecordStatus = false;
        this.showmodal = false;
        this.boolDisableAddCaseButton = true;
        this.boolDisableNewCaseButton = true;
        this.validateSubmit();
    }
    handleInputChange(event) {
        if (event.target.label === 'subscriberID') {
            this.strSubscriberId = event.target.value;
        } else if (event.target.name === 'npiNumber') {
            this.npiNumber = event.target.value;
            this.validateSubmit();
        } else if (event.target.name === 'claimNumberText') {
            this.claimNumberText = event.target.value;
            this.validateSubmit();
        } else if (event.target.name === 'certificationNumberText') {
            this.certificationNumberText = event.target.value;
            this.validateSubmit();
        } else {
            //do nothing
        }
    }
    validateSubmit() {
        if (this.medicalClaims) {
            if (
                this.npiNumber === undefined ||
                !this.npiNumber.match('^[0-9]{10}$') ||
                this.claimNumberText === undefined ||
                !this.claimNumberText.match('^([a-zA-Z0-9]{13}|[a-zA-Z0-9]{15}|[a-zA-Z0-9]{17})$')
            ) {
                this.disableSubmit = true;
            } else {
                this.disableSubmit = false;
            }

            if ((this.npiNumber !== undefined && this.npiNumber !== '') || (this.claimNumberText !== undefined && this.claimNumberText !== '')) {
                this.disableReset = false;
            } else {
                this.disableReset = true;
            }
        } else {
            if (
                this.npiNumber === undefined ||
                !this.npiNumber.match('^[0-9]{10}$') ||
                this.certificationNumberText === undefined ||
                !this.certificationNumberText.match('^([a-zA-Z0-9]{10}|[a-zA-Z0-9]{11})$')
            ) {
                this.disableSubmit = true;
            } else {
                this.disableSubmit = false;
            }

            if ((this.npiNumber !== undefined && this.npiNumber !== '') || (this.certificationNumberText !== undefined && this.certificationNumberText !== '')) {
                this.disableReset = false;
            } else {
                this.disableReset = true;
            }
        }
    }


    showTooltip() {
        if (this.boolReadOnly || this.boolDisableAddCaseButton) {
            this.boolshowTooltiponAddtoCase = true;
            const btnPos = this.template.querySelector('.btnAddCases').getBoundingClientRect();
            setTimeout(function() {
                if (this.template.querySelector('.addToCase')) {
                    this.template.querySelector('.addToCase').style.right = document.body.clientWidth - (btnPos.left + btnPos.width) + 'px';
                    this.template.querySelector('.addToCase').style.top = btnPos.height + 16 + 'px';
                    this.template.querySelector('.addToCase').style.visibility = 'visible';
                }
            }.bind(this), 10);
        }
    }

    showTooltiponNewCase() {
        if (this.boolReadOnly) {
            this.boolshowTooltiponNewCase = true;
            const btnPos = this.template.querySelector('.btnNewCases').getBoundingClientRect();
            setTimeout(function() {
                if (this.template.querySelector('.newCase')) {
                    this.template.querySelector('.newCase').style.right = document.body.clientWidth - (btnPos.left + btnPos.width) + 'px';
                    this.template.querySelector('.newCase').style.top = btnPos.height + 16 + 'px';
                    this.template.querySelector('.newCase').style.visibility = 'visible';
                }
            }.bind(this), 10);
        }
    }

    hideTooltip() {
        this.boolshowTooltiponAddtoCase = false;
    }
    hideTooltiponNewCase() {
        this.boolshowTooltiponNewCase = false;
    }
    //CEAS-65630
    handleNewCase() {
    let objCaseDefaults;
        if (this.medicalClaims) {
            objCaseDefaults = {
                Benefit_Claim_Type_ACE__c: 'Medical',
                Review_Type_ACE__c: 'Medical Record Review',
                Notes__c: this.caseStrNotes,
                Id: this.strCaseRuleId,
                View_Medical_Record_Status_Viewer_used__c: true,
                Line_of_business_ACE__c: this.strLineOfBusiness
            };
        } else if (this.medicalPriorAuth) {
            objCaseDefaults = {
                Benefit_Claim_Type_ACE__c: 'Medical',
                Notes__c: this.caseStrNotes,
                Id: this.strCaseRuleId,
                View_Medical_Record_Status_Viewer_used__c: true,
                Line_of_business_ACE__c: this.strLineOfBusiness
            };
        } else {
            //do nothing
        }

        const strProviderData = window.localStorage.getItem('lstProviderData_ACE');
        if (strProviderData !== undefined && strProviderData !== null) {
            const lstProviderStorage = JSON.parse(strProviderData);
            lstProviderStorage.forEach((element) => {
                if (element.mid === this.strMemberId) {
                    if (element.providerDetails !== undefined && element.providerDetails !== null) {
                        const strProviderDetails = JSON.parse(element.providerDetails);
                        if (strProviderDetails) {
                            objCaseDefaults.ProviderNPI_ACE__c =  this.validateData(strProviderDetails.strNPI);
                            objCaseDefaults.ProviderStreet_ACE__c = this.validateData(strProviderDetails.straddressLine1);
                            objCaseDefaults.TaxId_ACE__c = this.validateData(strProviderDetails.strTaxID);
                            objCaseDefaults.ProviderCity_ACE__c = this.validateData(strProviderDetails.strcity);
                            objCaseDefaults.ProviderState_ACE__c = this.validateData(strProviderDetails.strstateCode);
                            objCaseDefaults.Provider_Corporation_Code__c = this.validateData(strProviderDetails.strcorporateEntityCode);
                            objCaseDefaults.ProviderZipCode_ACE__c = this.validateData(strProviderDetails.strpostalCode);
                            objCaseDefaults.ProviderInfoName_ACE__c = this.validateData(strProviderDetails.strInstitutionalName);
                            objCaseDefaults.ProviderNetworkStatus_ACE__c = this.validateData(strProviderDetails.strNetworkStatus);
                            objCaseDefaults.ProviderFaxNumber_ACE__c = this.validateData(strProviderDetails.strFaxNumber);
                            objCaseDefaults.ProviderNumber_ACE__c = this.validateData(strProviderDetails.strProviderNumber);
                        }
                    }
                }
            });
        }
        objCaseDefaults = JSON.stringify(objCaseDefaults);
        const objMIDPlanId = {
            strPlanId: this.strPlanId,
            strMid: this.strMemberId
        };
        const objParameterData = {
            objCaseDefaults: objCaseDefaults,
            objMIDPlanId: objMIDPlanId
        };
        const strMedEventDestinationId = this.label.NewCaseForMedicalRecordPage_ACE + '_' + this.objTabData.tabId;
        BaseLWC.fireCustomEvent(this.label.NewCaseForMedicalRecordPage_ACE, objParameterData, strMedEventDestinationId, true, this.objTabData.tabId);
    }

    //validate data is correct
    validateData(data) {
        if(data) {
            return data;
        } else {
            return '';
        }
    }
    async enableDisableAddToCaseNewCase() {
        try {
            let CaseRuleType;
            if (this.strRecordTypeSelected === 'Claim') {
                CaseRuleType = this.label.CLAIMSRecType;
            } else if (this.strRecordTypeSelected === 'Prior Authorization') {
                CaseRuleType = this.label.PreServiceRecType;
            } else {
                //do nothing
            }
            this.boolDisableNewCaseButton = true;
            this.boolDisableAddCaseButton = true;
            this.boolShowButtons = false;
            this.showmodal = false;
            const promisesArray = [];
            if (BaseLWC.stringIsNotBlank(this.strLineOfBusiness)) {
                promisesArray.push(
                    fetchCaseRuleId({
                        caseRule: CaseRuleType,
                        strLineOfBusiness: this.strLineOfBusiness
                    })
                );
            }
            if (
                BaseLWC.isNotUndefinedOrNull(this.strClientMemberId) &&
                BaseLWC.isNotUndefinedOrNull(this.strGroupNumber) &&
                BaseLWC.isNotUndefinedOrNull(this.strMemberId) &&
                BaseLWC.isNotUndefinedOrNull(this.strCorporationCode)
            ) {
                promisesArray.push(
                    fetchCaseRecords({
                        mid: this.strMemberId,
                        groupNumber: this.strGroupNumber,
                        corpCode: this.strCorporationCode,
                        cmid: this.strClientMemberId
                    })
                );
            }
            const objResult = await Promise.all(promisesArray);
            const [caseRuleId, caseRec] = objResult;
            if (BaseLWC.isNotUndefinedOrNull(caseRuleId)) {
                this.strCaseRuleId = caseRuleId.Id;
            }
            if (caseRec.length === 0) {
                this.boolDisableNewCaseButton = false;
            } else {
                this.caseRecords = caseRec;
                this.boolDisableAddCaseButton = false;
                this.boolDisableNewCaseButton = false;
            }
            this.boolShowButtons = true;
        } catch (objError) {
            this.boolShowButtons = false;
            this.boolDisableAddCaseButton = true;
            this.boolDisableNewCaseButton = true;
        }
    }
    handleAddToCase() {
        this.showmodal = true;
    }
    closemodal() {
        this.showmodal = false;
    }
}
