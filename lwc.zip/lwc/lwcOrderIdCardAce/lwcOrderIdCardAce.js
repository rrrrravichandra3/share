//Created by Adarsh Dandriyal. 
import {LightningElement,api,wire} from 'lwc';
import BaseLWC from 'c/baseLWCFunctions_CF'; //Base LWC functions.
import {getPicklistValues,getObjectInfo} from 'lightning/uiObjectInfoApi';
import CreateCasePage_IdCardRequest_ACE from '@salesforce/label/c.CreateCasePage_IdCardRequest_ACE';
import IDCardRecipient_ACE from '@salesforce/label/c.IDCardRecipient_ACE';
import IDCardDeliveryMethod_ACE from '@salesforce/label/c.IDCardDeliveryMethod_ACE';
import IDCardRequiredError_ACE from '@salesforce/label/c.IDCardRequiredError_ACE';
import IDCardCaseOrigin_ACE from '@salesforce/label/c.IDCardCaseOrigin_ACE';
import IDCardCardType_ACE from '@salesforce/label/c.IDCardCardType_ACE';
import IDCardStatus_ACE from '@salesforce/label/c.IDCardStatus_ACE';
import IDCardSUBStatus_ACE from '@salesforce/label/c.IDCardSUBStatus_ACE';
import IDCardFaxToMember_ACE from '@salesforce/label/c.IDCardFaxToMember_ACE';
import IDCardFaxNotAvailable_ACE from '@salesforce/label/c.IDCardFaxNotAvailable_ACE';
import IDCardFaxToProvider_ACE from '@salesforce/label/c.IDCardFaxToProvider_ACE';
import IDCardFaxNumber_ACE from '@salesforce/label/c.IDCardFaxNumber_ACE';
import IDCardProviderName_ACE from '@salesforce/label/c.IDCardProviderName_ACE';
import IDCardMailToMember_ACE from '@salesforce/label/c.IDCardMailToMember_ACE';
import IDCardMember_ACE from '@salesforce/label/c.IDCardMember_ACE';
import IDCardAddress_ACE from '@salesforce/label/c.IDCardAddress_ACE';
import IDCardAlternateAddress_ACE from '@salesforce/label/c.IDCardAlternateAddress_ACE';
import IDCardState_ACE from '@salesforce/label/c.IDCardState_ACE';
import IDCardInCareOf_ACE from '@salesforce/label/c.IDCardInCareOf_ACE';
import IDCardCity_ACE from '@salesforce/label/c.IDCardCity_ACE';
import IDCardZipCode_ACE from '@salesforce/label/c.IDCardZipCode_ACE';
import IDCardCaseSubmited_ACE from '@salesforce/label/c.IDCardCaseSubmited_ACE';
import IDCardType_ACE from '@salesforce/label/c.IDCardType_ACE';
import IDCardSubType_ACE from '@salesforce/label/c.IDCardSubType_ACE';
import IDCardPendedCaseMessagePRefix_ACE from '@salesforce/label/c.IDCardPendedCaseMessagePRefix_ACE';
import IDCardPendedCaseMessageSuffix_ACE from '@salesforce/label/c.IDCardPendedCaseMessageSuffix_ACE';
import CreateCasePage_GovMedicareValue_ACE from '@salesforce/label/c.CreateCasePage_GovMedicareValue_ACE';
import CreateCasePage_GovMediciadValue_ACE from '@salesforce/label/c.CreateCasePage_GovMediciadValue_ACE';
import ViewClaimHistory_Medical_ACE from '@salesforce/label/c.ViewClaimHistory_Medical_ACE';
import Medical_PharmacyLabel_ACE from '@salesforce/label/c.Medical_PharmacyLabel_ACE';
import PhysicalOrderReasonLabel_ACE from '@salesforce/label/c.PhysicalOrderReasonLabel_ACE';
import IDCardIntegrationError_ACE from '@salesforce/label/c.IDCardIntegrationError_ACE';
import MAPDIdCardWarningMessage from '@salesforce/label/c.MAPDIdCardWarningMessage';
import MAPDOrderIdCardExistingRequestMessage from '@salesforce/label/c.MAPDOrderIdCardExistingRequestMessage';
import ViewClaimsMedicalStatistics_Withdrawn_ACE from '@salesforce/label/c.CreateCasePage_Withdrawn_ACE';
import IDCardEmailToMember_ACE from '@salesforce/label/c.IDCardEmailToMember_ACE';
import IDCardEmailToProv_ACE from '@salesforce/label/c.IDCardEmailToProv_ACE';
import CYFDCodes_ACE from '@salesforce/label/c.CYFDCodes_ACE';
import OrderIdCardErrorMessageEmail_ACE from '@salesforce/label/c.OrderIdCardErrorMessageEmail_ACE';
import OrderIdCardSuccessMessageEmail_ACE from '@salesforce/label/c.OrderIdCardSuccessMessageEmail_ACE';
import ResponsiblePartyLabel_ACE from '@salesforce/label/c.ResponsiblePartyLabel_ACE';
import SpinnerWarningMessageOrderIdcard_ACE from '@salesforce/label/c.SpinnerWarningMessageOrderIdcard_ACE';
import MemberContactDetails_EmailInvalidMessage_ACE from '@salesforce/label/c.MemberContactDetails_EmailInvalidMessage_ACE';
import case_object from '@salesforce/schema/Case';
import submitCaseFromIdCard from '@salesforce/apexContinuation/IdCardController_ACE.submitCaseFromIdCard';
import facetsUpdateTempAddress from '@salesforce/apexContinuation/CreateChildCaseController_ACE.facetsUpdateTempAddress';
import orderIdcardCallout from '@salesforce/apexContinuation/OrderIdCardController_ACE.orderIdcardCallout';
import SelfServiceRecipient_Field from '@salesforce/schema/Case.SelfServiceRecipient_ACE__c';
import DeliveryMethod_Field from '@salesforce/schema/Case.DeliveryMethod_ACE__c';
import CaseOrigin_Field from '@salesforce/schema/Case.Origin';
import Status_Field from '@salesforce/schema/Case.Status';
import PhysicalOrderReason_Field from '@salesforce/schema/Case.Physical_Order_Reason_ACE__c';
import RequestType_Field from '@salesforce/schema/Case.Request_Type_ACE__c';
import SubStatus_Field from '@salesforce/schema/Case.Sub_Status_ACE__c';
import {getRecord} from 'lightning/uiRecordApi';
import InquirerName_Field from '@salesforce/schema/InteractionLog_ACE__c.InquirerName_ACE__c';
import InquirerNameRelationship_Field from '@salesforce/schema/InteractionLog_ACE__c.Inquirer_Relationship_ACE__c';
import RecordTypeFormula_Field from '@salesforce/schema/InteractionLog_ACE__c.RecordTypeFormulaACE__c';
import CallType_Field from '@salesforce/schema/InteractionLog_ACE__c.Call_Type_ACE__c';
import IVRAuthenticated_Field from '@salesforce/schema/InteractionLog_ACE__c.IVRAuthenticated_ACE__c';
import ProviderInformationDetails_Field from '@salesforce/schema/InteractionLog_ACE__c.ProviderInformationDetails_ACE__c';
import State_Field from '@salesforce/schema/Case.StateIdCard_ACE__c';
import getOrderIdCardCasesIfAny from '@salesforce/apex/OrderIdCardController_ACE.getOrderIdCardCasesIfAny';
import fetchLastMailedDateOnIdCard from '@salesforce/apexContinuation/IdCardHelper_ACE.fetchLastMailedDateOnIdCard';
export default class LwcOrderIdCardAce extends LightningElement {
    /*Variables*/
    /*Track Variables*/
    showModal = false;
    /*Api Variables*/
    @api currentTabId;
    @api strPlanSummaryData;
    @api recordTypeId;
    @api objCommunicationPreferenceData;
    @api strLanguage;
    @api strAccountId;
    @api strInteractionLogId;
    @api strRecordId;
    @api strEmail;
    //CEAS-70901
    @api strLastUpdatedDate = '';
    //CEAS-74286
    strEmailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    boolIsNMCC = false;
    lstRecipient = [];
    lstDeliveryMethod = [];
    /*List Variables*/
    lstDeliveryMethodBackup = [];
    lstFamilyMemberNameOfOrderCard = [];
    objRequestForCardType = [];
    listOfFamilyname = [];
    lstHeaderOrder = [];
    lstStatus = [];
    lstCardType = [];
    lstState = [];
    lstSubStatus = [];
    lstCaseOrigin = [];
    lstsupressedLables = [];
    /*String Variables*/
    caseOriginDefaultValues = '';
    caseOriginDefaultValuesBackup = '';
    strUniqueIdentifier = '';
    strCaseAccount = '';
    boolEmailStatus = false;
    statusEmailDefaultValue = '';
    strCaseIdEmail = '';
    strCaseURL = '';
    objFamilyCardTypeHeader;
    recipientDefaultValue;
    deliveryMethodDefaultValue;
    strAddressOfMember = '';
    strFaxNumberFormatted = '';
    strFaxNumber;
    strAlternateAddressOfMember = '';
    strIdCardLevelIndicator;
    SubstatusDefaultValue = '';
    strSubscriberName = '';
    strCMIDUI = '';
    statusDefaultValue;
    strCardTypeDefaultValue = '';
    objPlanData;
    isSubmitResultText;
    caseNumbers;
    caseNumbersPended;
    caseType;
    caseSubtype;
    strInCareOf = '';
    strADDRESS = '';
    strCity = '';
    strState = '';
    strZipCode = '';
    strInquirerName = '';
    strInquirerRelationship = '';
    strRecordTypeName = '';
    strErrorSectionName = '';
    strErrorSection = '';
    strProviderInfoIdCard = '';
    isLoaded = false;
    boolStatusDisabled = false;
    isSubmitResultSuccess = false;
    boolIsRecipientAndMail = false;
    boolEmailIsRecipientAndMail = false;
    boolEmailIsRecipientAndProv = false;
    boolFaxIsRecipientAndMail = false;
    boolFaxIsRecipientAndProv = false;
    boolTempToast = false;
    isSubmitEnabled = true;
    boolSubstatus = false;
    boolMailAddress = true;
    boolAlteranteMailAddress = false;
    boolAddressNotAvailable = false;
    isError = false;
    isResultPendedSuccess = false;
    isResultPendedSuccessWithNoCases = false;
    isResultSuccess = false;
    boolCaseOrigin = false;
    boolrefresh = true;
    boolApiError = false;
    boolStandAloneCards = false;
    isApiError = false;
    isdeliveryMethodDefault = false;
    show10daysMessage = false;
    casePhysicalOrderReasonValue;
    lstCasePhysicalOrderReason;
    lstCaseRequestType;
    caseRequestTypeValue;
    objError = {};

    @api get boolCasePhysicalOrderReason() {
        return this.deliveryMethodDefaultValue === 'Mail' && this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMediciadValue_ACE && this.lstCasePhysicalOrderReason && this.lstCasePhysicalOrderReason.length > 0;
    }

    @api get boolCaseRequestType() {
        return this.deliveryMethodDefaultValue === 'Mail' && this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL' && this.lstCaseRequestType && this.lstCaseRequestType.length > 0;
    }

    @api get boolDisabled() {
        return this.deliveryMethodDefaultValue === 'Mail' && this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL';
    }
    strEmailDefault = '';
    boolEmailDefault = true;
    @api get showResponsiblePartyCheckbox() {
        return (this.deliveryMethodDefaultValue === 'Email' || this.deliveryMethodDefaultValue === 'Fax' ) && this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMediciadValue_ACE && this.strPlanSummaryData.strMedicaidEligibilityCode && this.label.CYFDCodes_ACE.includes(this.strPlanSummaryData.strMedicaidEligibilityCode);
    }
    //change success message based on deliveryMethod
    get getStrSuccessMessage() {
        if(this.deliveryMethodDefaultValue === 'Email') {
            return this.label.OrderIdCardSuccessMessageEmail_ACE;
        } else {
            return 'Case created and closed successfully. Your request for a fax has been successfully submitted.';
        }
    }
    strProvider;
    boolResponsibleParty = false;

    /*Map Variables*/
    mapOfFamilyMemberAndMemberNumber = {};
    MapOfFamilyMemberNameAndMemberId = {};
    MapOfFamilyMemberNumberAndMid = {};
    MapOfFamilyMemberIdAndCMID = {};
    MapOfDataforEmail = {};

    label = {
        CreateCasePage_IdCardRequest_ACE,
        IDCardRecipient_ACE,
        IDCardDeliveryMethod_ACE,
        IDCardRequiredError_ACE,
        IDCardCaseOrigin_ACE,
        IDCardCardType_ACE,
        IDCardStatus_ACE,
        IDCardSUBStatus_ACE,
        IDCardMailToMember_ACE,
        IDCardMember_ACE,
        IDCardAddress_ACE,
        IDCardAlternateAddress_ACE,
        IDCardState_ACE,
        IDCardInCareOf_ACE,
        IDCardCity_ACE,
        IDCardFaxToMember_ACE,
        IDCardFaxNotAvailable_ACE,
        IDCardFaxToProvider_ACE,
        IDCardFaxNumber_ACE,
        IDCardProviderName_ACE,
        IDCardZipCode_ACE,
        IDCardCaseSubmited_ACE,
        IDCardType_ACE,
        IDCardSubType_ACE,
        IDCardPendedCaseMessagePRefix_ACE,
        IDCardPendedCaseMessageSuffix_ACE,
        IDCardIntegrationError_ACE,
        MAPDIdCardWarningMessage,
        MAPDOrderIdCardExistingRequestMessage,
        ViewClaimsMedicalStatistics_Withdrawn_ACE,
        CreateCasePage_GovMedicareValue_ACE,
        CreateCasePage_GovMediciadValue_ACE,
        ViewClaimHistory_Medical_ACE,
        Medical_PharmacyLabel_ACE,
        PhysicalOrderReasonLabel_ACE,
        IDCardEmailToMember_ACE,
        IDCardEmailToProv_ACE,
        CYFDCodes_ACE,
        OrderIdCardErrorMessageEmail_ACE,
        OrderIdCardSuccessMessageEmail_ACE,
        ResponsiblePartyLabel_ACE,
        SpinnerWarningMessageOrderIdcard_ACE,
        MemberContactDetails_EmailInvalidMessage_ACE
   };
    /*To Get Case Object Info*/
    @wire(getObjectInfo, {
        objectApiName: case_object
    })
    objectInfo;
    /*To Fetch Recipeint PickList Value*/
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: SelfServiceRecipient_Field
    })
    recipientPicklistValues({
        error,
        data
    }) {
        if (data && data.values) {
            this.isError = false;
            const lstLocalRecipientValues = [];
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                //CEAS-55766
                if(this.strPlanSummaryData.strAceLineOfBusiness && ((this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMedicareValue_ACE && objType.value ==='Member') ||  this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMediciadValue_ACE)) {
                    lstLocalRecipientValues.push(objType);
                }
            }
            this.recipientDefaultValue = 'Member';
            this.lstRecipient = lstLocalRecipientValues;


        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Fetch Case Origin PickList Value*/
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: CaseOrigin_Field
    })
    originPicklistValues({
        error,
        data
    }) {
        if (data && data.values) {
            this.isError = false;
            const objTypeNull = {
                label: '--None--',
                value: ''
            };

            const lstLocaloriginvalues = [];
            lstLocaloriginvalues.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocaloriginvalues.push(objType)
            }
            this.caseOriginDefaultValues = 'TELEPHONE';
            this.caseOriginDefaultValuesBackup = 'TELEPHONE';
            this.lstCaseOrigin = lstLocaloriginvalues;


        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: DeliveryMethod_Field
    })
    deliveryPicklistValues({
        error,
        data
    }) {
        if (data && data.values) {
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocalDeliveryMethodValues = [];
            lstLocalDeliveryMethodValues.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;

                 //Right for MAPD and nmcc only two delivery methods are available if in future if there afre more please add lob check as well
                 if(this.strPlanSummaryData.strAceLineOfBusiness && (this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMediciadValue_ACE || (this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMedicareValue_ACE && (objType.value==='Directed to Self-Service' || objType.value==='Mail')))) {
                    lstLocalDeliveryMethodValues.push(objType);
                 }
            }
            this.deliveryMethodDefaultValue = 'Mail';
            this.lstDeliveryMethod = lstLocalDeliveryMethodValues;
            this.lstDeliveryMethodBackup = lstLocalDeliveryMethodValues;
            this.isError = false;
            this.showDisableSubmitButton()

        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: RequestType_Field
    })
    requestTypePicklistValues({error,data}) {
        if (data && data.values) {

            const lstLocalRequestType = [];

            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalRequestType.push(objType);

            }
            this.lstCaseRequestType = lstLocalRequestType;
            this.caseRequestTypeValue = 'Duplicate ID Card';
            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: PhysicalOrderReason_Field
    })
    physicalOrderReasonPicklistValues({error,data}) {
        if (data && data.values) {

            const lstLocalPhysicalOrderReason = [];
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            lstLocalPhysicalOrderReason.push(objTypeNull);

            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalPhysicalOrderReason.push(objType);

            }
            this.lstCasePhysicalOrderReason = lstLocalPhysicalOrderReason;
            this.casePhysicalOrderReasonValue = '--None--';
            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: Status_Field
    })
    statusPicklistValues({
        error,
        data
    }) {
        if (data && data.values) {

            const lstLocalStatus = [];

            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalStatus.push(objType);

            }
            if(this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL') {
                this.statusDefaultValue = 'Pended';
                this.SubstatusDefaultValue = 'Personal Pend';
                this.boolSubstatus = true;
            } else {
                this.statusDefaultValue = 'Closed';
            }
            
           this.lstStatus = lstLocalStatus;
            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Fetch Sub Status PickList Value*/
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: SubStatus_Field
    })
    subStatusPicklistValues({
        error,
        data
    }) {
        if (data && data.values) {
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocalSubStatus = [];
            lstLocalSubStatus.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalSubStatus.push(objType);

            }

            if(this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL') {
                this.SubstatusDefaultValue = 'Personal Pend';
                this.boolSubstatus = true;
            } else {
                this.SubstatusDefaultValue = lstLocalSubStatus[0].label;
            }

            this.lstSubStatus = lstLocalSubStatus;

            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Fetch State PickList Value*/
    @wire(getPicklistValues, {
        recordTypeId: '$recordTypeId',
        fieldApiName: State_Field
    })
    statePicklistValues({
        error,
        data
    }) {
        if (data && data.values) {
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            const lstLocalstate = [];
            lstLocalstate.push(objTypeNull);
            for (let i = 0; i < data.values.length; i++) {
                const objType = {
                    label: null,
                    value: null
                };
                objType.label = data.values[i].label;
                objType.value = data.values[i].value;
                lstLocalstate.push(objType);

            }
            this.strState = lstLocalstate[0].label;
            this.lstState = lstLocalstate;
            this.isError = false;
        } else if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else {
            /*Do nothing */
        }
    }
    /*To Get Interaction Log Id and Other Paramters*/
    @wire(getRecord, {
        recordId: '$strInteractionLogId',
        fields: [InquirerName_Field, InquirerNameRelationship_Field, RecordTypeFormula_Field, CallType_Field, IVRAuthenticated_Field, ProviderInformationDetails_Field]
    })
    wiredInteractionRecord({
        error,
        data
    }) {
        if (error) {
            this.isError = true;
            this.isLoaded = !this.isLoaded;
        } else if (data) {

            if (data.recordTypeInfo !== undefined && data.recordTypeInfo !== null) {
                let strDefaultCaseOrigin = '';
                this.strRecordTypeName = data.recordTypeInfo.name;
                if (data.recordTypeInfo.name === 'Secure Message') {
                    strDefaultCaseOrigin = 'SECURE MESSAGING';
                } else if (data.recordTypeInfo.name === 'Letter') {
                    strDefaultCaseOrigin = 'LETTER';
                } else if (data.recordTypeInfo.name === 'Email') {
                    strDefaultCaseOrigin = 'EMAIL';
                } else if (data.recordTypeInfo.name === 'Chat') {
                    strDefaultCaseOrigin = 'WEB CHAT';
                } else if (data.recordTypeInfo.name === 'Call') {
                    if (data.fields.Call_Type_ACE__c !== undefined && data.fields.Call_Type_ACE__c !== null &&
                        data.fields.Call_Type_ACE__c.value === 'Inbound') {
                        if (data.fields.IVRAuthenticated_ACE__c !== undefined && data.fields.IVRAuthenticated_ACE__c !== null &&
                            data.fields.IVRAuthenticated_ACE__c.value === 'Yes' || data.fields.IVRAuthenticated_ACE__c.value === 'Y') {
                            strDefaultCaseOrigin = 'IVR DEFAULT';
                        } else {
                            strDefaultCaseOrigin = 'TELEPHONE';
                        }
                    } else if (data.fields.Call_Type_ACE__c !== undefined && data.fields.Call_Type_ACE__c !== null &&
                        data.fields.Call_Type_ACE__c.value === 'Outbound') {
                        strDefaultCaseOrigin = 'OUTBOUND CALL';
                    } else {
                        /*Do Nothing*/
                    }
                } else {
                    if (data.recordTypeInfo.name === 'Internal') {
                        strDefaultCaseOrigin = 'TELEPHONE';
                    } else {
                        strDefaultCaseOrigin = data.recordTypeInfo.name.toUpperCase();
                    }
                }
                this.caseOriginDefaultValues = strDefaultCaseOrigin;
                this.caseOriginDefaultValuesBackup = strDefaultCaseOrigin;

            }

        if (data.fields !== undefined && data.fields !== null && data.fields.ProviderInformationDetails_ACE__c.value !== undefined &&
            data.fields.ProviderInformationDetails_ACE__c.value !== null) {
            this.strProviderInfoIdCard = JSON.parse(data.fields.ProviderInformationDetails_ACE__c.value);
        }
        if (data.fields !== undefined && data.fields !== null && data.fields.Inquirer_Relationship_ACE__c.value !== undefined &&
            data.fields.Inquirer_Relationship_ACE__c.value !== null) {
            this.strInquirerRelationship = data.fields.Inquirer_Relationship_ACE__c.value.toUpperCase();
        }
        if (data.fields !== undefined && data.fields !== null && data.fields.Inquirer_Relationship_ACE__c.value !== undefined &&
            data.fields.InquirerName_ACE__c.value !== null) {
            this.strInquirerName = data.fields.InquirerName_ACE__c.value;
        }
        this.enableCaseOrigin();


        } else {
            /*do nothing*/
        }
    }


    constructor() {
        super();
        this.isLoaded = !this.isLoaded;
        this.showModal = true;
        this.isSubmitResultSuccess = false;

    }

    connectedCallback() {
        this.planSummaryValue();
        this.handleOnLoad();
    }

    /*Handle on error case*/
    handleError(error) {
        this.isError = true;
        this.objError = error;
        if (this.isLoaded) {
            this.isLoaded = !this.isLoaded;
        }
    }

    handleOnLoad() {
        if(this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() !== 'GOVERNMENT-MEDICARE SUPPLEMENTAL') {
            getOrderIdCardCasesIfAny({
                strRecordId:this.strAccountId,
                strLineOfBusiness : this.strPlanSummaryData.strAceLineOfBusiness
        }).then((result)=>{
                this.show10daysMessage = result;
                this.handleLoad();
                if(this.strPlanSummaryData.strAceLineOfBusiness==='Government-Medicaid') {
                    this.boolIsNMCC = true;
                //CEAS-74286
                this.strCardTypeDefaultValue = 'Medical';
                const objFacetPolicy = this.strPlanSummaryData.objFacetPolicy;
                //CEAS-70901
                if(objFacetPolicy && objFacetPolicy.facetsSubscriberContrivedKey !== undefined && objFacetPolicy.facetsSubscriberContrivedKey !== null && objFacetPolicy.facetsSubscriberContrivedKey!== '') {
                    fetchLastMailedDateOnIdCard({
                        subscriberContrivedKey:objFacetPolicy.facetsSubscriberContrivedKey
                    }).then((objResult) =>{
                        this.strLastUpdatedDate = this.compareLastUpdatedDate(objResult);
                    }).catch((error) => {
                        this.handleError(error)
                    })
            }
            }
                
            }).catch(()=>{
                this.methodCatch();
            })
        } else {
            this.handleLoad();
        }

    }

     enableCaseOrigin() {
         if (this.strInteractionLogId !== undefined && this.strInteractionLogId !== null) {
             if (this.caseOriginDefaultValues === 'TELEPHONE' && this.strRecordTypeName === 'Internal') {
                 this.boolCaseOrigin = true;
             } else {
                 this.boolCaseOrigin = false;
             }
         } else {
             this.boolCaseOrigin = true;
         }
     }
    
    //Method for catch method calls
    methodCatch() {
        this.enableCaseOrigin();
        this.isApiError = true;
        this.isLoaded = !this.isLoaded;
    }

    /*Get A value of Selcted Plans*/
    getValueFromPLan(strPLanValue, strSelectedValue, strElseValue) {
        let valueToBeReturned;
        if (strPLanValue !== undefined && strPLanValue !== null) {
            valueToBeReturned = strSelectedValue;
        } else {
            valueToBeReturned = strElseValue;
        }
        return valueToBeReturned;

    }

    handleCheckboxChange(objEvent) {
        this.boolResponsibleParty = objEvent.target.checked;

    }

    handlecheckboxValidation(objComp) {
        let boolIsValid = true;
        if(this.showResponsiblePartyCheckbox && !this.boolResponsibleParty) {
            boolIsValid = false;
            
        }
        this.addRemoveValidationHelper(objComp,boolIsValid)
        return boolIsValid && this.checkComboboxValidity(objComp);
        
    }

    addRemoveValidationHelper(objComp,boolIsValid) {
        if (boolIsValid) {
            objComp.closest('.slds-form-element').classList.remove('slds-has-error');
        } else {
            objComp.closest('.slds-form-element').classList.add('slds-has-error');
        }
    }

    handleFaxChange(objEvent) {
        const className = objEvent.target.className;
        if (objEvent.currentTarget && objEvent.currentTarget.classList.contains('CardType')) {
            this.strCardTypeDefaultValue = objEvent.currentTarget.getAttribute('data-label');
            objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
        } else if (className.includes('FaxNumber')) {
            this.strFaxNumber = objEvent.target.value;
        } else if (className.includes('ToEmail')) {
            this.strEmail = objEvent.target.value;
        } else if (className.includes('Provider')) {
            this.strProvider = objEvent.target.value;
        } else {
            //Do nothing
        }
   }


    /*Get Plan Summary Wrapper*/
    planSummaryValue() {
        if (this.strPlanSummaryData !== undefined && this.strPlanSummaryData !== null) {
            const MapOfDataforEmailLocal = {};
            const casePlanParam = {
                strSubscriberID: this.getValueFromPLan(this.strPlanSummaryData.strSubscriberId, this.strPlanSummaryData.strSubscriberId, ''),
                strGroupNumber: this.getValueFromPLan(this.strPlanSummaryData.strGroupNumber, this.strPlanSummaryData.strGroupNumber, ''),
                strGroupName: this.getValueFromPLan(this.strPlanSummaryData.strGroupName, this.strPlanSummaryData.strGroupName, ''),
                strSectionNumber: this.getValueFromPLan(this.strPlanSummaryData.objViewEmployerGroupWrapper.strGroupSectionNumber, this.strPlanSummaryData.objViewEmployerGroupWrapper.strGroupSectionNumber, ''),
                strCorporationCode: this.getValueFromPLan(this.strPlanSummaryData.strCorporationCode, this.strPlanSummaryData.strCorporationCode, ''),
                boolPgIndicator: this.getValueFromPLan(this.strPlanSummaryData.boolPgIndicator, this.strPlanSummaryData.boolPgIndicator, ''),
                strCMID: this.getValueFromPLan(this.strPlanSummaryData.strClientMemberId, this.strPlanSummaryData.strClientMemberId, ''),
                strMid: this.getValueFromPLan(this.strPlanSummaryData.strMemberId, this.strPlanSummaryData.strMemberId, ''),
                strGroupCostCenter: this.getValueFromPLan(this.strPlanSummaryData.strGroupCostCenterNumber, this.strPlanSummaryData.strGroupCostCenterNumber, ''),
                strPolicyId: this.getValueFromPLan(this.strPlanSummaryData.strPolicyId, this.strPlanSummaryData.strPolicyId, ''),
                strEffectiveDate: this.getValueFromPLan(this.strPlanSummaryData.strEffectiveDate, this.strPlanSummaryData.strEffectiveDate, ''),
                strTerminationDate: this.getValueFromPLan(this.strPlanSummaryData.strTerminationDate, this.strPlanSummaryData.strTerminationDate, ''),
                strAccountNumber: this.getValueFromPLan(this.strPlanSummaryData.strAccountNumber, this.strPlanSummaryData.strAccountNumber, ''),
                strMultiPlan: this.getValueFromPLan(this.strPlanSummaryData.strMultiPlan, this.strPlanSummaryData.strMultiPlan, ''),
                strProductType: this.getValueFromPLan(this.strPlanSummaryData.strNetwork, this.strPlanSummaryData.strNetwork, ''),
                strFundingType: this.getValueFromPLan(this.strPlanSummaryData.strFundingTypeCode, this.strPlanSummaryData.strFundingTypeCode, ''),
                addOnServices: this.strPlanSummaryData.lstCoverageCodes,
                strPolicyClientMemberId: this.getValueFromPLan(this.strPlanSummaryData.strPolicyClientMemberId, this.strPlanSummaryData.strPolicyClientMemberId, ''),
                strCorpCode: this.getValueFromPLan(this.strPlanSummaryData.strCorpCode, this.strPlanSummaryData.strCorpCode, ''),
                strAddOnServices: '',
                Address_ACE__c: '',
                City_ACE__c: '',
                State_ACE__c: '',
                ZipCode_ACE__c: '',
                Email_ACE__c: '',
                lstFamilyName: null,
                boolIsCbcApiCallAvailable: this.getValueFromPLan(this.strPlanSummaryData.boolIsCbcApiCallAvailable, this.strPlanSummaryData.boolIsCbcApiCallAvailable, ''),
                boolIsAccountsAPICallAvailable: this.getValueFromPLan(this.strPlanSummaryData.boolIsAccountsAPICallAvailable, this.strPlanSummaryData.boolIsAccountsAPICallAvailable, ''),
                strAceLineOfBusiness: this.getValueFromPLan(this.strPlanSummaryData.strAceLineOfBusiness, this.strPlanSummaryData.strAceLineOfBusiness, ''),
                                strSourceSystemName: this.getValueFromPLan(this.strPlanSummaryData.strSourceSystemName, this.strPlanSummaryData.strSourceSystemName, '')

            };

            casePlanParam['subscriberSequenceNumber'] = this.getValueFromPLan(this.strPlanSummaryData.strSubscriberSequenceNumber, this.strPlanSummaryData.strSubscriberSequenceNumber, '');
            casePlanParam['memberNumber'] = this.strPlanSummaryData.strMemberNumber;
            casePlanParam['bluestarAccountNumber'] = this.strPlanSummaryData.objViewEmployerGroupWrapper.strblueStarAccountNumber;
            const strSenderAddress = this.strPlanSummaryData.strfirstName + ' ' + this.strPlanSummaryData.strlastname;
            if (this.objCommunicationPreferenceData !== null && this.objCommunicationPreferenceData !== undefined) {
                casePlanParam['Address_ACE__c'] = this.objCommunicationPreferenceData.streetAddress;
                casePlanParam['City_ACE__c'] = this.objCommunicationPreferenceData.city;
                casePlanParam['State_ACE__c'] = this.objCommunicationPreferenceData.state;
                casePlanParam['ZipCode_ACE__c'] = this.objCommunicationPreferenceData.zipCode;
                this.strAddressOfMember = strSenderAddress + ' ' + '</br>' + this.objCommunicationPreferenceData.streetAddress + ', </br>' +
                    this.objCommunicationPreferenceData.city +
                    ', ' + this.objCommunicationPreferenceData.state + ', ' + this.objCommunicationPreferenceData.zipCode;
                this.boolAddressNotAvailable = false;
                this.boolAlteranteMailAddress = false;
            }

            if (this.strAddressOfMember === undefined || this.strAddressOfMember === null || this.strAddressOfMember === '') {
                this.boolAddressNotAvailable = true;
                this.boolAlteranteMailAddress = true;

            }
            if (this.strEmail !== null && this.strEmail !== undefined) {
                casePlanParam['Email_ACE__c'] = this.strEmail;
                if(this.boolEmailDefault) {
                    this.strEmailDefault = this.strEmail;
                }
            } else {
                casePlanParam['Email_ACE__c'] = '';
            }
            this.boolEmailDefault = false;
            
            if (this.strLanguage !== null && this.strLanguage !== undefined) {
                casePlanParam['strLanguage'] = this.strLanguage;
            } else {
                casePlanParam['strLanguage'] = '';
            }
            const strCurrentPageMemberName = this.strPlanSummaryData.strfirstName + ' ' + this.strPlanSummaryData.strlastname;
            this.strInCareOf = strCurrentPageMemberName;
            this.strSubscriberName = strCurrentPageMemberName;
            const lstAddOnServices = casePlanParam.addOnServices;
            let strAddOnServices = '';
            let strAddOnServicesEmail = '';
            if (lstAddOnServices) {
                for (let intCount = 0; intCount < lstAddOnServices.length; intCount++) {
                    if (lstAddOnServices[intCount].strCode !== null) {
                        strAddOnServicesEmail = strAddOnServicesEmail + lstAddOnServices[intCount].strCode;
                        casePlanParam['strAddOnServicesEmail'] = strAddOnServices;
                    }
                    if (lstAddOnServices[intCount].strEffectiveEndDate !== undefined && lstAddOnServices[intCount].strEffectiveEndDate !== null && lstAddOnServices[intCount].strEffectiveEndDate !== "") {
                        const codeDate = new Date(lstAddOnServices[intCount].strEffectiveEndDate);
                        const CurrentDate = new Date();
                        CurrentDate.setHours(0, 0, 0, 0);

                        if (lstAddOnServices[intCount].strCode !== null && codeDate >= CurrentDate) {

                            strAddOnServices = strAddOnServices +',' +lstAddOnServices[intCount].strCode;

                        }
                    }

                }
                if(strAddOnServices!==''){
                    strAddOnServices=strAddOnServices.substr(1);
                     casePlanParam['strAddOnServices'] = strAddOnServices;
                }
            }

            if (casePlanParam.strTerminationDate) {
                const TerminationDate = casePlanParam.strTerminationDate;
                let TerminationDateArray = [];
                TerminationDateArray = TerminationDate.split('/');
                casePlanParam.strTerminationDate = TerminationDateArray[2] + '-' + TerminationDateArray[0] + '-' + TerminationDateArray[1];
            }

            if (casePlanParam.strEffectiveDate) {
                const EffectiveDate = casePlanParam.strEffectiveDate;
                let EffectiveDateArray = [];
                EffectiveDateArray = EffectiveDate.split('/');
                casePlanParam.strEffectiveDate = EffectiveDateArray[2] + '-' + EffectiveDateArray[0] + '-' + EffectiveDateArray[1];
            }
            MapOfDataforEmailLocal['Group Number'] = casePlanParam.strGroupNumber;	
            MapOfDataforEmailLocal['Account Name (Account/Group)'] = this.strSubscriberName;	
            MapOfDataforEmailLocal['Corporation Code (Plan)'] = casePlanParam.strCorpCode;	
            MapOfDataforEmailLocal['Policy Client Member Id'] = casePlanParam.strPolicyClientMemberId;	
            MapOfDataforEmailLocal['Line Of Business'] = casePlanParam.strAceLineOfBusiness;	
            this.MapOfDataforEmail = MapOfDataforEmailLocal;
            this.objPlanData = casePlanParam;
        }
    }

    handleLoad() {
        const objMAPDUIWrapper = {};
        const objMAPDIdCardMember = {};
        const lstHeaders = [];
        const objHeader = {};
        const lstFamilyMembers = [];
        let strCardTypeVal = '';
        const lstMembersUI = [];
        const intCount = 0;

        //Populating the Retail Wrapper for UI
        objMAPDUIWrapper.strMID = this.strPlanSummaryData.strMemberId;
        objMAPDUIWrapper.strPolicyId = this.strPlanSummaryData.strPolicyId;
        if(this.strPlanSummaryData.strAceLineOfBusiness && (this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMediciadValue_ACE || this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL')) {
            lstHeaders.push(this.label.ViewClaimHistory_Medical_ACE);
            strCardTypeVal = this.label.ViewClaimHistory_Medical_ACE;
        } else {
            lstHeaders.push(this.label.Medical_PharmacyLabel_ACE);
            strCardTypeVal = this.label.Medical_PharmacyLabel_ACE;
        }
        
       objHeader.lstOfHeader = lstHeaders;
        objMAPDUIWrapper.objMAPDCardHeader = objHeader;
        
        lstFamilyMembers.push(this.strSubscriberName + '_' + this.strPlanSummaryData.strMemberId);
        
        objMAPDIdCardMember.strMemberName = this.strSubscriberName;
        objMAPDIdCardMember.strMemberNameUI = this.strSubscriberName;
        objMAPDIdCardMember.strMemberMID = this.strPlanSummaryData.strMemberId;
        const strMemberName = lstFamilyMembers[intCount];
        const listOfMAPDlCheckBoxWrappers = [];
        const objIdCardCheckBoxWrapperOfMember = {};
        objIdCardCheckBoxWrapperOfMember.strMemberName = strMemberName;
        objIdCardCheckBoxWrapperOfMember.strCardType = strCardTypeVal;
        objIdCardCheckBoxWrapperOfMember.strCardKey = strMemberName + '-' + strCardTypeVal;
        
        objIdCardCheckBoxWrapperOfMember.strClassName = strMemberName + '-' + strCardTypeVal + ' ' + 'slds-text-align_center';
        objIdCardCheckBoxWrapperOfMember.boolCardChecked = true;
        objIdCardCheckBoxWrapperOfMember.boolCardDisabled = true;
            
        listOfMAPDlCheckBoxWrappers.push(objIdCardCheckBoxWrapperOfMember);
        objMAPDIdCardMember.lstCheckBoxWrapper = listOfMAPDlCheckBoxWrappers;
        lstMembersUI.push(objMAPDIdCardMember);
        objMAPDUIWrapper.lstMembers = lstMembersUI;
        const result = objMAPDUIWrapper;
        if (result !== undefined && result !== null && result.lstMembers !== undefined
            && result.lstMembers !== undefined && result.lstMembers !== null && result.objMAPDCardHeader !== undefined 
            && result.objMAPDCardHeader !== null) {
                
                //Setting API Errors to false
                this.boolApiError = false;
                this.isApiError = false;
                this.isError = false;
                if(this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() !== 'GOVERNMENT-MEDICARE SUPPLEMENTAL') {
                    this.boolIsMAPD = true;
                }
                
               //Assigning all values to UI
                this.listOfFamilyname = result.lstMembers;
                this.objFamilyCardTypeHeader = result.objMAPDCardHeader; 

                //Adding shading to alternate rows of family member
                for(let iterator=0; iterator<this.listOfFamilyname.length; iterator++) {
                    if(iterator % 2 === 0) {
                        this.listOfFamilyname[iterator].boolShaded = false;
                    } else {
                        this.listOfFamilyname[iterator].boolShaded = true;
                    }
                }
                
                //Populating ID Card Types 
                this.lstCardType = [];
                const objTypeNull = {
                    label: '--None--',
                    value: ''
                };
                this.lstCardType.push(objTypeNull);
                let objCardType = {};
                if(result.lstMembers.length > 0) {
                    objCardType = {
                        label: result.lstMembers[0].lstCheckBoxWrapper[0].strCardType,
                        value: result.lstMembers[0].lstCheckBoxWrapper[0].strCardType
                    };
                }
                this.lstCardType.push(objCardType);
            } else {
                    this.isApiError = true;
            }
            this.isLoaded = !this.isLoaded;
            this.boolIsRecipientAndMail = true;
            this.enableCaseOrigin();
    }

    @api
    openModal() {
        this.showModal = true;
    }

    @api
    closeModal() {
        this.showModal = false;
    }

    handleFocusout(objEvent) {
        if (this.showModal) {
            let boolIsComboboxOpen = false;
            if (objEvent.target.closest('.slds-combobox')) {
                boolIsComboboxOpen = objEvent.target.closest('.slds-combobox').classList.contains('slds-is-open');
            }

            [...this.template.querySelectorAll('.slds-combobox')].forEach((el) => {
                el.classList.remove('slds-is-open');
            });
            if (boolIsComboboxOpen) {
                objEvent.target.closest('.slds-combobox').classList.add('slds-is-open')
            }
        }

    }

    toggleCombobox(objEvent) {
        const objCmbx = objEvent.target.closest('.slds-combobox');
        if (objCmbx.querySelector('.highlight') && objCmbx.querySelector('.highlight').classList) {
            objCmbx.querySelector('.highlight').classList.remove('highlight');
        }
        const objDimensions = objCmbx.getBoundingClientRect();
        const objDropdown = objCmbx.querySelector('.slds-dropdown');
        objDropdown.style.top = objDimensions.top + 34 + 'px';
        objDropdown.style.width = objDimensions.width + 'px';
        objDropdown.style.left = objDimensions.left -
            objCmbx.closest('.slds-modal__container').getBoundingClientRect().left + 'px';
        if (objCmbx && objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]') && objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]').classList) {
            objCmbx.querySelector('[data-label="' + objEvent.target.value + '"]').classList.add('highlight');
        }
        objCmbx.classList.toggle('slds-is-open');
    }

    /* Method To Handle On Change of Status*/
    handleChangeStatus(objEvent) {
        this.statusDefaultValue = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
        if (this.statusDefaultValue === 'Pended') {
            this.SubstatusDefaultValue = 'Personal Pend';
            this.boolSubstatus = true;
        } else {
            this.SubstatusDefaultValue = this.lstSubStatus[0].label;
            this.boolSubstatus = false;
        }
    }

    /* Method To Handle On Change of Delivery Method*/
    handleChangeDeliveryMethod(objEvent) {
        this.deliveryMethodDefaultValue = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');

        this.isSubmitResultSuccess = false;
        this.boolIsRecipientAndMail = false;
        this.boolEmailCondition = false;	
        this.boolEmailIsRecipientAndMail = false;	
        this.boolEmailIsRecipientAndProv = false;		
        this.boolTempToast = false;
        this.boolFaxIsRecipientAndMail = false;
        this.boolFaxIsRecipientAndProv = false;

        if (!this.isApiError) {
            this.boolApiError = false;
            this.strErrorSectionName = '';
            if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
                this.boolIsRecipientAndMail = true;
                //44374 Showing Warning Message if PCP/MG is not assigned or dummy value
                

                if (this.boolAlteranteMailAddress) {

                    setTimeout(function() {
                        if(this.template.querySelector('button.AlternateAddress')) {
                            this.template.querySelector('button.AlternateAddress').classList.add('selected');
                            this.template.querySelector('button.AlternateAddress').focus();
                        }
                    }.bind(this), 700);
                } else {

                    setTimeout(function () {
                        if(this.template.querySelector('button.MailAddress')) {
                            this.template.querySelector('button.MailAddress').classList.add('selected');
                            this.template.querySelector('button.MailAddress').focus();
                        }
                    }.bind(this), 700);
                    
                }
            } else if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Member') {
                this.boolEmailIsRecipientAndMail = true;
                this.boolTempToast = true;
                this.boolEmailCondition = true;
            } else if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Provider') {
                this.boolEmailIsRecipientAndProv = true;
                this.boolTempToast = true;
                this.boolEmailCondition = true;
                this.strEmail = '';
                this.boolResponsibleParty = false;
            } else if (this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Member') {
                this.boolFaxIsRecipientAndMail = true;
                this.boolEmailCondition = true;
                this.boolTempToast = true;
            } else if (this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Provider') {
                this.boolFaxIsRecipientAndProv = true;
                this.boolEmailCondition = true;
                this.boolTempToast = true;
                this.boolResponsibleParty = false;
            } else {
                //Nothing
            }
            this.showDisableSubmitButton();
            //Set Default Values
            if (this.boolIsNMCC) {
                this.strCardTypeDefaultValue = this.lstCardType[1].label;
            } else {
                this.strCardTypeDefaultValue = this.lstCardType[0].label;
            }

        } else {
            this.strErrorSectionName = '';
            if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
                this.strErrorSectionName = 'MAIL TO MEMBER';
                this.boolApiError = true;
            } else {
                this.boolApiError = false;
                this.strErrorSectionName = '';
                this.showDisableSubmitButton();
            }
        }
    }
    /* Method To Handle On Change of SUB Status*/
    handleChangeSubStatus(objEvent) {
        this.SubstatusDefaultValue = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
    }
    /* Method To Handle On Change of Origin*/
    handleChangeOrigin(objEvent) {
        this.caseOriginDefaultValues = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
    }

    handleChangeRequestType(objEvent) {
        this.caseRequestTypeValue = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
    }

    handleChangePhysicalOrderReason(objEvent) {
        this.casePhysicalOrderReasonValue = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
    }
    /* Method To Handle On Change of Recipient*/
    handleChangeRecipient(objEvent) {
        this.recipientDefaultValue = objEvent.currentTarget.getAttribute('data-label');
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
        this.isSubmitResultSuccess = false;
        if (this.recipientDefaultValue === 'Provider') {
            const lstDeliveryMethodUI = [];
            const objTypeNull = {
                label: '--None--',
                value: ''
            };
            
            lstDeliveryMethodUI.push(objTypeNull);
            lstDeliveryMethodUI.push({
                label: 'Email',
                value: 'Email'
            });
            lstDeliveryMethodUI.push({
                label: 'Fax',
                value: 'Fax'
            });
            this.lstDeliveryMethod = lstDeliveryMethodUI;
        } else {
            this.lstDeliveryMethod = this.lstDeliveryMethodBackup;
        }
        this.boolIsRecipientAndMail = false;
        this.boolEmailCondition = false;
        this.boolEmailIsRecipientAndMail = false;
        this.boolTempToast = false;
        this.boolEmailIsRecipientAndProv = false;
        this.boolFaxIsRecipientAndMail = false;
        this.boolFaxIsRecipientAndProv = false;
        this.deliveryMethodDefaultValue = this.lstDeliveryMethod[0].label;
        this.showDisableSubmitButton();
    }

    /* Method To Show or Disable Submit Button */
    showDisableSubmitButton() {

        if (this.deliveryMethodDefaultValue === '--None--' || this.recipientDefaultValue === '--None--') {
            this.isSubmitEnabled = true;
        } else {
            this.isSubmitEnabled = false;
        }
    }


    /* Method to handle submit scenario*/
    handleSubmitClick () {
        this.isLoaded = !this.isLoaded;
        const objCase = this.getCaseObject();
        
        const inputzip = this.template.querySelector('.ZIPCODE');
        if (inputzip !== undefined && inputzip !== null) {
            inputzip.setCustomValidity('');
            inputzip.reportValidity();
        }
        const allValidPicklist = [...this.template.querySelectorAll('.slds-combobox__input')]
            .reduce((validSoFar, inputCmp) => {
                this.reportComboboxValidity(inputCmp);
                return validSoFar && this.checkComboboxValidity(inputCmp);
            }, true);
        const allValid = [...this.template.querySelectorAll('lightning-input')]
            .reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);

            const allValidCheckbox = this.template.querySelector('.checkboxclass')
            
            let boolcheckboxValidationPassed = true;
            
            if(allValidCheckbox) {
                boolcheckboxValidationPassed = this.handlecheckboxValidation(allValidCheckbox); 
            }

        if (allValid && allValidPicklist && boolcheckboxValidationPassed) {
           const strCaseStatusBeforeCallout = objCase.Status;
            if(this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
                this.handleMailSubmit(objCase,strCaseStatusBeforeCallout);
            } else {
                this.handleSelfService(objCase,strCaseStatusBeforeCallout);
            }
            
        } else {
            this.isLoaded = !this.isLoaded;
        }
    }

    handleSelfService(objCase,strCaseStatusBeforeCallout) {
        this.boolAlteranteMailAddress = false;
            this.isResultPendedSuccess = false;
            this.isResultPendedSuccessWithNoCases = false;
            
            const submitReq = {
            };
            
            const lstSubmitReq = [];
            lstSubmitReq.push(submitReq);
            const fepSubmitReq = {
            
            };
            submitCaseFromIdCard({
                    strCaseData: JSON.stringify(objCase),
                    strFamilyDataChecboxes: JSON.stringify(this.listOfFamilyname),
                    boolBlueStarCallout: false,
                    lstSubmitReq: lstSubmitReq,
                    fepSubmitReq: JSON.stringify(fepSubmitReq),
                    strMemberId: this.objPlanData.strMid,
                    mapOfFamilyMemberAndMemberNumber: this.mapOfFamilyMemberAndMemberNumber,
                    strIdCardLevelIndicator: this.strIdCardLevelIndicator,
                    boolcheckAvailblity: false,
                    strUniqueIdentifier: '',
                    mapOfDataforEmail: this.MapOfDataforEmail,
                    mapOfFamilyMemberNumberAndMid: this.MapOfFamilyMemberNumberAndMid,
                    mapOfFamilyMemberIdAndCMID: this.MapOfFamilyMemberIdAndCMID,
                    boolFEPIndicator: false,
                    boolStandAloneCards: this.boolStandAloneCards,
                    boolBoeingIndicator:false
                }).then((result) => {
                    this.isLoaded = !this.isLoaded;
                    this.isSubmitResultSuccess = true;
                    this.removeAddressErrorsOnSuccess();
                    if (result !== undefined && result !== null && result.boolResponseStatus && result.lstSuccessCases.length > 0) {
                        //Section for success response and success cases
                        this.handleSuccessUIFunctionality(result,strCaseStatusBeforeCallout)
                    } else {
                        this.handleErrorScenario();
                    }
                }).catch((error) => {
                    this.handleError(error);
                });
    }


    /* Remove validation error messages on submit success. */
    removeAddressErrorsOnSuccess() {
        const strInputZipCode = this.template.querySelector('.ZIPCODE.slds-has-error');
        const strInputCity = this.template.querySelector('.CITY.slds-has-error');
        const strInputAddress = this.template.querySelector('.ADDRESS.slds-has-error');
        const strInputState = this.template.querySelector('.id-class-state-err.slds-has-error');
        if(strInputZipCode) {
          strInputZipCode.classList.remove('slds-has-error');
        }
        if(strInputCity) {
          strInputCity.classList.remove('slds-has-error');
        }
        if(strInputAddress) {
          strInputAddress.classList.remove('slds-has-error');
        }
        if(strInputZipCode) {
          strInputState.classList.remove('slds-has-error');
        }
    }



    /*Method To Get The Case Object Details */
    getCaseObject() {
        const objCase = {
            Type: 'Member Management',
            Sub_Type_ACE__c: 'ID Card Request',
            SubscriberID_ACE__c: this.objPlanData.strSubscriberID,
            GroupNumber_ACE__c: this.objPlanData.strGroupNumber,
            GroupName_ACE__c: this.objPlanData.strGroupName,
            SectionNumber_ACE__c: this.objPlanData.strSectionNumber,
            CorporationCode_ACE__c: this.objPlanData.strCorporationCode,
            CMID_ACE__c: this.objPlanData.strCMID,
            GroupCostCenter_ACE__c: this.objPlanData.strGroupCostCenter,
            Policy_ID_ACE__c: this.objPlanData.strPolicyId,
            Plan_Effective_Date_ACE__c: this.objPlanData.strEffectiveDate,
            Plan_Termination_Date_ACE__c: this.objPlanData.strTerminationDate,
            Account_Number_ACE__c: this.objPlanData.strAccountNumber,
            Multiplan_ACE__c: this.objPlanData.strMultiPlan,
            Product_Type_ACE__c: this.objPlanData.strProductType,
            AddonServices_ACE__c: this.objPlanData.strAddOnServices,
            CaseCreationSource_ACE__c:'PatentCard/IdCard',
            DeliveryMethod_ACE__c: this.deliveryMethodDefaultValue,
            SelfServiceRecipient_ACE__c: this.recipientDefaultValue,
            Status: this.statusDefaultValue,
            Sub_Status_ACE__c: this.SubstatusDefaultValue,
            Address_ACE__c: '',
            City_ACE__c: '',
            State_ACE__c: '',
            RecordTypeId: this.recordTypeId,
            ZipCode_ACE__c: '',
            AccountId: this.strAccountId,
            InquirerName_ACE__c: this.strInquirerName,
            //Fix fieldName
            InquirerRelationship_ACE__c: this.strInquirerRelationship,
            InCareOf_ACE__c: '',
            CardTypeValues_ACE__c: '',
            IdCardLevelIndicator_ACE__c: '',
            UniqueIdentifierIDCard_ACE__c: '',
            Origin: this.caseOriginDefaultValues,
            Interaction_Log_Id_ACE__c: this.strInteractionLogId
        };
        objCase.SecureGroupName_ACE__c =  this.strPlanSummaryData !== null && this.strPlanSummaryData !== undefined && this.strPlanSummaryData.securedGroupNecessaryRole && this.strPlanSummaryData.securedGroupNecessaryRole !== null && this.strPlanSummaryData.securedGroupNecessaryRole !== undefined ? this.strPlanSummaryData.securedGroupNecessaryRole : '';
        if( this.strPlanSummaryData && this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICAID' && this.strPlanSummaryData.strFamilyCaseNumber) {
            objCase.FamilyCaseNumber_ACE__c = this.strPlanSummaryData.strFamilyCaseNumber;
        }
        objCase.IsCbcApiCallAvailable_ACE__c =false;
        objCase.IsAccountsAPICallAvailable_ACE__c =false;
        if (this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Member') {
            objCase.Fax_ACE__c = this.strFaxNumber;
            objCase.Status ='Closed';
            objCase.Sub_Status_ACE__c = null;
            objCase.CardTypeValues_ACE__c = this.strCardTypeDefaultValue;
            const faxNameMember = this.strSubscriberName.replace(/\s/g, '-');
            objCase.Email_ACE__c = `/name=${faxNameMember}/fax=${this.strFaxNumber}/rightfax@rightfax.pop`;
            if (this.strFaxNumber !== undefined && this.strFaxNumber !== null && this.strFaxNumber !== '' && this.strFaxNumber.length === 10) {
                this.strFaxNumberFormatted = '(' + this.strFaxNumber.substr(0, 3) + ') ' + this.strFaxNumber.substr(3, 3) + '-' + this.strFaxNumber.substr(6, this.strFaxNumber.length);
            }
        }
        if (this.strProvider && this.deliveryMethodDefaultValue === 'Fax' && this.recipientDefaultValue === 'Provider') {
            objCase.ProviderName_ACE__c = this.strProvider;
            objCase.ProviderFaxNumber_ACE__c = this.strFaxNumber;
            objCase.Fax_ACE__c = this.strFaxNumber;
            objCase.Status ='Closed';
            objCase.Sub_Status_ACE__c = null;
            const faxNameProvider = this.strProvider.replace(/\s/g, '-');
            objCase.Email_ACE__c = `/name=${faxNameProvider}/fax=${this.strFaxNumber}/rightfax@rightfax.pop`;
            objCase.CardTypeValues_ACE__c = this.strCardTypeDefaultValue;
            if (this.strFaxNumber !== undefined && this.strFaxNumber !== null && this.strFaxNumber !== '' && this.strFaxNumber.length === 10) {
                this.strFaxNumberFormatted = '(' + this.strFaxNumber.substr(0, 3) + ') ' + this.strFaxNumber.substr(3, 3) + '-' + this.strFaxNumber.substr(6, this.strFaxNumber.length);
            }
        }
        if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Member') {
            objCase.Email_ACE__c = this.strEmail;
            objCase.CardTypeValues_ACE__c = this.strCardTypeDefaultValue;
        }

        if (this.deliveryMethodDefaultValue === 'Email' && this.recipientDefaultValue === 'Provider') {
            objCase.ProviderName_ACE__c = this.strProvider;
            objCase.Email_ACE__c = this.strEmail;
            objCase.CardTypeValues_ACE__c = this.strCardTypeDefaultValue;
            
        }

        if((this.deliveryMethodDefaultValue === 'Email' || this.deliveryMethodDefaultValue === 'Fax') && this.recipientDefaultValue === 'Provider' && this.boolResponsibleParty && this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMediciadValue_ACE) {
            objCase.Responsible_Party_is_in_the_Office_ACE__c = this.boolResponsibleParty;
        }
        if(this.objPlanData.boolIsAccountsAPICallAvailable && this.objPlanData.boolIsAccountsAPICallAvailable=== true) {
            objCase.IsAccountsAPICallAvailable_ACE__c = this.objPlanData.boolIsAccountsAPICallAvailable;
        }
        if(this.objPlanData.boolIsCbcApiCallAvailable && this.objPlanData.boolIsCbcApiCallAvailable=== true) {
            objCase.IsCbcApiCallAvailable_ACE__c = this.objPlanData.boolIsCbcApiCallAvailable;
        }
         if( this.objPlanData.strAceLineOfBusiness!==undefined && this.objPlanData.strAceLineOfBusiness !==null && this.objPlanData.strAceLineOfBusiness !=='') {
            objCase.LineOfBusiness_ACE__c = this.objPlanData.strAceLineOfBusiness.toUpperCase();
        }
        
        if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member') {
            objCase.Address_ACE__c = this.objPlanData.Address_ACE__c;
            objCase.City_ACE__c = this.objPlanData.City_ACE__c;
            objCase.State_ACE__c = this.objPlanData.State_ACE__c;
            objCase.ZipCode_ACE__c = this.objPlanData.ZipCode_ACE__c;
            objCase.IdCardLevelIndicator_ACE__c = this.strIdCardLevelIndicator;
            objCase.InCareOf_ACE__c = this.strInCareOf;
            if(this.casePhysicalOrderReasonValue && this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMediciadValue_ACE) {
                objCase.Physical_Order_Reason_ACE__c = this.casePhysicalOrderReasonValue;
            }
            if(this.caseRequestTypeValue && this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL') {
                objCase.Request_Type_ACE__c = this.caseRequestTypeValue;
            }
        }
        if (objCase.InquirerName_ACE__c === undefined || objCase.InquirerName_ACE__c === null || objCase.InquirerName_ACE__c === '') {
            objCase.InquirerName_ACE__c = this.strSubscriberName;
        }
        if (this.deliveryMethodDefaultValue === 'Mail' && this.recipientDefaultValue === 'Member' && this.boolAlteranteMailAddress) {
            objCase.Address_ACE__c = this.strADDRESS;
            objCase.City_ACE__c = this.strCity;
            objCase.State_ACE__c = this.strState;
            objCase.ZipCode_ACE__c = this.strZipCode;
            objCase.InCareOf_ACE__c = this.strInCareOf;
            objCase.IdCardLevelIndicator_ACE__c = this.strIdCardLevelIndicator;
        }
        if (objCase.Sub_Status_ACE__c === '--None--') {
            objCase.Sub_Status_ACE__c = '';
        }
        
        return objCase;
    }

    reportComboboxValidity(objComp) {
        let boolIsValid = false;
        if (objComp.hasAttribute('required') && !objComp.hasAttribute('disabled')) {
            const strValue = objComp.value;
            [...objComp.closest('.slds-combobox').querySelectorAll('li[data-value]')]
            .forEach((el) => {
                boolIsValid = boolIsValid || (el.getAttribute('data-value') === strValue);
            });
        } else {
            boolIsValid = true;
        }
        this.addRemoveValidationHelper(objComp,boolIsValid)
        return boolIsValid;
    }
    checkComboboxValidity(objComp) {
        return !objComp.closest('.slds-form-element').classList.contains('slds-has-error');
    }

    handleOpenCaseChild(objEventChild) {
        if(objEventChild && objEventChild.detail) {
            this.openCase(objEventChild.detail)
        }
    }

    /*Launch a case on Select Sub Tab*/
    openCase(objEvent) {
        if (objEvent !== undefined && objEvent !== null && objEvent.target !== undefined && objEvent.target !== null &&
            objEvent.target.getAttribute('data-caseid') !== undefined && objEvent.target.getAttribute('data-caseid') !== null) {
            const caseId = objEvent.target.getAttribute('data-caseid');
            const caseIdURL = objEvent.target.getAttribute('data-caseurl');
            const strAccountIdOfCase = objEvent.target.getAttribute('data-caseaccid');
            let boolOpenSubtab = false;
            if (this.strAccountId === strAccountIdOfCase) {
                boolOpenSubtab = true;
                if(objEvent.currentTarget && objEvent.currentTarget.label === 'NEXT') {
                    this.showModal = false;
                }
            }
            const objDispatchEventData = {
                Id: caseId,
                TabId: this.currentTabId,
                CaseUrl: caseIdURL,
                AccountId: strAccountIdOfCase,
                boolOpenSubtab: boolOpenSubtab
            };
            const openSubTab = new CustomEvent('OpenSubTab', {
                detail: JSON.stringify(objDispatchEventData)
            });
            window.dispatchEvent(openSubTab);
        }
    }

    /* Method To Handle Change oF Main Address */
    handleMainAddress(objEvent) {
        const className = objEvent.currentTarget.className;
        if (this.template.querySelector('.address-button.selected')) {
            this.template.querySelector('.address-button.selected').classList.remove('selected');
        }
        if (className.includes('MailAddress')) {
            this.boolMailAddress = true;
            this.boolAlteranteMailAddress = false;
            setTimeout(function() {
                this.template.querySelector('button.MailAddress').classList.add('selected');
                this.template.querySelector('button.MailAddress').focus();
            }.bind(this), 500);

        } else if (className.includes('AlternateAddress')) {
            this.boolMailAddress = false;
            this.boolAlteranteMailAddress = true;
            setTimeout(function() {
                this.template.querySelector('button.AlternateAddress').classList.add('selected');
                this.template.querySelector('button.AlternateAddress').focus();
            }.bind(this), 500);
        } else {
            /*Do Nothing*/
        }
    }

    /* Method To Handle On Change of Alterante*/
    handleChangeAlternatevalue(objEvent) {

        if (objEvent.currentTarget && objEvent.currentTarget.classList.contains('STATE')) {
            this.strState = objEvent.currentTarget.getAttribute('data-label');
            objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
        } else {
            const className = objEvent.target.className;
            if (className.includes('InCareOf')) {
                this.strInCareOf = objEvent.target.value;
            } else if (className.includes('ADDRESS')) {
                this.strADDRESS = objEvent.target.value;
            } else if (className.includes('CITY')) {
                this.strCity = objEvent.target.value;
            } else if (className.includes('ZIPCODE')) {
                this.strZipCode = objEvent.target.value;
            } else {
                /*Do Nothing*/
            }
        }
        this.strAlternateAddressOfMember = this.strInCareOf + ' ' + '</br>' +
            this.strADDRESS + ', ' + '</br>' +
            this.strCity + ', ' +
            this.strState + ', ' +
            this.strZipCode;

    }


    handleMailSubmit(objCase, strCaseStatusBeforeCallout) {
        if(this.statusDefaultValue !== this.label.ViewClaimsMedicalStatistics_Withdrawn_ACE && this.strPlanSummaryData.strAceLineOfBusiness && ((this.statusDefaultValue === 'Closed' && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMediciadValue_ACE) || this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === this.label.CreateCasePage_GovMedicareValue_ACE) ) {
            if(this.boolAlteranteMailAddress && this.listOfFamilyname && objCase) {
                const objFacetPolicy = this.strPlanSummaryData.objFacetPolicy;
                const effectiveDate = new Date().toISOString().substr(0,10);
                let terminateDate = new Date(effectiveDate);
                terminateDate.setDate(terminateDate.getDate() + 5);
                terminateDate = terminateDate.toISOString().substr(0,10);
                if(objFacetPolicy && objFacetPolicy.facetsGroupContrivedKey && objFacetPolicy.facetsSubscriberContrivedKey) {
                    const objReq  = {
                        "groupContrivedKey": objFacetPolicy.facetsGroupContrivedKey,
                        "subscriberContrivedKey": objFacetPolicy.facetsSubscriberContrivedKey,
                        "subscriberAddressLine1": this.strADDRESS,
                        "subscriberAddressLine2": "",
                        "city": this.strCity,
                        "zipCode": this.strZipCode,
                        "state": this.strState,
                        "memberContrivedKey": objFacetPolicy.facetsMemberContrivedKey,
                        "effectiveDate": effectiveDate,
                        "terminationDate": terminateDate
                    }
                    facetsUpdateTempAddress({
                        strRecordId : '',
                        facetsMap : JSON.stringify(objReq),
                        boolOrderIdCard : true,
                        strCaseData : JSON.stringify(objCase),
                        strFamilyDataChecboxes : JSON.stringify(this.listOfFamilyname)
                    }).then((result)=>{
                        if (result && result.lstPendedCases === undefined) {
                            // Second Callout to submit order id card
                            // Do nothing
                            this.orderIdCardCalloutHelper(JSON.stringify(objCase),strCaseStatusBeforeCallout,true)
                        } else if (result !== undefined && result !== null && !result.boolResponseStatus && result.lstPendedCases.length > 0) {
                            this.boolAlteranteMailAddress = false;
                            this.isSubmitResultSuccess = true;
                            this.handlePendedUIFunctionality(result)
                            this.isLoaded = !this.isLoaded;
                        } else {
                            //Do Nothing
                            this.isLoaded = !this.isLoaded;
                        }
                    }).catch((error) => {
                        this.handleError(error);
                    });
                }
           } else {
                //submit callout
                this.orderIdCardCalloutHelper(JSON.stringify(objCase),strCaseStatusBeforeCallout,true)
            }
        } else {
            // Withdrawn case logic
            this.orderIdCardCalloutHelper(JSON.stringify(objCase),strCaseStatusBeforeCallout,false)
           
        }  
    }

    orderIdCardCalloutHelper(strObjCase,strCaseStatusBeforeCallout,boolCallout) {
        if(strObjCase) {
            orderIdcardCallout({
                strMid : this.strPlanSummaryData.strMemberId,
                strPolicyId : this.strPlanSummaryData.strPolicyId,
                strCaseData : strObjCase,
                strFamilyDataChecboxes : JSON.stringify(this.listOfFamilyname),
                boolCallout : boolCallout
            }).then((result)=>{
                this.isSubmitResultSuccess = true;
                this.boolAlteranteMailAddress = false;
                this.isLoaded = !this.isLoaded;
                if (result !== undefined && result !== null && result.boolResponseStatus && ((result.lstSuccessCases && result.lstSuccessCases.length > 0) || (result.lstPendedCases && result.lstPendedCases.length > 0))) {
                    //Section for success response and success cases
                    this.handleSuccessUIFunctionality(result,strCaseStatusBeforeCallout)
                    
                } else if (result !== undefined && result !== null && !result.boolResponseStatus && result.lstPendedCases.length > 0) {
                    
                    this.handlePendedUIFunctionality(result)
                } else {
                    //Do Nothing
                }
            }).catch((error)=>{
                this.handleError(error);
            })
        }
        
    }

    handleSuccessUIFunctionality(result,strCaseStatusBeforeCallout) {
        const lstOfCasesFromServer = [];
        if(this.deliveryMethodDefaultValue === 'Email' || this.deliveryMethodDefaultValue === 'Fax') {
            for (let i = 0; i < result.lstSuccessCases.length; i++) {
                this.boolEmailStatus = false;
                this.statusEmailDefaultValue = 'Closed';
                if (result.lstSuccessCases[i].Status === 'Open' && !result.boolEmailSuccess) {
                    this.boolEmailStatus = true;
                    this.statusEmailDefaultValue = 'Open';
                    this.strCaseIdEmail = result.lstSuccessCases[i].Id;
                    this.strCaseAccount = result.lstSuccessCases[i].AccountId;
                    this.strCaseURL = result.lstSuccessCases[i].CaseUrlIDCard_ACE__c;
                }
                const objCaseFromServer = this.createObjectforSuccessUI(result,i)
                //Creating list of cases with casenumber, id, url to be shown on UI
                lstOfCasesFromServer.push(objCaseFromServer)
            }
        } else {
            if(result.lstSuccessCases && result.lstSuccessCases.length > 0) {
                for (let i = 0; i < result.lstSuccessCases.length; i++) {
                    const objCaseFromServer = this.createObjectforSuccessUI(result,i)
                    //Creating list of cases with casenumber, id, url to be shown on UI
                    lstOfCasesFromServer.push(objCaseFromServer)
                }
            }
            if(result.lstPendedCases && result.lstPendedCases.length > 0 ) {
                for (let i = 0; i < result.lstPendedCases.length; i++) {
                    const objCaseFromServer = {
                        CaseNumber: result.lstPendedCases[i].CaseNumber,
                        Id: result.lstPendedCases[i].Id,
                        caseUrl: result.lstPendedCases[i].CaseUrlIDCard_ACE__c,
                        accountid: result.lstPendedCases[i].AccountId
                    };
                    //Creating list of cases with casenumber, id, url to be shown on UI
                    lstOfCasesFromServer.push(objCaseFromServer)
                }
           }
        }
        
        
        this.caseNumbers = lstOfCasesFromServer;
        this.isResultSuccess = true;
        this.caseType = 'Member Management';
        this.caseSubtype = 'ID Card Request';
        //Setting case status based on closed 
        if (strCaseStatusBeforeCallout === 'Closed') {
            this.isSubmitResultText = 'Case created and closed successfully.';
        } else { this.isSubmitResultText = 'Case created successfully.'; }
        
        if (this.strAlternateAddressOfMember === '') { this.strAlternateAddressOfMember = this.strAddressOfMember; }
        if(this.deliveryMethodDefaultValue ==='Directed to Self-Service') { this.isdeliveryMethodDefault= true; }
        this.isError = false;
        this.boolSubstatus = false;
        this.boolrefresh = false;
    }

    createObjectforSuccessUI(result,i) {	
        return {	
            CaseNumber: result.lstSuccessCases[i].CaseNumber,	
            Id: result.lstSuccessCases[i].Id,	
            caseUrl: result.lstSuccessCases[i].CaseUrlIDCard_ACE__c,	
            accountid: result.lstSuccessCases[i].AccountId	
        };	
    }

    handlePendedUIFunctionality(result) {
        const lstOfCasesFromServerPended = [];
        for (let i = 0; i < result.lstPendedCases.length; i++) {
            const objCaseFromServer = {
                CaseNumber: result.lstPendedCases[i].CaseNumber,
                Id: result.lstPendedCases[i].Id,
                caseUrl: result.lstPendedCases[i].CaseUrlIDCard_ACE__c,
                accountid: result.lstPendedCases[i].AccountId
            };
            lstOfCasesFromServerPended.push(objCaseFromServer)
        }
        this.caseNumbersPended = lstOfCasesFromServerPended;
        this.caseNumbers = lstOfCasesFromServerPended;
        this.boolSubstatus = false;
        this.boolrefresh = false;
        this.caseType = 'Member Management';
        this.caseSubtype = 'ID Card Request';
        this.isError = false;
        this.isResultSuccess = false;
        if (this.strAlternateAddressOfMember === '') {
            this.strAlternateAddressOfMember = this.strAddressOfMember;
        }
        this.isResultPendedSuccess = true;
    }

    /*Refresh Modal*/
    refreshModal() {

        this.isSubmitResultSuccess = false;
        this.isSubmitEnabled = false;
        this.isError = false;
        this.isLoaded = !this.isLoaded;
        this.isdeliveryMethodDefault = false;
        this.recipientDefaultValue = 'Member';
        this.isError = false;
        this.lstDeliveryMethod = this.lstDeliveryMethodBackup;
        this.deliveryMethodDefaultValue = 'Mail';
        this.strEmail = this.strEmailDefault;
        if(this.strPlanSummaryData.strAceLineOfBusiness && this.strPlanSummaryData.strAceLineOfBusiness.toUpperCase() === 'GOVERNMENT-MEDICARE SUPPLEMENTAL') {
            this.statusDefaultValue = 'Pended';
            this.SubstatusDefaultValue = 'Personal Pend';
            this.boolSubstatus = true;
            this.caseRequestTypeValue = 'Duplicate ID Card';
        } else {
            this.statusDefaultValue = 'Closed';
            this.SubstatusDefaultValue = '';
            this.boolSubstatus = false;
        }
       this.strADDRESS = '';
        this.strAlternateAddressOfMember = '';
        this.strCity = '';
        this.strState = '';
        this.strZipCode = '';
        this.strInCareOf = '';
        this.strCardTypeDefaultValue = '';
        this.boolMailAddress = false;
        this.boolAlteranteMailAddress = false;
        this.boolCaseOrigin = false;
        this.boolFaxIsRecipientAndMail = false;
        this.boolFaxIsRecipientAndProv = false;
        this.strFaxNumber = '';
        this.strFaxNumberFormatted = '';
        this.boolEmailIsRecipientAndProv = false;
        this.boolEmailIsRecipientAndMail = false;
        this.boolTempToast = false;
        this.boolIsRecipientAndMail = false;
        this.boolApiError = false;
        this.isApiError = false;
        this.caseOriginDefaultValues = this.caseOriginDefaultValuesBackup;
        this.strErrorSectionName = '';
        this.boolResponsibleParty = false;
        this.boolEmailCondition = false;
        this.strProvider = '';
        // Fire the custom event
        const orderIdCardEvent = new CustomEvent('RefreshOrderIdCard', {detail: 'FetchDataFromCommunicationCard',bubbles : true});
         // Fire the custom event
         this.dispatchEvent(orderIdCardEvent);
    }

    @api
    idcardModal(objCommunicationAddress){
        if(typeof objCommunicationAddress === 'string' && objCommunicationAddress) {
            this.objCommunicationPreferenceData= JSON.parse(objCommunicationAddress);
        } else{
            this.objCommunicationPreferenceData=objCommunicationAddress;
        }
        this.planSummaryValue();
        this.handleOnLoad();
    }

    /* Method to handle error scenario*/
    handleErrorScenario() {
        //Error Scenario
        this.isSubmitResultSuccess = false;
        this.boolIsRecipientAndMail = false;
        this.boolAlteranteMailAddress = false;
        this.isError = true;
        if (this.isLoaded) {
            this.isLoaded = !this.isLoaded;
        }
    }
    
    //CEAS-70901
    compareLastUpdatedDate(strResponse) {
        let strLatestDate = '';
        if(strResponse !== undefined && strResponse !== null && strResponse !== '') {
            const objResponse = JSON.parse(strResponse);
            if(objResponse.Data !== undefined && objResponse.Data !== null && objResponse.Data.Family !== undefined && objResponse.Data.Family !== null &&
                objResponse.Data.Family.MET0_COLL !== undefined && objResponse.Data.Family.MET0_COLL !== null &&
                objResponse.Data.Family.MET0_COLL[0].Attachments !== undefined && objResponse.Data.Family.MET0_COLL[0].Attachments !== null &&
                objResponse.Data.Family.MET0_COLL[0].Attachments.ATUF_COLL !== undefined && objResponse.Data.Family.MET0_COLL[0].Attachments.ATUF_COLL !== null) {
                    const lstAttachments = objResponse.Data.Family.MET0_COLL[0].Attachments.ATUF_COLL;
                    const lstDates = [];
                    let dtLatestDate;
                    lstAttachments.forEach(itrAttachment => {
                        lstDates.push(itrAttachment.ATUF_DATE2);

                    });
                    if(lstDates.length > 0) {
                        dtLatestDate = lstDates[0];
                        lstDates.forEach(itrDate => {
                            if (new Date(dtLatestDate) < new Date(itrDate)) {
                                dtLatestDate = new Date(itrDate);
                            }
                        });
                    }
                    strLatestDate = this.formatDate(dtLatestDate);
                }
        }
        return strLatestDate;
    }

    formatDate(data) {
        if (data != null) {
            let date = new Date(data);
            let month = date.getMonth() + 1;

            if(month <= 9) {
                month = "0" + month;
            }

            if(date.getDate() > 9 ) {
                return month + "/" + date.getDate() + "/" + date.getFullYear();
            } else {
                return month + "/" + "0" + date.getDate() + "/" + date.getFullYear();
            }
        } else {
            return '';
        }
    }

    validateEmail(event) {
        const strEmail = event.target.value;
        const objEmailField = this.template.querySelector('[data-id="' + event.target.dataset.id + '"]');
        if (BaseLWC.isUndefinedOrNullOrBlank(strEmail)) {
            objEmailField.setCustomValidity('Complete this field.');
        } else {
            if (strEmail.match(this.strEmailRegex)){
                objEmailField.setCustomValidity('');
            } else {
                objEmailField.setCustomValidity(this.label.MemberContactDetails_EmailInvalidMessage_ACE);
            }
        }
        objEmailField.reportValidity();
    }
}
