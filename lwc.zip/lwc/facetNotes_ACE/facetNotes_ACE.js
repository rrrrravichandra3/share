/**
 * @description       :
 * @author            : mahesh_ratilal_shimpi@bcbsil.com
 * @group             :
 * @last modified on  : 07-26-2022
 * @last modified by  : mahesh_ratilal_shimpi@bcbsil.com
**/
import { LightningElement, wire} from 'lwc';
import FlexiPageHeader_ACE from "@salesforce/resourceUrl/FlexiPageHeader_ACE";
import HCSCStaticResource_ACE from "@salesforce/resourceUrl/HCSCStaticResource_ACE";
import { loadStyle } from 'lightning/platformResourceLoader';
//Base LWC functions
import BaseLWC from 'c/baseLWCFunctions_CF';
import { EnclosingTabId, getTabInfo, closeTab, openSubtab } from 'lightning/platformWorkspaceApi';
import FacetsNotesAPIErrorMessage_ACE from '@salesforce/label/c.FacetsNotesAPIErrorMessage_ACE';
import FacetsTaskTitle_ACE from '@salesforce/label/c.FacetsTaskTitle_ACE';
import FacetsTaskInformationTitle_ACE from '@salesforce/label/c.FacetsTaskInformationTitle_ACE';
import getFacetsTaskNotes from '@salesforce/apexContinuation/FacetNotesController_ACE.getFacetsTaskNotes';
export default class FacetNotesACE extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;

    // custom labels
    label = {
        FacetsNotesAPIErrorMessage_ACE,
        FacetsTaskTitle_ACE,
        FacetsTaskInformationTitle_ACE
    };

    callID;
    boolError = false;
    boolWarning = false;
    boolSpinner = false;
    strErrorMessage = '';
    objTabData = {};
    facetNotes;
    errorPlaceHolder;

    connectedCallback() {
        this.fetchTabData();
    }

    fetchTabData = () => {
        let oldTabId;
        if (!this.enclosingTabId) {
            return;
        }
        getTabInfo(this.enclosingTabId).then((objTabData) => {
            this.objTabData = objTabData;
            const currentTabId = this.objTabData.tabId;
            const strURL = this.objTabData.url;
            const durl = new URL(strURL);
            const paramsVal = durl.searchParams.getAll('c__BaseURLParam')[0];
            const curl = BaseLWC.helperBaseDecodeUrl(paramsVal);
            if (curl.includes('&')) {
                this.callID = curl.split('&')[0].split('=')[1];
                oldTabId = curl.split('&')[1].split('=')[1]
            } else {
                this.callID = curl.split('=')[1];
            }
            const strEncodedURL = '?' + window.btoa(unescape(encodeURIComponent('strFacetsTaskId=' + this.callID + '&oldTabId=' + this.objTabData.tabId)));
            const objPageReference = {
                "type": "standard__navItemPage",
                "attributes": { "apiName": "Facets_Task_Information_ACE", "uid": this.callID },
                "state": { "c__BaseURLParam": strEncodedURL }
            };
            if (!oldTabId) {
                openSubtab( this.objTabData.parentTabId,{pageReference: objPageReference, focus: true})
                .then(() => {
                    closeTab(currentTabId);
                });
            } else {
                closeTab(oldTabId);
                if(this.callID) {
                    this.getFacetsTaskNotes(this.callID);
                }
            }
        }).catch((error) => {
            this.handleErrors(error);
        });
    }
    // call a apex continuation action to get Facets Task Notes
    getFacetsTaskNotes = (callID) => {
        this.boolSpinner = true;
        getFacetsTaskNotes({callID : callID})
            .then(result => {
                const facetNotes = JSON.parse(result);
                const notes = [];
                let  i = 0;
                if (BaseLWC.isNotUndefinedOrNull(facetNotes.callDetails) && BaseLWC.isNotUndefinedOrNull(facetNotes.callDetails[0].notes)) {
                    facetNotes.callDetails[0].notes.forEach(element => {
                        // logic to append ACE/Facets before note
                        if (!element.startsWith('ACE')) {
                            notes.push({key:i++, noteFrom :'FACET ', note:element});
                        }else {
                            element = element.replace("ACE-", "");
                            notes.push({key:i++, noteFrom :'ACE ', note:element});
                        }
                    });
                    this.facetNotes = [...notes];
                    this.boolError = false;
                } else {
                    this.handleErrors(this.label.FacetsNotesAPIErrorMessage_ACE);
                }
            })
            .catch(error => {
                this.errorPlaceHolder = error;
                this.handleErrors(this.label.FacetsNotesAPIErrorMessage_ACE);
            })
            .finally(() => {
                this.boolSpinner = false;
            });
    }

    handleErrors = (errorMessage) => {
        this.boolError = true;
        this.strErrorMessage = errorMessage;
    }

    handleReload = () => {
        this.getFacetsTaskNotes(this.callID);
    }

    renderedCallback() {
        Promise.all([
            loadStyle(this, FlexiPageHeader_ACE  + '/CSS/HideFlexiPageHeader_ACE.css'),
            loadStyle(this, HCSCStaticResource_ACE  + '/CSS/GenericCSS/commonStyleGuide.css')
        ])
    }
}
