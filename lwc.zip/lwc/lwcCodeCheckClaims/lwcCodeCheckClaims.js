/**
 * CEAS-77134
 * Code check functionality for claims.
 * 11/15/2023
 */

import { LightningElement, track, api, wire } from 'lwc';
import BaseLWC from "c/baseLWCFunctions_CF";
import ViewClaims_NoRecordsFound_ACE from '@salesforce/label/c.ViewClaims_NoRecordsFound_ACE';
import CodeCheck_APIAvailableError_ACE from '@salesforce/label/c.CodeCheck_APIAvailableError_ACE';
import ViewPlanSummary_CardHeader_Refresh_ACE from '@salesforce/label/c.ViewPlanSummary_CardHeader_Refresh_ACE';
import getCodeCheck from '@salesforce/apexContinuation/CodeCheckController_ACE.getCodeCheck';
import NotepadTransmissionChannel_ACE from '@salesforce/messageChannel/NotepadTransmissionChannel__c';
import {
    APPLICATION_SCOPE,
    createMessageContext,
    MessageContext,
    publish,
    releaseMessageContext,
    subscribe,
    unsubscribe,
} from 'lightning/messageService';

export default class LwcCodeCheckClaims extends LightningElement {
    NotepadTransmissionChannel = NotepadTransmissionChannel_ACE;
    @wire(MessageContext)
    messageContext;
    labels = {
        ViewClaims_NoRecordsFound_ACE,
        CodeCheck_APIAvailableError_ACE,
        ViewPlanSummary_CardHeader_Refresh_ACE
    };
    @track sections = [
        {
            label: 'Diagnosis Codes',
            items: [],
        },

        {
            label: 'Procedure Codes',
            items: [],
        },
    ];
    @api strServiceFrom;
    @api strUrlCorpCode;
    @track boolDisplayData = false;
    @track boolAPIError = false;
    @track boolNoRecords = false;
    @track premCodeData;
    @track premCodesAPI = [];
    @track isSectionOpen = false;
    @api strInteractionLogId;
    @api strCMID;
    @api strGroupNumber;
    @api strMemberId;
    @api boolHideAutoDoc;
    @api arrCodes;
    @track codeDisplayData;
    @track selectedItem = '';
    @track navigationData = this.sections;
    objCardError = {};
    boolIsCaseExists;
    premCodesMap = new Map();
    boolShowSpinner = false;
    boolShowNoRecordsFound = false;
    initialCode;
    currentSelectedCode;
    codeTypeGens = {};
    //pass to api.
    currentDate = new Date().toISOString().split('T')[0]; 

    //Set classes for accordian based on isSectionOpen.
    get accordianClass() {
        if (this.isSectionOpen) {
            return `slds-col slds-m-left_medium slds-size--8-of-12 slds-accordian__section slds-p-left_x-large slds-p-top_large slds-is-open`;
        }
        return `slds-col slds-m-left_medium slds-size--8-of-12 slds-accordian__section slds-p-left_x-large slds-p-top_large`;
    }

    get iconName() {
        return `utility:${this.isSectionOpen ? 'chevrondown' : 'chevronright'}`;
    }

    //Data table handlers
    @track lstTableData = [];
    columns = [
        { label: "Flag", fieldName: 'flag', sortable: true, type: 'text', boolInitSort: true, boolAsc: true, boolIsTooltip: true, boolIsInfoIconTooltip: true },
        { label: "Group Id", fieldName: 'bitCodeGroup', sortable: true, boolAsc: true, type: '' },
        { label: "Group Name", fieldName: 'name', sortable: false, type: '' },
        { label: "Effective Date", fieldName: 'effectiveDate', sortable: false, type: 'date' },
        { label: "End Date", fieldName: 'endDate', sortable: false, type: 'date' },
        { label: '', fieldName: 'bitPrem', sortable: false, type: '', boolHidden: true },
        { label: '', fieldName: 'isIconDisabled', sortable: false, type: '', boolHidden: true },
        { label: '', fieldName: 'strNotepad', sortable: false, type: '', boolHidden: true }
    ];
    @track
    objInitTableSettings = {
        pageSize: 10,
        restrictedPageSize: 6,
        boolShowSearch:false,
        boolPagination: true,
        columnsData: this.columns,
        boolShowIcon: true,
        iconNameToShow: 'utility:note',
        boolHeaderNoCapital: true,
    };
    //Close modal by firing event to parent component.
    closeModal() {
        const closeModalEvent = new CustomEvent("closemodal",
        { detail :false }, this);
        this.dispatchEvent(closeModalEvent);
    }

    //Init
    connectedCallback() {
        this.setPremCodes();
        this.fetchData();
    }

    //Toggle for showing and hiding table.
    toggleSection() {
        this.isSectionOpen = !this.isSectionOpen;
    }

    //Setting premierCodes data for API call.
    setPremCodes() {
        try {
            if (this.arrCodes && this.arrCodes.length) {
                this.sections = this.sections.map(el => {
                    el.items = [];
                    return el;
                });

                this.arrCodes.forEach(el => {
                    this.setPremCodesNavList(el);
                    this.premCodesAPI.push({
                        code: el.code ?? '',
                        codeType: el.codeType ?? ''
                    })
                });
            }
        } catch (error) {
            this.boolAPIError = true;
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }

    //Generator function for getting 2 seperate codeType values for description panel and autodoc. 
    createCodeTypesGens(codeType) {
        try {
            const codeTypeHeader = {
                'R': "R - NDC",
                '1': "1 - ICD 10 Diagnosis",
                '9': "9 - ICD 9 Diagnosis",
                'Z': "Z - ICD 10 Procedure",
                'H': "H - ICD 9 Procedure",
                'C': "C - CPT HCPCS",
                'G': "G - BIT_PCG"
            }
            const codeTypeForAutoDoc = {
                'R': "NDC",
                '1': "ICD 10 Diagnosis",
                '9': "ICD 9 Diagnosis",
                'Z': "ICD 10 Procedure",
                'H': "ICD 9 Procedure",
                'C': "CPT & HCPCS"
            }
            return (function* () {
                while (true) {
                    yield codeTypeHeader[codeType];
                    yield codeTypeForAutoDoc[codeType];
                }
            })();
        } catch (error) {
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }

    //logic for getting values from generator function.
    getNextCodeTypeGenerator(codeType) {
        try {
            if (!this.codeTypeGens[codeType]) {
                this.codeTypeGens[codeType] = this.createCodeTypesGens(codeType);
            }
            return this.codeTypeGens[codeType].next().value;
        } catch (error) {
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }

    //Setting the sections for displaying the premier codes in vertical navigation.
    setPremCodesNavList(el) {
        try {
            let tempIndex;
            if (el && el.codeType === '1') {
                tempIndex = '0';
            } else if (el && el.codeType === 'C') {
                tempIndex = '1';
            }

            if (el && tempIndex && typeof tempIndex === 'string') {
                if (el.primaryDX) {
                    const tempObj = { label: el.code + ' - Primary DX', name: this.checkSelected(el) };
                    this.sections[Number(tempIndex)].items?.unshift(tempObj)
                } else {
                    const tempObj = { label: el.code, name: this.checkSelected(el) };
                    this.sections[Number(tempIndex)].items?.push(tempObj)
                }
            }
        } catch (error) {
            this.boolAPIError = true;
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }

    //checking the selected code to set the vertical navigation selected logic.
    checkSelected(objPremCode) {
        if (objPremCode && objPremCode.selected) {
            this.initialCode = this.selectedItem = objPremCode.code;
            return objPremCode.code;
        } 
        return objPremCode.code;
    }

    //API call to get the premier codes.
    fetchData = () => {
        try {
            this.boolShowSpinner = true;
            let serviceFromDate = this.strServiceFrom;
            if(serviceFromDate){
                const dateCompos = serviceFromDate.split("/");
                const month = dateCompos[0];
                const day = dateCompos[1].slice(0,2);
                const year  = dateCompos[2];
                serviceFromDate = year.toString() + '-' + month.toString() + '-' + day.toString();
            } else {
                serviceFromDate  = this.currentDate;
            }
            getCodeCheck({
                strServiceDate: serviceFromDate,
                strCorporateEntityCode: this.strUrlCorpCode ?? 'IL1',
                strPremierCodes: JSON.stringify(this.premCodesAPI)
            }).then((response) => {
                this.boolShowSpinner = false;
                if (response) {
                    this.premCodeData = JSON.parse(response);
                    if (typeof this.premCodeData && this.premCodeData?.codes?.length) {
                        this.premCodeData.codes.forEach(el => {
                            this.premCodesMap.set(el.code,
                                {
                                    code: el.code,
                                    codeType: el.codeType,
                                    codeTypeHeader: this.getNextCodeTypeGenerator(el.codeType),
                                    codeTypeAutoDoc: this.getNextCodeTypeGenerator(el.codeType),
                                    codeGroups: el.codeGroups,
                                    descriptions: el.descriptions
                                })
                        })
                        if (this.initialCode) {
                            this.premCodeClick(this.initialCode);
                        }
                    }
                } else {
                    this.boolAPIError = true;
                }
            }).catch((error) => {
                this.boolShowSpinner = false;
                this.handleErrors(error);
            });
        } catch (error) {
            this.boolAPIError = true;
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    };

    //Removing the Primary DX text from code, so that we can find the code in premMap in premCodeClick().
    removePrimaryDXText(data) {
        if (data && typeof data === 'string') {
            return data.replace('- Primary DX', '').replace(/\s/g, '');
        }
    }

    autoDocStr(header, value) {
        if (!value) {
            value = '';
        }
        return header + '\t\t' + value + '\n';
    }

    //Create the data table to display the prem code data.
    createTableData(data) {
        try {
            if (data && typeof data === 'object' && data.length) {
                for (let i = 0; i < data.length; i++) {
                    const obj = data[i];
                    obj['flag'] = {};
                    obj['flag'].value = obj.strColor;
                    obj['flag'].strCellValue = obj.strHoverText;
                    obj['flag'].strTooltipNubbinAlignment = 'left-top';
                    if (obj.strColor === '1') {
                        obj['flag'].wrapper = `<span class="slds-m-horizontal_small circular-shape slds-badge bg-red">&nbsp;</span>` //slds-theme_error
                        obj['flag'].strTextTooltipContent = obj.strHoverText;
                    } else if (obj.strColor === '2') {
                        obj['flag'].wrapper = `<span class= "slds-m-horizontal_small circular-shape slds-badge bg-orange">&nbsp;</span>`
                        obj['flag'].strTextTooltipContent = obj.strHoverText;
                    } else if (obj.strColor === '3') {
                        obj['flag'].wrapper = `<span class= "slds-m-horizontal_medium">&nbsp;</span>`
                    }
                    obj['bitPrem'] = this.currentSelectedCode + '-' + obj['bitCodeGroup'];
                    let strSectionName = 'Premier Code - ' + this.currentSelectedCode + ' - ' + obj.bitCodeGroup;
                    let lstBenefitAccumulatorData = ['Benefits', 'Premier Code Lookup', strSectionName];
                    let strNotepad = lstBenefitAccumulatorData.join('\n\n') + '\n\n';
                    strNotepad += this.autoDocStr('Code Type', this.codeDisplayData.codeTypeAutoDoc);
                    strNotepad += this.autoDocStr('Code', this.currentSelectedCode);
                    strNotepad += this.autoDocStr('Long Description', this.codeDisplayData.descriptions.longDesc);
                    strNotepad += this.autoDocStr('Short Description', this.codeDisplayData.descriptions.shortDesc);
                    strNotepad += this.autoDocStr('Group ID', obj.bitCodeGroup);
                    strNotepad += this.autoDocStr('Group Name', obj.name);
                    strNotepad += this.autoDocStr('Effective Date', obj.effectiveDate);
                    strNotepad += this.autoDocStr('End Date', obj.endDate);
                    strNotepad = strNotepad.trim();
                    obj.strNotepad = strNotepad;
                    this.lstTableData.push(obj);
                }
                if (!this.lstTableData.length) {
                    this.boolShowNoRecordsFound = true;
                }
                this.toggleSection();
            } else {
                this.boolShowNoRecordsFound = true;
                this.toggleSection();
            }
        } catch (error) {
            this.boolNoRecords = true;
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }

    publishToNotepad(notepadMessage) {
        const message = {
            method: 'POST',
            reqSource: "lwcNotepadAce",
            boolIsFromAutdoc : true,
            notes : notepadMessage
        };

        publish(this.messageContext, this.NotepadTransmissionChannel, message);
    }
    //Handler to get event data when clicked on autodoc icon.
    handleRowAction(event) {
        try {
            const rowData = JSON.parse(JSON.parse(event.detail).renderedRowData);
            if (rowData) {
                this.handleAutoDoc(rowData);
            }
        } catch (error) {
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }

    //Handler to get event data when clicked on any prem code.
    handlePremCodeClick(event) {
        try {
            if (event && event.currentTarget?.dataset?.name) {
                this.premCodeClick(event.currentTarget.dataset.name);
            } else {
                this.boolNoRecords = true;
                this.boolDisplayData = false;
                this.boolAPIError = false;
            }
        } catch (error) {
            this.boolNoRecords = true;
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }

    //Get map data of selected code to create table.
    premCodeClick(code) {
        try {
            const selectedCode = this.removePrimaryDXText(code);
            this.selectedItem = selectedCode;
            this.currentSelectedCode = selectedCode;
            if (selectedCode && this.premCodesMap.size && this.premCodesMap.has(selectedCode)) {
                this.boolShowNoRecordsFound = false;
                this.codeDisplayData = this.premCodesMap.get(selectedCode);
                //displaying data or error.
                if (this.codeDisplayData.code && this.codeDisplayData?.codeGroups?.length) {
                    this.boolDisplayData = true;
                    this.boolNoRecords = false;
                    this.boolAPIError = false;
                    this.isSectionOpen = false;
                    this.lstTableData = [];
                    this.createTableData(this.codeDisplayData.codeGroups);
                } else {
                    this.boolNoRecords = true;
                    this.boolDisplayData = false;
                    this.boolAPIError = false;
                }
            } else {
                this.boolNoRecords = true;
                this.boolDisplayData = false;
                this.boolAPIError = false;
            }
        } catch (error) {
            this.boolNoRecords = true;
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }

    /**
     * To handle Errors.
     * Helps to show case errors.
     * All components should have this code.
     */
    handleErrors = (error) => {
        this.objCardError = error;
    };

    //Getting Index of item in table to disable when autodoc icon.
    getDataIndex(tableData, rowIdentifier) {
        if (tableData && rowIdentifier) {
            return tableData.findIndex(el => el.bitPrem === rowIdentifier);
        } else {
            return -1;
        }
    }

    //Autodoc logic.
    handleAutoDoc(data) {
        try {
            let codeDataObject = data.reduce((el, obj) => {
                el[obj.key] = obj.value;
                return el;
            }, {});
            let strNotepad = codeDataObject.strNotepad;
            this.publishToNotepad(strNotepad);

            if (this.boolHideAutoDoc) {
                return;
            }
            let objPattern = {};
            let lstTotalPattern = [];
            let lstValuesData = [];
            let objFieldData = {};
            let lstSectionsData = [];
            

            let premBitCode = codeDataObject.bitCodeGroup;
            let rowIdentifier = codeDataObject.bitPrem;

            const dataIndex = this.getDataIndex(this.lstTableData, rowIdentifier);

            let strSectionName = 'Premier Code - ' + this.currentSelectedCode + ' - ' + premBitCode;
            let lstBenefitAccumulatorData = ['Benefits', 'Premier Code Lookup', strSectionName];
            for (let i = 0; i < lstBenefitAccumulatorData.length; i++) {
                const subPatternForLstSections = {
                    "strLabel": lstBenefitAccumulatorData[i]
                };

                if (i === 0) {
                    subPatternForLstSections.strIcon = 'announcement';
                    subPatternForLstSections.strIconFamily = 'standard';
                    subPatternForLstSections.strIconColor = '#1b5297';
                    lstSectionsData.push(subPatternForLstSections);
                    continue;
                }

                subPatternForLstSections.strIcon = '';
                subPatternForLstSections.strIconFamily = '';
                subPatternForLstSections.strIconColor = '';
                lstSectionsData.push(subPatternForLstSections);
            }
            objPattern.lstSections = lstSectionsData;
            var a = codeDataObject;
            var objCodeCheckRows = a;
            this.lstTableData = [...this.lstTableData];

            objFieldData = {};
            objFieldData['strFieldLabel'] = 'Code Type';
            objFieldData['strFieldValue'] = this.codeDisplayData.codeTypeAutoDoc;
            lstValuesData.push(objFieldData);

            objFieldData = {};
            objFieldData['strFieldLabel'] = 'Code';
            objFieldData['strFieldValue'] = this.currentSelectedCode;
            lstValuesData.push(objFieldData);

            objFieldData = {};
            objFieldData['strFieldLabel'] = 'Long Description';
            objFieldData['strFieldValue'] = this.codeDisplayData.descriptions.longDesc;
            lstValuesData.push(objFieldData);

            objFieldData = {};
            objFieldData['strFieldLabel'] = 'Short Description';
            objFieldData['strFieldValue'] = this.codeDisplayData.descriptions.shortDesc;
            lstValuesData.push(objFieldData);

            const lstKeysOfObj = ["bitCodeGroup", "name", "effectiveDate", "endDate"];

            lstKeysOfObj.forEach(function (strKey) {
                objFieldData = {};
                if (strKey === 'bitCodeGroup') {
                    objFieldData['strFieldLabel'] = 'Group ID';
                } else if (strKey === 'name') {
                    objFieldData['strFieldLabel'] = 'Group Name';
                } else if (strKey === 'effectiveDate') {
                    objFieldData['strFieldLabel'] = 'Effective Date';
                } else if (strKey === 'endDate') {
                    objFieldData['strFieldLabel'] = 'End Date';
                }
                objFieldData['strFieldValue'] = objCodeCheckRows[strKey];
                lstValuesData.push(objFieldData);
            });

            objPattern.lstValues = lstValuesData;
            objPattern.strInteractionLogId = this.strInteractionLogId;
            lstTotalPattern.push(objPattern);
            let strAutoDocStorageKey = 'idCODE_CHECK_' + this.strInteractionLogId + this.strMemberId + this.currentSelectedCode + premBitCode;
            this.postMessageToAutoDoc(lstTotalPattern, strAutoDocStorageKey);
        } catch (error) {
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }

    /**
     * Refresh button logic
     * Make a sample callout and see if there is no api error.
    */
    handleRefreshLogic() {
        try {
            this.setPremCodes();
            this.fetchData();
        } catch (error) {
            this.boolShowSpinner = false;
            this.boolAPIError = true;
            this.handleErrors(error);
        }
    }

    //Post message autodoc.
    postMessageToAutoDoc(TotalPattern, strAutoDocStorageKey) {
        try {
            const objIframe = document.createElement("iframe");
            objIframe.src = "/apex/ClaimsSetlocalstoragePage_ACE";
            objIframe.style.display = "none";
            document.body.appendChild(objIframe);
            objIframe.onload = function () {
                objIframe.contentWindow.postMessage({
                    key: 'strAutodoc',
                    value: JSON.stringify(TotalPattern),
                    boolIsClaimsAutoDoc: true
                }, '*');
                if (this.strInteractionLogId !== '') {
                    if (this.boolIsInternalInteraction === true && BaseLWC.isUndefinedOrNullOrBlank(this.boolIsInternalInteraction)) {
                        let strKey = 'strAutoDocIconInfo_ACE' + this.strAccountId;
                        if (!BaseLWC.isUndefinedOrNullOrBlank(BaseLWC.helperBaseGetItem(strKey)) && BaseLWC.helperBaseGetItem(strKey) !== '') { // change in lwc
                            const objInternalDetails = JSON.parse(BaseLWC.helperBaseGetItem(strKey));
                            objInternalDetails[strAutoDocStorageKey] = "Yes";
                            BaseLWC.helperBaseRemoveItem(strKey);
                            BaseLWC.helperBaseSetItem(strKey, JSON.stringify(objInternalDetails), 30);
                        } else {
                            const objInternalDetails = {
                                strAutoDocStorageKey: "Yes"
                            };
                            BaseLWC.helperBaseSetItem(strKey, JSON.stringify(objInternalDetails), 30);
                        }
                    } else {
                        objIframe.contentWindow.postMessage({
                            key: 'strAutoDocIconInfo_ACE',
                            value: strAutoDocStorageKey,
                            boolIsClaimsAutoDoc: false
                        }, '*');
                    }
                    objIframe.contentWindow.postMessage({
                        key: 'strKeepAutodocActive',
                        value: 'true',
                        boolIsClaimsAutoDoc: true
                    }, '*');
                }
            }
        } catch (error) {
            this.boolShowSpinner = false;
            this.handleErrors(error);
        }
    }
}
