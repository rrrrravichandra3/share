import { LightningElement, api, track, wire } from 'lwc';
import RemoveLegacyModal_Description_ACE from '@salesforce/label/c.RemoveLegacyModal_Description_ACE';
import ViewAuthorizedParty_EffectiveDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_EffectiveDate_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import CreateAlerts_RequiredChk_ACE from '@salesforce/label/c.CreateAlerts_RequiredChk_ACE';
import NotificationTooltipCharacterLimit_ACE from '@salesforce/label/c.NotificationTooltipCharacterLimit_ACE';
import CreateAlerts_InvalidDate_ACE from '@salesforce/label/c.CreateAlerts_InvalidDate_ACE';
import CreateAlerts_ValidEndDateChk_ACE from '@salesforce/label/c.CreateAlerts_ValidEndDateChk_ACE';
import Alerts_SpecialHandlingText_ACE from '@salesforce/label/c.Alerts_SpecialHandlingText_ACE';
import Alerts_DisclaimerMessageRetail_ACE from '@salesforce/label/c.Alerts_DisclaimerMessageRetail_ACE';
import Alerts_DisclaimerMessage_ACE from '@salesforce/label/c.Alerts_DisclaimerMessage_ACE';
import CreateAlerts_StartDateChk_ACE from '@salesforce/label/c.CreateAlerts_StartDateChk_ACE';
import CreateAlerts_EndDateChk_ACE from '@salesforce/label/c.CreateAlerts_EndDateChk_ACE';
import Alerts_TitleCharacterLimit_ACE from '@salesforce/label/c.Alerts_TitleCharacterLimit_ACE';
import AlternativeText_Close_ACE from '@salesforce/label/c.AlternativeText_Close_ACE';
import ViewAuthorizedParty_ExpirationDate_ACE from '@salesforce/label/c.ViewAuthorizedParty_ExpirationDate_ACE';
import ConvertAlert_RemoveLegacyAlert_ACE from '@salesforce/label/c.ConvertAlert_RemoveLegacyAlert_ACE';
import RemoveLegacyModal_SuccessMessage_ACE from '@salesforce/label/c.RemoveLegacyModal_SuccessMessage_ACE';
import RemoveLegacyModal_RemoveNotificationTitle_ACE from '@salesforce/label/c.RemoveLegacyModal_RemoveNotificationTitle_ACE';
import HIPAAAuthParty_CancelLabel_ACE from '@salesforce/label/c.HIPAAAuthParty_CancelLabel_ACE';
import ConvertAlert_Remove_ACE from '@salesforce/label/c.ConvertAlert_Remove_ACE';
import fetchPicklistvalues from '@salesforce/apex/ManageAlertsController_ACE.fetchPicklistvalues';
import createAlerts from '@salesforce/apex/ManageAlertsController_ACE.createAlerts';
import { NavigationMixin } from "lightning/navigation";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import BaseLWC from "c/baseLWCFunctions_CF";
import { EnclosingTabId, closeTab, getTabInfo, setTabLabel, openSubtab, focusTab } from 'lightning/platformWorkspaceApi';

import EnableVPSTabSpecificEvents_ACE from '@salesforce/label/c.EnableVPSTabSpecificEvents_ACE';

export default class LwcCreateMemberNotification extends NavigationMixin(
    LightningElement
  ) {
    @wire(EnclosingTabId) enclosingTabId;
    Label = {
        RemoveLegacyModal_SuccessMessage_ACE,
        HIPAAAuthParty_CancelLabel_ACE,
        ConvertAlert_Remove_ACE,
        ConvertAlert_RemoveLegacyAlert_ACE,
        RemoveLegacyModal_RemoveNotificationTitle_ACE,
        AlternativeText_Close_ACE,
        ViewAuthorizedParty_ExpirationDate_ACE,
        RemoveLegacyModal_Description_ACE,
        ViewAuthorizedParty_EffectiveDate_ACE,
        IntegrationFailMessage_ACE,
        CreateAlerts_RequiredChk_ACE,
        NotificationTooltipCharacterLimit_ACE,
        CreateAlerts_InvalidDate_ACE,
        CreateAlerts_ValidEndDateChk_ACE,
        Alerts_SpecialHandlingText_ACE,
        Alerts_DisclaimerMessageRetail_ACE,
        Alerts_DisclaimerMessage_ACE,
        EnableVPSTabSpecificEvents_ACE,
        CreateAlerts_StartDateChk_ACE,
        CreateAlerts_EndDateChk_ACE,
        Alerts_TitleCharacterLimit_ACE

    };
    strTxtOther = 'OTHER';
    successToast = { title: 'Notification Created Successfully', message: '', variant: 'success' }
    strOther = '';
    strBaseCurrentParentTabId;
    strBaseCurrentTabUrl;
    boolBaseIsItSubTab;
    legacyStartDate;
    legacyEndDate;
    boollineofbusiness = false;
    lstFamilyDetails;
    boolReadOnly = true;
    boolIsUpdate = false;
    boolError = false;
    boolIsRequired = false;
    boolShowConfirmation = false;
    boolShowToastMessage = false;
    isLegacy = false;
    objResponse;
    //String 
    ShowCreateTitle = true;
    ShowUpdateTitle = false;
    selectedItem = '';
    strGroupId = '';
    strSubscriberId = '';
    strAccountNumber = '';
    strSectionNumber = '';
    strRecordType = 'Member';
    strLineOfBusiness = '';//hardcode
    strTitle = [];
    @track strApplicableTo = '';
    @track strApplicableToKey = '';
    @track strSelectedApplicableTo = '';
    @track strSelectedApplicableToKey = '';
    strActive;
    @api strTitleValue;
    strName = '';
    @track strApplicableToText = '';
    memberMap = new Map();
    objNameMember = {};
    lstFamily;
    strTitle = [];

    @api idAlert;
    @api strTabId;
    @api recordId;
    @api strMemberId;
    @api boolIsCreate;
    @api boolIsFromHCD;
    @api boolIsConvert;
    @api strDescription = '';
    @api datStartDate;
    @api datEndDate;
    @api strAlertId;
objCatchError;

    updateStartDate = (objEvent) => {
        this.datStartDate = objEvent.detail;
    }
    updateEndDate = (objEvent) => {
        this.datEndDate = objEvent.detail;
    }
    connectedCallback() {
        this.fetchTitleValues();
        this.fetchTabData();
        if(this.boolIsConvert) {
            this.setLegacyDates();
        }
    }
    showNotification(objToast) {
        const evt = new ShowToastEvent({
            title: objToast.title,
            message: objToast.message,
            variant: objToast.variant,
        });
        this.dispatchEvent(evt);
    }
    handleMouseOver() {
        const objTooltip = this.template.querySelector('[data-id="descriptionTooltip"]');
        if (objTooltip) {
            objTooltip.classList.remove('slds-hide');
            objTooltip.classList.add('slds-show');
        }
    }
    handleMouseOut() {
        const objTooltip = this.template.querySelector('[data-id="descriptionTooltip"]');
        if (objTooltip) {
            objTooltip.classList.remove('slds-show');
            objTooltip.classList.add('slds-hide');
        }
    }
    getValue() {
        if (!this.strApplicableToText) {
            setTimeout(() => {
                if (this.strApplicableTo) {
                    if (this.strApplicableTo.split(';').length > 1) {
                        this.strApplicableToText = this.strApplicableTo.split(";").length + " selected";
                    } else {
                        this.strApplicableToText = this.strApplicableTo;
                    }
                }
            }, 100);
        }
        if (this.strTitleValue) {
            setTimeout(() => {
                //this.strTitle = this.strTitleValue;
                this.selectedItem = this.strTitleValue;
            }, 100);
        }
    }
    selectOption(objEvent) {
        //Stores the value to display in the input field of the picklist.
        let strApplicableTo = this.strApplicableTo;
        let strApplicableToKey = this.strApplicableToKey;

        //Stores the values explicitly selected by the user and will be sent to apex on click of save.
        let strSelectedApplicableTo = this.strSelectedApplicableTo;
        let strSelectedApplicableToKey = this.strSelectedApplicableToKey;
        let lstApplicableTo = [];
        let lstApplicableToKey = [];
        let lstSelectedApplicableTo = [];
        let lstSelectedApplicableToKey = [];
        let strSelectedText = '';
        let selectId;

        if(objEvent.currentTarget && objEvent.currentTarget.childNodes.length > 1  
            && this.memberMap.size && this.memberMap.has(objEvent.currentTarget.childNodes[1].defaultValue)
            && this.memberMap.get(objEvent.currentTarget.childNodes[1].defaultValue)) {
                selectId = this.memberMap.get(objEvent.currentTarget.childNodes[1].defaultValue);
            }

        if (objEvent.currentTarget && selectId) {            
            //The div tag class name decides if the user is selecting/un selecting the picklist value. The class 'picklistOpions' means user selected a value.
            if (objEvent.currentTarget.childNodes[0].classList.contains("slds-hide")) {
                lstApplicableToKey = strApplicableToKey.split(';');
                if (strSelectedApplicableToKey) {
                    lstSelectedApplicableToKey = strSelectedApplicableToKey.split(';');
                }
                if (lstApplicableToKey.indexOf(selectId) === -1) {
                    if (strApplicableToKey) {
                        strApplicableTo = strApplicableTo + ';' + objEvent.currentTarget.childNodes[1].defaultValue;
                        strApplicableToKey = strApplicableToKey + ';' + selectId;
                        strSelectedText = (lstApplicableToKey.length + 1) + " Selected";
                    } else {
                        strApplicableTo = objEvent.currentTarget.childNodes[1].defaultValue;
                        strApplicableToKey = selectId;
                        strSelectedText = strApplicableTo;
                    }
                }
                if (lstSelectedApplicableToKey.indexOf(selectId) === -1) {
                    if (strSelectedApplicableToKey) {
                        strSelectedApplicableTo = strSelectedApplicableTo + ';' + objEvent.currentTarget.childNodes[1].defaultValue;
                        strSelectedApplicableToKey = strSelectedApplicableToKey + ';' + selectId;
                    } else {
                        strSelectedApplicableTo = objEvent.currentTarget.childNodes[1].defaultValue;
                        strSelectedApplicableToKey = selectId;
                    }
                }
                this.strApplicableTo = strApplicableTo;
                this.strApplicableToKey = strApplicableToKey;
                this.strSelectedApplicableTo = strSelectedApplicableTo;
                this.strSelectedApplicableToKey = strSelectedApplicableToKey;
                this.strApplicableToText = strSelectedText;
                objEvent.currentTarget.childNodes[0].classList.toggle('slds-hide');

            } else if (objEvent.currentTarget.childNodes.length && !objEvent.currentTarget.childNodes[0].classList.contains("slds-hide")) {
                //The below logic is used to remove a particular selection from the picklist array values.
                lstApplicableTo = strApplicableTo.split(';');
                lstApplicableToKey = strApplicableToKey.split(';');
                lstSelectedApplicableTo = strSelectedApplicableTo.split(';');
                lstSelectedApplicableToKey = strSelectedApplicableToKey.split(';');
                if (lstApplicableToKey.indexOf(selectId) > -1) {
                    lstApplicableTo.splice(lstApplicableTo.indexOf(objEvent.currentTarget.childNodes[1].defaultValue), 1);
                    lstApplicableToKey.splice(lstApplicableToKey.indexOf(selectId), 1);
                    strApplicableTo = lstApplicableTo.join(';');
                    strApplicableToKey = lstApplicableToKey.join(';');
                    this.strApplicableToKey = strApplicableToKey;
                    if (lstApplicableToKey.length > 1) {
                        strSelectedText = lstApplicableToKey.length + " Selected";
                    } else if (lstApplicableToKey.length === 1) {
                        strSelectedText = strApplicableTo;
                    } else {
                        //Do Nothing
                    }
                    this.strApplicableTo = strApplicableTo;
                    this.strApplicableToKey = strApplicableToKey;
                    this.strApplicableToText = strSelectedText;
                }
                if (lstSelectedApplicableToKey.indexOf(selectId) > -1) {
                    lstSelectedApplicableTo.splice(lstSelectedApplicableTo.indexOf(objEvent.currentTarget.childNodes[1].defaultValue), 1);
                    lstSelectedApplicableToKey.splice(lstSelectedApplicableToKey.indexOf(selectId), 1);
                    strSelectedApplicableTo = lstSelectedApplicableTo.join(';');
                    strSelectedApplicableToKey = lstSelectedApplicableToKey.join(';');
                    this.strSelectedApplicableTo = strSelectedApplicableTo;
                    this.strSelectedApplicableToKey = strSelectedApplicableToKey;
                }
                objEvent.currentTarget.childNodes[0].classList.toggle('slds-hide')
            } else {
                return;
            }
        }
    }
    insertAbbr() {
        const otherRequired = this.template.querySelector('.label-other');
        if (otherRequired && !otherRequired.querySelector('abbr.slds-required')) {
            const abbr = document.createElement('abbr');
            abbr.className = "slds-required";
            abbr.title = "required";
            abbr.textContent = "*";
            otherRequired.insertBefore(abbr, otherRequired.firstChild);
        }
    }
    removeAbbr() {
        const otherRequired = this.template.querySelector('.label-other');
        const abbr = otherRequired.querySelector('abbr.slds-required');
        if (abbr) {
            otherRequired.removeChild(abbr);
        }
    }
    closeConfirmationModal(){
        this.boolShowConfirmation = false;
        this.isLegacy = false;
    }
    changeOtherField(event) {
        this.selectedItem = event.target.value;
        if (this.selectedItem === 'Other') {
            this.boolIsRequired = true;
            this.insertAbbr();
        } else {
            this.removeAbbr();
            this.boolIsRequired = false;
        }
    }
    setDescriptionValue(event) {
        this.strDescription = event.detail.strDescription;
    }
    fireUpdatePNTAPRecordsEvent = () => {
        const boolValidated = this.validateDates();

        // if(boolValidated) {
        //     const submiteditmodalclickEvent = new CustomEvent("submiteditmodalclick",{
        //         detail:{
        //             startDate : this.startDate,
        //             endDate : this.endDate }
        //         }
        //     );
        //     this.dispatchEvent(submiteditmodalclickEvent);
        // }

    }
    fetchTitleValues() {
        fetchPicklistvalues({}).then(result => {
            if (result) {
                let tempArray = [];
                result.forEach(el => {
                    tempArray.push({ label: el, value: el });
                })
                this.strTitle = tempArray;
            }
        }).catch(error => {
            this.handleErrors(error);
        })

    }
    fetchTabData = () => {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId)
            .then((objTabData) => {
                this.processTabData(objTabData);
            })
            .catch((error) => {
                this.handleErrors(error);
            });
        }    
    };
    closeFocusedTab = () => {
        closeTab(this.strBaseCurrentTabId);
    }
    processTabData = (objTabData) => {
        try {
            this.objTabData = objTabData;
            this.strBaseCurrentTabId = this.objTabData.tabId;
            this.strBaseCurrentTabUrl = this.objTabData.url;
            this.boolBaseIsItSubTab = this.objTabData.isSubtab;
            if (this.boolBaseIsItSubTab === true) {
                this.strBaseCurrentParentTabId = this.objTabData.parentTabId;
            } else {
                this.strBaseCurrentParentTabId = this.objTabData.tabId;
            }
            this.planSummaryListener();
        } catch (error) {
            this.handleErrors(error);
        }
    };
    handleErrors = (error) => {
        this.objCatchError = error;
    };
    hideOnBlur() {
        this.showHideElement('[data-id="mainDiv"]', false);
    }
    strOtherUpdate(event) {
        this.strOther = event.target.value;
    }
    hideShow() {
        let lstSelectedApplicableTo = [];
        if (this.strSelectedApplicableToKey) {
            if (this.strSelectedApplicableToKey.indexOf(';') > -1) {
                lstSelectedApplicableTo = this.strSelectedApplicableToKey.split(";");
            } else {
                lstSelectedApplicableTo.push(this.strSelectedApplicableToKey);
            }
        }

        if (this.strApplicableToKey) {
            if (this.strApplicableToKey.indexOf(';') > -1) {
                const lstApplicableTo = this.strApplicableToKey.split(';');
                let boolElementNotFound = false;
                for (let elem = 0; elem < lstApplicableTo.length; elem++) {
                    this.template.querySelector('[data-id="mainDiv"]')
                    if (this.template.querySelector('[data-id=' + '"' + lstApplicableTo[elem] + '"]')) {
                        this.template.querySelector('[data-id=' + '"' + lstApplicableTo[elem] + '"]').firstChild.classList.remove("slds-hide");
                    } else {
                        boolElementNotFound = true;
                        break;
                    }
                    if (this.boolIsUpdate) {
                        if (lstSelectedApplicableTo.length > 0) {
                            if (lstSelectedApplicableTo.indexOf(lstApplicableTo[elem]) === -1) {
                                this.template.querySelector('[data-id=' + '"' + lstApplicableTo[elem] + '"]').classList.add("disableClass");
                            }
                        } else {
                            this.template.querySelector('[data-id=' + '"' + lstApplicableTo[elem] + '"]').classList.add("disableClass");
                        }
                    }
                }
                if (boolElementNotFound) {
                    return;
                } else {
                    //do nothing
                }
            } else {
                if (this.template.querySelector('[data-id=' + '"' + this.strSelectedApplicableToKey + '"]')) {
                    this.template.querySelector('[data-id=' + '"' + this.strSelectedApplicableToKey + '"]').firstChild.classList.remove("slds-hide");
                    if (this.boolIsUpdate) {
                        if (lstSelectedApplicableTo.length > 0) {
                            if (lstSelectedApplicableTo.indexOf(this.strApplicableToKey) === -1) {
                                this.template.querySelector('[data-id=' + '"' + this.strApplicableToKey + '"]').classList.add("disableClass");
                            }
                        } else {
                            this.template.querySelector('[data-id=' + '"' + this.strApplicableToKey + '"]').classList.add("disableClass");
                        }
                    }
                } else {
                    return;
                }
            }
        }
        //Toggle mainDiv on click, Note: added for CEAS-48824 
        this.toggleElement('[data-id="mainDiv"]');

        //AM:CEAS-50239, Set focus on "mainDiv", this facilitates onblur function to execute
        if(this.template.querySelector(".mainDivCSS")) {
            this.template.querySelector(".mainDivCSS").focus();
        }

        /*
        Previously, an event listener was added on the window to trap the "click" event and 
        close the mainDiv. It was causing issues, so I set up a timer to close the mainDiv after 5 seconds instead. 
        Note: added for CEAS-48824
        */
        //this.template.querySelector('[data-id="mainDiv"]')
        setTimeout(() => {
            if (!this.template.querySelector('[data-id="mainDiv"]').classList.contains("slds-hide")) {
                this.showHideElement("mainDiv", false);
            }
        }, 5000);
    }
    createNewUrl() {

        //Split location URL on the "?" character
        const urlArray = location.href.split("?");

        //Keep data before the "%" in the [1] index position of the urlArray.
        const keepFront = urlArray[1].substring(0, urlArray[1].indexOf("%"));

        //Decode the data after the '=' character in the keepFront variable, add an '&' for additional data ads
        let keepFrontDecoded = window.atob(keepFront.split('=')[1]) + '&';

        //Replace isCreate = true with isCreate=false;
        keepFrontDecoded = keepFrontDecoded.replace('isCreate=true', 'isCreate=false');

        //Encode all URL data and add to return URL
        return "/lightning/n/View_Alert_History?c__BaseURLParam=" + window.btoa(keepFrontDecoded);
    }

    planSummaryListener() {
        if (BaseLWC.stringIsNotBlank(this.Label.EnableVPSTabSpecificEvents_ACE) && this.Label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
            window.addEventListener("PlanSummaryEvent_" + this.strBaseCurrentParentTabId, this.capturePlanSummaryListener);
        } else {
            window.addEventListener("PlanSummaryEvent", this.capturePlanSummaryListener);
        }
    }
    capturePlanSummaryListener = (planSummaryDataEvent) => {

        if (planSummaryDataEvent.detail && typeof planSummaryDataEvent.detail === "string") {

            try {
                if (BaseLWC.stringIsNotBlank(this.Label.EnableVPSTabSpecificEvents_ACE) && this.Label.EnableVPSTabSpecificEvents_ACE.toLowerCase() === 'true') {
                    window.removeEventListener("PlanSummaryEvent_" + this.strBaseCurrentParentTabId, this.capturePlanSummaryListener);
                } else {
                    window.removeEventListener("PlanSummaryEvent", this.capturePlanSummaryListener);
                }
                this.objResponse = JSON.parse(planSummaryDataEvent.detail);
                const objPlanDetails = this.objResponse.objParameters.objMessage.objSelectedPlanDetails;
                const strSelectedPolicyId = objPlanDetails.strPolicyId;
                const lstAllPlanDetails = this.objResponse.objParameters.objMessage.objHistoryPlanDetails;
                this.lstFamilyDetails = this.objResponse.objParameters.objMessage.lstFamilyDetails;
                if (objPlanDetails.strAceLineOfBusiness !== null && objPlanDetails.strAceLineOfBusiness !== undefined) {
                    const strLOB = objPlanDetails.strAceLineOfBusiness.toUpperCase();
                    this.strLineOfBusiness = strLOB;
                    //added code
                    if (this.strLineOfBusiness == 'RETAIL') {
                        this.boollineofbusiness = true;

                    }
                    const titleData = this.strTitle
                    if (this.strLineOfBusiness !== 'RETAIL' && (BaseLWC.isNotUndefinedOrNull(titleData) && titleData !== '')) {
                        const newResult = titleData.filter(filterData => filterData !== 'Disabled Dependent');
                        this.strTitle = newResult;
                    }
                }
                if (!this.lstFamilyDetails) {
                    this.lstFamilyDetails = [];
                    for (const objIteratingPlanDetails in lstAllPlanDetails) {
                        if (lstAllPlanDetails[objIteratingPlanDetails].strPolicyId === strSelectedPolicyId) {
                            this.lstFamilyDetails = lstAllPlanDetails[objIteratingPlanDetails].lstFamilyWrapper;
                            break;
                        }
                    }
                } else if (objPlanDetails.lstFamilyWrapper) {
                    this.lstFamilyDetails = objPlanDetails.lstFamilyWrapper;
                } else {
                    //Do nothing
                }

                const lstMemberNames = [];
                const objNameMember = {};
                if (this.strMemberId === objPlanDetails.strMemberId) {
                    if (this.boolIsUpdate === false) {
                        this.strGroupId = objPlanDetails.strGroupNumber;
                        this.strSubscriberId = objPlanDetails.strSubscriberId;
                        this.strAccountNumber = objPlanDetails.strAccountNumber;
                        if (objPlanDetails.objViewEmployerGroupWrapper) {
                            this.strSectionNumber = objPlanDetails.objViewEmployerGroupWrapper.strGroupSectionNumber;
                        }
                    }
                }

                if (this.lstFamilyDetails) {
                    for (let i = 0; i < this.lstFamilyDetails.length; i++) {
                        const strFullName = this.lstFamilyDetails[i].strFirstName.trim() + ' ' + this.lstFamilyDetails[i].strLastName.trim();
                        const strKey = strFullName + '_' + this.lstFamilyDetails[i].strMemberId;
                        const objMember = {};
                        lstMemberNames.push({ key: strKey, value: strFullName });
                        objMember.FirstName = this.lstFamilyDetails[i].strFirstName;
                        objMember.LastName = this.lstFamilyDetails[i].strLastName;
                        objMember.MID_Surrogate_ACE__c = this.lstFamilyDetails[i].strMemberId;
                        objNameMember[strKey] = objMember;
                        if (this.strMemberId === this.lstFamilyDetails[i].strMemberId) {
                            if (!this.boolIsUpdate) {
                                this.strApplicableTo = strFullName;
                                this.strApplicableToKey = strKey;
                                this.strSelectedApplicableTo = strFullName;
                                this.strSelectedApplicableToKey = strKey;
                                this.strApplicableToText = strFullName;
                            }
                        }
                    }
                    this.lstFamily = lstMemberNames;
                    if(this.lstFamily) {
                        this.setApplicableToMap(this.lstFamily);
                    }
                    this.objNameMember = objNameMember;
                }
            } catch (objError) {
                this.handleErrors(objError);
            }

        }
    };
    setApplicableToMap(arr) {
        if(arr && Array.isArray(arr) && arr.length) {
            arr.forEach(el => {
                this.memberMap.set(el.value, el.key);
            })
        }
    }
    formatDate(strUnformatedDate) {
        if (strUnformatedDate !== null && strUnformatedDate !== undefined && strUnformatedDate !== '') {
            const objDateTime = new Date(strUnformatedDate);
            let intMonth = objDateTime.getMonth() + 1;
            let intDay = objDateTime.getDate();
            const intYear = objDateTime.getFullYear();
            if (intMonth < 10) {
                intMonth = "0" + intMonth;
            }
            if (intDay < 10) {
                intDay = "0" + intDay;
            }
            if(this.isLegacy) {
                return intMonth + "/" + intDay + "/" + intYear;
            } else {
                return intYear + "-" + intMonth + "-" + intDay;
            }
        }
        return null;
    }
    returnStartEndDateObject() {
        let datStartDate = this.formatDate(this.datStartDate);
        let datEndDate = this.formatDate(this.datEndDate);
        if (!datStartDate || !datEndDate) {
            datStartDate = this.formatDate(datStartDate);
            datEndDate = this.formatDate(datEndDate);
        }
        return {
            "startDate": datStartDate,
            "endDate": datEndDate
        }
    }
    validateDateFormat(datDate) {
        let boolIsErrorVal = true;

        const pattern = /(0\d{1}|1[0-2])\/([0-2]\d{1}|3[0-1])\/[0-9]{4}/;
        const matchPattern = datDate.match(pattern);

        if (!matchPattern) {
            return this.boolIsErrorVal;
        }
        const datDateConverted = this.formatDate(datDate);
        if (datDateConverted === 'Invalid Date') {
            return this.boolIsErrorVal;
        }
        this.boolIsErrorVal = false;
        return this.boolIsErrorVal;
    }
    validateAlertForm() {

        let boolIsError = true;
        const datCurrentDate = this.formatDate(new Date());
        const strTitle = this.selectedItem;
        const strOther = this.strOther;
        const objDates = this.returnStartEndDateObject();
        const datStartDate = objDates.startDate;
        const datEndDate = objDates.endDate;
        const strDescription = this.strDescription;
        const strGroupId = this.strGroupId;
        const strSectionNumber = this.strSectionNumber;
        const strApplicableTo = this.strApplicableTo;
        const boolIsUpdate = this.boolIsUpdate;

        if (this.boolIsRequired === false) {
            boolIsError = false;
            this.template.querySelector('.idAlertOtherError').classList.add('slds-hide');
        }
        if (BaseLWC.isNotUndefinedOrNull(strTitle) && strTitle !== '') {
            boolIsError = false;
            this.template.querySelector('.idAlertTitleError').classList.add('slds-hide');
        } else {
            boolIsError = true;
            this.template.querySelector('.idAlertTitleError').classList.remove('slds-hide');
        }
        if (BaseLWC.isNotUndefinedOrNull(strOther) && strOther !== '') {
            boolIsError = false;
            this.template.querySelector('.idAlertOtherError').classList.add('slds-hide');

        } else if (strOther == '' && this.boolIsRequired === true) {
            boolIsError = true;
            this.template.querySelector('.idAlertOtherError').classList.remove('slds-hide');
        } else {
            //Do Nothing
        }

        if (this.template.querySelector('.startDateDiv').classList.contains('disabled') === false) {
            if (BaseLWC.isNotUndefinedOrNull(datStartDate) && datStartDate !== '') {
                this.template.querySelector('.idAlertStartDateError').classList.add('slds-hide');
                //check to verify if the date is valid.
                const boolIsErrorVal = this.validateDateFormat(datStartDate);
                if (boolIsErrorVal) {
                    boolIsError = true;
                    this.template.querySelector('.idAlertInvalidStartDateError').classList.remove('slds-hide');
                    this.template.querySelector('.idAlertStartDateError').classList.add('slds-hide');
                    this.template.querySelector('.idAlertPastStartDateError').classList.add('slds-hide');
                } else {
                    if (new Date(datStartDate) < new Date(datCurrentDate)) {
                        boolIsError = true;
                        this.template.querySelector('.idAlertPastStartDateError').classList.remove('slds-hide');
                        this.template.querySelector('.idAlertInvalidStartDateError').classList.add('slds-hide');
                        this.template.querySelector('.idAlertStartDateError').classList.add('slds-hide');
                    } else {
                        this.template.querySelector('.idAlertPastStartDateError').classList.add('slds-hide');
                        this.template.querySelector('.idAlertStartDateError').classList.add('slds-hide');
                        this.template.querySelector('.idAlertInvalidStartDateError').classList.add('slds-hide');
                    }
                }
            } else {
                boolIsError = true;
                this.template.querySelector('.idAlertStartDateError').classList.remove('slds-hide');
                this.template.querySelector('.idAlertPastStartDateError').classList.add('slds-hide');
                this.template.querySelector('.idAlertInvalidStartDateError').classList.add('slds-hide');
            }
        }

        //To validate end date
        boolIsError = this.validateEndDate(boolIsUpdate, datEndDate, datStartDate, datCurrentDate, boolIsError);
        if (BaseLWC.isNotUndefinedOrNull(strDescription) && strDescription !== '') {
            this.template.querySelector('.idAlertDescriptionError').classList.add('slds-hide');
        } else {
            boolIsError = true;
            this.template.querySelector('.idAlertDescriptionError').classList.remove('slds-hide');
        }
        if (this.strRecordType !== 'Member') {
            if (BaseLWC.isNotUndefinedOrNull(strGroupId) && strGroupId !== '') {
                this.template.querySelector('.idGroupNumberError').classList.add('slds-hide');
            } else {
                boolIsError = true;
                this.template.querySelector('.idGroupNumberError').classList.remove('slds-hide');
            }
            if (BaseLWC.isNotUndefinedOrNull(strSectionNumber) && strSectionNumber !== '') {
                this.template.querySelector('.idSectionNumberError').classList.add('slds-hide');
            } else {
                boolIsError = true;
                this.template.querySelector('.idSectionNumberError').classList.remove('slds-hide');
            }
        }

        if (strApplicableTo) {
            this.template.querySelector('.idApplicableTo').classList.add('slds-hide');
        } else {
            boolIsError = true;
            this.template.querySelector('.idApplicableTo').classList.remove('slds-hide');
        }
        return boolIsError;
    }
    validateAlertFormDateCheck(datEndDate, datStartDate, datCurrentDate, boolIsError) {
        //Throw an error if the end date is before start date.
        let boolIsErrorVal = boolIsError;

        if (new Date(datEndDate) <= new Date(datStartDate)) {
            boolIsErrorVal = true;
            this.template.querySelector('.idAlertIncorrectEndDateError').classList.remove('slds-hide');
            this.template.querySelector('.idAlertEndDateError').classList.add('slds-hide');
            this.template.querySelector('.idAlertInvalidEndDateError').classList.add('slds-hide');
            this.template.querySelector('.idAlertPastEndDateError').classList.add('slds-hide');
        } else {
            this.template.querySelector('.idAlertIncorrectEndDateError').classList.add('slds-hide');
        }

        //Throw error if user is updating the End date to past date.
        if (datEndDate < datCurrentDate) {
            boolIsErrorVal = true;
            this.template.querySelector('.idAlertPastEndDateError').classList.remove('slds-hide');
            this.template.querySelector('.idAlertEndDateError').classList.add('slds-hide');
            this.template.querySelector('.idAlertInvalidEndDateError').classList.add('slds-hide');
            this.template.querySelector('.idAlertIncorrectEndDateError').classList.add('slds-hide');
        } else {
            this.template.querySelector('.idAlertPastEndDateError').classList.add('slds-hide');
        }
        return boolIsErrorVal;
    }
    validateEndDate(boolIsUpdate, datEndDateval, datStartDate, datCurrentDate, boolIsErrorVal) {
        let boolIsError = boolIsErrorVal;
        const datEndDate = datEndDateval;
        if (!boolIsUpdate) {
            if (BaseLWC.isNotUndefinedOrNull(datEndDate) && datEndDate !== '') {

                this.template.querySelector('.idAlertEndDateError').classList.add('slds-hide');
                this.template.querySelector('.idAlertInvalidEndDateError').classList.add('slds-hide');

                //check to verify if the date is valid.
                const boolIsErrorValue = this.validateDateFormat(datEndDate);

                if (boolIsErrorValue) {
                    boolIsError = true;
                    this.template.querySelector('.idAlertInvalidEndDateError').classList.remove('slds-hide');
                    this.template.querySelector('.idAlertEndDateError').classList.add('slds-hide');
                    this.template.querySelector('.idAlertPastEndDateError').classList.add('slds-hide');
                    this.template.querySelector('.idAlertIncorrectEndDateError').classList.add('slds-hide');
                } else {
                    this.template.querySelector('.idAlertEndDateError').classList.add('slds-hide');
                    boolIsError = this.validateAlertFormDateCheck(datEndDate, datStartDate, datCurrentDate, boolIsError);
                }

            } else {
                boolIsError = true;
                this.template.querySelector('.idAlertEndDateError').classList.remove('slds-hide');
                this.template.querySelector('.idAlertInvalidEndDateError').classList.add('slds-hide');
                this.template.querySelector('.idAlertPastEndDateError').classList.add('slds-hide');
                this.template.querySelector('.idAlertIncorrectEndDateError').classList.add('slds-hide');
            }
        } else {
            if (BaseLWC.isNotUndefinedOrNull(datEndDate) && datEndDate !== '') {

                this.template.querySelector('.idAlertEndDateError').classList.add('slds-hide');

                //check to verify if the date is valid.
                const boolIsErrorValue = this.validateDateFormat(datEndDate);

                if (boolIsErrorValue) {
                    boolIsError = true;
                    this.template.querySelector('.idAlertInvalidEndDateError').classList.remove('slds-hide');
                    this.template.querySelector('.idAlertEndDateError').classList.add('slds-hide');
                    this.template.querySelector('.idAlertPastEndDateError').classList.add('slds-hide');
                    this.template.querySelector('.idAlertIncorrectEndDateError').classList.add('slds-hide');
                } else {
                    this.template.querySelector('.idAlertPastEndDateError').classList.add('slds-hide');
                    boolIsError = this.validateAlertFormDateCheck(datEndDate, datStartDate, datCurrentDate, boolIsError);
                }

            } else {
                boolIsError = true;
                this.template.querySelector('.idAlertEndDateError').classList.remove('slds-hide');
                this.template.querySelector('.idAlertInvalidEndDateError').classList.add('slds-hide');
                this.template.querySelector('.idAlertIncorrectEndDateError').classList.add('slds-hide');
                this.template.querySelector('.idAlertPastEndDateError').classList.add('slds-hide');
            }
        }
        return boolIsError;
    }
    save(event) {

        const boolIsError = this.validateAlertForm();
        this.isLegacy = false;
        let strAlertIdToSend;
        if (event.target.label && event.target.label === 'Save New') {
            strAlertIdToSend = '';
        } else {
            strAlertIdToSend = this.strAlertId;
        }
        if (!boolIsError) {
            const objAlert = {};
            const objNameMember = this.objNameMember;
            const strApplicableToKey = this.strSelectedApplicableToKey;
            let arrMembers = [];
            let arrApplicableTo = [];

            const objDates = this.returnStartEndDateObject();
            objAlert.StartDate_ACE__c = objDates.startDate;
            objAlert.EndDate_ACE__c = objDates.endDate;
            objAlert.Description_ACE__c = this.strDescription;
            objAlert.Title_ACE__c = this.strOther;
            objAlert.AccountNumber_ACE__c = this.strAccountNumber;
            objAlert.GroupNumber_ACE__c = this.strGroupId;
            objAlert.SectionNumber_ACE__c = this.strSectionNumber;
            objAlert.SubscriberID_ACE__c = this.strSubscriberId;
            objAlert.Account_ACE__c = this.recordId;
            objAlert.ApplicableTo_ACE__c = this.strApplicableTo;
            if (this.selectedItem) {
                objAlert.TitlePicklist_ACE__c = this.selectedItem;
            }

            //Set the Alert record Id in case of Update Alert.
            if (this.boolIsUpdate) {
                objAlert.Id = this.idAlert;
            }

            //Prepare the arrMembers array with the additional members selected by the User from Applicable To picklist.
            if (BaseLWC.isNotUndefinedOrNull(strApplicableToKey)) {
                //Since the strApplicableTo variable is Member names seperated by ';', use the split function of the string and prepare the arrAplicable to array.
                if (strApplicableToKey.indexOf(';') > -1) {
                    arrApplicableTo = strApplicableToKey.split(";");
                } else {
                    arrApplicableTo.push(strApplicableToKey);
                }

                /* "objNameMember" is a object with Member Name as key and his first name, last name and the mid object as Value.
                * We use the Member name from the strApplicable To picklist and get the member details from objNameMember object.
                * We use these details to create new Person Account records in salesforce in case the member is not created yet inside salesforce
                */
                arrApplicableTo.forEach(function (strMemberName) {
                    arrMembers.push(objNameMember[strMemberName]);
                });

            }

            const strAlertsACE = JSON.stringify(objAlert);
            const strMembersACE = JSON.stringify(arrMembers);
            const strLegacyAlertId = strAlertIdToSend;

            createAlerts({ strAlertsACE, strMembersACE, strLegacyAlertId }).then(result => {
                if(result) {
                    if(strLegacyAlertId) {
                        this.boolShowToastMessage = true;                        
                    } else {
                        this.showNotification(this.successToast);
                    }
                    setTimeout(() => {
                        this.closeFocusedTab();
                        this[NavigationMixin.Navigate]({
                            type: "standard__recordPage",
                            attributes: {
                              recordId:result,
                              actionName: "view"
                            }
                          })
                    }, 3000);                                        
                }
            })

        }//758 
    }
    cancel() {
        const isBoolEdit = this.boolIsUpdate;
        const boolIsFromHCD = this.boolIsFromHCD;
        const urlCheck = this.createNewUrl(); 
        /* Check if the Cancel button clicked from Create Alert / Edit Alert.
         * In case from Edit Alert, redirect the user to detail page.
         * In case of Create Alert to Alert History.
         */
        if (isBoolEdit) {
            if (this.objTabData) {
                const focusedTabId = this.objTabData.tabId;
                setTabLabel(focusedTabId, '');
            }
            this[NavigationMixin.Navigate]({
                type: "standard__recordPage",
                attributes: {
                  recordId:this.idAlert,
                  actionName: "view"
                }
              })
        } else {        
            let boolIsContains = false;
            let strPageName;
            if (this.objTabData) {
                try {
                    getTabInfo(this.objTabData.parentTabId).then(objRes => {
                        if (boolIsFromHCD === 'true') {
                            strPageName = 'View_Alert_History';
                        } else {
                            strPageName = 'View_Agent_Alert_History';
                        }
                        for (let j = 0; j < objRes.subtabs.length; j++) {
                            const strSubtabUrl = objRes.subtabs[j].url;
                            if (strSubtabUrl.includes(strPageName)) {
                                boolIsContains = true;
                                const focusedTabId = objRes.subtabs[j].tabId;
                                focusTab(
                                    focusedTabId
                                ).catch();
                                closeTab(
                                    this.objTabData.tabId
                                ).catch();
                            }
                        }
                        if (boolIsContains === false) {                    
                           //AM:CEAS-48825, open sub tab with modified URL to open notifications view for member
                           openSubtab(this.objTabData.parentTabId,{url: urlCheck, focus: true}
                           ).catch();
                            closeTab(
                            this.objTabData.tabId
                            ).catch();
                        }
                    });
                } catch (error) {
                    //Do Nothing
                }
            }
        }
    }
    showHideElement(elementToFind, show) {

        if (show) {
            this.template.querySelector(elementToFind)?.classList.remove('slds-hide');
        } else {
            this.template.querySelector(elementToFind)?.classList.add('slds-hide');
        }

    }
    toggleElement(elementToFind) {
        //show div
        if (this.template.querySelector(elementToFind).classList.contains('slds-hide')) {
            this.showHideElement(elementToFind, true);
        } else {
            this.showHideElement(elementToFind, false);
        }
    }
    verifyAndCreateNotification() {
        const isValidationSuccessful = this.validateAlertForm();
        this.isLegacy = true;
        if (!isValidationSuccessful) {
            this.setLegacyDates();
            this.boolShowConfirmation =  true;
        }
    }
    setLegacyDates() {
        this.isLegacy = true;
        if (this.datStartDate) {
            this.legacyStartDate =  this.formatDate(this.datStartDate);
        }
        if (this.datEndDate) {
            this.legacyEndDate =  this.formatDate(this.datEndDate);
        }
    }
}
