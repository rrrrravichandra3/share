import { LightningElement,track,api } from 'lwc';

export default class LwcOtherInsuranceInformation extends LightningElement {

    @track otherInsuranceInfoA;
    @track otherInsuranceInfoB;
    @track strLOB;
    @track otherInsuraceInfo;
    @track boolAutoDocDisable;
    @track boolAutoDoc;
    @api intServiceLineIndex;
    @api boolIsInternalInteraction;
    @api strAccountId;
    @api strDcnNumber;
    @api strClaimNumber;
    @api strUrlAdjNumber;
    @api strCaseRecordTypeId;
    @api strUrlClaimId;
    @track strMemId;
    @track grpNumber;
    @track strCmid;
    @track strInteractionId;
    @api 
    get strInteractionLogId() {
        return this.strInteractionId;
    }

    set strInteractionLogId(value) {
        if (value) {
            this.strInteractionId = value;
        }
    }
    @api 
    get strMemeberId() {
        return this.strMemId;
    }

    set strMemeberId(value) {
        if (value) {
            this.strMemId = value;
        }
    }
    @api 
    get groupNumber() {
        return this.grpNumber;
    }

    set groupNumber(value) {
        if (value) {
            this.grpNumber = value;
        }
    }
    @api 
    get strCMID() {
        return this.strCmid;
    }

    set strCMID(value) {
        if (value) {
            this.strCmid = value;
        }
    }
    @api
    get autoDocDisable() {
        return this.boolAutoDocDisable;
    }
    set autoDocDisable(value) {
        if (value) {
            this.boolAutoDocDisable = value;
        }
    } 
    
    @api
    get hideAutoDoc() {
        return this.boolAutoDoc;
    }
    set hideAutoDoc(value) {
        if (value) {
            this.boolAutoDoc = value;
        }
    } 
    @api
    get otherInsuranceInfoData() {
        return this.otherInsuraceInfo;
    }
    set otherInsuranceInfoData(value) {
        if (value) {
            this.otherInsuraceInfo = this.deepCloneMap(value);
        }
    }

    @api
    get infoLineOfBusiness() {
        return this.strLOB;
    }
    set infoLineOfBusiness(value) {
        if (value) {
            this.strLOB = value;
        }
    }

    deepCloneMap = (obj) => {
        let Val;
        if (typeof obj == 'number' || typeof obj == 'string' || typeof obj == 'undefined') {
            Val = obj;
        } else if (obj instanceof Map) {
            Val = new Map();
            for (const [key, value] of obj.entries()) {
                Val.set(key, this.deepCloneMap(value));
            }
        } else if (Array.isArray(obj)) {
            Val = obj.map(el => {
                return this.deepCloneMap(el);
            });
        } else {
            Val = JSON.parse(JSON.stringify(obj));
        }
        return Val;
    }


    connectedCallback(){
        this.fetchData();    
    }
   
    fetchSectionsWrapper( sectionLabel, sectionId, fields, boolHideCardIcon, boolHideAutodoc) {
        return {
            'sectionLabel' : sectionLabel,
            'sectionId' : sectionId,
            'boolHideCardIcon': boolHideCardIcon,
            'fields' : fields,
            'boolHideAutodoc': boolHideAutodoc
        }
    }
    
    fetchFieldWrapper(label, value, uniqueId, tabId) {
        return {
            'label' : label,
            'value' : this.getDefaultedValue(value),
            'tabIdInField' : tabId,
            'uniqueId' : uniqueId,
            'boolText' : true
        };
    }

    getDefaultedValue(value) {
       return value ? value : '-';
    }

    closeModal() {
        const closeModalEvent = new CustomEvent("closemodal",
        { detail :false }, this);
        this.dispatchEvent(closeModalEvent);
    }

    fetchData(){
        let InfoData = JSON.parse(JSON.stringify(this.otherInsuraceInfo));
        let lstInsuranceData = [];
        let serviceLinesData = [];
        let tplServiceLineData = [];
        if(typeof this.intServiceLineIndex === 'number' && InfoData && InfoData.serviceLines) {
            lstInsuranceData = InfoData.lstInsuranceData;
            serviceLinesData = InfoData.serviceLines[this.intServiceLineIndex];
            if(serviceLinesData && serviceLinesData.tpl && serviceLinesData.tpl.length) {
                tplServiceLineData = serviceLinesData.tpl[0]?.amounts;
            }
        }

        if(lstInsuranceData && lstInsuranceData.length){
            lstInsuranceData.forEach ((objInsuranceData) => {
                if(objInsuranceData.payerIdentifier === '1'){
                    const otherInfoAFields = [];
                    otherInfoAFields.push(this.fetchFieldWrapper('Other Insurance A', objInsuranceData?.insuranceName, 'other-insurance-a', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('Other Insurance A Effective Date',objInsuranceData?.coverageBeginDate, 'other-insurance-a-effective-date', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('Alternate Coverage ID', serviceLinesData?.alternateCoverageProvisionCode , 'alternate-coverage-id', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('Claim Government Subsidy', serviceLinesData?.amounts?.strSubsidyAmount, 'claim-government-subsidy', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('COB Savings Basic Amount', tplServiceLineData?.savingAmount, 'cob-savings-basic-amount', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('COB Savings Major Medical Amount', tplServiceLineData?.majorMedicalSavingAmount, 'cob-savings-major-medical-amount', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('Other Insurance A Policy ID', objInsuranceData?.policyIdentifier, 'other-insurance-a-policy-id', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('Other Insurance A Patient Liability Amount', tplServiceLineData?.patientShareAmount, 'other-insurance-a-patient-liability-amount', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('Other Insurance A Allowed Amount', tplServiceLineData?.allowedAmount, 'other-insurance-a-allowed-amount', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('Other Insurance A Paid Amount', tplServiceLineData?.paidAmount, 'other-insurance-a-paid-amount', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('Other Insurance A COB Recovery Basic Amount', tplServiceLineData?.recoveryAmount, 'other-insurance-a-cob-recovery-basic-amount', 'insuranceInformation'));
                    otherInfoAFields.push(this.fetchFieldWrapper('Other Insurance A COB Recovery Major Medical Amount', tplServiceLineData?.majorMedicalRecoveryAmount, 'other-insurance-a-cob-recovery-major-medical-amount', 'insuranceInformation'));
        
                    this.otherInsuranceInfoA = this.fetchSectionsWrapper('Other Insurance A', 'otherInsuranceA', otherInfoAFields, true, false);
                } else if(objInsuranceData.payerIdentifier === '2') {
                    const otherInfoBFields = [];
                    otherInfoBFields.push(this.fetchFieldWrapper('Other Insurance B', objInsuranceData?.insuranceName, 'other-insurance-b', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('Other Insurance B Effective Date', objInsuranceData?.partBEffectiveDate, 'other-insurance-a-effective-date', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('Alternate Coverage ID', serviceLinesData?.alternateCoverageProvisionCode , 'alternate-coverage-id', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('Claim Government Subsidy', serviceLinesData?.amounts?.strSubsidyAmount, 'claim-government-subsidy', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('COB Savings Basic Amount', tplServiceLineData?.savingAmount, 'cob-savings-basic-amount', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('COB Savings Major Medical Amount', tplServiceLineData?.majorMedicalSavingAmount, 'cob-savings-major-medical-amount', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('Other Insurance B Policy ID', objInsuranceData?.policyIdentifier, 'other-insurance-b-policy-id', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('Other Insurance B Patient Liability Amount', tplServiceLineData?.patientShareAmount, 'other-insurance-b-patient-liability-amount', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('Other Insurance B Allowed Amount', tplServiceLineData?.allowedAmount, 'other-insurance-b-allowed-amount', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('Other Insurance B Paid Amount', tplServiceLineData?.paidAmount, 'other-insurance-b-paid-amount', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('Other Insurance B COB Recovery Basic Amount', tplServiceLineData?.recoveryAmount, 'other-insurance-b-cob-recovery-basic-amount', 'insuranceInformation'));
                    otherInfoBFields.push(this.fetchFieldWrapper('Other Insurance B COB Recovery Major Medical Amount', tplServiceLineData?.majorMedicalRecoveryAmount, 'other-insurance-b-cob-recovery-major-medical-amount', 'insuranceInformation'));
        
                    this.otherInsuranceInfoB = this.fetchSectionsWrapper('Other Insurance B', 'otherInsuranceB', otherInfoBFields, true, false);

                }
            })       
            
        }
    }  
            
    getManualCaseCreationInfo() {
        this.dispatchEvent(new CustomEvent('openmanualcase', {
            detail: {
                message: 'openmanualcase'
            }
        }));
    }
    
}