import { LightningElement, wire, track, api } from 'lwc';
//Base LWC functions.
import BaseLWC from 'c/baseLWCFunctions_CF';

import fetchSmsTextMessages from '@salesforce/apex/SmsTextMessageHCDListViewController_ACE.fetchSmsTextMessagesLwc';

//import labels
import SMSTextMessage_TableHeader_Outbound_ACE from '@salesforce/label/c.SMSTextMessage_TableHeader_Outbound_ACE';
import SMSTextMessage_TableHeader_DateTimeOpened_ACE from '@salesforce/label/c.ViewCaseSummary_DateTimeOpened_ACE';
import SMSTextMessage_TableHeader_Subject_ACE from '@salesforce/label/c.ViewCaseSummary_Subject_ACE';
import SMSTextMessage_TableHeader_CreatedBy_ACE from '@salesforce/label/c.SMSTextMessage_TableHeader_CreatedBy_ACE';
import SMSTextMessage_TableHeader_CaseType_ACE from '@salesforce/label/c.SMSTextMessage_TableHeader_CaseType_ACE';
import SMSTextMessage_TableHeader_SubType_ACE from '@salesforce/label/c.SMSTextMessage_TableHeader_SubType_ACE';
import SMSTextMessage_TableHeader_CaseStatus_ACE from '@salesforce/label/c.SMSTextMessage_TableHeader_CaseStatus_ACE';
import SMSTextMessage_TableHeader_CaseNumber_ACE from '@salesforce/label/c.ViewCaseSummary_CaseNumber_ACE';
import SMSTextMessage_TableHeader_MessageBody_ACE from '@salesforce/label/c.SMSTextMessage_TableHeader_MessageBody_ACE';
import SafeMode_ToastMessage_ACE from '@salesforce/label/c.SafeMode_ToastMessage_ACE';
import InteractionHistoryPage_NoRecordFound_ACE from '@salesforce/label/c.InteractionHistoryPage_NoRecordFound_ACE';
import IntegrationFailMessage_ACE from '@salesforce/label/c.IntegrationFailMessage_ACE';
import { EnclosingTabId, getTabInfo, openSubtab } from 'lightning/platformWorkspaceApi';

export default class LwcSmsTextMessageTabComponent extends LightningElement {
    @wire(EnclosingTabId) enclosingTabId;

    label = {
        SMSTextMessage_TableHeader_Outbound_ACE,
        SMSTextMessage_TableHeader_DateTimeOpened_ACE,
        SMSTextMessage_TableHeader_Subject_ACE,
        SMSTextMessage_TableHeader_CreatedBy_ACE,
        SMSTextMessage_TableHeader_CaseType_ACE,
        SMSTextMessage_TableHeader_SubType_ACE,
        SMSTextMessage_TableHeader_CaseStatus_ACE,
        SMSTextMessage_TableHeader_CaseNumber_ACE,
        SMSTextMessage_TableHeader_MessageBody_ACE,
        SafeMode_ToastMessage_ACE,
        InteractionHistoryPage_NoRecordFound_ACE,
        IntegrationFailMessage_ACE
    }

    @api tabData;
    @api globalData;
    @api boolSafeMode;

    boolSpinner = false;
    boolShowNoRecorsFound = false;
    boolAPIError = false;
    boolDisplayData = false;
    boolDisplayLimitMessage = false;

    intLimitCount = 100;
    strLimitMessage = '';
    lstTableData = [];
    columns = [
        { label: this.label.SMSTextMessage_TableHeader_Outbound_ACE, fieldName: 'outBound', sortable: true, type: '' },
        { label: this.label.SMSTextMessage_TableHeader_DateTimeOpened_ACE, fieldName: 'dateTimeOpened', boolInitSort: true, boolAsc: false, sortable: true, type: 'date' },
        { label: this.label.SMSTextMessage_TableHeader_Subject_ACE, fieldName: 'subject', sortable: true, type: '' },
        { label: this.label.SMSTextMessage_TableHeader_CreatedBy_ACE, fieldName: 'createdBy', sortable: true, type: '' },
        { label: this.label.SMSTextMessage_TableHeader_CaseType_ACE, fieldName: 'caseType', sortable: true, type: '' },
        { label: this.label.SMSTextMessage_TableHeader_SubType_ACE, fieldName: 'subType', sortable: true, type: '' },
        { label: this.label.SMSTextMessage_TableHeader_CaseStatus_ACE, fieldName: 'caseStatus', sortable: true, type: '' },
        { label: this.label.SMSTextMessage_TableHeader_CaseNumber_ACE, fieldName: 'caseNumber', sortable: true, type: '' }
    ]

    objInitTableSettings = {
        pageSize: 25,
        restrictedPageSize: 5,
        boolViewMore: true,
        columnsData: this.columns,
        boolShowFilter: true,
        boolSecondaryTable: true,
        boolShowSearch: true,
        boolShowSearchLabel: true,
        filterData: [
            { strType: 'date', intCol: 2, strFilterName: "Date/Time Sent" },
            { strType: 'picklist', intCol: 5, strFilterName: "Case Type" },
            { strType: 'picklist', intCol: 6, strFilterName: "Sub-Type" },
            { strType: 'picklist', intCol: 7, strFilterName: "Case Status" },
            { strType: 'text', intCol: 8, strFilterName: "Case Number" }

        ],
    };

    connectedCallback() {
        this.fetchData();
    }

    refreshData = () => {
        this.fetchData();
    }

    fetchData = () => {
        this.boolSpinner = true;
        this.boolShowNoRecorsFound = false;
        this.boolAPIError = false;
        this.boolDisplayData = false;

        fetchSmsTextMessages({ strAccountIdParam: this.tabData.recordId }).then(result => {

            const data = JSON.parse(result);
            const intDataLength = data.length;

            this.strLimitMessage = `Displaying 100/${intDataLength} text messages.`;
            const lstData = [];
            for (let i = 0; i < intDataLength; i++) {
                const obj = { ...data[i] };
                let dtTimeOpened = '';
                if (BaseLWC.dtDateTimeISOtoLocal(obj.dateTimeOpened) !== 'Invalid Date') {
                    dtTimeOpened = BaseLWC.dtDateTimeISOtoLocal(obj.dateTimeOpened)
                }
                obj['dateTimeOpened'] = {
                    value: obj.dateTimeOpened,
                    wrapper: `<span>${dtTimeOpened}</span>`
                }
                obj['caseNumber'] = {
                    value: obj['caseNumber'],
                    strCaseId: obj['caseId'],
                    wrapper: `<a data-casenumber="${obj.caseNumber}">${obj.caseNumber}</a>`
                };
                obj['createdBy'] = {
                    value: obj['createdBy'],
                    strUserId: obj['userId'],
                    wrapper: `<a data-userid="${obj.userId}">${obj.createdBy}</a>`
                };
                obj['boolSecTable'] = true;
                obj['strSecTable'] = `<p>${obj.msgBody}</p>`;
                lstData.push(obj);
                if (i === (this.intLimitCount - 1)) {
                    this.boolDisplayLimitMessage = true;
                    break;
                }
            }
            this.lstTableData = [...lstData];

            this.boolSpinner = false;
            this.boolDisplayData = true;
            if (!this.lstTableData.length) {
                this.boolShowNoRecorsFound = true;
            }
        }).catch(() => {
            this.boolSpinner = false;
            this.boolAPIError = true;
        })

    }

    handleRowAction(event) {
        const rowData = JSON.parse(event.detail);
        if (rowData.activeColumnName === this.label.SMSTextMessage_TableHeader_CreatedBy_ACE) {
            this.openUserDetails(rowData.activeColumnData.value.strUserId)
        } else if (rowData.activeColumnName === this.label.SMSTextMessage_TableHeader_CaseNumber_ACE) {
            this.openCaseDetails(rowData.activeColumnData.value.strCaseId, rowData.activeColumnData.value.value)
        } else {
            //Do nothing
        }
    }

    openCaseDetails = (strCaseId, strCaseNumber) => {
        if (this.enclosingTabId) {
            getTabInfo(this.enclosingTabId).then(objTabData => {
                const objParsedTabData = JSON.parse(JSON.stringify(objTabData));
                if (objParsedTabData.url) {
                    const strDecodedURL = BaseLWC.helperBaseDecodeUrl(objParsedTabData.url);
                    if (!BaseLWC.isValidUrl(strDecodedURL)) {
                        return
                    }
                    const objUrl = new URL(strDecodedURL);
                    const strProducerId = objUrl.searchParams.get("producerId");
                    let strParams = '?mid=' + this.globalData.strUrlMemberId + '&caseNumber=' + strCaseNumber;
                    if (this.globalData.boolProspectMember) {
                        strParams += '&boolProspectMember=true&boolProducer=false&boolURLFormed=true'
                    } else {
                        if (this.globalData.objAccRecords.RecordType.value.fields.DeveloperName.value === 'Producer_ACE') {
                            strParams += '&boolProducer=true&producerId=' + strProducerId
                        } else {
                            strParams += '&boolProducer=false'
                        }
                    }
    
                    const strUrl = '/lightning/r/Case/' + strCaseId + '/view' + BaseLWC.helperBaseEncodeUrl(strParams);
    
                    openSubtab(this.tabData.tabId, { url: strUrl, focus: true })
                        .then(() => {
                            //Do nothing
                        }).catch(() => {
                            //Do nothing
                        })
                }
            })
        }
       
    }

    openUserDetails = (strUserId) => {
        const strUrl = '/lightning/r/User/' + strUserId + '/view';

        openSubtab(this.tabData.tabId, { url: strUrl, focus: true })
            .then(() => {
                //Do nothing
            }).catch(() => {
                //Do nothing
            })

    }

    closeLimitMessage = () => {
        this.boolDisplayLimitMessage = false;
    }
}