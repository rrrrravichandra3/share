import { LightningElement, api } from 'lwc';
import HCSCClaimsStaticResource_ACE from '@salesforce/resourceUrl/HCSCClaimsStaticResource_ACE';

export default class AlertDescriptionRichTextACE extends LightningElement {

    @api strHelpText;
    @api strLabel;
    @api strPlaceholder;
    @api strAGSDescription;
    strDescription;
    strTooltipImagePath = HCSCClaimsStaticResource_ACE + '/Images/info.png';

    sendDescriptionValueToParent(event) {
        const strInput = event.target.value;
        if (strInput !== undefined && strInput !== null && strInput !== '') {
            if (strInput.replace(/<\/?[^>]+(>|$)/g, "").length > 500) {
                const objEditor = this.template.querySelector('lightning-input-rich-text');
                const intStartIndex = 500;
                const intEndIndex = strInput.replace(/<\/?[^>]+(>|$)/g, "").length;
                objEditor.setRangeText('', intStartIndex, intEndIndex, 'select');
            }
        }
        this.strDescription = event.target.value;
        const objValueChangeEvent = new CustomEvent('valuechange', {
            detail: { strDescription: this.strDescription }
        });
        this.dispatchEvent(objValueChangeEvent);
    }

    handleMouseOver() {
        const objTooltip = this.template.querySelector('[data-id="descriptionTooltip"]');
        if (objTooltip) {
            objTooltip.classList.remove('slds-hide');
            objTooltip.classList.add('slds-show');
        }
    }

    handleMouseOut() {
        const objTooltip = this.template.querySelector('[data-id="descriptionTooltip"]');
        if (objTooltip) {
            objTooltip.classList.remove('slds-show');
            objTooltip.classList.add('slds-hide');
        }
    }
}