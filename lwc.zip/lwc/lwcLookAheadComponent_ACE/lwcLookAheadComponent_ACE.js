import { LightningElement,api,track } from 'lwc';

export default class LwcLookAheadComponent_ACE extends LightningElement {
    @api lstInitDataset;
    @api lstTotalDataset;
    @api lstVisibleDataset;
    @api strLabel;
    @api strValue;
    @api strEmptyErrorMessage;
    @api strErrorMessage;
    @api strPlaceholder;
    @api strMaxLength;
    @api boolRequired;
    @api boolError;
    @track boolStrValue;

    connectedCallback() {
        //set the array values into array of objects
        const lstDataset = this.lstTotalDataset;
        if (lstDataset && lstDataset.length) {
            const lstAllDataset = lstDataset.map((item,index) => {
                return {
                    data: item,
                    value: item,
                    index: index
                }
            });
            this.lstTotalDataset = lstAllDataset;
            this.lstVisibleDataset = lstAllDataset;
        }
    }


    userSearchHandler(objEvent) {
        const strEventType = objEvent.type;
        const objTarget = objEvent.currentTarget;
        if (strEventType === 'click') {
            if (objTarget.closest('.slds-combobox').classList.contains('slds-is-open')) {
                objTarget.setAttribute("aria-expanded", false);
            } else {
                objTarget.setAttribute("aria-expanded", true);
            }
            objTarget.closest('.slds-combobox').classList.toggle('slds-is-open')
        } else {
            objTarget.setAttribute("aria-expanded", true);
            objTarget.closest('.slds-combobox').classList.add('slds-is-open')
            if (objEvent.key === "ArrowDown") {
                objTarget.closest('.slds-combobox').querySelector("[role='option']").focus();
                return;
            }
        }

        //Fire Event for the platform ((()))

        const objResponse = {
            strIdDestination: 'LookAheadEvent',
            data: objTarget.value,
        }
        const objLookaheadEvent = new CustomEvent('lwcLookAheadEvent', { detail: JSON.stringify(objResponse) });
        window.dispatchEvent(objLookaheadEvent);

        const strValue = objTarget.value;
        const lstTotalData = JSON.parse(JSON.stringify(this.lstTotalDataset))
        const lstMatchedData = [];
        const objRegExp = new RegExp(strValue, 'ig');
        for (let i = 0; i < lstTotalData.length; i++) {
            if (lstTotalData[i].data.toLowerCase().includes(strValue.toLowerCase())) {
                const obj = lstTotalData[i];
                if (strValue !== '') {
                    obj.value = lstTotalData[i].data.replace(objRegExp, '<strong>$&</strong>')
                }
                lstMatchedData.push(obj);
            }
        }
        this.lstVisibleDataset = lstMatchedData;
        if(this.lstVisibleDataset && this.lstVisibleDataset.length === 0) {
            this.boolStrValue = true;
        } else {
            this.boolStrValue = false;
        }
        
    }
    isKeyDownTab(objEvent) {
        if (objEvent.key === "Tab") {
            objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
            objEvent.currentTarget.setAttribute("aria-expanded", false);
            //Fire Event
            const objResponse = {
                strIdDestination: 'LookAheadEvent',
                data: 'tab',
            }
            const objLookaheadEvent = new CustomEvent('lwcLookAheadEvent', { detail: JSON.stringify(objResponse) });
            window.dispatchEvent(objLookaheadEvent);
        } 
    }

    optionsKeyHandler(objEvent) {
        const objTarget = objEvent.currentTarget; 
        if (objEvent.key === "ArrowDown") {
            objTarget.nextSibling.querySelector("[role='option']").focus()
        } else if(objEvent.key === "ArrowUp") {
            objTarget.previousSibling.querySelector("[role='option']").focus()
        } 
    }

    optionSelectHandler(objEvent) {
        const value = objEvent.currentTarget.querySelector('.slds-listbox__option-text').getAttribute('data-value');
        this.strValue = value;
        //Fire Event;
        const objResponse = {
            strIdDestination: 'LookAheadEvent',
            data: value,
        }
        const objLookaheadEvent = new CustomEvent('lwcLookAheadEvent', { detail: JSON.stringify(objResponse) });
        window.dispatchEvent(objLookaheadEvent);

        objEvent.currentTarget.setAttribute("aria-expanded", false);
        objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
    }

    userFocusout(objEvent) {
        if (objEvent && objEvent.relatedTarget){
            if(objEvent.relatedTarget.closest(".slds-combobox") &&
            !objEvent.relatedTarget.closest(".slds-combobox").contains(objEvent.currentTarget)) {
                objEvent.currentTarget.setAttribute("aria-expanded", false);
                objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
            }else{
                //Do nothing
            }
        }else if(objEvent){
            objEvent.currentTarget.setAttribute("aria-expanded", false);
            objEvent.currentTarget.closest('.slds-combobox').classList.remove('slds-is-open');
        } else {
            
        }
    }
}