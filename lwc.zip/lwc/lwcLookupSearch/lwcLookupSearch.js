import { LightningElement, api, track } from 'lwc';

export default class LwcMultiLookup extends LightningElement {
    @api lookupLabel;
    @api placeHolder = 'Search.....';
    @api selectedRecordIds = [];
    @api addedRecordIds = [];
    @api removedRecordIds = [];

    @api maxErrorMessage;
    @api restrictSelection;
    @api restrictMessage;
    setRemovedElements = new Set();
    setAddedElements = new Set();
    loading = false;
    showFooter = false;
    //holds all records retrieving from database
    @track items = [];
    //holds only selected checkbox items that is being displayed based on search
    @track selectedItems = [];
    //holds only selected checkbox items that is being displayed based on search
    @track selectedItemsTempValues = [];
    //since values on checkbox deselection is difficult to track, so workaround to store previous values.
    //clicking on Done button, first previousSelectedItems items to be deleted and then selectedItems to be added into globalSelectedItems
    @track previousSelectedItems = [];
    //this holds checkbox values (Ids) which will be shown as selected
    @track value = [];
    @track globalSelectedItems = [];
    lstAllValues = [];
    //boolShowPills = false;
    @track picklistItems = [];
    boolAllRecordsCalled = false;
    //captures the text to be searched from user input
    searchInput = '';
    //based on this flag dialog box will be displayed with checkbox items
    showPicklist = false;
    //to show 'No records found' message
    hasNoRecord = false;
    showFieldSet = false;
    @track showError = false;
    @track lookupInitData = [];
    _max;
    preventClose = false;
    get boolShowPills() {
        return this.globalSelectedItems.length > 0;
    }
    handleBlur() {
        this.preventClose = false;
        this.showPicklist = false;
    }
    handleDivClick() {
        this.preventClose = true;
    }
    @api
    set max(value) {
        this._max = value;
    }
    get max() {
        return this._max;
    }
    @api
    set lookupData(value) {
        if (value) {
            this.formatData(value);
        }
    }
    get lookupData() {
        return this.lookupInitData;
    }


    get showErrorChild() {
        return this.showError;
    }
    @api
    set showErrorChild(value) {
        this.showError = value;
        if (this.template.querySelector('.slds-input')) {
            if (this.showError) {
                this.template.querySelector('.slds-input').parentElement.classList.add('slds-has-error');
            } else {
                this.template.querySelector('.slds-input').parentElement.classList.remove('slds-has-error');
            }
        }
    }

    get picklistItemsNew() {
        const result = this.picklistItems.filter((el) => el !== undefined);
        return result;
    }

    get globalSelectedItemsNew() {
        const result = this.globalSelectedItems.filter((el) => el !== undefined);
        return result;
    }

    formatData(data) {
        this.lookupInitData = data.map((el) => {
            return {
                label: el,
                value: el
            };
        });
        this.setOptions(this.lookupInitData);
    }

    // Create Options with main title, sub title and sub title 2
    setOptions(result) {
        try {
            result.map((resElement) => {
                // if Second field is required
                let title = resElement.recName;
                let id = resElement.recId;
                if (!title) {
                    title = resElement.label;
                    id = resElement.value;
                }
                let labelTitle = title;
                if (this.searchInput) {
                    const reg = new RegExp(this.searchInput, 'ig');
                    labelTitle = title.replace(reg, '<strong>$&</strong>');
                }
                //prepare items array using spread operator which will be used as checkbox options
                this.items.push({ value: id, label: title, dispLabel: labelTitle });
            });
            this.items = this.sortPicklist(this.items);
            this.picklistItems = this.items;
            if (!this.lstAllValues.length) {
                this.lstAllValues = this.picklistItems;
            }
            if (this.picklistItems.length > 0) {
                this.hasNoRecord = false;
                this.showFieldSet = true;
            } else {
                //display No records found message
                this.showFieldSet = false;
                this.hasNoRecord = true;
                this.loading = false;
            }
        } catch (err) {
            //do nothing
        }
    }
    timer;
    searchTextDebounce(event) {
        clearTimeout(this.timer);
        this.loading = true;
        this.showPicklist = false;
        this.searchInput = event.target.value;
        this.timer = setTimeout(() => {
            this, this.searchText();
        }, 200);
    }
    searchText() {
        let lstFilteredResult = this.lstAllValues.filter((val) => val.label.toLowerCase().includes(this.searchInput.toLowerCase()));
        //filter for selected items
        lstFilteredResult = lstFilteredResult.filter((val) => {
            let boolFound = true;
            for (let i = 0; i < this.globalSelectedItems.length; i++) {
                if (val.value === this.globalSelectedItems[i].value) {
                    boolFound = false;
                    break;
                }
            }
            return boolFound;
        });
        if (lstFilteredResult.length) {
            this.items = [];
            this.value = [];
            this.picklistItems = [];
            this.setOptions(lstFilteredResult);
            this.loading = false;
            this.showPicklist = true;
        } else {
            this.hasNoRecord = true;
        }
    }
    getAllRecords() {
        this.showPicklist = false;
        this.showPicklist = true;
    }

    setSelectedRecord(event) {
        try {
            this.preventClose = false;
            const recId = event.currentTarget.dataset.id;
            const selectName = event.currentTarget.dataset.name;
            let dispLabel = selectName;
            if (this.searchInput) {
                const reg = new RegExp(this.searchInput, 'ig');
                dispLabel = dispLabel.replace(reg, '<strong>$&</strong>');
            }
            const eventObj = {
                globalSelectedItems: this.globalSelectedItems,
                maxSelected: false
            };
            if (this.globalSelectedItems.length >= this.max) {
                this.showErrorChild = true;
                eventObj.maxSelected = true;
            } else {
                const newsObject = { value: recId, label: selectName, dispLabel: selectName };
                //pill_container
                this.globalSelectedItems.push(newsObject);
                eventObj.globalSelectedItems = this.globalSelectedItems;
                this.picklistItems = this.picklistItems.filter((el) => el.value !== recId);
            }
            const selectedEvent = new CustomEvent('selection', { detail: eventObj });
            // Dispatches the event
            this.dispatchEvent(selectedEvent);
            this.showPicklist = false;
            //this.boolShowPills = true;
            //event.preventDefault();
        } catch (_e) {
            //do nothing
        }
    }

    getAllRecords() {
        this.showPicklist = false;
        this.sortPicklist(this.globalSelectedItems);
        this.showPicklist = true;
    }

    //this method removes the pill item
    handleRemoveRecord(event) {
        this.showFooter = false;
        let removeItem = event.target.dataset.item;
        let removeItemLabel = event.target.label;
        if (!event.type) {
            removeItem = event.dataset.item;
            removeItemLabel = event.label;
        }

        this.removedElements += removeItem;
        this.removedElements += ',';

        const set1 = new Set();
        for (const item of this.setAddedElements) {
            if (item !== removeItem) {
                set1.add(item);
            }
        }
        this.setAddedElements = new Set();
        for (const item of set1) {
            this.setAddedElements.add(item);
        }

        this.setRemovedElements.add(removeItem);

        //this will prepare globalSelectedItems array excluding the item to be removed.
        this.globalSelectedItems = this.globalSelectedItems.filter((item) => item.value !== removeItem);
        this.globalSelectedItems.forEach((p) => {
            this.previousSelectedItems = this.previousSelectedItems.filter((item) => item.value !== p.value);
        });

        const eventObj = {
            globalSelectedItems: this.globalSelectedItems
        };

        const selectedEvent = new CustomEvent('selection', { detail: eventObj });
        // Dispatches the event
        this.dispatchEvent(selectedEvent);

        this.showPicklist = false;
        let displabel = removeItemLabel;
        if (this.searchInput) {
            const reg = new RegExp(this.searchInput, 'ig');
            displabel = displabel.replace(reg, '<strong>$&</strong>');
        }
        const lstPicklist = [...this.picklistItems, { value: removeItem, label: removeItemLabel, dispLabel: displabel }];

        this.picklistItems = [...this.sortPicklist(lstPicklist)];
        const arrItems = this.globalSelectedItems;

        this.selectedItems = arrItems;

        this.value = [];
        this.showError = false;
        this.template.querySelector('.slds-input').parentElement.classList.remove('slds-has-error');
    }

    hidePicklist(e) {
        if (!this.preventClose) {
            this.showPicklist = false;
            this.preventClose = false;
        }
    }

    sortPicklist(lstPicklistValue) {
        return lstPicklistValue.sort((a, b) => {
            const fa = a.label.toLowerCase();
            const fb = b.label.toLowerCase();
            if (fa < fb) {
                return -1;
            }
            if (fa > fb) {
                return 1;
            }
        });
    }

    @api
    resetList() {
        this.globalSelectedItems = [];
        this.showError = false;
        this.template.querySelector('.slds-input').parentElement.classList.remove('slds-has-error');
    }
}
