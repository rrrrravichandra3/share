import { LightningElement,api, track,wire} from 'lwc';
import getAccumulatorData from '@salesforce/apexContinuation/NewCaseCheckClass_ACE.getAccumulatorData';
import BaseLWC from 'c/baseLWCFunctions_CF';
//CEAS-83660
import NotepadTransmissionChannel_ACE from '@salesforce/messageChannel/NotepadTransmissionChannel__c';
import {
    MessageContext,
    publish,
} from 'lightning/messageService';


export default class LwcAccumulatorClaimDetails_ACE extends LightningElement {
    NotepadTransmissionChannel = NotepadTransmissionChannel_ACE;
    @wire(MessageContext)
    messageContext;
    @api strLOB;
    @api boolIsInternalInteraction;
    @api strAccountId;
    @api strInteractionLogId;
    @api sectionNumber;
    strNotepadNotes;
    @api 
    get boolHideAutoDoc() {
        return this.boolAutoDoc;
    }

    set boolHideAutoDoc(value) {
        this.boolAutoDoc = value;
    }
    @api strInteractionId;
    @api strClaimDetails;
    @api corpCode;
    boolShowSpinner = false;
    strRequestBody = '';
    columnsGMS = [
        { label: 'Accumulation Type', fieldName: 'AccumType', sortable: false, type: '' },
        { label: 'Applied to Subscript', fieldName: 'AppliedToSubscript', type: '' },
        { label: 'Cost Containment Indicator', fieldName: 'CostContainmentIndicator', type: 'date' },
        { label: 'Internal Descriptor', fieldName: 'InternalDescriptor', sortable: false, type: ''},
        { label: 'Treatment Group', fieldName: 'TreatmentGroup', sortable: false, type: ''},
        { label: 'Limit', fieldName: 'AccumLimit', sortable: false, type: ''},
        { label: 'Total Used', fieldName: 'AmountUsed', sortable: false, type: ''},
        { label: 'Remaining', fieldName: 'AmountRemaining', sortable: false, type: ''},
        { label: 'Amount Applied', fieldName: 'AmountApplied', sortable: false, type: ''},
        { label: 'Value Qualifier', fieldName: 'ValueQualifier', sortable: false, type: ''},
        { label: 'Percentage Level', fieldName: 'PercentageLevel', sortable: false, type: ''},
        { label: 'Carry Over Credit', fieldName: 'CarryOverCreditIndicator', sortable: false, type: ''},
        { label: '', fieldName: 'rowIndex', sortable: false, type: '', boolHidden:true },
        { label: '', fieldName: 'isIconDisabled', sortable: false, type: '', boolHidden:true }
    ];

    columnsRetail = [
        { label: 'Assembly Name', fieldName: 'AssemblyName', sortable: false, type: '' },
        { label: 'Applied to Subscript', fieldName: 'AppliedToSubscript', type: '' },
        { label: 'Limit', fieldName: 'AccumLimit', type: 'date' },
        { label: 'Total Used', fieldName: 'AmountUsed', sortable: false, type: ''},
        { label: 'Remaining', fieldName: 'AmountRemaining', sortable: false, type: ''},
        { label: 'Amount Applied', fieldName: 'AmountApplied', sortable: false, type: ''},
        { label: 'Value Qualifier', fieldName: 'ValueQualifier', sortable: false, type: ''},
        { label: 'Percentage Level', fieldName: 'PercentageLevel', sortable: false, type: ''},
        { label: 'Carry Over Credit', fieldName: 'CarryOverCreditIndicator', sortable: false, type: ''},
        { label: '', fieldName: 'rowIndex', sortable: false, type: '', boolHidden:true },
        { label: '', fieldName: 'isIconDisabled', sortable: false, type: '', boolHidden:true }
    ];

    @track
    benefitAccumlatorSetting = {
        pageSize: 25,
        restrictedPageSize:5,
        boolViewMore: true,
        boolShowSearch: false,
        boolShowIcon: true,
        iconNameToShow: 'utility:note',
        boolHeaderNoCapital: true
    };

    mapBenefitTypevsData = {};
    @track lstRenderingData;

    connectedCallback() {
        //Call API
        this.setColums();
        this.constructRequestBody();
        this.fetchAccumulatorData();
    }
    setColums() {
        if(this.strLOB && this.strLOB.toUpperCase() === 'GMS') {
            this.benefitAccumlatorSetting.columnsData = this.columnsGMS;
        } else if(this.strLOB && this.strLOB.toUpperCase() === 'RETAIL') {
            this.benefitAccumlatorSetting.columnsData = this.columnsRetail;
        }
    }
    constructRequestBody(objClaimData) {
        const objRequest = {};
        if(this.strClaimDetails) {
            let strAdjustment = this.strClaimDetails.strAdjustmentNumber;
            if(typeof strAdjustment === 'string' && strAdjustment.length <= 1) {
                strAdjustment = '0' + strAdjustment;
            }
            this.boolShowSpinner = true;
            objRequest['DCN'] = this.strClaimDetails.strDcnNumber;
            objRequest['RCN'] = this.strClaimDetails.recordControlNumbers;
            objRequest['corporateEntityCode'] = this.corpCode;
            objRequest['adjustmentSuffix'] = strAdjustment;
            objRequest['billingBeginningDate'] = this.convertDateFormat(this.strClaimDetails.strServiceFrom);
            objRequest['billingEndDate'] = this.convertDateFormat(this.strClaimDetails.strServiceTo);
            objRequest['groupNumber'] = this.strClaimDetails.strGroupNumber;
            objRequest['sectionNumber'] = this.sectionNumber;
        }
        this.strRequestBody = JSON.stringify(objRequest);

    }
    convertDateFormat(strDate) {
        if(strDate && typeof strDate === 'string') {
            let lstDate = strDate.split('/');
            return lstDate[2] + '-' + lstDate[0] + '-' + lstDate[1];
        }
        return null;
    }
    fetchAccumulatorData() {
        //Calling Apex
        getAccumulatorData({
            strRequestBody: this.strRequestBody
        }).then(objResult => {
            this.boolShowSpinner = false;
            this.processAPIData(objResult);
        }).catch(error => {
            this.boolShowSpinner = false;
        });
        //Parsing Response
    }
    replaceNulls(objOrignalValue) {
        let objValue = objOrignalValue;
        Object.keys(objValue).forEach(function(key) {
            if(objValue[key]) {
                //Do Nothing
            } else {
                objValue[key] = '-';
            }
        })
        return objValue;
    }
    processAPIData(strResponse) {
        if(strResponse) {
            const objResponse = JSON.parse(strResponse);
            if(objResponse && objResponse.accumDetails) {
                let mapBenefitTypevsData = {};
                objResponse.accumDetails.forEach((objIteration) => {
                    let lstValues = [];
                    let mapFamilyorIndividual = {};
                    lstValues.push(this.replaceNulls(objIteration));
                    if(mapBenefitTypevsData && mapBenefitTypevsData[objIteration.BenefitPeriodType]) {
                        //if map already has value then concat
                        if(mapBenefitTypevsData[objIteration.BenefitPeriodType] && mapBenefitTypevsData[objIteration.BenefitPeriodType][objIteration.FamilyorIndividualIndicator]) {
                            mapBenefitTypevsData[objIteration.BenefitPeriodType][objIteration.FamilyorIndividualIndicator] = mapBenefitTypevsData[objIteration.BenefitPeriodType][objIteration.FamilyorIndividualIndicator].concat(lstValues);
                        } else {
                            mapBenefitTypevsData[objIteration.BenefitPeriodType][objIteration.FamilyorIndividualIndicator] = lstValues;
                        }
                    } else {
                        mapFamilyorIndividual[objIteration.FamilyorIndividualIndicator] = lstValues;
                        mapBenefitTypevsData[objIteration.BenefitPeriodType] = mapFamilyorIndividual;
                    }
                });
                this.mapBenefitTypevsData = mapBenefitTypevsData;
            }
            this.processAPItoUIdata();
        }
    }
    processAPItoUIdata() {
            let lstKeys = Object.keys(this.mapBenefitTypevsData);
            let lstDates = [];
            let mapBenefitTypevsData = this.mapBenefitTypevsData;
            if(lstKeys && lstKeys.length) {
                let intIndex = 0;
                lstKeys.forEach((objIteration) => {
                    if(objIteration && mapBenefitTypevsData[objIteration]) {
                        let mapDates = {};
                        let strFormattedDate = '';
                        let strUnformattedDate = '';
                        strUnformattedDate = mapBenefitTypevsData[objIteration][Object.keys(mapBenefitTypevsData[objIteration])[0]][0].BenefitPeriodBeginningDate;
                        if(strUnformattedDate && strUnformattedDate.split('-') && strUnformattedDate.split('-').length > 2) {
                            strFormattedDate = strUnformattedDate.split('-')[1] + '/' + strUnformattedDate.split('-')[2] + '/' + strUnformattedDate.split('-')[0];
                        }
                        mapDates['BenefitPeriodBeginningDate'] = strFormattedDate;
                        strUnformattedDate = mapBenefitTypevsData[objIteration][Object.keys(mapBenefitTypevsData[objIteration])[0]][0].BenefitPeriodEndingDate;
                        if(strUnformattedDate && strUnformattedDate.split('-') && strUnformattedDate.split('-').length > 2) {
                            strFormattedDate = strUnformattedDate.split('-')[1] + '/' + strUnformattedDate.split('-')[2] + '/' + strUnformattedDate.split('-')[0];
                        }
                        mapDates['BenefitPeriodEndingDate'] = strFormattedDate;
                        mapDates['BenefitPeriodType'] = objIteration;
    
                        let innerKey = Object.keys(mapBenefitTypevsData[objIteration]);
                        innerKey.forEach((objInnerIteration) => {
                            let lstTableData = [];
                            let mapInnerData = {};
                            if(mapBenefitTypevsData[objIteration][objInnerIteration]) {
                                mapInnerData['relationIndicator'] = objInnerIteration;
                                mapInnerData['tableData'] = mapBenefitTypevsData[objIteration][objInnerIteration];
                                mapInnerData['tableData'].map((objElement) => {
                                    objElement['rowIndex'] = intIndex;
                                    intIndex++;
                                });
                            }
                            lstTableData.push(mapInnerData);
                            if(mapDates['lstTableData']) {
                                lstTableData = mapDates['lstTableData'].concat(lstTableData);
                            }
                            
                            mapDates['lstTableData'] = lstTableData;
                        });
                        lstDates.push(mapDates);
                    }
                });
            }
            this.lstRenderingData =  lstDates;
    }
    handleAutoDocRowAction(objEvent){
        let strNotepadNotes = '';
        let renderedRowData = {},
            dataIndex = '';
        if(objEvent.detail) {
            const objEventData = JSON.parse(objEvent.detail);
            if(objEventData && objEventData.renderedRowData) {
                renderedRowData = objEventData.renderedRowData;
            }
        }
        let checkData = {};
        if(this.strLOB && this.strLOB.toUpperCase() === 'RETAIL') {
            JSON.parse(renderedRowData).forEach(objData => {
                if (objData.key === 'AssemblyName') {
                    checkData.AssemblyName = this.checkNullValue(objData.value);
                } else if (objData.key === 'AppliedToSubscript') {
                    checkData.AppliedToSubscript = this.checkNullValue(objData.value);
                } else if (objData.key === 'AccumLimit') {
                    checkData.Limit = this.checkNullValue(objData.value);
                } else if (objData.key === 'AmountUsed') {
                    checkData.TotalUsed = this.checkNullValue(objData.value);
                } else if (objData.key === 'AmountRemaining') {
                    checkData.AmountRemaining = this.checkNullValue(objData.value);
                } else if (objData.key === 'AmountApplied') {
                    checkData.AmountApplied = this.checkNullValue(objData.value);
                }else if (objData.key === 'ValueQualifier') {
                    checkData.ValueQualifier = this.checkNullValue(objData.value);
                }else if (objData.key === 'PercentageLevel') {
                    checkData.PercentageLevel = this.checkNullValue(objData.value);
                }else if (objData.key === 'CarryOverCreditIndicator') {
                    checkData.CarryOverCredit = this.checkNullValue(objData.value);
                } else if(objData.key === 'rowIndex') {
                    dataIndex = Number(objData.value);
                } else {
                    //do nothing
                }
            });
        } else if(this.strLOB && this.strLOB.toUpperCase() === 'GMS') {
            JSON.parse(renderedRowData).forEach(objData => {
                if (objData.key === 'AccumType') {
                    checkData.AccumulationType = this.checkNullValue(objData.value);
                } else if (objData.key === 'CostContainmentIndicator') {
                    checkData.CostContainmentIndicator = this.checkNullValue(objData.value);
                } else if (objData.key === 'TreatmentGroup') {
                    checkData.TreatmentGroup = this.checkNullValue(objData.value);
                } else if (objData.key === 'InternalDescriptor') {
                    checkData.InternalDescriptor = this.checkNullValue(objData.value);
                } else if (objData.key === 'CostContainmentIndicator') {
                    checkData.CostContainmentIndicator = this.checkNullValue(objData.value);
                } else if (objData.key === 'AppliedToSubscript') {
                    checkData.AppliedToSubscript = this.checkNullValue(objData.value);
                } else if (objData.key === 'AmountUsed') {
                    checkData.TotalUsed = this.checkNullValue(objData.value);
                } else if (objData.key === 'AccumLimit') {
                    checkData.Limit = this.checkNullValue(objData.value);
                } else if (objData.key === 'AmountRemaining') {
                    checkData.AmountRemaining = this.checkNullValue(objData.value);
                }else if (objData.key === 'AmountApplied') {
                    checkData.AmountApplied = this.checkNullValue(objData.value);
                }else if (objData.key === 'ValueQualifier') {
                    checkData.ValueQualifier = this.checkNullValue(objData.value);
                }else if (objData.key === 'PercentageLevel') {
                    checkData.PercentageLevel = this.checkNullValue(objData.value);
                }else if (objData.key === 'CarryOverCreditIndicator') {
                    checkData.CarryOverCredit = this.checkNullValue(objData.value);
                } else if(objData.key === 'rowIndex') {
                    dataIndex = Number(objData.value);
                } else {
                    //do nothing
                }
            });
        } else {
            //Do nothing
        }
        let strBenefitType = '';
        let strBenefitRelation = '';
        if (this.lstRenderingData && this.lstRenderingData.length) {
            this.lstRenderingData.forEach((outerElement, outerIndex) => {
                if(outerElement && outerElement.lstTableData) {
                    outerElement.lstTableData.forEach((outerTableElement,outerTableIndex) => {
                        if(outerTableElement && outerTableElement.tableData) {
                            outerTableElement.tableData.forEach((innerTableElement,innerTableIndex) => {
                                if(innerTableElement.rowIndex === dataIndex) {
                                    innerTableElement.isIconDisabled = false;
                                    strBenefitType = outerElement.BenefitPeriodType;
                                    strBenefitRelation = outerTableElement.relationIndicator;
                                }
                            });
                        }
                    });
                }
            })
            this.lstRenderingData = JSON.parse(JSON.stringify(this.lstRenderingData));
        }
        const lstValuesData = [], TotalPattern = [], lstSectionsData = [];
        const objPattern = {
            strInteractionLogId: this.strInteractionLogId
        };
        const strAccumAutoDocHead = ' Benefit Type - ' + ' ' + strBenefitType + ' - Benefit Relation ' + strBenefitRelation;
        const strCheckNumberSequence = 'Accum' + ' ' + (dataIndex + 1);
        const lstCheckNumberData = ['CLAIMS ACCUMULATOR', strAccumAutoDocHead, strCheckNumberSequence];
        let lstKeysOfObj = [];
        if(this.strLOB && this.strLOB.toUpperCase() === 'RETAIL') {
            lstKeysOfObj = ['AssemblyName','AppliedToSubscript','Limit','TotalUsed','AmountRemaining','AmountApplied','ValueQualifier','PercentageLevel','CarryOverCredit'];
        } else if(this.strLOB && this.strLOB.toUpperCase() === 'GMS') {
            lstKeysOfObj = ['AccumulationType','AppliedToSubscript','CostContainmentIndicator','InternalDescriptor','TreatmentGroup','Limit','TotalUsed','AmountRemaining','AmountApplied','ValueQualifier','PercentageLevel','CarryOverCredit'];
        }  else {
            //Do Nothing
        }
 
        for (let i = 0; i < lstCheckNumberData.length; i++) {
            strNotepadNotes += lstCheckNumberData[i].toUpperCase() + '\n\n';
            const subPatternForLstSections = {
                "strLabel": lstCheckNumberData[i].toUpperCase()
            };

            if (i === 0) {
                subPatternForLstSections.strIcon = 'add_contact';
                subPatternForLstSections.strIconFamily = 'action';
                subPatternForLstSections.strIconColor = '#5876a3';
            } else {
                subPatternForLstSections.strIcon = '';
                subPatternForLstSections.strIconFamily = '';
                subPatternForLstSections.strIconColor = '';
            }
            lstSectionsData.push(subPatternForLstSections);
        }
        objPattern.lstSections = lstSectionsData;

        lstKeysOfObj.forEach(function(strKey) {
            const objFieldData = {};
            objFieldData["strFieldLabel"] = ((strKey).replace(/([a-z])([A-Z])/g, '$1 $2')).toUpperCase();
            objFieldData["strFieldValue"] = checkData[strKey];
            lstValuesData.push(objFieldData);
            strNotepadNotes +=objFieldData["strFieldLabel"] + '\t\t' + objFieldData["strFieldValue"] + '\n';
        });
        this.strNotepadNotes = strNotepadNotes;
        objPattern.lstValues = lstValuesData;
        TotalPattern.push(objPattern);
        this.publishToNotepad();
        this.postMessageToAutoDoc(TotalPattern);
    }
    //CEAS-83660
    publishToNotepad() {
        const message = {
            method: 'POST',
            reqSource: "lwcNotepadAce",
            boolIsFromAutdoc : true,
            notes : this.strNotepadNotes.trim()
        };
        publish(this.messageContext, this.NotepadTransmissionChannel, message);
    }

    checkNullValue(objData){
        if(objData){
            return objData;
        }
        return '';

    }

    //CEAS-77151
    postMessageToAutoDoc( TotalPattern) {
        if (this.strInteractionLogId && !this.boolHideAutoDoc) {
            const objIframe = document.createElement("iframe");
            const strInteractionLogId = this.strInteractionLogId;
            const boolIsInternalInteraction = this.boolIsInternalInteraction;
            const strAccountId = this.strAccountId;
            objIframe.src = "/apex/ClaimsSetlocalstoragePage_ACE";
            objIframe.style.display = "none";
            document.body.appendChild(objIframe);
            objIframe.onload = function() {
                objIframe.contentWindow.postMessage({
                    key: 'strAutodoc',
                    value: JSON.stringify(TotalPattern),
                    boolIsClaimsAutoDoc: true
                }, '*');
                if (strInteractionLogId) {
                    objIframe.contentWindow.postMessage({
                        key: 'strKeepAutodocActive',
                        value: 'true',
                        boolIsClaimsAutoDoc: true
                    }, '*');
                }
            }
        }
    }
}
